<?php
if(!defined('sugarEntry'))define('sugarEntry', true);

/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/
/*
* Author: Ashok Kumar Gupta
* Date Created: 06-10-2016
* Project : Create Case
* Description: show dynamic and dependent drop down for category and subcategory
* Last Modified: 19-10-2016
*/
ini_set("display_errors",0);
global $current_user,$app_list_strings;
$myUser = new User();

    //For Case History
    if(!empty($_GET['loyalty_id_c']) && $_GET['loyalty_id_c']  !='Guest' && $_GET['guest'] =='no'){
        $loyalty_id = $_GET['loyalty_id_c'];	
       
        
            $query_caseHist = "SELECT cases.case_number, cases_cstm.customer_name_c, cases.id, cases_cstm.origin_c,"
                        . " cases.priority, cases.status, cases.assigned_user_id, cases.date_entered, cases_cstm.member_tier_c  "
                        . " FROM cases JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " WHERE cases.deleted =0 AND cases_cstm.loyalty_id_c = '".$loyalty_id."' limit 5 ";

            $result = $GLOBALS['db']->query($query_caseHist);
            $count = $result->num_rows;
            $field_query_caseHist ='';
             if($count > 0){ 

                $field_query_caseHist .= '<style>.case-history-layout{width:100%;}#case_history{border-collapse:collapse;}#case_history,#case_history td, #case_history th{border: 1px solid black;}#case_history th{background-color:#FDE848;}</style><tr id="global_id"><td class="case-history-layout"><table width="100%" id="case_history" border="1">';
                $field_query_caseHist .= '<tr><th>Case ID</th><th>Customer Name</th><th>Origin</th><th>Priority</th><th>Status</th>';
                $field_query_caseHist .= '<th>Agent ID</th><th>Created On</th><th>Member Tier</th></tr>';

                while($row = $GLOBALS['db']->fetchByAssoc($result)){

                        $originname = $app_list_strings['origin_list'][$row['origin_c']];$priorityname = $app_list_strings['case_priority_dom'][$row['priority']];
                        $userid = $row['assigned_user_id'];
                        $myUser->retrieve($userid);
                        $assignedName = $myUser->full_name;
                        $caseID =$row['id'];
                        $caseNum =$row['case_number'];

                        $link ='<a href="index.php?module=Cases&return_module=Cases&action=DetailView&record='.$caseID.'">'.$caseNum.'</a>';

                        $field_query_caseHist .= '<tr>';

                         $field_query_caseHist .= '<td align="center"><div>'.$link.'</div></td>';
                         $field_query_caseHist .= '<td align="center"><div>'.$row['customer_name_c'].'</div></td>';
                         $field_query_caseHist .= '<td align="center"><div>'.$originname.'</div></td>';
                         $field_query_caseHist .= '<td align="center"><div>'.$priorityname.'</div></td>';
                         $field_query_caseHist .= '<td align="center"><div>'.$row['status'].'</div></td>';
                         $field_query_caseHist .= '<td align="center"><div>'.$assignedName.'</div></td>';
                         $field_query_caseHist .= '<td align="center"><div>'.$row['date_entered'].'</div></td>';
                         $field_query_caseHist .= '<td align="center"><div>'.$row['member_tier_c'].'</div></td>';

                        $field_query_caseHist .= '</tr>';

                }

                $field_query_caseHist .= '</td></table></tr><br />';
            }else{
                  $field_query_caseHist = '<tr><div>NO RECORD FOUND</div></tr>';
            }
            echo  $field_query_caseHist;
        } 
        if(!empty($_GET['mobile_number'])){
        
            $mobNum = $_GET['mobile_number'];
            $query_caseHist = "SELECT cases.case_number, cases_cstm.customer_name_c, cases_cstm.mobile_number_c, cases.id, cases_cstm.origin_c,"
                    . " cases.priority, cases.status, cases.assigned_user_id, cases.date_entered, cases_cstm.member_tier_c  "
                    . " FROM cases JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                    . " WHERE cases.deleted =0 AND cases_cstm.mobile_number_c = '".$mobNum."'  AND cases_cstm.loyalty_id_c = 'Guest' limit 5 ";

                $result = $GLOBALS['db']->query($query_caseHist);
                $count = $result->num_rows;
                $field_query_caseHistGuest =''; 
                if($count > 0){ 
                    $field_query_caseHistGuest .= '<style>.case-history-layout{width:100%;}#case_history{border-collapse:collapse;}#case_history,#case_history td, #case_history th{border: 1px solid black;}#case_history th{background-color:#FDE848;}</style><tr id="global_id"><td class="case-history-layout"><table width="100%" id="case_history" border="1">';
                    $field_query_caseHistGuest .= '<tr><th>Case ID</th><th>Customer Name</th><th>Mobile Number</th><th>Origin</th><th>Priority</th><th>Status</th>';
                    $field_query_caseHistGuest .= '<th>Agent ID</th><th>Created On</th><th>Member Tier</th></tr>';

                    while($row = $GLOBALS['db']->fetchByAssoc($result)){

                            $originname = $app_list_strings['origin_list'][$row['origin_c']];$priorityname = $app_list_strings['case_priority_dom'][$row['priority']];
                            $userid = $row['assigned_user_id'];
                            $myUser->retrieve($userid);
                            $assignedName = $myUser->full_name;
                            $caseID =$row['id'];
                            $caseNum =$row['case_number'];

                            $link ='<a href="index.php?module=Cases&return_module=Cases&action=DetailView&record='.$caseID.'">'.$caseNum.'</a>';

                            $field_query_caseHistGuest .= '<tr>';

                             $field_query_caseHistGuest .= '<td align="center"><div>'.$link.'</div></td>';
                             $field_query_caseHistGuest .= '<td align="center"><div>'.$row['customer_name_c'].'</div></td>';
                             $field_query_caseHistGuest .= '<td align="center"><div>'.$row['mobile_number_c'].'</div></td>';
                             $field_query_caseHistGuest .= '<td align="center"><div>'.$originname.'</div></td>';
                             $field_query_caseHistGuest .= '<td align="center"><div>'.$priorityname.'</div></td>';
                             $field_query_caseHistGuest .= '<td align="center"><div>'.$row['status'].'</div></td>';
                             $field_query_caseHistGuest .= '<td align="center"><div>'.$assignedName.'</div></td>';
                             $field_query_caseHistGuest .= '<td align="center"><div>'.$row['date_entered'].'</div></td>';
                             $field_query_caseHistGuest .= '<td align="center"><div>'.$row['member_tier_c'].'</div></td>';

                            $field_query_caseHistGuest .= '</tr>';

                    }

                    $field_query_caseHistGuest .= '</td></table></tr><br />';
                }else{
                    $field_query_caseHistGuest .= '<tr><div>NEW GUEST</div></tr>';
                }
                echo  $field_query_caseHistGuest;
        }
   
   
	
?>
