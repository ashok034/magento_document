<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

// Include the main TCPDF library (search for installation path).
//require_once('include/TCPDF_master/examples/tcpdf_include.php');
require_once('include/entryPoint.php');
require_once('include/TCPDF_master/tcpdf.php');

// extend TCPF with custom functions
class MYPDF extends TCPDF {

        
        //Page header
	/*public function Header() {
		// Logo
		$image_file = K_PATH_IMAGES.'logo_example.jpg';
		$this->Image($image_file, 120, 10, 15, '', 'JPG', '', 'T', false, 300, '', false, false, 0, false, false, false);
		                // add a page
              $this->SetFont('helvetica', 'B', 20);
		// Title
		//$this->Cell(0, 15, '<< TCPDF Example 003 >>', 0, false, 'C', 0, '', 0, false, 'M', 'M');
	}*/
        
}
$recordid = isset($this->bean->id) ? $this->bean->id :'' ;

/*$sqlRel  = "SELECT count(id) as total FROM `cases_cases_1_c` WHERE deleted=0 limit 1";
$result = $GLOBALS['db']->query($sqlRel, false);
 $row = $GLOBALS['db']->fetchByAssoc($result);
  $total = $row['total'];  
   */     
// create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Nakumatt');
$pdf->SetTitle('Customer Acknowledgement');
$pdf->SetSubject('Customer Acknowledgement');



    $pdf->AddPage();

    
    $supplier_name = $this->bean->prod_supplier_name;
    $delivery_note_no = $this->bean->repair_delivery_note_no;
    $repair_tag_no = $this->bean->repair_tag_no;
    $repair_serial_no = $this->bean->repair_serial_no;
    $repair_model_no = $this->bean->repair_model_no;
    $repair_nature_of_fault = $this->bean->repair_nature_of_fault;
    $mobile_number_c = $this->bean->mobile_number_c;
    $customer_name_c = $this->bean->customer_name_c;
    $product_value = $this->bean->product_value;
    $quality_description = $this->bean->quality_description;
    $purchase_date = $this->bean->purchase_date;
    $expiry_date = $this->bean->expiry_date;
    
    $case_number = $this->bean->case_number;
    $date_of_collection_repair = $this->bean->date_of_collection_repair;   
    $customer_description = $this->bean->customer_description;
    $billAmount = $this->bean->bill_amount;
	
	//product detail
	$prod_sku = $this->bean->prod_sku;
	$date_sent_to_supplier = $this->bean->date_sent_to_supplier;
    $supplier_comments_repair = $this->bean->supplier_comments_repair;
	$customer_approval_date = $this->bean->customer_approval_date;
	
	$receipt_no = $this->bean->receipt_no;
	$date_of_faxed_email = $this->bean->date_of_faxed_email;
	$repair_date_to_supplier = $this->bean->repair_date_to_supplier;
	$suppliers_delivery_note_no = $this->bean->suppliers_delivery_note_no;
	
    // create some HTML content
    $html ='';$html_lbl ='';
    
    $html .= '<hr>
<table width="100%" border="0" id="cst_ack" style="font-size: small">
  <tr>
    <td width="63%" valign="top"><br><img src="custom/modules/Cases/images/nakumatt2.jpg" border="0" width="200" /></td>
    <td width="37%" style="text-align: left;">NAKUMATT HOLDINGS LIMITED<br />
      Head Office Road C,Off Enterpise Road,<br />
      P.O.Box 78355-00507, Nairobi, Kenya<br />
      Tel: +254 20 650 137/8/9,<br />
      +254 733 632 130,+254 722 204 931<br />
      Fax: +254 20 650150<br />
      Email:nakumatt@nakumatt.net
	</td>
  </tr>
</table><h2 style="text-align: center">Customer Acknowledgement</h2>
<hr>
<table width="100%" border="0" style="font-size:small" cellpadding="5">
  <tr>
    <td width="23%" ><strong>Customer Name:</strong></td>
    <td width="34%">'.$customer_name_c.'</td>
    <td width="15%"><strong>Date:</strong></td>
    <td width="28%">'.date("d/m/Y").'</td>
  </tr>
  <tr>
    <td><strong>Telephone Number:</strong></td>
    <td>'.$mobile_number_c.'</td>
    <td><strong>Product Code:</strong></td>
    <td>'.$prod_sku.'</td>
  </tr>
  <tr>
    <td><strong>Product Description:</strong></td>
	 <td colspan="3">'.$quality_description.'</td>
  </tr>
  <tr>
    <td><strong>Serial No.:</strong></td>
    <td>'.$repair_serial_no.'</td>
    <td><strong>Model No.:</strong></td>
    <td>'.$repair_model_no.'</td>
  </tr>
  <tr>
    <td><strong>Supplier Name:</strong></td>
    <td>'.$supplier_name.'</td>
    <td><strong>Tag No.:</strong></td>
    <td>'.$repair_tag_no.'</td>
  </tr>
  <tr>
    <td><strong>Nature of Fault/Damage:</strong></td>
	 <td colspan="3" ><br><br>'.$repair_nature_of_fault.'</td>

  </tr>
</table>
<hr>
<table width="100%" border="0" style="font-size: small" cellpadding="5">
  <tr>
    <td width="23%"><strong>Date to Supplier:</strong></td>
    <td width="34%">'.$date_sent_to_supplier.'</td>
    <td width="15%"><strong>Delivery Note:</strong></td>
    <td width="28%">'.$delivery_note_no.'</td>
  </tr>
  <tr>
    <td><strong>Supplier Comments:</strong></td>
	<td colspan="3">'.$supplier_comments_repair.'</td>
  </tr>
  <tr>
    <td><strong>Customer Approval Date:</strong></td>
    <td>'.$customer_approval_date.'</td>
    <td><strong>Bill Amount:</strong></td>
    <td>'.$billAmount.'</td>
  </tr>
  <tr>
    <td><strong>Receipt No.:</strong></td>
    <td>'.$receipt_no.'</td>
    <td><strong>Date:</strong></td>
    <td>'.$repair_date_to_supplier.'</td>
  </tr>
  <tr>
    <td><strong>Date faxed to Supplier/E-mail:</strong></td>
    <td><br><br>'.$date_of_faxed_email.'</td>
   <td><strong>Supplier Delivery Note:</strong></td>
    <td><br><br>'.$suppliers_delivery_note_no.'</td>
  </tr>
 
</table>
<br>
<table width="100%" border="0" style="font-size: small" cellpadding="5">
  <tr>
    <td width="13%"><strong>Comments:</strong></td>
    <td width="87%" style="border-bottom:1px dotted black;">&nbsp;</td>
  </tr>
 
</table>
<br><br>
<table width="100%" border="0" style="font-size: small" cellpadding="5">
  <tr>
    <td width="23%"><strong>Date of Collection:</strong></td>
    <td width="34%">'.$date_of_collection_repair.'</td>
    <td width="15%"><strong>Customer Signature:</strong></td>
    <td width="28%" style="border-bottom:1px dotted black;">&nbsp;</td>
  </tr>
</table><br>
<hr>
<table width="100%" border="0" style="font-size: small" cellpadding="5">
<tr><td colspan="6"></td></tr>
  <tr>
    <td width="25%"><strong>Branch Manager Name:</strong></td>
    <td width="20%" style="border-bottom:1px dotted black;">&nbsp;</td>
    <td width="10%"><strong>P/R No.:</strong></td>
    <td width="15%" style="border-bottom:1px dotted black;">&nbsp;</td>
    <td width="15%"><strong>Signature:</strong></td>
    <td width="15%" style="border-bottom:1px dotted black;">&nbsp;</td>
  </tr><tr><td colspan="6"></td></tr>
  <tr>
    <td><strong>Verified in fully by:</strong></td>
    <td style="border-bottom:1px dotted black;">&nbsp;</td>
    <td><strong>P/R No.:</strong></td>
    <td style="border-bottom:1px dotted black;">&nbsp;</td>
    <td><strong>Signature:</strong></td>
    <td style="border-bottom:1px dotted black;">&nbsp;</td>
  </tr><tr><td colspan="6"></td></tr>
  <tr>
    <td><strong>Released by:</strong></td>
    <td style="border-bottom:1px dotted black;">&nbsp;</td>
    <td><strong>P/R No.:</strong></td>
    <td style="border-bottom:1px dotted black;">&nbsp;</td>
    <td><strong>Signature:</strong></td>
    <td style="border-bottom:1px dotted black;">&nbsp;</td>
  </tr>
</table>
<br />
<hr>
<p></p>
<p></p><p></p>
<table width="100%" border="0">
  <tr>
    <td width="21%" style="text-align: center; border-top:1px dotted black;vertical-align:bottom;"><strong>Branch Stamp</strong></td>
    <td width="79%" align="right"><img src="custom/modules/Cases/images/nakumatt2.jpg" border="0" width="100" /></td>
  </tr>
</table>



';  
   
   
   
    
  //  $html .= '<br /><br /><br /><br /><td align="right"><img src="custom/modules/Cases/images/nakumatt2.jpg" height="41" width="100"  /></td>';
    // output the HTML content
    $pdf->writeHTML($html, true, 0, true,0);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
//$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
//$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
//$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}



// ---------------------------------------------------------


// set font
$pdf->SetFont('helvetica', '', 9);

// add a page
//$pdf->AddPage();


// reset pointer to the last page
$pdf->lastPage();


// ---------------------------------------------------------
ob_start();
// close and output PDF document
$pdf->Output('Customer_Ack_Form_'.$case_number.'.pdf', 'I');//D

ob_end_flush();


//============================================================+
// END OF FILE
//============================================================+
