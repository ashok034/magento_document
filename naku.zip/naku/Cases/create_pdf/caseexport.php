<?php

require_once 'include/dompdf/dompdf_config.inc.php';
global $current_user;
$name = $current_user->first_name . '&nbsp;' . $current_user->last_name;
$current_date = date('d/m/Y  h:i A');
$dompdf = new Dompdf();
$content = '';
$header = '<html>
            <body>
                <div style="width:100%;color:#fff;background:#17479d;padding:5px 0px;margin:0px;text-align:center;">
                    <img src="custom/include/images/logo.png" style="padding: 7px;position: absolute;left: 10px;"><h2>Customer Service List</h2>
                </div>';
$content .= '   <table border="1" cellspacing="0" cellpadding="5" width="100%">  
                    <thead>
                        <tr>
                            <th nowrap>Loyalty ID</th>
                            <th nowrap>Mobile</th>
                            <th nowrap>Case ID</th>
                            <th nowrap>Case Title</th> 
                            <th nowrap>Category</th>  
                            <th nowrap>Origin</th>  
                            <th nowrap>Priority</th>  
                            <th nowrap>Status</th>
                            <th nowrap>Assigned To</th>
                            <th nowrap>Created On</th>
                        </tr>
                </thead>';
//Fetch data
$caseIDs = implode("','", $_POST['chk']);
$condition = " cases.id IN ('" . $caseIDs . "')";
$default_query_case = "SELECT cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c,cases.case_number,cases.name,cases_cstm.category_c,cases_cstm.origin_c,cases.priority,cases.status, LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, cases.date_entered FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 "
        . " where " . $condition . " AND cases.deleted=0 ORDER BY cases.date_entered DESC";
$result = $db->query($default_query_case);
while ($row = $db->fetchByAssoc($result)) {
    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
    $content .= '<tbody>
                        <tr>
                          <td>' . $row["loyalty_id_c"] . '</td>
                          <td>' . $row["mobile_number_c"] . '</td>
                          <td>' . $row["case_number"] . '</td>
                          <td>' . $row["name"] . '</td>
                          <td>' . $row["category_c"] . '</td>
                          <td>' . $row["origin_c"] . '</td>
                          <td>' . $row["priority"] . '</td>
                          <td>' . $row["status"] . '</td>
                          <td>' . $row["created_by_name"] . '</td>
                          <td>' . $row["date_entered"] . '</td>
                     </tr>
                <tbody>';
}
$content .= '</table>';
$footer = '<table style="width:100%;color:#ccc;background:#17479d;padding:5px 0px;margin:0px;">
            <tr>
		<td width="30%"><span style="float:left!important;margin-left:10px;">Printed by: ' . $name . '&nbsp;' . $current_date . '</span></td>
		<td style="text-align:center;width:30%;">www.nakumatt.net</td>
		<td  width="30%">&nbsp;</td>
            </tr>
        </table>
        <h4 style="color:red;">The content is confidential and not meant to be shared in any form with any external persons / entities.</h4>
        </body>
        </html>';
$html = $header . $content . $footer;
$dompdf->load_html($html);
// (Optional) Setup the paper size and orientation
$dompdf->set_paper('A4', 'landscape');
// Render the HTML as PDF
$dompdf->render();
// Output the generated PDF to Browser
$filename = "CS" . date('Y-m-d:H:i:s') . ".pdf";
$dompdf->stream($filename);
?>