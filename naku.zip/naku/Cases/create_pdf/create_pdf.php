<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

// Include the main TCPDF library (search for installation path).
//require_once('include/TCPDF_master/examples/tcpdf_include.php');
require_once('include/entryPoint.php');
require_once('include/TCPDF_master/tcpdf.php');

// extend TCPF with custom functions
class MYPDF extends TCPDF {

        
        //Page header
	/*public function Header() {
		// Logo
		$image_file = K_PATH_IMAGES.'logo_example.jpg';
		$this->Image($image_file, 120, 10, 15, '', 'JPG', '', 'T', false, 300, '', false, false, 0, false, false, false);
		                // add a page
              $this->SetFont('helvetica', 'B', 20);
		// Title
		//$this->Cell(0, 15, '<< TCPDF Example 003 >>', 0, false, 'C', 0, '', 0, false, 'M', 'M');
	}*/
        
}
$recordid = isset($this->bean->id) ? $this->bean->id :'' ;

/*$sqlRel  = "SELECT count(id) as total FROM `cases_cases_1_c` WHERE deleted=0 limit 1";
$result = $GLOBALS['db']->query($sqlRel, false);
 $row = $GLOBALS['db']->fetchByAssoc($result);
  $total = $row['total'];  
   */     
// create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Nakumatt');
$pdf->SetTitle('Payment Voucher');
$pdf->SetSubject('Payment Voucher');



    $pdf->AddPage();

    $headerString = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;NAKUMATT HOLDINGS LIMITED <br />"
            . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Head Office Road C,Off Enterpise Road,<br />"
            . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;P.O.Box 78355-00507, Nairobi, Kenya<br />"
            . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tel: +254 20 650 137/8/9,<br />";
    $headerString .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;+254 733 632 130,+254 722 204 931<br />"
            . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fax: +254 20 650150<br />"
            . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email:nakumatt@nakumatt.net<br />";

    $school_school_name = $this->bean->school_school_name;
    $school_cheque_no = $this->bean->school_cheque_no;
    $school_voucher_No = $this->bean->school_voucher_No;
    // create some HTML content
    $html ='';$html_lbl ='';
    $html_lbl.= '';
    $html_lbl .= '<table id ="header_tab_label" cellpadding="0" cellspacing="0" border="0" >';
    $html_lbl .= '<tr><td style="font-size:18px;">PAYMENT VOUCHER</td><td></td></tr>';
    $html_lbl .= '<tr><td></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date  : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.date("d/m/Y").'</td></tr>';
    $html_lbl .= '<tr><td>We enclose herewith cheque no. '.$school_cheque_no.'</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cheque No. : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$school_cheque_no.'</td></tr>';
    $html_lbl .= '<tr><td>Being payment for School fees redemption: </td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Voucher No.  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$school_voucher_No.'</td></tr>';
    $html_lbl .= '</table>';
    //&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;BOX No 455567
    $html .= '<table width="100%" border="0" id="cst_ack" style="font-size: small">
  <tr>
    <td width="63%" valign="top"><br><br><img src="custom/modules/Cases/images/nakumatt2.jpg" border="0" width="200" /></td>
    <td width="37%" style="text-align: left;">NAKUMATT HOLDINGS LIMITED<br />
      Head Office Road C,Off Enterpise Road,<br />
      P.O.Box 78355-00507, Nairobi, Kenya<br />
      Tel: +254 20 650 137/8/9,<br />
      +254 733 632 130,+254 722 204 931<br />
      Fax: +254 20 650150<br />
      Email:nakumatt@nakumatt.net
	</td>
  </tr>
</table><table style="font-size: large" border="0" >
             <tr> <td style="text-align:left;" colspan="2">TO : &nbsp;&nbsp;'.$school_school_name.',<br /></td>
            </tr></table>'; $html .= $html_lbl;
    
    $date_string =$this->bean->date_entered;//date("d/m/Y", strtotime($this->bean->date_entered));
    $date = explode(" ",$date_string);
    $school_dop =$date[0];//$date;//=date('d-m-Y',strtotime($this->bean->date_entered));
   
    
    $school_particulars = $this->bean->school_particulars;
    $school_amount_payable = sprintf("%.2f",$this->bean->school_amount_payable);
    if(strtoupper($this->bean->school_branch_country) == strtoupper('Kenya')){
        $currency = 'KSh';
    }elseif (strtoupper($this->bean->school_branch_country) ==strtoupper('Rwanda')) {
        $currency = 'FRw';
    }elseif (strtoupper($this->bean->school_branch_country) ==strtoupper('Tanzania')) {
        $currency = 'TSh';
    }elseif (strtoupper($this->bean->school_branch_country) ==strtoupper('Uganda')) {
        $currency = 'USh';
    }
    $html .= '<br><br><table border="1"  id ="body_tab" cellpadding="1" cellspacing="1">'
            . '<tr style="text-align:center"><th> Date</th><th colspan="3">Particulars</th><th>'.$currency.'</th><th>Cls</th></tr>'
            . '<tr ><td height="300" style="text-align:left" >'.$school_dop.'</td><td style="text-align:left" colspan="3">'.$school_particulars.'</td>'
            . '<td style="text-align:left">'.$school_amount_payable.'</td><td> N/A </td></tr></table>';

    $html .= '<br /><br /><br /><br /><br />Approved by-----------------------'
              . '--------------------- &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
              . 'Checked by-------------------------------------------------';
    
    $html .= '<br /><br /><br /><br /><td align="right"><img src="custom/modules/Cases/images/nakumatt2.jpg" width="100"  /></td>';
    // output the HTML content
    $pdf->writeHTML($html, true, 0, true,30);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
//$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
//$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
//$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}



// ---------------------------------------------------------


// set font
$pdf->SetFont('helvetica', '', 9);

// add a page
//$pdf->AddPage();


// reset pointer to the last page
$pdf->lastPage();


// ---------------------------------------------------------
ob_start();
// close and output PDF document
$pdf->Output('create_case.pdf', 'I');//D

ob_end_flush();


//============================================================+
// END OF FILE
//============================================================+
