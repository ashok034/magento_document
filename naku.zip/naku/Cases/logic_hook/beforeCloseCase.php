<?php
class before_close_cases {
    function before_close($bean, $event, $arguments) {
        if ($bean->status == 'Resolved') {
            $sql = "select c01.id,c01.name,c01.status from cases c01 join cases_cases_1_c cc02 on c01.id = cc02.cases_cases_1cases_ida where c01.status <> 'Resolved' "
                    . " AND cc02.cases_cases_1cases_idb ='" . $bean->id . "' AND cc02.deleted = 0 AND c01.deleted = 0";
            $result = $GLOBALS['db']->query($sql);
            if ($result->num_rows > 0) {
                SugarApplication::redirect('index.php?module=Cases&action=EditView&message=1&record=' . $bean->id);
            }/*else {
                $bean->save();
            }*/ //comment this line becasue at the time of resolving case send to multiple emails to customer.
        }
    }
}
?> 