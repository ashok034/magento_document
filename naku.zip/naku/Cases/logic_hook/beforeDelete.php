<?php

   if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

   class before_delete_class
   {
	function before_delete_method($bean, $event, $arguments)
	{
           // echo "<pre>";print_r($bean);
            if($event == 'before_delete'){
                
                $sqlRel  = "SELECT  cases.status, cases_cases_1_c.cases_cases_1cases_ida  FROM `cases_cases_1_c` cases_cases_1_c  JOIN cases cases "
                        . " ON cases_cases_1_c.cases_cases_1cases_ida = cases.id where cases_cases_1_c.cases_cases_1cases_idb ='".$bean->id."' "
                        . " AND cases.deleted=0 AND cases_cases_1_c.deleted=0 "; 
              
                $result = $GLOBALS['db']->query($sqlRel, false);
                $num_rows = $result->num_rows;
                $return_array = array();
                $relate_array = array();
                $myChildRecord = array();
                $i=0;
                while($row = $GLOBALS['db']->fetchByAssoc($result)){
                    $return_array['status'][] = $row['status'];
                    $relate_array['cases_cases_1cases_ida'][] = $row['cases_cases_1cases_ida'];
                    array_push($myChildRecord,'');
                    if($row['status'] == 'Resolved'){
                      $i++;
                    }
                }
                if($result->num_rows == $i){ 
                    
                  
                    $sqlChildDel  = 'UPDATE cases set deleted =1 WHERE id IN ("' . implode('", "', $relate_array['cases_cases_1cases_ida']) . '")';
                    $result_child_case = $GLOBALS['db']->query($sqlChildDel);
                    
                    $bean = BeanFactory::getBean("Cases",$bean->id);     //Retrieve bean
                    $bean->deleted = 1;   
                    

                    $bean->save();                    
                    $msg = 3;
                    $queryParams = array(
                        'module' => 'Cases',
                        'action' => 'ListView',
                        'message' => $msg
                    );
                     
                }else{ 
                    $msg = 4;
                     $queryParams = array(
                        'module' => 'Cases',
                        'action' => 'DetailView',
                         'record' => $bean->id,
                        'message' => $msg
                    );
                }
               
                SugarApplication::redirect('index.php?' . http_build_query($queryParams));
                
            }
	}
}
?> 