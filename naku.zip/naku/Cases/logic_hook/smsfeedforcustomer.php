<?php
if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

class smsfeedforcustomer {
	public function connectionCRMDB() {
        global $sugar_config;
        $servername = $sugar_config['crm_host'];//"localhost";//$sugar_config['crm_host'];
        $username = $sugar_config['crm_user'];//"root";//$sugar_config['crm_user'];
        $password = $sugar_config['crm_password'];//"";//$sugar_config['crm_password'];
        $dbname = $sugar_config['crm_db'];//"mag_217";//$sugar_config['crm_db'];
        $conn = new mysqli($servername, $username, $password, $dbname);
        return $conn;
    }
	
	function getactualval($per,$str)
	{
	
		return explode($per,$str);
	}
	
    function sendSMS($bean, $event, $arguments){  
        global $db,$sugar_config;
        $case_id = $bean->id;
        $sql = "SELECT case_number FROM cases WHERE id = '{$case_id}'"; //get Case Number
        $case_status    = $bean->status;
        $case_number    = $db->getOne($sql);
        $case_title     = strip_tags($bean->name);
        $case_desc      = strip_tags($bean->description);
        $customer_name  = strip_tags($bean->customer_name_c);
        $member_tier    = $bean->member_tier_c;
        $resolution     = strip_tags($bean->resolution);
        $customer_email = $bean->email_c;
        $customer_mobile = $bean->mobile_number_c;
        $member_type_c = $bean->member_type_c;
       // $customer_mobile = '254734017935';
	   
		$_DateCre  = date('d M Y',strtotime($bean->date_entered)); 
        
        $query = "SELECT estimate_resolution_input, estimate_resolution_date FROM naku_casesubcategory JOIN cases_cstm cases_cstm on naku_casesubcategory.id = cases_cstm.subcategory_c WHERE cases_cstm.id_c = '{$case_id}'";
        $result = $GLOBALS['db']->query($query, false);
        $row = $GLOBALS['db']->fetchByAssoc($result);
		$time_sms = $row['estimate_resolution_input']." ".$row['estimate_resolution_date']; 
                
                
        if($case_status =='Resolved'){
             //save the record to accomodate the resolved cases 
            $bean->resolved_date = date('Y-m-d');
            
             //SMS
			 
			//$message .= "Dear ".$customer_name.", Your request number (Ticket No. ".$case_number.") has been successfully resolved ";
            // dynamically start from Magento 
			$conn = $this->connectionCRMDB();
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			}
			
			$code ="sms_case_closure";//code from magento
			$sql_sms_template = "SELECT variable.code,variable_value.plain_value FROM variable JOIN  variable_value WHERE variable.variable_id = variable_value.variable_id AND variable.code ='".$code."'";
			$result_sms_template = $conn->query($sql_sms_template);
			$row_sms_template = $result_sms_template->fetch_assoc();
			$code = $row_sms_template['code'];
			$plain_value = $row_sms_template['plain_value'];
			
			$_check = $this->getactualval("%s1",$plain_value);
			$collect_cheque1 = $_check[0] .$customer_name;
			
			$_check2 = $this->getactualval("%s2",$_check[1]);
			$collect_cheque2 = $_check2[0].$case_number.$_check2[1];
			
					
			$message .= $collect_cheque1."".$collect_cheque2;
			//Dynamically from magento
			
			
            $text_mess = $message;
            $messages = array();
            if (!empty($customer_mobile)) {
                $messages[] = array("sender" => 'Nakumatt', "phone" => array($customer_mobile), "text" => $text_mess);
            }

            $smsArray = array("messages" => $messages);
            $smsJson = json_encode($smsArray);
            $url = "http://192.168.0.128:8100/sms/sendBulk";
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $smsJson);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3000);

            $data = curl_exec($ch);
          //  fwrite($fp, $data);
            if (curl_errno($ch))
                print curl_error($ch);
            else
                curl_close($ch);
            //curl_close($ch);
            //$array_data = simplexml_load_string($data);
            //echo $data;
           // print_r(json_decode($data));exit;
           //nd of SMS
            
        }
        if($case_status =='Created' && !empty($customer_mobile)){
           //within xx days
		   
			// dynamically start from Magento 
			$conn = $this->connectionCRMDB();
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			}
			
			$code ="sms_case_creation";
			$sql_sms_template = "SELECT variable.code,variable_value.plain_value FROM variable JOIN  variable_value WHERE variable.variable_id = variable_value.variable_id AND variable.code ='".$code."'";
			$result_sms_template = $conn->query($sql_sms_template);
			$row_sms_template = $result_sms_template->fetch_assoc();
			$code = $row_sms_template['code'];
			$plain_value = $row_sms_template['plain_value'];
			
			$_check = $this->getactualval("%s1",$plain_value);
			$collect_cheque1 = $_check[0] .$customer_name;
			
			$_check2 = $this->getactualval("%s2",$_check[1]);
			$collect_cheque2 = $_check2[0].$case_number;
			
			$_check3 = $this->getactualval("%s3",$_check2[1]);
			$collect_cheque3 = $_check3[0].$time_sms;
			
			$message .= $collect_cheque1."".$collect_cheque2."".$collect_cheque3;
			//Dynamically from magento
		
          //  $message .= "Dear ".$customer_name.", Your query has been registered (Ticket No. ".$case_number.") with our service desk. We will try to resolve your query within ".$time_sms;  
            //SMS
            $text_mess = $message;
            $messages = array();
            if (!empty($customer_mobile)) {
                $messages[] = array("sender" => 'Nakumatt', "phone" => array($customer_mobile), "text" => $text_mess);
            }

            $smsArray = array("messages" => $messages);
            $smsJson = json_encode($smsArray);
            $url = "http://192.168.0.128:8100/sms/sendBulk";
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $smsJson);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3000);

            $data = curl_exec($ch);
          //  fwrite($fp, $data);
            if (curl_errno($ch))
                print curl_error($ch);
            else
                curl_close($ch);
            //curl_close($ch);
            //$array_data = simplexml_load_string($data);
            //echo $data;
           // print_r(json_decode($data));exit;
           //nd of SMS
            
        }
        if($case_status =='Closed' && !empty($customer_mobile)){
           //within xx days Dear “XXX�? Your request number XXXX has been successfully resolved
		   // dynamically start from Magento 
			$conn = $this->connectionCRMDB();
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			}
			
			$code ="sms_feedback_case_closure";
			$sql_sms_template = "SELECT variable.code,variable_value.plain_value FROM variable JOIN  variable_value WHERE variable.variable_id = variable_value.variable_id AND variable.code ='".$code."'";
			$result_sms_template = $conn->query($sql_sms_template);
			$row_sms_template = $result_sms_template->fetch_assoc();
			$code = $row_sms_template['code'];
			$plain_value = $row_sms_template['plain_value'];
			
			$_check = $this->getactualval("%s1",$plain_value);
			$collect_cheque1 = $_check[0] .$customer_name;
			
			$_check2 = $this->getactualval("%s2",$_check[1]);
			$collect_cheque2 = $_check2[0].$case_number;
			
			$message .= $collect_cheque1."".$collect_cheque2;
			//Dynamically from magento
			
			
            //SMS
            $text_mess = $message;
            $messages = array();
            if (!empty($customer_mobile)) {
                $messages[] = array("sender" => 'Nakumatt', "phone" => array($customer_mobile), "text" => $text_mess);
            }

            $smsArray = array("messages" => $messages);
            $smsJson = json_encode($smsArray);
            $url = "http://192.168.0.128:8100/sms/sendBulk";
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $smsJson);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3000);

            $data = curl_exec($ch);
          //  fwrite($fp, $data);
            if (curl_errno($ch))
                print curl_error($ch);
            else
                curl_close($ch);
            //curl_close($ch);
            //$array_data = simplexml_load_string($data);
            //echo $data;
           // print_r(json_decode($data));exit;
           //nd of SMS
            
        }
    }
}
?>