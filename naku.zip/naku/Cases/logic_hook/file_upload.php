<?php

if (!defined('sugarEntry') || !sugarEntry)
    die('Not A Valid Entry Point');
/* * *******************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 * ****************************************************************************** */
ini_set("upload_max_filesize", "100M");
class upload_class {
    function uploadFiles(&$bean, $event, $arguments) {
         //File Upload functionality
       //$filename = strtotime("now") . '_' . $bean->case_number . '.' . end(explode('.', $_FILES['filename_file']['name']));
       //echo "<br />".  $file_path = $sugar_config['site_url']. '/upload/cases_files/'.$this->bean->case_number.'_'.$this->bean->filename;
      // $file_path = $_SERVER['DOCUMENT_ROOT'] .'/nakumatt_sugarcrm_2017'. '/upload/cases_files/'. $this->bean->case_number . '/' . $filename;
        
      //  move_uploaded_file($_FILES["filename_file"],'D:/xampp/htdocs/nakumatt_sugarcrm_2017/upload/cases_file/'.$_FILES['filename_file']['name']);
      /*echo  $file_path = 'D:/xampp/htdocs/nakumatt_sugarcrm_2017/upload/cases_file/'.$_FILES['filename_file']['name'];
       echo '<pre>'; print_r($_FILES); 
        if (move_uploaded_file($_FILES["filename_file"]["tmp_name"],$file_path)) { 
            echo "The file " . basename($_FILES["filename_file"]["name"]) . " has been uploaded.";exit;
           echo $GLOBALS['log']->debug('The Cases file '. basename($_FILES["filename_file"]["name"]) . 'has been uploaded');
            $flag = 1;
        } else {
            echo $GLOBALS['log']->debug('Sorry, there was an error uploading your file');exit;
        }  */
        require_once('config.php');
        
       /*

        global $root_directory;global $log;global $upload_dir;
        
         if (!is_uploaded_file($_FILES["filename_file"]['tmp_name']) )
         {
             $log->debug("Exiting confirm_upload method ...");
           
         }
         else if ($_FILES["filename_file"]['size'] > $upload_maxsize)
         {
             die("ERROR: uploaded file was too big: max filesize:$upload_maxsize");
         }

         if( !is_writable( $root_directory.'/'.$upload_dir))
         {
             die ("ERROR: cannot write to directory: $root_directory/$upload_dir for uploads");
         }
         echo $root_directory.'/'.$upload_dir;
         */
         
      /*echo  $file_name = basename($_FILES['filename_file']['name']);
     // echo  $destination = $root_directory.'/'.$upload_dir.$file_name;
       $destination = 'D:/xampp/htdocs/nakumatt_sugarcrm_2017/upload/'.$file_name;
        if (!move_uploaded_file($_FILES['filename_file']['tmp_name'], $destination)){
             die ("ERROR: can't move_uploaded_file to $destination");
        }$log->debug("Exiting final_move method ...");
        */
        echo "<pre>";print_r($_FILES);
        echo  $file_name = basename($_FILES['filename_file']['name']);
		$file_path = 'D:/xampp/htdocs/nakumatt_sugarcrm_2017/upload/'.$file_name;
                if(move_uploaded_file($_FILES["filename_file"]["tmp_name"],$file_path)) {
                    echo "The file " . basename($_FILES["filename_file"]["name"]) . " has been uploaded.";
                   
                } else {
                    echo "Sorry, there was an error uploading your file.";
                } 
                
                
                
    }
}
?>