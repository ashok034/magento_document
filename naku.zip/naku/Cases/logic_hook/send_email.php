<?php
if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

class send_email_class {

	 public function connectionCRMDB() {
        global $sugar_config;
        $servername = $sugar_config['crm_host'];//"localhost";//$sugar_config['crm_host'];
        $username = $sugar_config['crm_user'];//"root";//$sugar_config['crm_user'];
        $password = $sugar_config['crm_password'];//"";//$sugar_config['crm_password'];
        $dbname = $sugar_config['crm_db'];//"mag_217";//$sugar_config['crm_db'];
        $conn = new mysqli($servername, $username, $password, $dbname);
        return $conn;
    }
	
	function getactualval($per,$str)
	{
	
		return explode($per,$str);
	}

    function sendEmailCases($bean, $event, $arguments){         
        //File write code for DEBUGING
        /*$myfile = fopen("newfile.txt", "a") or die("Unable to open file!");
        $txt = "test\n";
        fwrite($myfile, $txt);*/
        //End File write code for DEBUGING
        global $db,$sugar_config;
		$case_id = $bean->id;
        $sql = "SELECT case_number FROM cases WHERE id = '{$case_id}'"; //get Case Number
        $case_status    = $bean->status;
        $case_number    = $db->getOne($sql);
        $case_title     = strip_tags($bean->name);
        $case_desc      = strip_tags($bean->description);
        $customer_name  = $bean->customer_name_c;
        $member_tier    = $bean->member_tier_c;
        $resolution     = strip_tags($bean->resolution);
        $customer_email = $bean->email_c;
		
		$_DateCre  = date('d M Y',strtotime($bean->date_entered)); 
		$_BranchProd = ucfirst($bean->branch_name);
		
        //School Fees Redemption & Payment Informations Details
        $school_parent_name         = $bean->school_parent_name;
        $school_name                = $bean->school_school_name;
        $school_child_name          = $bean->school_child_name;
        $school_points_redeemed     = $bean->school_points_redeemed;
        $school_amount_payable      = $bean->school_amount_payable;
        $school_cheque_status       = $bean->school_cheque_status;
        $school_cheque_no           = $bean->school_cheque_no;
        $school_cheque_issuedate    = $bean->school_cheque_issuedate;
        $school_voucher_No          = $bean->school_voucher_No;
        $school_particulars         = $bean->school_particulars;
        $school_cheque_dispatch     = $bean->school_cheque_dispatch;
        
        //get User Details
        $myUser = new User();
        $myUser->retrieve_by_string_fields(array('department' => 'Loyalty' ));
        $user=BeanFactory::getBean('Users',$myUser->id);
        $primary_email=$user->emailAddress->getPrimaryAddress($user); 
        $user_name = $user->user_name;
        //get Subcategory Details
        $subcat = new naku_CaseSubCategory();
        $subcat->retrieve($bean->subcategory_c);
        $subCatName = $subcat->name;
       // $sla = $subcat->sla;
	   //Changed the code as per new estimate resolution @ 02-05-2017 @Author: Ashok 
		$estimate_resolution_input = $subcat->estimate_resolution_input;
		$estimate_resolution_date = $subcat->estimate_resolution_date;
		$sla_duration = $subcat->estimate_resolution_input .' '.$subcat->estimate_resolution_date;
       /* if($sla == '1w'){
            $sla_duration = '1 Week';
        }elseif($sla == '2w'){
            $sla_duration = '2 Week';
        }elseif($sla == 'm2w'){
            $sla_duration = 'More than 2 Week';
        }else{
            $sla_duration = $sla.' Hrs.';
        }*/
		
		
		$subcat_service = strtoupper('School fee redemption');
			
		 $myCategory = new naku_CaseCategory();
		$myCategory->retrieve($bean->category_c);
		$catName = $myCategory->name;
		
		$cat_product = strtoupper('Product');
		$cat_service = strtoupper('Service');
		
		
		/**************header***************************/
		
		    $message_temp_header= "<head>
<meta charset='utf-8'>
<meta name='viewport' content='initial-scale = 1.0,maximum-scale = 1.0' />
<meta http-equiv='X-UA-Compatible' content='IE=edge'>
<title>Untitled Document</title>
<style type='text/css'>
@font-face {
	font-family: 'Montserrat-Regular';
	src:url('fonts/Montserrat-Regular.eot');
	src:url('fonts/Montserrat-Regular.eot?#iefix') format('embedded-opentype'),
		url('fonts/Montserrat-Regular.woff') format('woff'),
		url('fonts/Montserrat-Regular.ttf') format('truetype');
}
* {
	margin: 0;
	padding: 0;
	box-sizing: border-box;
}
body {
	font-family: 'Montserrat-Regular';
	font-size: 13px;
	color: #262626;
}
.emailTblWrapper {
	max-width: 850px;
	width: 100%;
	margin: 0 auto;
}
.headerBG {
	background: #fff;
}
.header {
	width: 100%;
	padding: 15px 10px;
	min-height: 80px;
	border-bottom: 1px solid #dadada;
}
.header .logo {
	box-sizing: border-box;
	display: block;
	text-align: center;
	padding: 10px;
}
.emailContentPart {
	padding: 20px 0;
	text-align: left;
}
.emailContentPart td {
	padding: 5px 0 10px;
}
.emailContentPart td h3 {
	margin: 5px 0 10px;
}
.emailContentPart td img {
	width: 100%;
}
.emailContentPart a {
	color: #17479d;
}
p {
	margin: 5px 0px 15px;
	line-height: 20px;
}
h1, h2, h3, h4, h5, h6 {
	margin: 10px 0px 25px;
}
h1 {
	font-size: 24px;
}
.footer {
	background: #fff;
	font-size: 12px;
}
.footer a {
	color: #325bb9;
	text-decoration: underline;
}
.footer a:hover {
	text-decoration: none;
}
.rightTxt {
	text-align: right;
}
.custCare {
	text-align: center;
	padding: 15px;
	font-size: 14px;
}
.toplinks {
	text-align: right;
	font-size: 12px;
	color: #7e7e7e;
	font-size: 13px;
}
.toplinks a {
	color: #7e7e7e;
	font-size: 11px;
	margin: 0 5px;
}
.toplinks a:hover {
	text-decoration:none;
}
.clm-logo-container {
	border-collapse: collapse;
	width: 100%;
}
.clm-logo-container td.heading {
	width: 100%;
	display: block;
	clear: both;
}
.clm-logo-container td {
	padding: 0px 5px;
	box-sizing: border-box;
	vertical-align: top;
	width: 25%;
	display: block;
	float: left;
}
.clm-logo-container td:first-child {
	padding-left: 0px;
}
/*Social media section start here*/
.social-media-sect {
	background: #7e7e7e;
	width: 60%;
	margin: 0 auto;
	padding: 5px 5px;
	color: #fff;
	text-align: center;
	max-width: 443px;
}
.social-media-sect td {
	padding: 5px 5px;
	display: block;
	float: left;
	vertical-align: middle
}
.social-sect {
	float: left;
	display: block;
	max-width: 235px;
}
.social-sect table {
	width: 100%;
}
.social-sect a {
	display: inline-block;
	margin: 0 6px;
}
.social-media-sect .divider {
	max-width: 3px;
	text-align: center;
	line-height: 32px;
	margin: 15px 3px;
	height: 25px;
	border-right: 1px solid #fff;
	padding: 0 !important;
}
.social-sect table td:nth-child(3) {
	line-height: 28px;
	padding: 6px 7px;
	min-width: 80px;
}
.downloadApp-sect {
	max-width: 230px;
}
.downloadApp-sect table {
	width: 100%;
}
.downloadApp-sect table td:first-child {
	line-height: 28px;
	padding: 6px 7px;
}
.social-sect a, .downloadApp-sect a {
	margin: 0 4px;
	display: inline-block;
}
.social-sect table .downloadApp-sect table {
	width: 100% !important;
}
/*Social media section end here*/

@media (max-width: 767px) {
.toplinks a {
	display: block;
	text-align: center;
	margin: 5px 5px 0px;
}
.toplinks span {
	display: none;
}
.clm-logo-container td {
	width: 50%;
	margin: 10px 0;
}
.clm-logo-container td:first-child {
	padding-left: 5px;
}
/*Social media section start here 767*/
.social-media-sect .divider {
	clear: both;
	display: block;
	float: none;
	max-width: 100% !important;
	border-bottom: 1px solid #fff;
	border-right: none;
	margin: 5px 0px;
	height: 1px;
}
.social-sect {
	margin: 0 auto;
	float: none !important;
}
.downloadApp-sect {
	max-width: 250px;
	float: none !important;
	margin: 0 auto;
}
/*Social media section end here 767*/
}

@media (max-width: 420px) {
.header td.logo {
	width: 100%;
	display: block;
	float: none;
	text-align: center;
	padding: 10px 0px;
}
.clm-logo-container td {
	width: 100%;
}
/*Social media section start here 420*/
.social-sect table td {
	width: 50%;
}
.social-sect table td:nth-child(3) {
	width: 100%;
	padding: 0px 7px;
}
.downloadApp-sect table td {
	width: 50%;
}
.downloadApp-sect table td:first-child {
	width: 100%;
	padding: 0px 7px;
}
/*Social media section end here 420*/
}
</style>
</head>


<body>
<table class='emailTblWrapper'>
  <tr>
    <td class='headerBG'>
		<table class='header'>
        <tr>
          <td class='logo'><a href='#'><img src='custom/include/images/nakumatt-logo.png' alt=''></a></td>
        </tr>
      </table></td>
  </tr>
 ";	
		/*******************Footer*************************/
		$message_temp_footer  = '<tr>
    <td><table class="footer">
        <tr>
          <td valign="top"><table>
              <tr>
                <td valign="top"><table class="social-media-sect">
                    <tr>
                      <td class="social-sect"><table>
                          <tr>
                            <td><a href="#"><img src="custom/include/images/fb-icon.png" alt="" /></a></td>
                            <td><a href="#"><img src="custom/include/images/twitter-icon.png" alt="" /></a></td>
                            <td>#Nakumatt</td>
                          </tr>
                        </table></td>
                      <td class="divider"></td>
                      <td class="downloadApp-sect"><table>
                          <tr>
                            <td> Download App</td>
                            <td><a href="#"><img src="custom/include/images/android-icon.png" alt=""/></a></td>
                            <td><a href="#"><img src="custom/include/images/apple-icon.png" alt=""/></a></td>
                          </tr>
                        </table></td>
                    </tr>
                  </table></td>
              </tr>
              <tr>
                <td class="custCare">Customer Care : 123456</td>
              </tr>
              <tr>
                <td><p>You have received this mail because your e-mail ID is registered with Nakumatt. This is a system-generated e-mail, please don\'t reply to this message. The content sent in this mail have been posted by Nakumatt. Nakumatt has taken all reasonable steps to ensure that the information in this mailer is 
                    authentic. </p>
                  <p>Users are advised to research bonafides of advertisers independently. Nakumatt shall not have any responsibility in this regard. 
                    We recommend that you visit our <a href="#">Terms &amp; Conditions</a> and the <a href="#">Privacy Policy</a> for more comprehensive information. </p></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td><a href="#">Unsubscribe</a> | <a href="#">Report a problem</a></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
      </table></td>
  </tr>';
		
		/**********************END***************************/
        if((strtoupper($subCatName) == $subcat_service) && $school_cheque_status == 'Dispatched'){
            $subject = "Case Id: ".$case_number." - ".$school_cheque_status;   
            //$email = $primary_email;
			$message ="";
			$message .= "<html>";
			$message .=$message_temp_header;//header
			$message .= "<tr> <td><table class='emailContentPart'> <tr>";
			
            $message .= "<td>Dear ".$customer_name.",<br/><br/> Your cheque against Request <b>$case_number</b>  for School fee redemption of Nakumatt loyalty points is ready. Kindly visit our the store to collect your cheque.<br/><br/>Thank you,<br/> Nakumatt</td>";
           
            $message .= "</tr></table></td></tr>";
			$message .=$message_temp_footer;//footer
			$message .= "</body>";					
			$message .= "</table></html>";
            $email = $customer_email;
            
            require_once('include/SugarPHPMailer.php'); 
            $emailObj = new Email(); 
            $defaults = $emailObj->getSystemDefaultEmail(); 
            $mail = new SugarPHPMailer(); 
            $mail->setMailerForSystem(); 
            $mail->From = $sugar_config['mail_from_c'];//"reports@nakumatt.net";//$defaults['email']; 
            $mail->FromName = $sugar_config['mail_from_name_c'];//"Nakumat Holdings";//$defaults['name']; 
            $mail->Subject = $subject; 
            $mail->Body_html = from_html($message);
            //$mail->Body = wordwrap($message, 900);
            $mail->IsHTML(true); //Omit or comment out this line if plain text
            $mail->Body = $mail->Body_html;//$message; 
            $mail->prepForOutbound(); 
            $mail->AddAddress($email); 
            if (!$mail->send()) {
              $GLOBALS['log']->info("Mailer error: " . $mail->ErrorInfo);
           }
           
           //SMS
		   
            $branch_store_name = $bean->branch_store_name;
			
					
			// dynamically start from Magento 
			$conn = $this->connectionCRMDB();
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			}
			
			$code ="sms_notification_to_collect_cheque";
			$sql_sms_template = "SELECT variable.code,variable_value.plain_value FROM variable JOIN  variable_value WHERE variable.variable_id = variable_value.variable_id AND variable.code ='".$code."'";
			$result_sms_template = $conn->query($sql_sms_template);
			$row_sms_template = $result_sms_template->fetch_assoc();
			$code = $row_sms_template['code'];
			$plain_value = $row_sms_template['plain_value'];
			
			$_check = $this->getactualval("%s1",$plain_value);
			$collect_cheque1 = $_check[0] .$customer_name;
			
			$_check2 = $this->getactualval("%s2",$_check[1]);
			$collect_cheque2 = $_check2[0].$case_number;
			
			$_check3 = $this->getactualval("%s3",$_check2[1]);
			$collect_cheque3 = $_check3[0].$branch_store_name;
			
			$message .= $collect_cheque1."".$collect_cheque2."".$collect_cheque3;
			//Dynamically from magento
			
					
            //$messages = 'Dear '.$customer_name.', your cheque against Request '.$case_number.'  for School fee redemption of Nakumatt loyalty points is ready. Kindly visit our '.$branch_store_name.' store to collect your cheque';
			
						
            $text_mess = $messages;
            $messages = array();
            if (!empty($customer_mobile)) {
                $messages[] = array("sender" => 'Nakumatt', "phone" => array($customer_mobile), "text" => $text_mess);
            }

            $smsArray = array("messages" => $messages);
            $smsJson = json_encode($smsArray);
            $url = "http://192.168.0.128:8100/sms/sendBulk";
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $smsJson);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3000);

            $data = curl_exec($ch);
          //  fwrite($fp, $data);
            if (curl_errno($ch))
                print curl_error($ch);
            else
                curl_close($ch);
            //curl_close($ch);
            //$array_data = simplexml_load_string($data);
           // echo $data;
           // print_r(json_decode($data));exit;
           //nd of SMS 
           
           
        }else if((strtoupper($subCatName) == $subcat_service) && $school_cheque_status == 'Inprogress'){ 
            $subject = "Case Id: ".$case_number." - ".$school_cheque_status; 
            //$email = $primary_email;
            $message ="";
			$message .= "<html>";
			$message .=$message_temp_header;//header
			$message .= "<tr> <td><table class='emailContentPart'> <tr>";
            $message .= "<td>Dear ".$user_name.",<br/><br/> New Cases has been registered with case id - <b>$case_number</b>  for School fee redemption of Nakumatt loyalty points. Kindly look into the attachment.<br/><br/>Thank you,<br/> Nakumatt</td>";
            $message .= "</tr></table></td></tr>";
			$message .=$message_temp_footer;//footer
			$message .= "</body>";					
			$message .= "</table></html>";
            $email = $primary_email;
            
            require_once('include/SugarPHPMailer.php'); 
            $emailObj = new Email(); 
            $defaults = $emailObj->getSystemDefaultEmail(); 
            $mail = new SugarPHPMailer(); 
            $mail->setMailerForSystem(); 
			$mail->From = $sugar_config['mail_from_c'];//"reports@nakumatt.net";//$defaults['email']; 
            $mail->FromName = $sugar_config['mail_from_name_c'];//"Nakumat Holdings";//$defaults['name']; 
            $mail->Subject = $subject; 
            $mail->Body_html = from_html($message);
            //$mail->Body = wordwrap($message, 900);
            $mail->IsHTML(true); //Omit or comment out this line if plain text
            $mail->Body = $mail->Body_html;//$message; 
            
            $file_name = $bean->filename;
            $location = "upload/{$bean->id}";
            $mime_type = $attachment->file_mime_type;
            // Add attachment to email
            $mail->AddAttachment($location, $file_name, 'base64', $mime_type);
            $mail->prepForOutbound(); 
            $mail->AddAddress($email); 
            if (!$mail->send()) {
              $GLOBALS['log']->info("Mailer error: " . $mail->ErrorInfo);
           } 
        }else{
            /*if($case_status =='Created'){ 
                if(empty($bean->fetched_row)){
                    $subject = "Case Id: ".$case_number." - ".$case_status; 
					$message = "";
                    $message .= "<html>";
					$message .=$message_temp_header;//header
					$message .= "<tr> <td><table class='emailContentPart'> <tr>";
					$message .= '<td>Dear '.$customer_name.',<br/><br/> Your query <b>'.$case_number.'</b> has been registered with our service desk. We will try to resolve your query within '.$sla_duration.'.<br/><br/></td>';
					$message .= " </tr></table></td></tr>";
					$message .=$message_temp_footer;//footer
					$message .= "</body>";					
					$message .= "</table></html>";
                   $email = $customer_email;
                }
            }else if($case_status =='Resolved'){
                $subject = "Case Id: ".$case_number." - ".$case_status; 
				$message ="";
                $message .= "<html>";
				$message .=$message_temp_header;//header
				$message .= "<tr> <td><table class='emailContentPart'> <tr>";
                $message .= '<td>Dear '.$customer_name.',<br/><br/> Your request number <b>'.$case_number.'</b> has been successfully resolved.<br/><br/>Thank you,<br/> Nakumatt</td>';
                $message .= " </tr></table></td></tr>";
				$message .=$message_temp_footer;//footer
				$message .= "</body>";	
				$message .= "</table></html>";
                $email = $customer_email;
            }else if(($case_status !='Resolved') || ($case_status !='Created' )){
                 $subject = "Case Id: ".$case_number." - ".$case_status; 
				 $message ="";
				$message .= "<html>";
				$message .=$message_temp_header;//header
				$message .= "<tr> <td><table class='emailContentPart'> <tr>";
				$message .= '<td>Dear '.$customer_name.',<br/><br/> Your request number <b>'.$case_number.'</b> is currently ('.ucfirst($case_status).').<br/><br/>Thank you,<br/> Nakumatt</td>';
                $message .= " </tr></table></td></tr>";
				$message .=$message_temp_footer;//footer
				$message .= "</body>";	
				$message .= "</table></html>";
                $email = $customer_email;
            }
            require_once('include/SugarPHPMailer.php'); 
            $emailObj = new Email(); 
            $defaults = $emailObj->getSystemDefaultEmail(); 
            $mail = new SugarPHPMailer(); 
            $mail->setMailerForSystem(); 
            $mail->From = $sugar_config['mail_from_c'];//"reports@nakumatt.net";//$defaults['email']; 
            $mail->FromName = $sugar_config['mail_from_name_c'];//"Nakumat Holdings";//$defaults['name']; 
            $mail->Subject = $subject; 
            $mail->Body_html = from_html($message);
            //$mail->Body = wordwrap($message, 900);
            $mail->IsHTML(true); //Omit or comment out this line if plain text
            $mail->Body = $mail->Body_html;//$message; 
            $mail->prepForOutbound(); 
            $mail->AddAddress($email); 
            if (!$mail->send()) {
              $GLOBALS['log']->info("Mailer error: " . $mail->ErrorInfo);
           } */
        }
    }
} 
?>