<?php

if (!defined('sugarEntry') || !sugarEntry)
    die('Not A Valid Entry Point');
/* * *******************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 * ****************************************************************************** */

require_once('include/entryPoint.php');
require_once('include/TCPDF_master/tcpdf.php');
class ComplaintForm {

	//to connect from Magento
	public function connectionCRMDB() {
        global $sugar_config;
        $servername = $sugar_config['crm_host'];//"localhost";//$sugar_config['crm_host'];
        $username = $sugar_config['crm_user'];//"root";//$sugar_config['crm_user'];
        $password = $sugar_config['crm_password'];//"";//$sugar_config['crm_password'];
        $dbname = $sugar_config['crm_db'];//"mag_217";//$sugar_config['crm_db'];
        $conn = new mysqli($servername, $username, $password, $dbname);
        return $conn;
    }
	
	function getactualval($per,$str)
	{
		return explode($per,$str);
	}
	
    function ComplaintFormToSupplier($bean, $event, $arguments) {
            //get User Details
			//Author: Ashok DAted: 28-04-2017 desc : check condition for category and subcateogry 
			$mycat = new naku_CaseCategory();
			$mycat->retrieve($bean->category_c);
			$catName = $mycat->name;
			$category_product = strtoupper('Product');
			
            $subcat = new naku_CaseSubCategory();
            $subcat->retrieve($bean->subcategory_c);
            $subCatName = $subcat->name;
            
            global $db,$sugar_config;
            $case_id        = $bean->id;
            $case_status    = $bean->status;
            $case_id = $bean->id;
            $sql = "SELECT case_number FROM cases WHERE id = '{$case_id}'"; 
            $case_number    = $db->getOne($sql);
           // $case_number    = $bean->case_number;
            
            $case_title     = strip_tags($bean->name);
            $case_desc      = strip_tags($bean->description);
            $customer_name  = strip_tags($bean->customer_name_c);
            $member_tier    = $bean->member_tier_c;
            $resolution     = strip_tags($bean->resolution);
            $customer_email = $bean->email_c;
            $customer_mobile = $bean->mobile_number_c;
            
			//Ashok dated: 07-07-2017
			$_DateCre  = date('d M Y',strtotime($bean->date_entered)); 
			$_BranchProd = ucfirst($bean->branch_name);
		
            //fetch users detail
            if(strtoupper($catName) == $category_product && $subCatName != ''){
               
              if($bean->product_replaced == 'No'){
                    
                    $productCode = $bean->product_code_no;
                    $quality_description = $bean->quality_description;
                     $product_value = $bean->product_value;
                     $branch_manager_comments = $bean->branch_manager_comments;
                     
                    $prod_repair_status = $bean->prod_repair_status;
                    $repair_serial_no = $bean->repair_serial_no;
                    $repair_model_no = $bean->repair_model_no;
                    $repair_tag_no = $bean->repair_tag_no;
                    $repair_nature_of_fault = $bean->repair_nature_of_fault;
                    $repair_date_to_supplier = $bean->repair_date_to_supplier;
                    $repair_delivery_note_no = $bean->repair_delivery_note_no;
                    $supplier_comments_repair = $bean->supplier_comments_repair;
                    $customer_approval_date = $bean->customer_approval_date;
                    $bill_amount = $bean->bill_amount;
                    $suppliers_delivery_note_no = $bean->suppliers_delivery_note_no;
                    $date_of_collection_repair = $bean->date_of_collection_repair;
                    $customer_description = $bean->customer_description;
                    
                    $supplier_email = $bean->email;
                    $customer_email = $bean->email_c;
                    if($prod_repair_status == 'InProgress'){
                        $subject = "Product Repair Detail";
                        $message = '<html><body>';
                        if(empty($bean->fetched_row)){
                            $message .= '<br/> Case Number : <b>'.$case_number.'</b> has been sent.<br/><br/>';
                            $message .= ' Please find the Description below : <br/><br/> Case Title: <b>'.$case_title .'</b><br/> Cases Description: '.$case_desc;
                            $message .= ' <br/><br/>Please find the product repair details';
                            $message .= ' <br/> <br/>';
                            $message .= 'Product Code :<b>'.$product_value.'</b><br/>';
                            $message .= 'Product Description :'.$quality_description.'<br/>';
                            $message .= 'Repair Serial No :<b>'.$repair_serial_no.'</b>&nbsp;&nbsp;&nbsp; Model No :<b>'.$repair_model_no.'</b>&nbsp;&nbsp; Tag No :<b>'.$repair_tag_no.'</b>';
                            $message .= '<br/>';
                            $message .= 'Nature of Fault :'.$repair_nature_of_fault.'<br/>';
                            $message .= 'Value of the Product :'.$product_value.'<br/><br/>';
                            $message .= 'Branch Manager Comments:'.$branch_manager_comments.'<br/><br/>';
                            $message .= 'Repair Date :'.$repair_date_to_supplier.'<br/>';
                            $message .= 'Customer Name :'.$customer_name.'&nbsp;&nbsp;&nbsp; Contact Number :'.$customer_mobile.'&nbsp;&nbsp;&nbsp; Email address :'.$customer_email.'<br/>';
                            $message .= ' <br/> <br/>';
                            $message .= "Thank You.<br/><br/>NAKUMATT HOLDINGS LIMITED <br />Head Office Road C,Off Enterpise Road,<br />P.O.Box 78355-00507, Nairobi, Kenya<br />Tel: +254 20 650 137/8/9,<br />";
                            $message .= "+254 733 632 130,+254 722 204 931<br />Fax: +254 20 650150<br />Email:nakumatt@nakumatt.net<br />";
                            $message .= "</body></html>";
                            //$email = 'nakumattcrmtest@gmail.com';//
                            $email = $supplier_email;
                            
                            //*********************************************//
                            //PDF creation 

                                // create new PDF document
                                $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

                                // set document information
                                $pdf->SetCreator(PDF_CREATOR);
                                $pdf->SetAuthor('Nakumatt');
                                $pdf->SetTitle('Product Details');
                                $pdf->SetSubject('Product Details');
                                $pdf->AddPage();

                                $headerString = "NAKUMATT HOLDINGS LIMITED <br />Head Office Road C,Off Enterpise Road,<br />P.O.Box 78355-00507, Nairobi, Kenya<br />Tel: +254 20 650 137/8/9,<br />";
                                $headerString .= "+254 733 632 130,+254 722 204 931<br />Fax: +254 20 650150<br />Email:nakumatt@nakumatt.net<br />";

                               
                                // create some HTML content
                                $html ='';$html_lbl ='';
                                $html_lbl.= '';
                                $html .= '<table id ="header_tab" cellpadding="1" cellspacing="1" border="0" >
                                        <tr style="text-align:left;"> <td style="text-align:left;" colspan="2">Product Details<br /></td>
                                        <td style="text-align:right;"><img src="custom/modules/Cases/images/nakumatt_1.png" border="0" height="91" width="71" align="middle" /></td>
                                        <td style="text-align:left;font-size: small;" colspan="2" color="#000000">';
                                $html .= $headerString;
                                $html .= ' </td></tr></table>'; $html .= $html_lbl;
                                $html .= $message;
                                $html .= '<br /><br /><br /><br /><td align="right"><img src="custom/modules/Cases/images/nakumatt2.jpg" height="41" width="100"  /></td>';
                                // output the HTML content
                                $pdf->writeHTML($html, true, 0, true,30);

                                // set header and footer fonts
                                $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
                                $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

                                // set default monospaced font
                                $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

                                // set auto page breaks
                                $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

                                // set image scale factor
                                $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

                                // set some language-dependent strings (optional)
                                if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
                                       require_once(dirname(__FILE__).'/lang/eng.php');
                                       $pdf->setLanguageArray($l);
                                }
                                // ---------------------------------------------------------

                                // set font
                                $pdf->SetFont('helvetica', '', 9);

                                // add a page
                                $pdf->AddPage();


                                // reset pointer to the last page
                                $pdf->lastPage();


                                // ---------------------------------------------------------
                                ob_start();
                                $eol = PHP_EOL;
                                $filename = "product_detail.pdf";
                                // close and output PDF document
                                $pdfdoc=   $pdf->Output('product_detail.pdf', 'S');//D

                            //********************************************//
                            $cust_message =' Hi, <br /><br /> Please see the attachment of the product which needs to be repaired.<br /><br />';
                            $cust_message .= "Regards,<br/>NAKUMATT HOLDINGS LIMITED <br />Head Office Road C,Off Enterpise Road,<br />P.O.Box 78355-00507, Nairobi, Kenya<br />Tel: +254 20 650 137/8/9,<br />";
                            $cust_message .= "+254 733 632 130,+254 722 204 931<br />Fax: +254 20 650150<br />Email:nakumatt@nakumatt.net<br />";

                            $attachment = chunk_split(base64_encode($pdfdoc));
                            $from = $sugar_config['mail_from_c'];//"reports@nakumatt.net";
                            $separator = md5(time());

                            $headers  = "From: ".$from.$eol;
                            $headers .= "MIME-Version: 1.0".$eol; 
                            $headers .= "Content-Type: multipart/mixed; boundary=\"".$separator."\"".$eol.$eol; 
                            $headers .= "Content-Transfer-Encoding: 7bit".$eol;
                            $headers .= "This is a MIME encoded message.".$eol.$eol;

                            // message
                            $headers .= "--".$separator.$eol;
                            $headers .= "Content-Type: text/html; charset=\"iso-8859-1\"".$eol;
                            $headers .= "Content-Transfer-Encoding: 8bit".$eol.$eol;
                            $headers .= $cust_message.$eol.$eol;
                            // attachment
                            $headers .= "--".$separator.$eol;
                            $headers .= "Content-Type: application/octet-stream; name=\"".$filename."\"".$eol; 
                            $headers .= "Content-Transfer-Encoding: base64".$eol;
                            $headers .= "Content-Disposition: attachment".$eol.$eol;
                            $headers .= $attachment.$eol.$eol;
                            $headers .= "--".$separator."--";

                            $to =$email;
                            
                            $supplier_email = $bean->email;
                            $customer_email = $bean->email_c;
							
							//change the code for the error found.
                            if(isset($supplier_email) && isset($customer_email)){
								 $array_email = array($supplier_email,$customer_email);
							}else if(!isset($supplier_email) && isset($customer_email)){
								 $array_email = array($customer_email);
							}
                    
                           // $array_email = array($supplier_email,$customer_email);
                            foreach($array_email as $email_k){
                              require_once('include/SugarPHPMailer.php'); 
                              $emailObj = new Email(); 
                              $defaults = $emailObj->getSystemDefaultEmail(); 
                              $mail = new SugarPHPMailer(); 
                              $mail->setMailerForSystem(); 
                              $mail->From = $sugar_config['mail_from_c'];//"reports@nakumatt.net";//$defaults['email']; 
							  $mail->FromName = $sugar_config['mail_from_name_c'];//"Nakumat Holdings";//$defaults['name'];  
                              $mail->Subject = $subject; 
                              $mail->Body_html = from_html($cust_message);
                              //$mail->Body = wordwrap($message, 900);
                              $mail->IsHTML(true); //Omit or comment out this line if plain text
                              $mail->Body = $mail->Body_html;//$message; 
                              $mail->prepForOutbound(); 
                              $mail->AddAddress($email_k); 
                              $mail->AddStringAttachment($pdfdoc, 'product_detail.pdf');
                              if (!$mail->send()) { 
                                $GLOBALS['log']->info("Mailer error: " . $mail->ErrorInfo);
                              } 
                            }
                        }
                        if (($bean->fetched_row['customer_approval_date'] !== $bean->customer_approval_date) && (!empty($bean->customer_approval_date)) && (!empty($bean->supplier_comments_repair))) {
                            // Do custom logic
                            //SMS
														
                         //   $messages = 'Dear '.$customer_name.',Your request '.$case_number.' related to your purchase of '.$bean->prod_sku.' has been approved';
							
							// dynamically start from Magento 
							$conn = $this->connectionCRMDB();
							if ($conn->connect_error) {
								die("Connection failed: " . $conn->connect_error);
							}
							
							$code ="sms_update_prod_quality_complaints_approved";
							$sql_sms_template = "SELECT variable.code,variable_value.plain_value FROM variable JOIN  variable_value WHERE variable.variable_id = variable_value.variable_id AND variable.code ='".$code."'";
							$result_sms_template = $conn->query($sql_sms_template);
							$row_sms_template = $result_sms_template->fetch_assoc();
							$code = $row_sms_template['code'];
							$plain_value = $row_sms_template['plain_value'];
							
							$_check = $this->getactualval("%s1",$plain_value);
							$collect_cheque1 = $_check[0] .$customer_name;
							
							$_check2 = $this->getactualval("%s2",$_check[1]);
							$collect_cheque2 = $_check2[0].$case_number;
							
							$_check3 = $this->getactualval("%s3",$_check2[1]);
							$collect_cheque3 = $_check3[0].$bean->prod_sku;
							
							$message .= $collect_cheque1."".$collect_cheque2."".$collect_cheque3;
							//Dynamically from magento
											
							
							
							
                            $text_mess =$messages;
                            $messages = array();
                            if (!empty($customer_mobile)) {
                                $messages[] = array("sender" => 'Nakumatt', "phone" => array($customer_mobile), "text" => $text_mess);
                            }

                            $smsArray = array("messages" => $messages);
                            $smsJson = json_encode($smsArray);
                            $url = "http://192.168.0.128:8100/sms/sendBulk";
                            $ch = curl_init();
                            curl_setopt($ch, CURLOPT_URL, $url);
                            curl_setopt($ch, CURLOPT_POSTFIELDS, $smsJson);
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                            curl_setopt($ch, CURLOPT_POST, true);
                            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3000);

                            $data = curl_exec($ch);
                          //  fwrite($fp, $data);
                            if (curl_errno($ch))
                                print curl_error($ch);
                            else
                                curl_close($ch);
                            
                        }else if(empty($bean->customer_approval_date) && (!empty($bean->supplier_comments_repair))){
                             //SMS
                           // $messages = 'Dear '.$customer_name.',Your request '.$case_number.' related to your purchase of '.$bean->prod_sku.' has been rejected';
							
							// dynamically start from Magento 
							$conn = $this->connectionCRMDB();
							if ($conn->connect_error) {
								die("Connection failed: " . $conn->connect_error);
							}
							
							$code ="sms_update_prod_quality_complaints_rejected";
							$sql_sms_template = "SELECT variable.code,variable_value.plain_value FROM variable JOIN  variable_value WHERE variable.variable_id = variable_value.variable_id AND variable.code ='".$code."'";
							$result_sms_template = $conn->query($sql_sms_template);
							$row_sms_template = $result_sms_template->fetch_assoc();
							$code = $row_sms_template['code'];
							$plain_value = $row_sms_template['plain_value'];
							
							$_check = $this->getactualval("%s1",$plain_value);
							$collect_cheque1 = $_check[0] .$customer_name;
							
							$_check2 = $this->getactualval("%s2",$_check[1]);
							$collect_cheque2 = $_check2[0].$case_number;
							
							$_check3 = $this->getactualval("%s3",$_check2[1]);
							$collect_cheque3 = $_check3[0].$bean->prod_sku;
							
							$message .= $collect_cheque1."".$collect_cheque2."".$collect_cheque3;
							//Dynamically from magento
										
											
                            $text_mess =$messages;
                            $messages = array();
                            if (!empty($customer_mobile)) {
                                $messages[] = array("sender" => 'Nakumatt', "phone" => array($customer_mobile), "text" => $text_mess);
                            }

                            $smsArray = array("messages" => $messages);
                            $smsJson = json_encode($smsArray);
                            $url = "http://192.168.0.128:8100/sms/sendBulk";
                            $ch = curl_init();
                            curl_setopt($ch, CURLOPT_URL, $url);
                            curl_setopt($ch, CURLOPT_POSTFIELDS, $smsJson);
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                            curl_setopt($ch, CURLOPT_POST, true);
                            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3000);

                            $data = curl_exec($ch);
                          //  fwrite($fp, $data);
                            if (curl_errno($ch))
                                print curl_error($ch);
                            else
                                curl_close($ch);
                        }
                    }
                    if($prod_repair_status == 'Recieved' && $bean->customer_approved == 'Yes'){
                         $suppliers_comments_repair = $bean->suppliers_comments_repair;
                        $subject = "Product Received - Customer Acknowledgment";
                        $message = '<html><body>';
                        $message .= 'Dear '.$customer_name.', <br/><br/> Case raised : <b>'.$case_number.'</b> has been resolved.<br/><br/>';
                        $message .= ' Please find the Description below : <br/><br/> Case Title: <b>'.$case_title .'</b><br/> Cases Description: '.$case_desc;
                        $message .= ' <br/><br/>Please find the product repair details';
                        $message .= ' <br/> <br/>';
                        $message .= 'Product Code :<b>'.$product_value.'</b><br/>';
                        $message .= 'Product Description :'.$quality_description.'<br/>';
                        $message .= 'Repair Serial No :<b>'.$repair_serial_no.'</b>&nbsp;&nbsp;&nbsp; Model No :<b>'.$repair_model_no.'</b>&nbsp;&nbsp; Tag No :<b>'.$repair_tag_no.'</b>';
                        $message .= '<br/>';
                        $message .= 'Nature of Fault :'.$repair_nature_of_fault.'<br/>';
                        $message .= 'Repair Date :'.$repair_date_to_supplier.'<br/>';
                        $message .= 'Date of Collection :'.$date_of_collection_repair.'<br/>';
                        $message .= 'Customer Comments :'.$customer_description.'<br/>';
                        $message .= ' <br/> <br/>';
                        $message .= "Thank You.<br/><br/>NAKUMATT HOLDINGS LIMITED <br />Head Office Road C,Off Enterpise Road,<br />P.O.Box 78355-00507, Nairobi, Kenya<br />Tel: +254 20 650 137/8/9,<br />";
                        $message .= "+254 733 632 130,+254 722 204 931<br />Fax: +254 20 650150<br />Email:nakumatt@nakumatt.net<br />";
                        $message .= "</body></html>";
                        $email = $customer_email;
                         //*********************************************//
                        //PDF creation 

                            // create new PDF document
                            $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

                            // set document information
                            $pdf->SetCreator(PDF_CREATOR);
                            $pdf->SetAuthor('Nakumatt');
                            $pdf->SetTitle('Customer Acknowledgment');
                            $pdf->SetSubject('Customer Acknowledgment');
                            $pdf->AddPage();

                            $headerString = "NAKUMATT HOLDINGS LIMITED <br />Head Office Road C,Off Enterpise Road,<br />P.O.Box 78355-00507, Nairobi, Kenya<br />Tel: +254 20 650 137/8/9,<br />";
                            $headerString .= "+254 733 632 130,+254 722 204 931<br />Fax: +254 20 650150<br />Email:nakumatt@nakumatt.net<br />";

                          
                            // create some HTML content
                            $html ='';$html_lbl ='';
                            $html_lbl.= '';
                           // $html_lbl .= '<table id ="header_tab_label" cellpadding="0" cellspacing="0" border="0" >';
                           // $html_lbl .= '<tr><td style="font-size:18px;">Product Details</td><td></td></tr>';
                           // $html_lbl .= '</table>';
                            //&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;BOX No 455567
                            $html .= '<table id ="header_tab" cellpadding="1" cellspacing="1" border="0" >
                                    <tr style="text-align:left;"> <td style="text-align:left;" colspan="2">Product Details<br /></td>
                                    <td style="text-align:right;"><img src="custom/modules/Cases/images/nakumatt_1.png" border="0" height="91" width="71" align="middle" /></td>
                                    <td style="text-align:left;font-size: small;" colspan="2" color="#000000">';
                            $html .= $headerString;
                            $html .= ' </td></tr></table>'; $html .= $html_lbl;
                             $html .= $message;
                            $html .= '<br /><br /><br /><br /><td align="right"><img src="custom/modules/Cases/images/nakumatt2.jpg" height="41" width="100"  /></td>';
                            // output the HTML content
                            $pdf->writeHTML($html, true, 0, true,30);

                            // set header and footer fonts
                            $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
                            $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

                            // set default monospaced font
                            $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

                            // set auto page breaks
                            $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

                            // set image scale factor
                            $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

                            // set some language-dependent strings (optional)
                            if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
                                   require_once(dirname(__FILE__).'/lang/eng.php');
                                   $pdf->setLanguageArray($l);
                            }
                            // ---------------------------------------------------------

                            // set font
                            $pdf->SetFont('helvetica', '', 9);

                            // add a page
                            $pdf->AddPage();


                            // reset pointer to the last page
                            $pdf->lastPage();


                            // ---------------------------------------------------------
                            ob_start();
                            $eol = PHP_EOL;
                            $filename = "customer_ack.pdf";
                            // close and output PDF document
                            $pdfdoc=   $pdf->Output('customer_ack.pdf', 'S');//D

                        //********************************************//
                            $cust_message =' Hi '.$customer_name .', <br /><br /> Please see the acknowledgement receipt in the attachment of the product which needs to be repaired.<br /><br />';
                            $cust_message .= "Regards,<br/>NAKUMATT HOLDINGS LIMITED <br />Head Office Road C,Off Enterpise Road,<br />P.O.Box 78355-00507, Nairobi, Kenya<br />Tel: +254 20 650 137/8/9,<br />";
                            $cust_message .= "+254 733 632 130,+254 722 204 931<br />Fax: +254 20 650150<br />Email:nakumatt@nakumatt.net<br />";

                            $attachment = chunk_split(base64_encode($pdfdoc));
                            $from =  $sugar_config['mail_from_c'];//"reports@nakumatt.net";
                            $separator = md5(time());

                            $headers  = "From: ".$from.$eol;
                            $headers .= "MIME-Version: 1.0".$eol; 
                            $headers .= "Content-Type: multipart/mixed; boundary=\"".$separator."\"".$eol.$eol; 
                            $headers .= "Content-Transfer-Encoding: 7bit".$eol;
                            $headers .= "This is a MIME encoded message.".$eol.$eol;

                            // message
                            $headers .= "--".$separator.$eol;
                            $headers .= "Content-Type: text/html; charset=\"iso-8859-1\"".$eol;
                            $headers .= "Content-Transfer-Encoding: 8bit".$eol.$eol;
                            $headers .= $cust_message.$eol.$eol;
                            // attachment
                            $headers .= "--".$separator.$eol;
                            $headers .= "Content-Type: application/octet-stream; name=\"".$filename."\"".$eol; 
                            $headers .= "Content-Transfer-Encoding: base64".$eol;
                            $headers .= "Content-Disposition: attachment".$eol.$eol;
                            $headers .= $attachment.$eol.$eol;
                            $headers .= "--".$separator."--";

                            $to =$email;
                            require_once('include/SugarPHPMailer.php'); 
                            $emailObj = new Email(); 
                            $defaults = $emailObj->getSystemDefaultEmail(); 
                            $mail = new SugarPHPMailer(); 
                            $mail->setMailerForSystem(); 
                            $mail->From = $sugar_config['mail_from_c'];//"reports@nakumatt.net";//$defaults['email']; 
							$mail->FromName = $sugar_config['mail_from_name_c'];//"Nakumat Holdings";//$defaults['name']; 
                            $mail->Subject = $subject; 
                            $mail->Body_html = from_html($cust_message);
                            //$mail->Body = wordwrap($message, 900);
                            $mail->IsHTML(true); //Omit or comment out this line if plain text
                            $mail->Body = $mail->Body_html;//$message; 
                            $mail->prepForOutbound(); 
                            $mail->AddAddress($to); 
                            $mail->AddStringAttachment($pdfdoc, 'customer_ack.pdf');
                            if (!$mail->send()) {
                              $GLOBALS['log']->info("Mailer error: " . $mail->ErrorInfo);
                           }
							
							//sms on product received MAgento configurations
							$_DateCre  = date('d M Y',strtotime($bean->date_entered)); 
							$_BranchProd = ucfirst($bean->branch_name);
							$_BranchProdVal='';
							if($_BranchProd !=''){
								$_BranchProdVal =$_BranchProd;
							}else{
								$_BranchProdVal ='submitted store';
								
							}
							
							$code ="sms_notification_to_collect_product";//from magento table
							$sql_sms_template = "SELECT variable.code,variable_value.plain_value FROM variable JOIN  variable_value WHERE variable.variable_id = variable_value.variable_id AND variable.code ='".$code."'";
							$result_sms_template = $conn->query($sql_sms_template);
							$row_sms_template = $result_sms_template->fetch_assoc();
							$code = $row_sms_template['code'];
							$plain_value = $row_sms_template['plain_value'];
							
							$_check = $this->getactualval("%s1",$plain_value);
							$collect_cheque1 = $_check[0] .$customer_name;
							
							$_check2 = $this->getactualval("%s2",$_check[1]);
							$collect_cheque2 = $_check2[0].$_DateCre;
							
							$_check3 = $this->getactualval("%s3",$_check2[1]);
							$collect_cheque3 = $_check3[0].$_BranchProdVal;
							
							$message .= $collect_cheque1."".$collect_cheque2."".$collect_cheque3;
							
							//$messages_sms = ' Dear '.$customer_name.', the product you had dropped on ('.$_DateCre.'), is now ready for collection. Please collect it from ('.$_BranchProdVal.'). Thank you Nakumatt';
							
							
                            $text_mess =$messages_sms;
                            $messages_sms = array();
                            if (!empty($customer_mobile)) {
                                $messages_sms[] = array("sender" => 'Nakumatt', "phone" => array($customer_mobile), "text" => $text_mess);
                            }

                            $smsArrayRec = array("messages" => $messages_sms);
                            $smsJson = json_encode($smsArrayRec);
                            $url = "http://192.168.0.128:8100/sms/sendBulk";
                            $ch = curl_init();
                            curl_setopt($ch, CURLOPT_URL, $url);
                            curl_setopt($ch, CURLOPT_POSTFIELDS, $smsJson);
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                            curl_setopt($ch, CURLOPT_POST, true);
                            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3000);

                            $data = curl_exec($ch);
                            if (curl_errno($ch))
                                print curl_error($ch);
                            else
                                curl_close($ch);
								
						//end of the sms
                    }
                }
            }
       }
}
?>