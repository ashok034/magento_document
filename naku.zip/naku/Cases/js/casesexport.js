//export case filter javascript functions
Calendar.setup({
    inputField: "created_on",
    form: "export_search_form",
    ifFormat: "%m/%d/%Y %I:%M%P",
    daFormat: "%m/%d/%Y %I:%M%P",
    button: "created_on_trigger",
    singleClick: true,
    dateStr: "",
    startWeekday: 0,
    step: 1,
    weekNumbers: false
});
Calendar.setup({
    inputField: "from_date",
    form: "export_search_form",
    ifFormat: "%m/%d/%Y %I:%M%P",
    daFormat: "%m/%d/%Y %I:%M%P",
    button: "from_date_trigger",
    singleClick: true,
    dateStr: "",
    startWeekday: 0,
    step: 1,
    weekNumbers: false
});
Calendar.setup({
    inputField: "to_date",
    form: "export_search_form",
    ifFormat: "%m/%d/%Y %I:%M%P",
    daFormat: "%m/%d/%Y %I:%M%P",
    button: "to_date_trigger",
    singleClick: true,
    dateStr: "",
    startWeekday: 0,
    step: 1,
    weekNumbers: false
});
function getAgentsList() {
    open_popup('Users', 600, 400, '', true, false, {"call_back_function": "set_return", "form_name": "export_search_form", "field_to_name_array": {"id": "get_agent_id", "name": "agent_id"}}, 'single', true);
}
$(document).ready(function () {
    //Validate filter form
    $('#select_all').on('click', function () {
        if (this.checked) {
            $('.checkbox').each(function () {
                this.checked = true;
            });
        } else {
            $('.checkbox').each(function () {
                this.checked = false;
            });
        }
    });
    $('.checkbox').on('click', function () {
        if ($('.checkbox:checked').length == $('.checkbox').length) {
            $('#select_all').prop('checked', true);
        } else {
            $('#select_all').prop('checked', false);
        }
    });
});