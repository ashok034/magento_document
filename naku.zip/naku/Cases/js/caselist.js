//Lookup Date
Calendar.setup({
    inputField: "lookup_date",
    ifFormat: "%Y-%m-%d %I:%M%P",
    daFormat: "%Y-%m-%d %I:%M%P",
    button: "open_calendar",
    singleClick: true,
    dateStr: "",
    startWeekday: 0,
    step: 1,
    weekNumbers: false
});
//Mouse enter submit
function submitOnEnter(e) {
    var characterCode = (e && e.which) ? e.which : event.keyCode;
    if (characterCode == 13) {
        document.getElementById('search_form').submit();
        return false;
    } else {
        return true;
    }
}
$(document).ready(function () {
    //Data Grid
   /* $('#example').DataTable({
        "paging": true,
        "bFilter": false,
        "lengthChange": false,
        "iDisplayLength": 10,//remove customer id value of Null
        "columns": [null, null, null, null, null, null, null, null, null, {"orderable": false}, {"orderable": false}, {"orderable": false}, null, {"orderable": false}]
    });*/
	
	$('#example').DataTable({
		"paging": true,
		"bFilter": false,
		"order": [[ 0, 'desc' ]],
		"lengthChange": false,
		"iDisplayLength": 50,
		"sDom": '<"top"flp><"title">lt<"top"L><"bottom"i><"top"flp>',//'<"top"flp>rt<"bottom"i><"clear">',
		"columns": [null, null, null, null, null, null, {"orderable": false}, {"orderable": false}, null, null, null, null, null, null, {"orderable": false}]
	});
			
			
    //Validate filter form
    $('#search_form').validate({
        rules: {
            lookup_type: {
                required: true
            },
            lookup_value: {
                required: true
            },
            lookup_date: {
                required: true
            }
        },
        submitHandler: function () {
            var lookup_type = $('#lookup_type').val();
            var lookup_value = $('#lookup_value').val();
            if (lookup_type == 'mobile_number') {
                //var phoneno = /^\d{10}$/;] 
				var phoneno = /^\d+$/;
				
                if (lookup_value.match(phoneno)) {
                    return true;
                } else {
                    alert("Please provide the correct mobile number.");
                    $('#lookup_value').addClass('error');
                    return false;
                }
            } else if (lookup_type == 'email_id') {
                var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
                if (lookup_value.match(mailformat)) {
                    return true;
                } else {
                    alert("Please fill in a valid email address.");
                    $('#lookup_value').addClass('error');
                    return false;
                }
            } else {
                return true;
            }
        }
    });
    //If lookup type dob then hide to lookup text box
    $("#lookup_type").change(function () {
        if ($(this).val() == "dob") {
            $("#show_lookup_date").show();
            $("#show_lookup_text").hide();
        } else {
            $("#show_lookup_date").hide();
            $("#show_lookup_text").show();
        }
    });
});