$(document).ready(function () {
    $("#search_form_submit").click(function(){ 
        if($("#from_date").val() == "" || $("#to_date").val() == "")
        {
            if($("#from_date").val() == "")
            {  
             $("#fromdateerror").html("<p>From date is required Field</p>");
            }else
            {
            $("#fromdateerror").html("");
            }
            if($("#to_date").val() == "")
            {
             $("#to_dateerror").html("<p>To date is required Field</p>");
            }
            else
            {
            $("#to_dateerror").html("");
            }

            return false;
        }
        else
        {
        return true;
        }
    }); 
});