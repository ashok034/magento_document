function CheckDate(edate){
    var fromdate = $('#from_date').val();
	if(edate != '' || fromdate !=''){
    var edtSelsArr = edate.split("/");
	var dispatchDateRep = new Date(edtSelsArr[2] , edtSelsArr[0] -1, edtSelsArr[1]);
    var pdtSelsArr = fromdate.split("/");
	var fromdate = new Date(pdtSelsArr[2] , pdtSelsArr[0] -1, pdtSelsArr[1]);
		if (dispatchDateRep < fromdate) {
		alert("End Date can not be less then Start Date");
		$('#to_date').val('');
		} 
	}
}

jQuery('#periodmonthedd').on('change', function(){
    var option = jQuery("select#periodmonthsdd").find('option:selected').val(); //from dd first option
	var ex_month = option.split("-");
	var Monthfullname = getMonthNumber(ex_month[0]); //get month number
	var Yearfullname = ex_month[1]; //get year
	var FrmMonthval = "01"+"/"+Monthfullname+"/"+Yearfullname;
	var toMonth = jQuery("select#periodmonthedd").find('option:selected').val(); //to month dd
	var to_month_explode = toMonth.split("-");
	var ToMonthfullname = getMonthNumber(to_month_explode[0]); //get month number
	var ToYearfullname = to_month_explode[1]; //get year
	var ToMonthval = "01"+"/"+ToMonthfullname+"/"+ToYearfullname;
	if(new Date(ToMonthval) < new Date(FrmMonthval)){
	alert("To Month cannot be less then From Month");
	  $('select#periodmonthedd').val("");
	 
	}
});

function getMonthNumber(monthnumber)
{
var months = {Jan: '01',Feb: '02',Mar : '03',Apr : '04',May: '05',Jun: '06',Jul : '07',Aug : '08',Sep : '09',Oct : '10', Nov : '11',Dec : '12'};
return months[monthnumber];
}

jQuery('#periodquaedd').on('change', function(){
 var option = jQuery("select#periodquasdd").find('option:selected').val(); //from quarter first option
 var ex_month = option.split("_");
 var Qstart = ex_month[0];
 var option = jQuery("select#periodquaedd").find('option:selected').val(); //from quarter last option
 var q_month = option.split("_");
 var Qend = q_month[0];
 if(new Date(Qend) < new Date(Qstart)){
	alert("To Quarter can not be less then From Quarter");
	  $('select#periodquaedd').val("");
	 
	}
});

jQuery('#getYeareDd').on('change', function(){
 var optionstartYear = jQuery("select#getYearsDd").find('option:selected').val(); //from year first option
 var Ystart = optionstartYear;
 var optionendyear = jQuery("select#getYeareDd").find('option:selected').val(); //from year last option
 var Yend = optionendyear;
 if(new Date(Yend) < new Date(Ystart)){
	alert("To Year can not be less then From Year");
	  $('select#getYeareDd').val("");
	}
});

jQuery( "#search_form_clear" ).bind( "click", function() {
 jQuery("#sub_category_id").html("<option value=''>Select</option><option value='all'>All</option>");
 jQuery(".subcatdd,.formonth,.forqua,.foryears").hide();
});

		