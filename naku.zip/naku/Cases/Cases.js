/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

function SubCat(pid) {
    if (pid == "") {
        document.getElementById("subcategory_c").innerHTML = "";
        return;
    } else {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        var url = "./ajax_functionality.php";
        url = url + "?cateory_id=" + pid;
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("subcategory_c").innerHTML = xmlhttp.responseText;
            }
        };
        xmlhttp.open("GET", url, true);
        xmlhttp.send();
    }
}

function caseHistory() {
    var number = $('#loyalty_id_c').val();
    if ($("#case_history").val() == '') {
        $("#case_history").val('');
    }
    if (number == "") {
        //document.getElementById("case_history").innerHTML = "No Record";
        return;
    } else if (number.length == 0) {
        //document.getElementById("case_history").innerHTML = "No Record";
        return;
    } else {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        var urlcase = "";
        url = urlcase + "?entryPoint=ajax_casehistory&guest=no&loyalty_id_c=" + number;

        /* var urlcase = "./ajax_casehistory.php";
         url = urlcase+"?loyalty_id_c="+number;
         */
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("casehistory").innerHTML = xmlhttp.responseText;

            }
        };
        xmlhttp.open("GET", url, true);
        xmlhttp.send();
    }

}
function SimilarCases(pid) {
    if (pid == "") {
        document.getElementById("similarcases").innerHTML = "";
        return;
    } else {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        var urlcase = "";
        url = urlcase + "?entryPoint=ajax_similarcases&simcat=" + pid;

        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("similarcases").innerHTML = xmlhttp.responseText;
            }
        };
        xmlhttp.open("GET", url, true);
        xmlhttp.send();
    }

}

$(document).ready(function () {
//SKU lookup
    $('#prod_supplier_name').attr('readonly', 'readonly').css('background-color', '#DEDEDE');
    $('#po_box').attr('readonly', 'readonly').css('background-color', '#DEDEDE');
    $('#email').attr('readonly', 'readonly').css('background-color', '#DEDEDE');
    $('#fax_no').attr('readonly', 'readonly').css('background-color', '#DEDEDE');
    $('#prod_supplier_id').attr('readonly', 'readonly').css('background-color', '#DEDEDE');

    $("#btn_prod_sku").on("click", function () {
        var prod_sku = $('#prod_sku').val();
        var base_url = window.location.origin + window.location.pathname;
        if (prod_sku != '') {
            $.ajax({
                url: base_url + '?module=Cases&entryPoint=get_supplier',
                data: {prod_sku: prod_sku, },
                type: 'post',
                dataType: 'json',
                success: function (output) {
                    var jsonstring = JSON.stringify(output);
                    var data = $.parseJSON(jsonstring);
                    if (data.flag != 0) {
                        $(data).each(function (i, val) {
                            prod_supplier_name = val.name;
                            prod_sku = val.prod_sku;
                            po_box = val.supplier_po_box;
                            email = val.supplier_email;
                            fax_no = val.supplier_fax_no;
                            prod_supplier_id = val.supplier_id;
                            $('#prod_sku').val(prod_sku).attr('readonly', 'readonly').css('background-color', '#DEDEDE');
                            $('#prod_supplier_name').val(prod_supplier_name).attr('readonly', 'readonly').css('background-color', '#DEDEDE');
                            $('#po_box').val(po_box).attr('readonly', 'readonly').css('background-color', '#DEDEDE');
                            $('#email').val(email).attr('readonly', 'readonly').css('background-color', '#DEDEDE');
                            $('#fax_no').val(fax_no).attr('readonly', 'readonly').css('background-color', '#DEDEDE');
                            $('#prod_supplier_id').val(prod_supplier_id).attr('readonly', 'readonly').css('background-color', '#DEDEDE');
                        });
                    } else {

                        alert('Data not found.');

                    }
                }
            });
        } else if (prod_sku == '') {
            alert("Please enter product sku number.");
        }
    });//SKU lookup
    //Clear supplier
    $("#btn_clr_sku").on("click", function (e) {
        e.preventDefault();
        $("#prod_sku").val("").removeAttr('readonly').css('background-color', '#FFFFFF');
        $("#prod_supplier_name").val("").attr('readonly', 'readonly').css('background-color', '#DEDEDE');
        $("#po_box").val("").attr('readonly', 'readonly').css('background-color', '#DEDEDE');
        $("#email").val("").attr('readonly', 'readonly').css('background-color', '#DEDEDE');
        $("#fax_no").val("").attr('readonly', 'readonly').css('background-color', '#DEDEDE');
        $("#prod_supplier_id").val("").attr('readonly', 'readonly').css('background-color', '#DEDEDE');
    });

    //EOC
});