<?php

if (!defined('sugarEntry') || !sugarEntry)
    die('Not A Valid Entry Point');

require_once("include/entryPoint.php");
global $current_user,$db,$sugar_config;

if (($_REQUEST['module'] == 'Cases') && (!empty($_REQUEST['record'])) && (!empty($_REQUEST['userid']))) {
	
	
    $userid = $_REQUEST['userid'];
    $record = $_REQUEST['record']; 
	$myCases = new aCase();
	$myCases->retrieve($record);
	$myCases->assigned_user_id = $userid;
	$myCases->date_modified = $sugar_config['current_sla_time'];
	$myCases->modified_user_id = $current_user->id;
	if($myCases->save()){
		SugarApplication::redirect('index.php?module=Cases');
	}
   
}
    exit;
?>
