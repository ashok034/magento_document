<?php

//if(!defined('sugarEntry'))define('sugarEntry', true);
if (!defined('sugarEntry') || !sugarEntry)
    die('Not A Valid Entry Point');
/* * *******************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 * ****************************************************************************** */
/*
 * Author: Ashok Kumar Gupta
 * Project : Get all the suppliers
 * Last Modified: 19-01-2017
 */
require_once("include/entryPoint.php");
global $current_user,$db;
if (!empty($_POST['prod_sku'])) {
    $prod_sku = $_POST['prod_sku'];
    $data = array();
    /*$sql = "SELECT name,supplier_po_box,prod_sku,supplier_email,supplier_fax_no,supplier_id "
            . "FROM naku_suppliers where deleted=0 AND prod_sku = '$prod_sku' ";
	*/
			
	 $sql = "SELECT naku_suppliers.name,naku_suppliers.supplier_po_box,naku_itemsuppliers.id as prod_sku,naku_suppliers.supplier_email,naku_suppliers.supplier_fax_no,naku_suppliers.supplier_id FROM naku_suppliers naku_suppliers join naku_itemsuppliers naku_itemsuppliers ON naku_suppliers.supplier_id = naku_itemsuppliers.supplier_id  where naku_suppliers.deleted=0 AND naku_itemsuppliers.id = '$prod_sku'";
			
			
			
    $result = $db->query($sql);
    while ($row = $db->fetchByAssoc($result)) {
        $data[] = $row;
    }
    if (count($data) > 0) {
        echo json_encode($data[0]);
    } else {
        echo json_encode(array('flag' => '0'));
    }
    exit();
}
/*
if (!empty($_POST['prod_repair_sku'])) {
    $prod_sku = $_POST['prod_repair_sku'];
    $data = array();
    $sql = "SELECT name,supplier_id,prod_sku "
            . "FROM naku_suppliers where deleted=0 AND prod_sku = '$prod_sku' ";
    $result = $db->query($sql);
    while ($row = $db->fetchByAssoc($result)) {
        $data[] = $row;
    }
    if (count($data) > 0) {
        echo json_encode($data[0]);
    } else {
        echo json_encode(array('flag' => '0'));
    }
    exit();
}
*/
    
?>
