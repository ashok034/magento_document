<?php
$viewdefs ['Cases'] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
            0 => 
          array (
            'customCode' => '<a>Action</a><input title="Action" class="button" type="button" value="Action">',
          ),
           1 => 
          array (
           'customCode' => '{$EDIT}',
          ),
            //hide close as of now
            /* 2 => 
          array (
           'customCode' => '{$CLONE}',
          ),*/
          2 => 
          array (
           'customCode' => '{$DELETE}',
          ),
          3  => 
          array (
            'customCode' => '{$ESCALATE}',
          ),
          4 => 
          array (
           'customCode' => '{$FIND_DUBLICATE}',
          ),
            ////School fees redemption dated 24-11-2016 by ashok desc: to hide the panel based on subcategory
         5 => 
          array (
            'customCode' => '{if $DISPDFCOND == "School fee redemption"}{if $CHEQUE == "show"}{$CUSTOM_PDF}{/if}{/if}',//customisation in progress by ashok on 23-11-2106
          ),
		  //change the code to display pdf based on repair Ashok Dated: 28-04-2017
          6 => 
          array (
           'customCode' => '{if $REPAIR == "repair"}{$REPAIR_DELIVER_NOTE_PDF}{/if}',
          ),
          7 => 
          array (
           'customCode' => '{if $REPAIR == "repair"}{if $COLLECTION_DATE != ""}{$CUSTOMER_ACK_PDF}{/if}{/if}',
          ),
        ),
        'enctype'=> 'multipart/form-data',
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      
      'useTabs' => false,
      'tabDefs' => 
      array (
        'LBL_CASE_INFORMATION' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL2' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
         'lbl_editview_panel_parent' => 
      array (
         0 => 
        array (
          0=> 
          array (
            'label' => 'Parent Case Number',
            'customCode' =>'{$PCASENUM}'
          ),
          1 => 
          array (
               'label' => 'LBL_CASES_CASES_1_FROM_CASES_L_TITLE_PARENT',
              'customCode' =>'{$MYPARENT}'
              ),
        /* 1 => 
          array (
            'name' => 'cases_cases_1_name',
            'type' => 'relate',
            'studio' => 'visible',
            'label' => 'LBL_CASES_CASES_1_FROM_CASES_L_TITLE_PARENT',
            'id' => 'cases_cases_1cases_ida',
            'link' => false,
            'width' => '10%',
            'default' => true,
          ),*/
        ),
      ),
      'lbl_editview_panel1' => 
      array (
         0 => 
        array (
          0 => 
          array (
            'name' => 'case_number',
            'label' => 'LBL_CASE_NUMBER',
          ),
          1 => 
          array (
            'name' => 'loyalty_id_c',
            'label' => 'LBL_LOYALTY_ID',
          ),
        ),
          
        1 => 
        array (
          0 => 
          array (
             'name' => 'member_type_c',
            'label' => 'LBL_MEMBER_TYPE',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'customer_name_c',
            'label' => 'LBL_CUSTOMER_NAME',
          ),
          1 => 
          array (
            'name' => 'member_tier_c',
            'label' => 'LBL_MEMBER_TIER',
          ),
        ),
       3 => 
        array (
           0 => 
          array (
            'name' => 'mobile_number_c',
            'label' => 'LBL_MOBILE_NUMBER',
          ),
          1 => 
          array (
            'name' => 'dob_c',
            'label' => 'LBL_DOB',
              
          ),
        ),
        4 => 
        array (
           0 => 
          array (
            'name' => 'email_c',
            'label' => 'LBL_EMAIL',
          ),
          
           1 => 
          array (
            'name' => 'gender_c',
            'label' => 'LBL_GENDER',
          ),
        ),   
      ),
        
      'lbl_case_information' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'assigned_user_name',
            'customCode' => '{$fields.assigned_user_name.value}',
            'label' => 'LBL_ASSIGNED_TO',
          ),
            1 => 'caserelation_c',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'created_by_name',
            'label' => 'LBL_CREATED',
          ),
          1 => 'priority',
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'category_c',
            'studio' => 'visible',
            'label' => 'LBL_CATEGORY',
            'customCode' => '{$CATEGORY}',
              
          ),
          1 => 
          array (
            'name' => 'subcategory_c',
            'studio' => 'visible',
            'label' => 'LBL_SUBCATEGORY',
            'customCode' => '{$SUBCATEGORY}',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'origin_c',
            'studio' => 'visible',
            'label' => 'LBL_ORIGIN',
          ),
          1 => 
          array (
            'name' => 'branch_store_name',
            'studio' => 'visible',
            'customCode' => '{$fields.branch_store_name.value}',
          ),
        ),
        4 => 
        array (
          0 => 'status',
          1 => 
          array (
               'name' => 'date_modified',
               'customCode' => '{$fields.date_modified.value} {$APP.LBL_BY} {$fields.modified_by_name.value}&nbsp;',
               'label' => 'LBL_DATE_MODIFIED',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'label' => 'LBL_SUBJECT',
          ),
          1 => 
          array (
            'name' => 'date_entered',
            'customCode' => '{$fields.date_entered.value} {$APP.LBL_BY} {$fields.created_by_name.value}',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'description',
            'comment' => 'Full text of the note',
            'label' => 'LBL_DESCRIPTION',
          ),
            
        ),
        7 => 
        array (
          0 =>
            array (
            'name' => 'resolution',
            'comment' => 'Full text of the note',
            'label' => 'LBL_RESOLUTION',
          ),
        ),
         8 => 
        array (
          0 =>
            array (
           'name'=>'filename',
           'label' => 'Upload Receipt',
           //'customCode' =>'{$IMGPPP}',
          ),
           1 => 
          array (
            'name' => 'calculate_case',
            'label' => 'LBL_CALCULATE_CASE',
          ),
        ),  
        9 => 
        array (
          0 =>
            array (
           'name'=>'resolved_date',
           'label' => 'LBL_RESOLVED_DATE',
           'customCode' => '{$fields.resolved_date.value}',
          ),
        ), 
		10 => 
        array (
          0 =>
            array (
           'name'=>'case_comments',
           'label' => 'LBL_CASE_COMMENTS',
          ),
        ), 		
      ),
      'lbl_editview_panel_school' => 
      array (
         0 => 
        array (
           0 => 
          array (
            'name' => 'school_receipt_no',
            'studio' => 'visible',
            'label' => 'LBL_SCHOOL_RECEIPT_NO',
            
          ),
          1 => 
          array (
            'name' => 'school_till_no',//'school_points_redeemed',
            'studio' => 'visible',
            'label' => 'LBL_SCHOOL_TILL_NO',//'LBL_SCHOOL_POINTS_REDEEMED',
          ),
        ),
          
        1 => 
        array (
           0 => 
          array (
            'name' => 'school_child_name',
            'studio' => 'visible',
            'label' => 'LBL_SCHOOL_CHILD_NAME',
          ),
          1 => 
          array (
            'name' => 'school_points_redeemed',
            'label' => 'LBL_SCHOOL_POINTS_REDEEMED',
          ),
        ),
        2 => 
        array (
           0 => 
          array (
            'name' => 'school_school_name',
            'studio' => 'visible',
            'label' => 'LBL_SCHOOL_SCHOOL_NAME',
          ),
          1 => 
          array (
            'name' => 'school_redemption_rate',
            'label' => 'LBL_SCHOOL_REDEMPTION_RATE',
            'customCode' => '{$fields.school_redemption_rate.value}',
          ),
        ),
        3 => 
        array (
           0 => 
          array (
            
            'name' => 'school_parent_name',
            'customCode' => '{$fields.school_parent_name.value}',
            'label' => 'LBL_SCHOOL_RARENT_NAME',
          ),
          1 => 
          array (
            'name' => 'school_amount_payable',
            'label' => 'LBL_SCHOOL_AMOUNT_PAYABLE',
          ),
        ),
      ),
      'lbl_editview_panel_cheque' => 
      array (
        0 => 
        array (
           0 => 
          array (
            'name' => 'school_cheque_status',
            'label' => 'LBL_SCHOOL_CHEQUE_STATUS',
          ),
           1 => 
          array (
            'name' => 'school_particulars',
            'label' => 'LBL_SCHOOL_PARTICULARS',
          ),
        ),
        1 => 
        array (
           0 => 
          array (
            'name' => 'school_cheque_no',
            'label' => 'LBL_SCHOOL_CHEQUE_NO',
          ),
          1 => 
          array (
            'name' => 'school_cheque_issuedate',
            'label' => 'LBL_SCHOOL_CHEQUE_ISSUE',
          ),
        ),
        2 => 
        array (
           0 => 
          array (
            'name' => 'school_cheque_dispatch',
            'label' => 'LBL_SCHOOL_DISPATCH_DATE',
          ),
          1 => 
          array (
            'name' => 'school_voucher_No',
            'label' => 'LBL_SCHOOL_VOUCHER_NO',
          ),
        ),         
      ),  
      'lbl_editview_panel_product_quality_complaint' => 
      array (
        0 => 
        array (
           0 => 
          array (
            'name' => 'product_value',
            'label' => 'LBL_PRODUCT_VALUE',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'quality_description',
            'label' => 'LBL_PRODUCT_QUALITY_DESCRIPTION',
          ),
        ),
        2 => 
        array (
           0 => 
          array (
            'name' => 'purchase_date',
            'label' => 'LBL_PURCHASE_DATE',
          ),
          1 => 
          array (
            
            'name' => 'expiry_date',
            'label' => 'LBL_EXPIRY_DATE',
          ),
        ),
        3=> 
        array (
           0 => 
          array (
            'name' => 'till_no',
            'label' => 'LBL_TILL_NO',
          ),
          1 => 
          array (
            'name' => 'receipt_no',
            'label' => 'LBL_RECEIPT_NO',
          ),
        ),
         4=> 
        array (  
           0 => 
          array (
            'name' => 'branch_name',
            'label' => 'LBL_BRANCH_NAME',
            'customCode' => '{$fields.branch_name.value}',
          ),
         ),
        5=> 
        array (
           0 => 
          array (
            'name' => 'nature_of_complaint',
            'label' => 'LBL_NATURE_OF_COMPLAINT',
          ),
        ),
      ),
      'lbl_editview_product_supplier' => 
      array (
        0 => 
        array (
           0 => 
          array (
            'name' => 'prod_sku',
            'label' => 'LBL_PROD_SKU',
          ),
          1 => 
          array (
            'name' => 'prod_supplier_name',
            'label' => 'LBL_PROD_SUPPLIER_NAME',
          ),
        ),
        1 => 
        array (
           0 => 
          array (
            'name' => 'po_box',
            'label' => 'LBL_PO_BOX',
          ),
          1 => 
          array (
            'name' => 'email',
            'label' => 'LBL_EMAIL_SUPPLIER',
          ),
        ),
        2 => 
        array (
           0 => 
          array (
            'name' => 'fax_no',
            'label' => 'LBL_FAX_NO',
          ),        
        ),
      ),
      //Action taken form 
      'lbl_editview_panel_product_actions' => 
      array ( 
        
       0=> 
        array (
         0 => 
          array (
            'name' => 'product_replaced',
            'label' => 'LBL_PRODUCT_REPLACED',
          ),
          1 => 
          array (
            'name' => 'credit_repair',
            'label' => 'LBL_CREDIT_REPAIR',
          ),
        ),
                 
        1=> 
        array (
          0 => 
          array (
            'name' => 'date_sent_to_supplier',
            'label' => 'LBL_DATE_SENT_TO_SUPPLIER',
          ),
          1 => 
          array (
            'name' => 'credit_note',
            'label' => 'LBL_CREDIT_NOTE',
          ),
        ),
        2=> 
        array (
           0 => 
          array (
            'name' => 'branch_manager_comments',
            'label' => 'LBL_BRANCH_MANAGER_COMMENTS',
          ),
        ),
      ),
      //Repair form 
      'lbl_editview_panel_product_repair' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'prod_repair_status',
            'label' => 'LBL_REPAIR_STATUS',
          ),
          1 => 
          array (
            'name' => 'repair_tag_no',
            'label' => 'LBL_REPAIR_TAG_NO',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'repair_serial_no',
            'label' => 'LBL_SERIAL_NO',
          ),
          1 => 
          array (
            'name' => 'repair_model_no',
            'label' => 'LBL_REPAIR_MODEL_NO',
          ),
        ),
        3=> 
        array (
         0 => 
          array (
            'name' => 'repair_nature_of_fault',
            'label' => 'LBL_NATURE_OF_FAULT',
          ),
        ),
        4=> 
         array (
          0 => 
           array (
             'name' => 'repair_delivery_note_no',
             'label' => 'LBL_DELIVERY_NOTE_NO',
           ),
		   1 =>'',
        ),
      ),
	  'lbl_editview_panel_supplier_info' => 
        array (
            0=> 
             array (
                0 => 
                  array (
                    'name' => 'repair_date_to_supplier',
                    'label' => 'LBL_DATE_TO_SUPPLIER',
                  ),
                1 => 
                array (
                  'name' => 'supplier_comments_repair',
                  'label' => 'LBL_SUPPLIER_COMMENTS_REPAIR',
                ),

              ),
            1=> 
             array (
              0 => 
               array (
                 'name' => 'bill_amount',
                 'label' => 'LBL_BILL_AMOUNT',
               ),
               1 => 
                  array (
                    'name' => 'customer_approved',
                    'label' => 'LBL_CUSTOMER_APPROVED',
                ),
            ), 
			2=> 
            array (
                      0 => 
                  array (
                    'name' => 'customer_approval_date',
                    'label' => 'LBL_CUSTOMER_APPROVAL_DATE',
                  ),

                 1=>array('customCode' =>'',),
            ),
			3=> 
            array (
                      0 => 
                  array (
                    'name' => 'suppliers_delivery_note_no',
                    'label' => 'LBL_SUPPLIERS_DELIVERY_NOTE_NO',
                  ),

                 1 => 
                  array (
                    'name' => 'date_of_faxed_email',
                    'label' => 'LBL_DATE_OF_FAXED_EMAIL',
                  ),
            ),
        ),
      'lbl_editview_panel_delivery_note' => 
            array (
            0=> 
            array (
              0 => 
              array (
                'name' => 'date_of_collection_repair',
                'label' => 'LBL_DATE_OF_COLLECTION',
              ),
              1 =>  
                array (
                'customCode' => '',
              ),
            ),
           1=> 
            array (
               0 => 
              array (
                'name' => 'customer_description',
                'label' => 'LBL_CUSTOMER_DESCRIPTION',
              ),
              
            ),
        ),
        //eoc  
      'lbl_editview_panel2' => 
      array (
        0 => 
        array (
          0 =>  array (
            'customCode' => '<tr id="casehistory" width="0%" ><td>{$CASEHISTORY}</td></tr>',
          ),
        ),
      ),
      'lbl_editview_panel3' => 
      array (
        0 => 
        array (
          0 =>  array (
            'customCode' => '<tr id="similarcases" width="0%" ><td>{$SIMILARCASES}</td></tr>',
          ),
           
        ),
      ),
    ),
  ),
);
?>
