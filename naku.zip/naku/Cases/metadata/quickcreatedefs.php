<?php
$viewdefs ['Cases'] = 
array (
  'QuickCreate' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'LBL_CASE_INFORMATION' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL2' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'lbl_case_information' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'case_number',
            'comment' => 'Visual unique identifier',
            'studio' => 
            array (
              'quickcreate' => false,
            ),
            'label' => 'LBL_NUMBER',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'created_by_name',
            'label' => 'LBL_CREATED',
          ),
          1 => 'priority',
        ),
        2 => 
        array (
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'origin_c',
            'studio' => 'visible',
            'label' => 'LBL_ORIGIN',
          ),
          1 => 
          array (
            'name' => 'date_entered',
            'comment' => 'Date record created',
            'label' => 'LBL_DATE_ENTERED',
          ),
        ),
        4 => 
        array (
          0 => 'status',
        ),
        5 => 
        array (
          0 => 'name',
        ),
        6 => 
        array (
          0 => 'description',
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'customer_name_c',
            'label' => 'LBL_CUSTOMER_NAME',
          ),
          1 => 
          array (
            'name' => 'loyalty_id_c',
            'label' => 'LBL_LOYALTY_ID',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'mobile_number_c',
            'label' => 'LBL_MOBILE_NUMBER',
          ),
          1 => 
          array (
            'name' => 'member_tier_c',
            'label' => 'LBL_MEMBER_TIER',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'email_c',
            'label' => 'LBL_EMAIL',
          ),
          1 => 
          array (
            'name' => 'dob_c',
            'label' => 'LBL_DOB',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'gender_c',
            'label' => 'LBL_GENDER',
          ),
          1 => 
          array (
            'name' => 'point_balance_c',
            'label' => 'LBL_POINT_BALANCE',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'member_type_c',
            'label' => 'LBL_MEMBER_TYPE',
          ),
          1 => 
          array (
            'name' => 'points_expired_c',
            'label' => 'LBL_POINTS_EXPIRED',
          ),
        ),
      ),
    ),
  ),
);
?>
