<?php
$searchdefs ['Cases'] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'customer_name_c' => 
      array (
        'name' => 'customer_name_c',
        'default' => true,
        'width' => '10%',
      ),
        'search_c' => 
        array (
          'type' => 'enum',
          'label' => 'Search',
          'width' => '10%',
          'default' => true,
          'name' => 'search_c',
          'displayParams' => array(
              'size' => 1, 
           ),
        ),
         'input_field_c' => 
            array (
              'name' => 'input_field_c',
              'default' => true,
              'width' => '10%',
            ),
        
    ),
     'advanced_search' => 
   array (
     /*'case_number' => 
      array (
        'name' => 'case_number',
        'default' => true,
        'width' => '10%',
      ),
      'created_by' => 
      array (
        'type' => 'assigned_user_name',
        'label' => 'LBL_CREATED',
        'width' => '10%',
        'default' => true,
        'name' => 'created_by',
      ),
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'status' => 
      array (
        'name' => 'status',
        'default' => true,
        'width' => '10%',
      ),
      'priority' => 
      array (
        'name' => 'priority',
        'default' => true,
        'width' => '10%',
      ),
      'origin_c' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_ORIGIN',
        'width' => '10%',
        'name' => 'origin_c',
      ),
      'member_type_c' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_MEMBER_TYPE',
        'width' => '10%',
        'name' => 'member_type_c',
      ),
      'current_user_only' => 
      array (
        'label' => 'LBL_CURRENT_USER_FILTER',
        'type' => 'bool',
        'default' => true,
        'width' => '10%',
        'name' => 'current_user_only',
      ),*/
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
