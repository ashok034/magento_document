<?php
$viewdefs ['Cases'] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
        'form' => array('enctype'=> 'multipart/form-data',
                                            ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
        'includes' =>
      array (
            0 => array ( 'file' => 'custom/modules/Cases/Cases.js', ),
            1 => array ( 'file' => 'custom/modules/Cases/validations.js', ),
        ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'LBL_CASE_INFORMATION' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL2' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'member_type_c',
            'label' => 'LBL_MEMBER_TYPE',
          ),
          1 => 
          array (
            'name' => 'loyalty_id_c',
            'label' => 'LBL_LOYALTY_ID',
            'customCode'=>'<input type="text" name="loyalty_id_c" id="loyalty_id_c" value ="{$fields.loyalty_id_c.value}" title="" onblur="caseHistory();">',
          ),
         
        ), 
        1 => 
        array (
           0 => 
          array (
            'name' => 'customer_name_c',
            'label' => 'LBL_CUSTOMER_NAME',
          ),
          1 => 
          array (
		    'name' => 'mobile_number_c',
            'label' => 'LBL_MOBILE_NUMBER',
            'customCode'=>' <input type="text" name="mobile_number_c" id="mobile_number_c" size="30" value="{$fields.mobile_number_c.value}" title="" onblur="mobile_number(this.value);" placeholder="Enter Mobile Number with ISD code">',
			
           
          ),
        ),
        2 => 
        array (
          0 => 
          array (
             'name' => 'member_tier_c',
            'label' => 'LBL_MEMBER_TIER',
          ),
          1 => 
          array (
			'name' => 'email_c',
            'label' => 'LBL_EMAIL',
            'customCode'=>' <input type="text" name="email_c" id="email_c" size="30" maxlength="255" value="{$fields.email_c.value}" title="" >',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
           'name' => 'dob_c',
            'label' => 'LBL_DOB',
            'displayParams' =>
                array (
                    'field' =>
                    array (
                            'onchange' => 'birthdate_validation(this.value);',
                    ),
                ),
          ),          
           1 => 
          array (
            'name' => 'gender_c',
            'label' => 'LBL_GENDER',
          ),
        ), 
        4 => 
        array (
          0 => '',
          1 => 
          array (
            'customCode'=>' <input type="button" name="btn_customer" id="btn_email" class="btn_customer" tabindex="0" title="Select Email" class="button firstChild" value="Customer Lookup" style="align:right;"/>
                            <button type="button" name="btn_clr" id="btn_clr" tabindex="0" title="Clear User" class="button btn_clr lastChild" value="Clear User">Clear</button>',
          ),
        ),  
          
      ),
      'lbl_case_information' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'case_number',
            'type' => 'readonly',
          ),  
        ),
        1 => 
        array (
          0 => 
          array (
           'name' => 'assigned_user_name',
           'label' => 'LBL_ASSIGNED_TO_NAME',   
			//make field auto populate form users @Ashok Dated: 20-04-2017
           'displayParams' => 
          array (
             'field_to_name_array' => array (
				 'id'=>'assigned_user_id',
				 'name' => 'assigned_user_name',
				 'user_origin' => 'origin_c',
				 'user_branch_store' => 'branch_store_name',
             ),
           ),
          ),
          1 => 'priority',
        ),
        /*
        * Author: Ashok Kumar Gupta
        * Date Created: 06-10-2016
        * Project : Create Case
        * Description: show dynamic and dependent drop down for category and subcategory
        */
        2 => 
        array (
          0 => 
          array (
            'name' => 'category_c',
            'studio' => 'visible',
            'label' => 'LBL_CATEGORY',
			'customCode' => '<select name="category_c" id="category_c"  title="" tabindex="s" onchange="SubCat(this.value);" value="{$fields.category_c.value}">{$CATEGORY}</select>',
          ),
          1 => 
          array (
            'name' => 'subcategory_c',
            'studio' => 'visible',
            'label' => 'LBL_SUBCATEGORY',
			'customCode' => '<select name="subcategory_c" id="subcategory_c" title="" tabindex="s" onchange="SimilarCases(this.value);school_fees_redemption(this.value);" value="{$fields.subcategory_c.value}">{$SUBCATEGORY}</select>',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'origin_c',
            'studio' => 'visible',
            'label' => 'LBL_ORIGIN',
          ),
          1 => 
          array (
            'name' => 'branch_store_name',
            'comment' => 'branch name stored',
            'label' => 'LBL_BRANCH_STORE_NAME',
          ),
        ),
        4 => 
        array (
          0 => 'status',
          1 => 'caserelation_c',
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'name',
			'displayParams'=>array('maxlength'=>64),
            
          ),          
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'description',
            'comment' => 'Full text of the note',
            'label' => 'LBL_DESCRIPTION',
            'displayParams'=>array('rows'=>10, 'cols'=>150),
          ),
        ),
        7 => 
        array (
          0 =>
            array (
            'name' => 'resolution',
            'comment' => 'Full text of the note',
            'label' => 'LBL_RESOLUTION',
            'displayParams'=>array('rows'=>10, 'cols'=>150),
          ),
        ),
         8 => 
        array (
          0 =>
            array (
           'name'=>'filename',
           'label' => 'Upload Receipt',
          ),
          1 =>
            array (
           'customCode'=>'<input type="hidden" name="school_branch_country" id="school_branch_country" value="{$fields.school_branch_country.value}"/>',
          ),
        ),  
		9 => 
        array (
          0 =>
            array (
			   'name'=>'case_comments',
			   'label' => 'LBL_CASE_COMMENTS',
          ),
        ),  
      ),
      'lbl_editview_panel_school' => 
      array (
         0 => 
        array (
           0 => 
          array (
             'name' => 'school_receipt_no',
            'label' => 'LBL_SCHOOL_RECEIPT_NO',
            
          ),
          1 => 
          array (
            'name' => 'school_till_no',//'school_points_redeemed',
            'label' => 'LBL_SCHOOL_TILL_NO',//'LBL_SCHOOL_POINTS_REDEEMED',
          ),
        ),
        1 => 
        array (
           0 => 
          array (
             'name' => 'school_child_name',
            'label' => 'LBL_SCHOOL_CHILD_NAME',
            
          ),
          1 => 
          array (
            'name' => 'school_points_redeemed',
            'label' => 'LBL_SCHOOL_POINTS_REDEEMED',
          ),
        ),
        2 => 
        array (
           0 => 
          array (
            'name' => 'school_school_name',
            'label' => 'LBL_SCHOOL_SCHOOL_NAME',
          ),
          1 => 
          array (
              
            'name' => 'school_redemption_rate',
            'label' => 'LBL_SCHOOL_REDEMPTION_RATE',
            'customCode' => '<select type="text" name="school_redemption_rate" id="school_redemption_rate"><option value={$REDEMTION_RATE_SAVED}>{$REDEMTION_RATE_SAVED}</option></select>',
          ),
        ),
        3 => 
        array (
           0 => 
          array (
           'name' => 'school_parent_name',
            'label' => 'LBL_SCHOOL_RARENT_NAME',
          ),
          1 => 
          array (
            'name' => 'school_amount_payable',
            'label' => 'LBL_SCHOOL_AMOUNT_PAYABLE',
          ),
        ),
          
      ),
      'lbl_editview_panel_cheque' => 
      array (
        0 => 
        array (
           0 => 
          array (
            'name' => 'school_cheque_status',
            'label' => 'LBL_SCHOOL_CHEQUE_STATUS',
          ),
          1 => array(
              'customCode' => '',
          ),
        ),
        1 => 
        array (
           0 => 
          array (
            'name' => 'school_cheque_no',
            'label' => 'LBL_SCHOOL_CHEQUE_NO',
          ),
          1 => array(
              'customCode' => '',
          ),
        ),
       2 => 
        array (
           0 => 
          array (
            'name' => 'school_cheque_issuedate',
            'label' => 'LBL_SCHOOL_CHEQUE_ISSUE',
          ),
          1 => array(
              'customCode' => '',
          ),
        ),
       3 => 
        array (
          0 => 
          array (
            'name' => 'school_voucher_No',
            'label' => 'LBL_SCHOOL_VOUCHER_NO',
          ),
          1 => array(
              'customCode' => '',
          ),
        ),
        4 => 
        array (
           0 => 
          array (
            'name' => 'school_particulars',
            'label' => 'LBL_SCHOOL_PARTICULARS',
          ),
          1 => array(
              'customCode' => '',
          ),
        ),
        5 => 
        array (
           0 => 
          array (
            'name' => 'school_cheque_dispatch',
            'label' => 'LBL_SCHOOL_DISPATCH_DATE',
            'displayParams' =>
             array (
                 'field' =>
                 array (
                         'onchange' => 'chequeDispatchDateVal(this.value);',
                 ),
             ),
              
          ),
          1 => array(
              'customCode' => '',
          ),   
        ),
          
      ),
        //product complaint form
      'lbl_editview_panel_product_quality_complaint' => 
      array (
        0 => 
        array (
           0 => 
          array (
            'name' => 'product_value',
            'label' => 'LBL_PRODUCT_VALUE',
          ),
          1 => 
          array (
            'customCode'=>'',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'quality_description',
            'label' => 'LBL_PRODUCT_QUALITY_DESCRIPTION',
          ),
        ),
        2 => 
        array (
           0 => 
          array (
            'name' => 'purchase_date',
            'label' => 'LBL_PURCHASE_DATE',
            'displayParams' =>
                array (
                    'field' =>
                    array (
                            'onchange' => 'purchaseDateVal(this.value);',
                    ),
                ),
          ),
          1 => 
          array (
            
            'name' => 'expiry_date',
            'label' => 'LBL_EXPIRY_DATE',
            /*'displayParams' =>
             array (
                 'field' =>
                 array (
                         'onchange' => 'expiryDateVal(this.value);',
                 ),
             ),*/
              
          ),
        ),
        3=> 
        array (
           0 => 
          array (
            'name' => 'till_no',
            'label' => 'LBL_TILL_NO',
          ),
          1 => 
          array (
            'name' => 'receipt_no',
            'label' => 'LBL_RECEIPT_NO',
          ),
        ),
        4=> 
        array (  
           0 => 
          array (
            'name' => 'branch_name',
            'label' => 'LBL_BRANCH_NAME',
          ),
          1=>array('customCode' =>'',),
         ),
        5=> 
        array (
           0 => 
          array (
            'name' => 'nature_of_complaint',
            'label' => 'LBL_NATURE_OF_COMPLAINT',
          ),
        ),
        
      ),   
        //supplier details
       'lbl_editview_product_supplier' => 
      array (
        0 => 
        array (
           0 => 
          array (
            'name' => 'prod_sku',
            'label' => 'LBL_PROD_SKU',
            'customCode'=>' <input type="text" name="prod_sku" id="prod_sku" value ="{$fields.prod_sku.value}";>
                           <input type="button" name="btn_prod_sku" id="btn_prod_sku" class="btn_prod_sku" tabindex="0" title="Select SKU"  value="Supplier Lookup" />
                           <button type="button" name="btn_clr_sku" id="btn_clr_sku" tabindex="0" title="Clear SKU"  value="Clear SKU">Clear</button>',
          
              
          ),
          1 => 
          array (
            'name' => 'prod_supplier_name',
            'label' => 'LBL_PROD_SUPPLIER_NAME',
          ),
        ),
        1 => 
        array (
           0 => 
          array (
            'name' => 'po_box',
            'label' => 'LBL_PO_BOX',
          ),
          1 => 
          array (
            'name' => 'email',
            'label' => 'LBL_EMAIL_SUPPLIER',
          ),
        ),
        2 => 
        array (
           0 => 
          array (
            'name' => 'fax_no',
            'label' => 'LBL_FAX_NO',
          ),  
           1 => 
          array (
            'name' => 'prod_supplier_id',
            'label' => 'Supplier ID',
            'customCode'=>' <input type="text" name="prod_supplier_id" id="prod_supplier_id" value ="{$fields.prod_supplier_id.value}";>',
          ), 
        ),
      ),
       //Action taken form 
      'lbl_editview_panel_product_actions' => 
      array ( 
       0=> 
        array (
         0 => 
          array (
            'name' =>'product_replaced',
            'label' =>'LBL_PRODUCT_REPLACED',
          ),
          1 => 
          array (
            'name' =>'credit_repair',
            'label' =>'LBL_CREDIT_REPAIR',
          ),
        ),
                 
        1=> 
        array (
          0 => 
          array (
            'name' =>'date_sent_to_supplier',
            'label' =>'LBL_DATE_SENT_TO_SUPPLIER',
            'displayParams' =>
             array (
                 'field' =>
                 array (
                         'onchange' => 'sentToSupplierDateVal(this.value);',
                 ),
             ),
          ),
          1 => 
          array (
            'name' =>'credit_note',
            'label' => 'LBL_CREDIT_NOTE',
          ),
        ),
        2=> 
        array (
           0 => 
          array (
            'name' => 'branch_manager_comments',
            'label' => 'LBL_BRANCH_MANAGER_COMMENTS',
          ),
        ),
      ),
      //Repair form 
      'lbl_editview_panel_product_repair' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'prod_repair_status',
            'label' => 'LBL_REPAIR_STATUS',
          ),
          1 => 
          array (
            'name' => 'repair_tag_no',
            'label' => 'LBL_REPAIR_TAG_NO',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'repair_serial_no',
            'label' => 'LBL_SERIAL_NO',
          ),
          1 => 
          array (
            'name' => 'repair_model_no',
            'label' => 'LBL_REPAIR_MODEL_NO',
            ),
          ),
        2=> 
        array (
         0 => 
          array (
            'name' => 'repair_nature_of_fault',
            'label' => 'LBL_NATURE_OF_FAULT',
          ),
        ),
              
        3=> 
            array (
                0 => 
                array (
                  'name' => 'repair_delivery_note_no',
                  'label' => 'LBL_DELIVERY_NOTE_NO',
                ),
            ),
        ),  
		'lbl_editview_panel_supplier_info' => 
        array (
            0=> 
              array (
                0 => 
                  array (
                    'name' => 'repair_date_to_supplier',
                    'label' => 'LBL_DATE_TO_SUPPLIER',
                  ),
                1 => 
                array (
                  'name' => 'supplier_comments_repair',
                  'label' => 'LBL_SUPPLIER_COMMENTS_REPAIR',
                ),

              ),
            1=> 
              array (
                 0 => 
                array (
                  'name' => 'bill_amount',
                  'label' => 'LBL_BILL_AMOUNT',
                ),
                1 => 
                array (
                  'name' => 'customer_approved',
                  'label' => 'LBL_CUSTOMER_APPROVED',
                ),
              ),
			2=> 
              array (
                 0 => 
                array (
                  'name' => 'customer_approval_date',
                  'label' => 'LBL_CUSTOMER_APPROVAL_DATE',
                ),
                1 => array('customCode'=>'',),
              ),
            3=> 
              array (
                    0 => 
                array (
                  'name' => 'suppliers_delivery_note_no',
                  'label' => 'LBL_SUPPLIERS_DELIVERY_NOTE_NO',
                ),

                1 => 
                array (
                  'name' => 'date_of_faxed_email',
                  'label' => 'LBL_DATE_OF_FAXED_EMAIL',
                ),
            ),
        ),  
        'lbl_editview_panel_delivery_note' => 
            array (  
            0=> 
            array (
               0 => 
              array (
                'name' => 'customer_description',
                'label' => 'LBL_CUSTOMER_DESCRIPTION',
              ),
            ),
            1=> 
            array (
               0 => 
              array (
                'name' => 'date_of_collection_repair',
                'label' => 'LBL_DATE_OF_COLLECTION',
              ),
              1 => array('customCode'=>'',),
            ),
        ), 
      'lbl_editview_panel2' => 
      array (
        0 => 
        array (
          0 =>  array (
            'customCode' => '<tr id="casehistory" width="0%" ><td>{$AACASEHISTORYS}</td></tr>',
          ),
           
        ),
      ),
      'lbl_editview_panel3' => 
      array (
        0 => 
        array (
          0 =>  array (
            'customCode' => '<tr id="similarcases" name="similarcases" width="0%" ><td>{$SIMILARCASES}</td></tr>',
          ),
        ),
      ),
    ),
  ),
);
?>
