<?php
$listViewDefs ['Cases'] = 
array (
  'CASE_NUMBER' => 
  array (
    'width' => '5%',
    'label' => 'LBL_LIST_NUMBER',
    'default' => true,
	'link' => true,
  ),
    
  'CASERELATION_C' => 
  array (  
    'type' => 'varchar',
    'default' => true,
    'label' => 'LBL_CASES_RELATIONSHIP_C',
    'link' => false,
    'sortable' => false,
    'width' => '10%',
  ),
  'CUSTOMER_NAME_C' => 
  array (
    'type' => 'varchar',
    'default' => true,
	'link' => true,
    'label' => 'LBL_CUSTOMER_NAME',
    'width' => '10%',
  ),
    
    /*'cases_cases_1_name' =>   array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_CASES_CASES_1_FROM_CASES_L_TITLE',
    'id' => 'cases_cases_1cases_ida',
    'link' => true,
    'width' => '10%',
    'default' => true,
        
  ),*/
    
  'NAME' => 
  array (
    'width' => '20%',
    'label' => 'LBL_LIST_SUBJECT',
    'link' => true,
    'default' => false,
  ),
  'CATEGORY_C' => 
  array (
    'default' => true,
    'label' => 'LBL_CATEGORY',
    //'link' => true,
    'width' => '10%',
  ),
  'SUBCATEGORY_C' => 
  array (
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_SUBCATEGORY',
    //'link' => true,
    'width' => '10%',
  ),
  'ORIGIN_C' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_ORIGIN',
    'width' => '10%',
  ),
  'PRIORITY' => 
  array (
    'width' => '10%',
    'label' => 'LBL_LIST_PRIORITY',
    'default' => true,
  ),
  'STATUS' => 
  array (
    'width' => '10%',
    'label' => 'LBL_LIST_STATUS',
    'default' => true,
  ),
  'CREATED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_CREATED',
    'id' => 'CREATED_BY',
    'width' => '10%',
    'default' => true,
  ),
  'DATE_ENTERED' => 
  array (
    'width' => '10%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => true,
  ),
  'EMAIL_C' => 
  array (
    'type' => 'varchar',
    'default' => true,
    'label' => 'LBL_EMAIL',
    'width' => '10%',
  ),
  'MOBILE_NUMBER_C' => 
  array (
    'type' => 'varchar',
    'default' => true,
    'label' => 'LBL_MOBILE_NUMBER',
    'width' => '10%',
  ),
  'MEMBER_TIER_C' => 
  array (
    'type' => 'varchar',
    'default' => true,
    'label' => 'LBL_MEMBER_TIER',
    'width' => '10%',
  ),
  'MEMBER_TYPE_C' => 
  array (
    'type' => 'varchar',
    'default' => false,
    'label' => 'LBL_MEMBER_TYPE',
    'width' => '10%',
  ),
  'LOYALTY_ID_C' => 
  array (
    'type' => 'varchar',
    'default' => false,
    'label' => 'LBL_LOYALTY_ID',
    'width' => '10%',
  ),
  'POINTS_EXPIRED_C' => 
  array (
    'type' => 'varchar',
    'default' => false,
    'label' => 'LBL_POINTS_EXPIRED',
    'width' => '10%',
  ),
);
?>
