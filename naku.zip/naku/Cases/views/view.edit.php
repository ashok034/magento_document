<?php
if (!defined('sugarEntry') || !sugarEntry)
    die('Not A Valid Entry Point');

/* * *******************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 * ****************************************************************************** */
//off error reporting only notice
error_reporting(error_reporting() & ~E_NOTICE);
ini_set("display_errors",0);
class CasesViewEdit extends ViewEdit {

    //Prepopulate parent customer details in child case
    function preDisplay() {
        parent::preDisplay();
        $parentId = isset($_REQUEST['parent_id']) ? $_REQUEST['parent_id'] : '';
        echo'<input type="hidden" id="parent_record_id" value="'.$parentId.'">';
        $parentType = isset($_REQUEST['parent_type']) ? $_REQUEST['parent_type'] : '';
        //to check if the case is child or parent
        $sqlRel = "SELECT count(id) as total FROM `cases_cases_1_c` where cases_cases_1cases_ida ='" . $parentId . "' AND deleted=0 ";
        $result = $GLOBALS['db']->query($sqlRel, false);
        $row = $GLOBALS['db']->fetchByAssoc($result);
        $total = $row['total'];
        //to redirect to parent detail view page 
        if ($total > 0) {
            $queryParams = array(
                'module' => 'Cases',
                'action' => 'DetailView',
                'message' => 1,
                'record' => $parentId,
            );
            //redirect
            SugarApplication::redirect('index.php?' . http_build_query($queryParams));
        }
		
		
        //check if record is set for parent for Cases module
        if (isset($parentId) && $parentType == 'Cases') {
            $focus = new aCase();
            $focus->retrieve($parentId);
            $focus->name = isset($focus->name) ? $focus->name : '';
            $this->bean->member_type_c = $focus->member_type_c;
            $this->bean->loyalty_id_c = $focus->loyalty_id_c;
            $this->bean->customer_name_c = $focus->customer_name_c;
            $this->bean->member_tier_c = $focus->member_tier_c;
            $this->bean->mobile_number_c = $focus->mobile_number_c;
            $this->bean->dob_c = $focus->dob_c;
            $this->bean->email_c = $focus->email_c;
            $this->bean->gender_c = $focus->gender_c;
            $this->bean->date_entered = $focus->date_entered;
            $this->bean->caserelation_c = 'Child';
            //Validation to auto display case history
            if ($focus->loyalty_id_c == 'Guest') {
                echo '<script type="text/javascript" >
                    $(document).ready(function(){	
                        $("#category_c").focus();
                        //Make field non-mandatory for guest user 
                         removeFromValidate("EditView","mobile_number_c");
                         $("#mobile_number_c_label").html("Mobile Number:");
                    });
                     </script>';
            } else {
                echo '<script type="text/javascript" >
                    $(document).ready(function(){	
                        $("#loyalty_id_c").focus();
                        $("#category_c").focus();
                    });
                     </script>';
            }
            //on child create set priority to High for Gold customers
            if ($focus->member_tier_c == 'Gold') {
                echo '<script type="text/javascript" >  
                      $(document).ready(function(){	
                        $("#priority").val("P1");
                      });
                     </script>';
            }
        }
    }

    public function display() {

        
        $this->bean->name = isset($this->bean->name) ? $this->bean->name : '';
        //Display current user and assign the same 
        global $current_user, $app_list_strings, $mod_strings, $sugar_config;
        $myUser = new User(); //users bean
        //
      //  echo "<pre>";print_r($_REQUEST);exit;
        //display alert message validation on close of parent cases till child class is closed
        if (!empty($_REQUEST['message'])) {
            if ($_REQUEST['message'] == 1 && !empty($_REQUEST['record'])) {
                echo '<script type="text/javascript" >
                     $(document).ready(function(){ 
                                     alert("Child case needs to be resolved before parent case");			 
                     });
                     </script>';
            }
        }
         //remove validation of mobile number for Guest users
        if ($this->bean->loyalty_id_c == 'Guest') {
            echo '<script type="text/javascript" >
                $(document).ready(function(){
                     removeFromValidate("EditView","mobile_number_c");
                     $("#mobile_number_c_label").html("Mobile Number:");

                });
                 </script>';
        }
        
        //Display current user and assign the same to assigned field 
        if(!isset($this->bean->id)){
            $curr_user = $current_user->id;
            $curr_user_name = $current_user->name;
            $this->bean->created_by_name = $curr_user_name;
            $this->bean->created_by = $curr_user;
			
			$this->bean->origin_c = $GLOBALS['app_list_strings']['origin_list'];
				
			
        }
		//Save siteurl in hidden field @ Ashok on 22-08-2017
		$siturl = $sugar_config['site_url'];
		echo '<input type="hidden" name="siteurl" id="siteurl" value="'.$siturl.'">';
		
		
        //display branch names 
        $storeDetail = $this->view_object_map['edit'];
        $branch_name = array(''=>'Select');
        foreach($storeDetail as $k=>$v ){
           // $res = preg_replace("/[^a-zA-Z0-9]/", "", $v['branch_name']); //remove special character coming
            $branch_name[$v['branch_name']]=$v['branch_name'];
        }
        if( (!empty($this->bean->branch_store_name)) && ($this->bean->branch_store_name !='')) { 
                  $GLOBALS['app_list_strings']['store_branch_name'] =$this->bean->branch_store_name;
        }else{ 
            $GLOBALS['app_list_strings']['store_branch_name'] = $branch_name; //to fetch the store branch name
        }
      // $GLOBALS['app_list_strings']['store_branch_name'] = $branch_name; //to fetch the store branch name
		
		//users auto populate the fields @Ashok@dated:30-05-2017
		$myUser = new User();
		$myUser->retrieve($current_user->id);
	    if( $myUser->user_origin == 2){		
					$this->bean->origin_c = '2';
				    $this->bean->branch_store_name = $myUser->user_branch_store; 
		}else if( $myUser->user_origin == 3){	
				$this->bean->origin_c = '3';
			   //$this->bean->branch_store_name = $myUser->user_branch_store; 
		}
        //EOC for the users autopopulate
       $GLOBALS['app_list_strings']['supplier_branch_list'] = $branch_name;//to change the dropdown value for branch name
       echo '<style type="text/css">
                #create_link, #create_image{display:none;} 
                div#loading_image_clookup {
                    position: fixed;
                    right: 0;
                    top: 0;
                    left: 0;
                    bottom: 0;
                    background: rgba(0,0,0,0.5);
                    z-index: 9999;
                    text-align:center;
                 }
                 #loading_image_clookup img {
                    position: absolute;
                    top: 50%;
                    left: 50%;
                 }
            </style>
            <div id="loading_image_clookup" style="display:none;">
                <img src="themes/Sugar5/images/img_loading.gif" />
            </div>'; //to hide create link
        //validations - Make field mandatory and non mandatory based on member type
        $jsscript = <<<EOQ
            <script>
                $(document).ready(function(){
                        var parent_record_id = $('#parent_record_id').val();
                        var memeber_type_val = $('#member_type_c').val(); //Hide customer lookup for child and gust member
                        if(parent_record_id !='' || memeber_type_val == 'guest'){
                            $("#member_type_c").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                            $("#customer_name_c").attr("readonly","readonly").css("background-color","#DEDEDE");
                            $("#mobile_number_c").attr("readonly","readonly").css("background-color","#DEDEDE");
                            $("#email_c").attr("readonly","readonly").css("background-color","#DEDEDE");
                            $("#loyalty_id_c").attr("readonly","readonly").css("background-color","#DEDEDE");
                            $("#member_tier_c").attr("readonly","readonly").css("background-color","#DEDEDE");
                            $("#dob_c").attr("readonly","readonly").css("background-color","#DEDEDE");
                            $("#gender_c").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                            $("#dob_c_trigger").hide();
                            $(".btn_customer").hide();
                            $(".btn_clr").hide();
                        }  
                        $('#member_type_c').focus();//Focus on dropdown
                        $('#caserelation_c').prop('readonly',true);
                        $('#caserelation_c').css('background-color' , '#DEDEDE');    
                        $('#member_tier_c').prop('readonly',true);
                        $('#member_tier_c').css('background-color' , '#DEDEDE'); 
						
						$('#loyalty_id_c').css('background-color' , 'orange');
						$('#mobile_number_c').css('background-color' , 'orange');
						$('#email_c').css('background-color' , 'orange');
						
                        $('#member_type_c').change(function() {
                                memberType(); 
                        });

                        //Start 22/12/2016 - Ashok for product repir
                        if($('#prod_repair_status').val() == 'InProgress'){
                                  //$("#LBL_EDITVIEW_PANEL_PRODUCT_RECEIVED").hide();
									$("#detailpanel_9").hide();   
									$("#detailpanel_10").hide();  

                                removeFromValidate('EditView','date_of_collection_repair');
                                $('#date_of_collection_repair_label').html('{$mod_strings['LBL_DATE_OF_COLLECTION']}: ');
                                removeFromValidate('EditView','repair_date_to_supplier');
                                $('#repair_date_to_supplier_label').html('{$mod_strings['LBL_DATE_TO_SUPPLIER']}: ');

                                removeFromValidate('EditView','supplier_comments_repair');
                                $('#supplier_comments_repair_label').html('{$mod_strings['LBL_SUPPLIER_COMMENTS_REPAIR']}: ');

                                removeFromValidate('EditView','customer_approval_date');
                                $('#customer_approval_date_label').html('{$mod_strings['LBL_CUSTOMER_APPROVAL_DATE']}: ');
                                removeFromValidate('EditView','bill_amount');
                                $('#bill_amount_label').html('{$mod_strings['LBL_BILL_AMOUNT']}: ');
                               // removeFromValidate('EditView','suppliers_delivery_note_no');
                               // $('#suppliers_delivery_note_no_label').html('{$mod_strings['LBL_SUPPLIERS_DELIVERY_NOTE_NO']}: ');
                               // removeFromValidate('EditView','date_of_faxed_email');
                                //$('#date_of_faxed_email_label').html('{$mod_strings['LBL_DATE_OF_FAXED_EMAIL']}: ');

                                $("#resolution_label").hide();
                                $("#resolution").hide();
                                

                        }if($('#prod_repair_status').val() == 'Recieved'){ 
								$("#resolution_label").hide();
                                $("#resolution").hide();
                               $("#LBL_EDITVIEW_PANEL_PRODUCT_RECEIVED").show();
                               $("#detailpanel_9").show();  
							   $("#detailpanel_10").hide();

                               // addToValidate('EditView','date_of_collection_repair','varchar',true,'{$mod_strings['LBL_DATE_OF_COLLECTION']}');   
								 removeFromValidate('EditView','date_of_collection_repair');
                                $('#date_of_collection_repair_label').html('{$mod_strings['LBL_DATE_OF_COLLECTION']}: ');
								
                                $('#date_of_collection_repair_label').html('{$mod_strings['LBL_DATE_OF_COLLECTION']}: <font color="red">*</font>');
                                addToValidate('EditView','repair_date_to_supplier','varchar',true,'{$mod_strings['LBL_DATE_TO_SUPPLIER']}');                           
                                $('#repair_date_to_supplier_label').html('{$mod_strings['LBL_DATE_TO_SUPPLIER']}: <font color="red">*</font>');
                                addToValidate('EditView','supplier_comments_repair','varchar',true,'{$mod_strings['LBL_SUPPLIER_COMMENTS_REPAIR']}');                           
                                $('#supplier_comments_repair_label').html('{$mod_strings['LBL_SUPPLIER_COMMENTS_REPAIR']}: <font color="red">*</font>');
                                addToValidate('EditView','customer_approval_date','varchar',true,'{$mod_strings['LBL_CUSTOMER_APPROVAL_DATE']}');                           
                                $('#customer_approval_date_label').html('{$mod_strings['LBL_CUSTOMER_APPROVAL_DATE']}: <font color="red">*</font>');
                                addToValidate('EditView','bill_amount','varchar',true,'{$mod_strings['LBL_BILL_AMOUNT']}');                           
                                $('#bill_amount_label').html('{$mod_strings['LBL_BILL_AMOUNT']}: <font color="red">*</font>');
                                //addToValidate('EditView','suppliers_delivery_note_no','varchar',true,'{$mod_strings['LBL_SUPPLIERS_DELIVERY_NOTE_NO']}');                           
                               // $('#suppliers_delivery_note_no_label').html('{$mod_strings['LBL_SUPPLIERS_DELIVERY_NOTE_NO']}: <font color="red">*</font>');
                               // addToValidate('EditView','date_of_faxed_email','varchar',true,'{$mod_strings['LBL_DATE_OF_FAXED_EMAIL']}');                           
                               // $('#date_of_faxed_email_label').html('{$mod_strings['LBL_DATE_OF_FAXED_EMAIL']}: <font color="red">*</font>');
							   
								
                                                               
                        }if($('#prod_repair_status').val() == 'Delivered'){ 
                               $("#LBL_EDITVIEW_PANEL_PRODUCT_RECEIVED").show();
                               $("#detailpanel_9").show();  
							   $("#detailpanel_10").show();

                                addToValidate('EditView','date_of_collection_repair','varchar',true,'{$mod_strings['LBL_DATE_OF_COLLECTION']}');                           
                                $('#date_of_collection_repair_label').html('{$mod_strings['LBL_DATE_OF_COLLECTION']}: <font color="red">*</font>');
                                addToValidate('EditView','repair_date_to_supplier','varchar',true,'{$mod_strings['LBL_DATE_TO_SUPPLIER']}');                           
                                $('#repair_date_to_supplier_label').html('{$mod_strings['LBL_DATE_TO_SUPPLIER']}: <font color="red">*</font>');
                                addToValidate('EditView','supplier_comments_repair','varchar',true,'{$mod_strings['LBL_SUPPLIER_COMMENTS_REPAIR']}');                           
                                $('#supplier_comments_repair_label').html('{$mod_strings['LBL_SUPPLIER_COMMENTS_REPAIR']}: <font color="red">*</font>');
                                addToValidate('EditView','customer_approval_date','varchar',true,'{$mod_strings['LBL_CUSTOMER_APPROVAL_DATE']}');                           
                                $('#customer_approval_date_label').html('{$mod_strings['LBL_CUSTOMER_APPROVAL_DATE']}: <font color="red">*</font>');
                                addToValidate('EditView','bill_amount','varchar',true,'{$mod_strings['LBL_BILL_AMOUNT']}');                           
                                $('#bill_amount_label').html('{$mod_strings['LBL_BILL_AMOUNT']}: <font color="red">*</font>');
                                //addToValidate('EditView','suppliers_delivery_note_no','varchar',true,'{$mod_strings['LBL_SUPPLIERS_DELIVERY_NOTE_NO']}');                           
                               // $('#suppliers_delivery_note_no_label').html('{$mod_strings['LBL_SUPPLIERS_DELIVERY_NOTE_NO']}: <font color="red">*</font>');
                                //addToValidate('EditView','date_of_faxed_email','varchar',true,'{$mod_strings['LBL_DATE_OF_FAXED_EMAIL']}');                           
                                //$('#date_of_faxed_email_label').html('{$mod_strings['LBL_DATE_OF_FAXED_EMAIL']}: <font color="red">*</font>');

                                $("#resolution_label").show();
                                $("#resolution").show();
                                
                        }
						
                        if($('#school_cheque_status').val() =='Inprogress'){
                            $("#school_particulars_label").closest("td").hide();
                            $("#school_particulars").closest("td").hide();  
                            $("#school_particulars").val(); 
                            removeFromValidate('EditView','school_particulars');

                            $("#school_voucher_No_label").closest("td").hide();
                            $("#school_voucher_No").closest("td").hide();  
                            $("#school_voucher_No").val(); 
                            removeFromValidate('EditView','school_voucher_No');

                            $("#school_cheque_dispatch_label").closest("td").hide();
                            $("#school_cheque_dispatch").closest("td").hide();  
                            $("#school_cheque_dispatch").val();
                            $("#school_cheque_dispatch_trigger").closest("td").hide();  
                            removeFromValidate('EditView','school_cheque_dispatch');

                            $("#school_cheque_issuedate_label").closest("td").hide();
                            $("#school_cheque_issuedate").closest("td").hide();  
                            $("#school_cheque_issuedate").val();
                            $("#school_cheque_issuedate_trigger").closest("td").hide();
                            removeFromValidate('EditView','school_cheque_issuedate');

                            $("#school_cheque_no_label").closest("td").hide();
                            $("#school_cheque_no").closest("td").hide();  
                            $("#school_cheque_no").val(); 
                            removeFromValidate('EditView','school_cheque_no');
                        }
                        //Eoc 22/12/2016 - Ashok

                        //Gold memeber always High priority
                        $("#member_tier_c").change(function() {
                            var member_tier = $("#member_tier_c").val();
                            if ((member_tier != null) && (member_tier == 'Gold' || member_tier == 'gold')) {
                                $("#priority").val('P1').css('pointer-events','none');
                            }
                        });
                        //school fees redemtion validations 
                        var redemtion ='';
                        school_fees_redemption(redemtion);
                        //Priority change based on subcategories nature
                        $("#subcategory_c").change(function() {
                            var subcatid = this.value;
                            if(subcatid !=''){
                                $.ajax({
                                        url: '{$sugar_config['site_url']}/index.php?module=Cases&action=getPriority',
                                        data: { subcatid : subcatid },
                                        type: 'post',
                                        success: function(result) {
                                            var member_tier = $("#member_tier_c").val();
                                            if ((member_tier != null) && (member_tier == 'Gold' || member_tier == 'gold')) {
                                                $("#priority").val('P1').css('pointer-events','none');
                                            }else{
                                                $("#priority").val(result).css('pointer-events','none');
                                            }
                                        }
                                });
                                subcat = $("#subcategory_c option:selected").text(); 
								
								var strSubcat = subcat;
								var subcat = strSubcat.toUpperCase();
								var strSubCat = "School fee redemption";
								var subcat_school = strSubCat.toUpperCase();
						
								//branch is 2 and call center is 3
                                /*if(subcat == subcat_school){
                                 $('select[name="origin_c"] option[value!=""][value !="2"]').hide();
                                }else{
                                    $('select[name="origin_c"] option[value!=""][value !="2"]').show();
                                    $('#origin_c').css({"background-color": "#FFFFFF", "pointer-events": "fill"});  
                                }*/
                            }
                        });
                                        
                        //Customer Lookup function for get Customer information
                        $( ".btn_customer" ).on( "click", function(e) {
                            e.preventDefault();
                            var loyalty_id      = $('#loyalty_id_c').val();
                            var mobile_number   = $('#mobile_number_c').val();
                            var email           = $('#email_c').val();
                            if(loyalty_id !='' || mobile_number !='' || email !=''){
                                $('#loading_image_clookup').show();
                                $.ajax({
                                    url: '{$sugar_config['site_url']}/index.php?module=Cases&action=getCustomerInfo',
                                    data: { loyalty_id : loyalty_id, mobile_number : mobile_number, email : email, },
                                    type: 'post',
                                    dataType: 'json',
                                    success: function(output) {
                                        //console.log(output);
                                        var jsonstring = JSON.stringify(output);
                                        var data = $.parseJSON(jsonstring);
                                        if(data.flag !=0){
                                            $('#loading_image_clookup').hide();
                                            $(data).each(function(i,val){
                                                var customer_name   =   val.first_name + ' '+ val.last_name;
                                                var mobile          =   val.phone_mobile;
                                                mobile = mobile.replace(/\D+/g,'');
                                                var email           =   val.email;
                                                var loyalty_id      =   val.loyalty_id;
                                                var member_tier     =   val.member_tier;
                                                var birthdate       =   val.birthdate;
                                                var member_type     =   val.member_type;
                                                var gender          =   val.title;

                                                $('#customer_name_c').val(customer_name).attr('readonly','readonly').css('background-color','#DEDEDE');
                                                $('#mobile_number_c').val(mobile).attr('readonly','readonly').css('background-color','#DEDEDE');
                                                $('#email_c').val(email).attr('readonly','readonly').css('background-color','#DEDEDE');
                                                $('#loyalty_id_c').val(loyalty_id).attr('readonly','readonly').css('background-color','#DEDEDE');
                                                $('#member_tier_c').val(member_tier).attr('readonly','readonly').css('background-color','#DEDEDE');
                                                $('#dob_c').val(birthdate).attr('readonly','readonly').css('background-color','#DEDEDE');
                                                $('#dob_c_trigger').hide();
                                                if(member_tier == 'Gold' || member_tier == 'gold'){
                                                    $("#priority").val('P1').css('pointer-events','none');
                                                }
                                                if(member_type == 0){
                                                    $("#member_type_c").val('member').css({'pointer-events':'none','background-color':'#DEDEDE'});
                                                }else if(member_type == 1){
                                                    $("#member_type_c").val('corporate').css({'pointer-events':'none','background-color':'#DEDEDE'});
                                                }else{
                                                    $("#member_type_c").val('guest').css({'pointer-events':'none','background-color':'#DEDEDE'});
                                                }
                                                if(gender == 1){
                                                    $("#gender_c").val('male').css({'pointer-events':'none','background-color':'#DEDEDE'});
                                                }else{
                                                    $("#gender_c").val('female').css({'pointer-events':'none','background-color':'#DEDEDE'});
                                                }
                                            });
                                        }else{
                                                alert('Customer data not found.');
                                                $('#loading_image_clookup').hide();
                                            }
                                    }
                                });
                            }else{alert('Please enter data in any one of the lookup field.');}
                        });//Customer lookup
                                    
                        //Reset mobile,loyalty and email
                         $( ".btn_clr" ).on( "click", function(e) {
                            e.preventDefault();
                            //change the color of the text box on 02-05-2017
                            $("#mobile_number_c").val("").removeAttr('readonly').css('background-color','orange');
                            $("#email_c").val("").removeAttr('readonly').css('background-color','orange');
                            $("#loyalty_id_c").val("").removeAttr('readonly').css('background-color','orange');
                            $("#customer_name_c").val("").removeAttr('readonly').css('background-color','#FFFFFF');
                            $("#member_tier_c").val("").removeAttr('readonly').css('background-color','#FFFFFF');
                            $("#dob_c").val("").removeAttr('readonly').css('background-color','#FFFFFF');
                            $("#member_type_c").val("").css({'pointer-events':'auto','background-color':'#FFFFFF'});
                            $('#dob_c_trigger').show();
                            $("#priority").val("");
                            $("#gender_c").val("").css({'pointer-events':'auto','background-color':'#FFFFFF'});
                        });
                    });//document ready
                    //ajax call on branch name    Dated: 28-02-2016  BY: Ashok     
                   // $('#school_redemption_rate').css({"background-color": "#DEDEDE", "pointer-events": "none"});
	                //22/08/2017 - change the code on change of subcategory
                    $("#subcategory_c").change(function() {
                        var loyalty_id      = $('#loyalty_id_c').val();
                        var member_tier_c   = $('#member_tier_c').val();
                        var subcategory_c = $("#subcategory_c option:selected").text(); 
						
						
						//UPPER CASE @ashok Dated:17-07-2017
						var strSubcat = subcategory_c;
						var subcat = strSubcat.toUpperCase();
						var strSubCat = "School fee redemption";
						var subcat_school = strSubCat.toUpperCase();
						
						
                        var branch_store_name =$('#branch_store_name').val();
                        if((loyalty_id =='' || member_tier_c =='') && subcat == subcat_school){ 
                             alert('Please Fill Proper Member Data');   
                        }else{
                            if(loyalty_id !='' && member_tier_c !='' && subcategory_c !='' && subcat == subcat_school){ 
                                $.ajax({
                                    url: '{$sugar_config['site_url']}/index.php?module=Cases&action=getRedemptionRate',
                                    data: { loyalty_id : loyalty_id, member_tier_c : member_tier_c, subcategory_c : subcategory_c,branch_store_name : branch_store_name, },
                                    type: 'post',
                                    dataType: 'json',
                                    success: function(output) {
                                        if(output !=false){
                                            var option = $('<option></option>').prop("value", output.currency_amount).text(output.currency_amount);
                                            $("#school_redemption_rate").empty().append(option);
                                            $('#school_redemption_rate').css({"background-color": "#DEDEDE", "pointer-events": "none"});
                                            
                                             $("#school_branch_country").val(output.name);
                                        }else{
                                            alert("Redemption rate is not found.");
                                             var option = $('<option></option>').prop("value", "").text("");
                                             $("#school_redemption_rate").empty().append(option);
                                             $('#school_redemption_rate').css({"background-color": "#DEDEDE", "pointer-events": "fill"});
                                             $('#school_points_redeemed').val('');
                                             $('#school_points_redeemed').val('0.0');
                                             $('#school_amount_payable').val('0.0');
                                             
                                        }
                                    }
                                });
                            }
                        }
                    });
                        
                    function school_fees_redemption(redemtion){
                        var cat = '';var subcat ='';
                        cat = $("#category_c option:selected").text();  
                        subcat = $("#subcategory_c option:selected").text(); 
						
						var strSubcat = subcat;
						var subcat = strSubcat.toUpperCase();
						var strSubCat = "School fee redemption";
						var subcat_school = strSubCat.toUpperCase();
						
						
						var strcat = cat;
						var cat = strcat.toUpperCase();
						var strCat = "Product";
						var cat_product = strCat.toUpperCase();
						
						
						

                        //check if the category and subcategory condition match
                        if(subcat == subcat_school){
                                    
                            if($("#member_type_c").val() == 'corporate' || $("#member_type_c").val() == 'guest' ){
                                    alert("Loyalty applies only for loyal member.");  
                                    $("#subcategory_c").val('');
                            }else{
                                //product validations by ashok on 21/12/2016
                                $("#LBL_EDITVIEW_PANEL_PRODUCT_QUALITY_COMPLAINT").hide();
                                $("#LBL_EDITVIEW_PRODUCT_BRANCH").hide();
                                $("#LBL_EDITVIEW_PRODUCT_SUPPLIER").hide();
                                $("#LBL_EDITVIEW_PANEL_PRODUCT_REPAIR").hide();
								$("#LBL_EDITVIEW_PANEL_SUPPLIER_INFO").hide();
                                $("#LBL_EDITVIEW_PANEL_PRODUCT_RECEIVED").hide();
                                $("#detailpanel_5").hide();
                                $("#detailpanel_6").hide();
                                $("#detailpanel_7").hide();
                                $("#detailpanel_8").hide();
                                $("#detailpanel_9").hide();
								$("#detailpanel_10").hide();

                                $("#LBL_EDITVIEW_PANEL_SCHOOL").show();
                                $("#detailpanel_3").show();
                                $("#LBL_EDITVIEW_PANEL_CHEQUE").show();
                                $("#detailpanel_4").show();

                                $("#school_parent_name_label").show();
                                $("#school_parent_name").show();     
                                addToValidate('EditView','school_parent_name','varchar',true,'{$mod_strings['LBL_SCHOOL_RARENT_NAME']}');                           
                                $('#school_parent_name_label').html('{$mod_strings['LBL_SCHOOL_RARENT_NAME']}: <font color="red">*</font>');

                                $("#school_points_redeemed_label").show();
                                $("#school_points_redeemed").show();     
                                addToValidate('EditView','school_points_redeemed','varchar',true,'{$mod_strings['LBL_SCHOOL_POINTS_REDEEMED']}');                           
                                $('#school_points_redeemed_label').html('{$mod_strings['LBL_SCHOOL_POINTS_REDEEMED']}: <font color="red">*</font>');

                                $("#school_school_name_label").show();
                                $("#school_school_name").show();     
                                addToValidate('EditView','school_school_name','varchar',true,'{$mod_strings['LBL_SCHOOL_SCHOOL_NAME']}');                           
                                $('#school_school_name_label').html('{$mod_strings['LBL_SCHOOL_SCHOOL_NAME']}: <font color="red">*</font>');

                                $("#school_redemption_rate_label").show();
                                $("#school_redemption_rate").show();     
                                addToValidate('EditView','school_redemption_rate','varchar',true,'{$mod_strings['LBL_SCHOOL_REDEMPTION_RATE']}');                           
                                $('#school_redemption_rate_label').html('{$mod_strings['LBL_SCHOOL_REDEMPTION_RATE']}: <font color="red">*</font>');

                                $("#school_child_name_label").show();
                                $("#school_child_name").show();     
                                addToValidate('EditView','school_child_name','varchar',true,'{$mod_strings['LBL_SCHOOL_CHILD_NAME']}');                           
                                $('#school_child_name_label').html('{$mod_strings['LBL_SCHOOL_CHILD_NAME']}: <font color="red">*</font>');

                                 $("#school_amount_payable_label").show();
                                $("#school_amount_payable").show();     
                                addToValidate('EditView','school_amount_payable','varchar',true,'{$mod_strings['LBL_SCHOOL_AMOUNT_PAYABLE']}');                           
                                $('#school_amount_payable_label').html('{$mod_strings['LBL_SCHOOL_AMOUNT_PAYABLE']}: <font color="red">*</font>');

                                ////08-02-2017 by Ashok for receipt and till no in loyalty school fees redemtion

                                 $("#school_receipt_no_label").show();
                                $("#school_receipt_no").show();     
                                addToValidate('EditView','school_receipt_no','varchar',true,'{$mod_strings['LBL_SCHOOL_RECEIPT_NO']}');                           
                                $('#school_receipt_no_label').html('{$mod_strings['LBL_SCHOOL_RECEIPT_NO']}: <font color="red">*</font>');

                                $("#school_till_no_label").show();
                                $("#school_till_no").show();     
                                addToValidate('EditView','school_till_no','varchar',true,'{$mod_strings['LBL_SCHOOL_TILL_NO']}');                           
                                $('#school_till_no_label').html('{$mod_strings['LBL_SCHOOL_TILL_NO']}: <font color="red">*</font>');

                                //Cheque contition validations
                                $("#school_cheque_status_label").show();
                                $("#school_cheque_status").show();   
                                addToValidate('EditView','school_cheque_status','varchar',true,'{$mod_strings['LBL_SCHOOL_CHEQUE_STATUS']}');                           
                                $('#school_cheque_status_label').html('{$mod_strings['LBL_SCHOOL_CHEQUE_STATUS']}: <font color="red">*</font>');

                                var cheque = $('#school_cheque_status').val();
                                if(cheque ==''){
                                    $('#school_cheque_status').val('Inprogress');
									$("#school_cheque_status").css({"background-color": "#DEDEDE", "pointer-events": "none"});

                                    $("#school_particulars_label").closest("td").hide();
                                    $("#school_particulars").closest("td").hide();  
                                    $("#school_particulars").val(); 
                                    removeFromValidate('EditView','school_particulars');

                                    $("#school_voucher_No_label").closest("td").hide();
                                    $("#school_voucher_No").closest("td").hide();  
                                    $("#school_voucher_No").val(); 
                                    removeFromValidate('EditView','school_voucher_No');

                                    $("#school_cheque_dispatch_label").closest("td").hide();
                                    $("#school_cheque_dispatch").closest("td").hide();  
                                    $("#school_cheque_dispatch").val();
                                    $("#school_cheque_dispatch_trigger").closest("td").hide();  
                                    removeFromValidate('EditView','school_cheque_dispatch');

                                    $("#school_cheque_issuedate_label").closest("td").hide();
                                    $("#school_cheque_issuedate").closest("td").hide();  
                                    $("#school_cheque_issuedate").val();
                                    $("#school_cheque_issuedate_trigger").closest("td").hide();
                                    removeFromValidate('EditView','school_cheque_issuedate');

                                    $("#school_cheque_no_label").closest("td").hide();
                                    $("#school_cheque_no").closest("td").hide();  
                                    $("#school_cheque_no").val(); 
                                    removeFromValidate('EditView','school_cheque_no');
                                }if(cheque =='Ready'){
                                     $("#school_particulars_label").closest("td").show();
                                        $("#school_particulars").closest("td").show();  
                                       $("#school_particulars").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                                       // addToValidate('EditView','school_particulars','varchar',true,'{$mod_strings['LBL_SCHOOL_PARTICULARS']}');                           
                                       // $('#school_particulars_label').html('{$mod_strings['LBL_SCHOOL_PARTICULARS']}: <font color="red">*</font>');

                                        $("#school_voucher_No_label").closest("td").show();
                                        $("#school_voucher_No").closest("td").show();  
                                       $("#school_voucher_No").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                                        //$("#school_voucher_No").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                                       // removeFromValidate('EditView','school_voucher_No');

                                        $("#school_cheque_issuedate_label").closest("td").show();
                                        $("#school_cheque_issuedate").closest("td").show();  
                                       $("#school_cheque_issuedate").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                                         $("#school_cheque_issuedate_trigger").hide();
                                        //addToValidate('EditView','school_cheque_issuedate','varchar',true,'{$mod_strings['LBL_SCHOOL_CHEQUE_ISSUE']}');                           
                                       // $('#school_cheque_issuedate_label').html('{$mod_strings['LBL_SCHOOL_CHEQUE_ISSUE']}: <font color="red">*</font>');

                                        $("#school_cheque_no_label").closest("td").show();
                                        $("#school_cheque_no").closest("td").show();  
                                        $("#school_cheque_no").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                                       // addToValidate('EditView','school_cheque_no','varchar',true,'{$mod_strings['LBL_SCHOOL_CHEQUE_NO']}');                           
                                       // $('#school_cheque_no_label').html('{$mod_strings['LBL_SCHOOL_CHEQUE_NO']}: <font color="red">*</font>');

                                        $("#school_cheque_dispatch_label").closest("td").hide();
                                        $("#school_cheque_dispatch").closest("td").hide();  
                                        $("#school_cheque_dispatch").val('');
                                        $("#school_cheque_dispatch_trigger").hide();  
                                        removeFromValidate('EditView','school_cheque_dispatch');
                                } if(cheque == 'Dispatched'){
                                        $("#school_particulars_label").closest("td").show();
                                        $("#school_particulars").closest("td").show();  
                                        $("#school_particulars").css({"background-color": "#DEDEDE", "pointer-events": "none"});

                                        $("#school_voucher_No_label").closest("td").show();
                                        $("#school_voucher_No").closest("td").show();  
                                        $("#school_voucher_No").css({"background-color": "#DEDEDE", "pointer-events": "none"});

                                        $("#school_cheque_issuedate_label").closest("td").show();
                                        $("#school_cheque_issuedate").closest("td").show();  
                                        $("#school_cheque_issuedate").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                                        $("#school_cheque_issuedate_trigger").hide();

                                        $("#school_cheque_no_label").closest("td").show();
                                        $("#school_cheque_no").closest("td").show();  
                                        $("#school_cheque_no").css({"background-color": "#DEDEDE", "pointer-events": "none"});

                                        $("#school_cheque_dispatch_label").closest("td").show();
                                        $("#school_cheque_dispatch").closest("td").show();  
                                        $("#school_cheque_dispatch_trigger").hide();  
                                        $("#school_cheque_dispatch").css({"background-color": "#DEDEDE", "pointer-events": "none"});

                                        $("#school_cheque_status_label").closest("td").show();
                                        $("#school_cheque_status").closest("td").show();  
                                        $("#school_cheque_status").css({"background-color": "#FFFFFF", "pointer-events": "fill"});
                                }if(cheque == 'Delivered'){
                                        $("#school_particulars_label").closest("td").show();
                                        $("#school_particulars").closest("td").show();  
                                        $("#school_particulars").css({"background-color": "#DEDEDE", "pointer-events": "none"});

                                        $("#school_voucher_No_label").closest("td").show();
                                        $("#school_voucher_No").closest("td").show();  
                                        $("#school_voucher_No").css({"background-color": "#DEDEDE", "pointer-events": "none"});

                                        $("#school_cheque_issuedate_label").closest("td").show();
                                        $("#school_cheque_issuedate").closest("td").show();  
                                        $("#school_cheque_issuedate").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                                        $("#school_cheque_issuedate_trigger").hide();

                                        $("#school_cheque_no_label").closest("td").show();
                                        $("#school_cheque_no").closest("td").show();  
                                        $("#school_cheque_no").css({"background-color": "#DEDEDE", "pointer-events": "none"});

                                        $("#school_cheque_dispatch_label").closest("td").show();
                                        $("#school_cheque_dispatch").closest("td").show();  
                                        $("#school_cheque_dispatch_trigger").hide();  
                                        $("#school_cheque_dispatch").css({"background-color": "#DEDEDE", "pointer-events": "none"});

                                        $("#school_cheque_status_label").closest("td").show();
                                        $("#school_cheque_status").closest("td").show();  
                                        $("#school_cheque_status").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                                }
                                //While create onchange          
                                $('#school_cheque_status').change(function(){
                                   if($('#school_cheque_status').val() == 'Inprogress'){

                                       $("#school_particulars_label").closest("td").hide();
                                       $("#school_particulars").closest("td").hide();  
                                       $("#school_particulars").val(); 
                                       removeFromValidate('EditView','school_particulars');

                                       $("#school_voucher_No_label").closest("td").hide();
                                       $("#school_voucher_No").closest("td").hide();  
                                       $("#school_voucher_No").val(); 
                                       removeFromValidate('EditView','school_voucher_No');

                                       $("#school_cheque_dispatch_label").closest("td").hide();
                                       $("#school_cheque_dispatch").closest("td").hide();  
                                       $("#school_cheque_dispatch").val();
                                       $("#school_cheque_dispatch_trigger").hide();  
                                       removeFromValidate('EditView','school_cheque_dispatch');

                                       $("#school_cheque_issuedate_label").closest("td").hide();
                                       $("#school_cheque_issuedate").closest("td").hide();  
                                       $("#school_cheque_issuedate").val();
                                       $("#school_cheque_issuedate_trigger").hide();
                                       removeFromValidate('EditView','school_cheque_issuedate');

                                       $("#school_cheque_no_label").closest("td").hide();
                                       $("#school_cheque_no").closest("td").hide();  
                                       $("#school_cheque_no").val(); 
                                       removeFromValidate('EditView','school_cheque_no');

                                       $('#status').val('InProgress');
                                       $("#resolution_label").hide();
                                       $("#resolution").hide();
                                      // removeFromValidate('EditView','resolution');

                                   }else if($('#school_cheque_status').val() == 'Ready'){
                                       $("#school_particulars_label").closest("td").show();
                                       $("#school_particulars").closest("td").show();  
                                       addToValidate('EditView','school_particulars','varchar',true,'{$mod_strings['LBL_SCHOOL_PARTICULARS']}');                           
                                       $('#school_particulars_label').html('{$mod_strings['LBL_SCHOOL_PARTICULARS']}: <font color="red">*</font>');

                                       $("#school_voucher_No_label").closest("td").show();
                                       $("#school_voucher_No").closest("td").show();  
                                       $("#school_voucher_No").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                                       removeFromValidate('EditView','school_voucher_No');


                                       $("#school_cheque_issuedate_label").closest("td").show();
                                       $("#school_cheque_issuedate").closest("td").show();  
                                        $("#school_cheque_issuedate_trigger").show();
                                       addToValidate('EditView','school_cheque_issuedate','varchar',true,'{$mod_strings['LBL_SCHOOL_CHEQUE_ISSUE']}');                           
                                       $('#school_cheque_issuedate_label').html('{$mod_strings['LBL_SCHOOL_CHEQUE_ISSUE']}: <font color="red">*</font>');

                                       $("#school_cheque_no_label").closest("td").show();
                                       $("#school_cheque_no").closest("td").show();  
                                       addToValidate('EditView','school_cheque_no','varchar',true,'{$mod_strings['LBL_SCHOOL_CHEQUE_NO']}');                           
                                       $('#school_cheque_no_label').html('{$mod_strings['LBL_SCHOOL_CHEQUE_NO']}: <font color="red">*</font>');

                                       $("#school_cheque_dispatch_label").closest("td").hide();
                                       $("#school_cheque_dispatch").closest("td").hide();  
                                       $("#school_cheque_dispatch").val('');
                                       $("#school_cheque_dispatch_trigger").hide();  
                                       removeFromValidate('EditView','school_cheque_dispatch');

                                       $('#status').val('InProgress');
                                       $("#resolution_label").hide();
                                       $("#resolution").hide();
                                       //removeFromValidate('EditView','resolution');
                                   }else if($('#school_cheque_status').val() == 'Dispatched'){
                                        $("#school_cheque_dispatch_label").closest("td").show();
                                        $("#school_cheque_dispatch").closest("td").show();  
                                        $("#school_cheque_dispatch_trigger").show();  
                                        addToValidate('EditView','school_cheque_dispatch','varchar',true,'{$mod_strings['LBL_SCHOOL_DISPATCH_DATE']}');                           
                                        $('#school_cheque_dispatch_label').html('{$mod_strings['LBL_SCHOOL_DISPATCH_DATE']}: <font color="red">*</font>');

                                        $("#resolution_label").hide();
                                        $("#resolution").hide();
                                        removeFromValidate('EditView','resolution');
                                   }else if($('#school_cheque_status').val() == 'Delivered'){
                                       $("#school_cheque_dispatch_label").closest("td").show();
                                       $("#school_cheque_dispatch").closest("td").show();  
                                       $("#school_cheque_dispatch_trigger").hide();  
                                        
                                       addToValidate('EditView','school_cheque_dispatch','varchar',true,'{$mod_strings['LBL_SCHOOL_DISPATCH_DATE']}');                           
                                       $('#school_cheque_dispatch_label').html('{$mod_strings['LBL_SCHOOL_DISPATCH_DATE']}: <font color="red">*</font>');

                                       // 145 - 3/15/2017 - Once the cheque is delivered, the case should be in resolved status and system should prompt user to fill resolution School Fee redemption 
                                        $('#status').val('Resolved').trigger("change");
                                        $("#resolution_label").show();
                                        $("#resolution").show();

                                   }
                               });

                                //save error on mismatch against product quality
                                removeFromValidate('EditView','date_sent_to_supplier');
                                removeFromValidate('EditView','branch_manager_comments');
                            }          
                        
						}else if(cat == cat_product &&  subcat != ''){
							$("#LBL_EDITVIEW_PANEL_PRODUCT_QUALITY_COMPLAINT").show();
							$("#LBL_EDITVIEW_PRODUCT_BRANCH").show();
							$("#LBL_EDITVIEW_PRODUCT_SUPPLIER").show();
							$("#detailpanel_5").show();
							$("#detailpanel_6").show();    
							$("#detailpanel_7").show(); 

							$("#LBL_EDITVIEW_PANEL_SCHOOL").hide();
							$("#detailpanel_3").hide();
							$("#LBL_EDITVIEW_PANEL_CHEQUE").hide();
							$("#detailpanel_4").hide();

							//Make field mandatory for complaint form
							addToValidate('EditView','prod_sku','varchar',true,'{$mod_strings['LBL_PROD_SKU']}');                           
							$('#prod_sku_label').html('{$mod_strings['LBL_PROD_SKU']}: <font color="red">*</font>'); 
							addToValidate('EditView','branch_name','varchar',true,'{$mod_strings['LBL_BRANCH_NAME']}');                           
							$('#branch_name_label').html('{$mod_strings['LBL_BRANCH_NAME']}: <font color="red">*</font>');
							addToValidate('EditView','date_complaint_forwarded','varchar',true,'{$mod_strings['LBL_DATE_COMPLAINT_FORWARDED']}');                           
							$('#date_complaint_forwarded_label').html('{$mod_strings['LBL_DATE_COMPLAINT_FORWARDED']}: <font color="red">*</font>');
							addToValidate('EditView','grn_no','varchar',true,'{$mod_strings['LBL_GRN_NO']}');                           
							$('#grn_no_label').html('{$mod_strings['LBL_GRN_NO']}: <font color="red">*</font>');
							addToValidate('EditView','product_value','varchar',true,'{$mod_strings['LBL_PRODUCT_VALUE']}');                           
							$('#product_value_label').html('{$mod_strings['LBL_PRODUCT_VALUE']}: <font color="red">*</font>');
							//addToValidate('EditView','compiled_by','varchar',true,'{$mod_strings['LBL_COMPILED_BY']}');                           
							//$('#compiled_by_label').html('{$mod_strings['LBL_COMPILED_BY']}: <font color="red">*</font>');
							//addToValidate('EditView','send_to_head_office_by','varchar',true,'{$mod_strings['LBL_SEND_TO_HEAD_OFFICE_BY']}');                           
						   // $('#send_to_head_office_by_label').html('{$mod_strings['LBL_SEND_TO_HEAD_OFFICE_BY']}: <font color="red">*</font>');
							addToValidate('EditView','product_code_no','varchar',true,'{$mod_strings['LBL_PRODUCT_CODE_NO']}');                           
							$('#product_code_no_label').html('{$mod_strings['LBL_PRODUCT_CODE_NO']}: <font color="red">*</font>');
							addToValidate('EditView','quality_description','varchar',true,'{$mod_strings['LBL_PRODUCT_QUALITY_DESCRIPTION']}');                           
							$('#quality_description_label').html('{$mod_strings['LBL_PRODUCT_QUALITY_DESCRIPTION']}: <font color="red">*</font>');
							addToValidate('EditView','purchase_date','varchar',true,'{$mod_strings['LBL_PURCHASE_DATE']}');                           
							$('#purchase_date_label').html('{$mod_strings['LBL_PURCHASE_DATE']}: <font color="red">*</font>');
							addToValidate('EditView','receipt_no','varchar',true,'{$mod_strings['LBL_RECEIPT_NO']}');                           
							$('#receipt_no_label').html('{$mod_strings['LBL_RECEIPT_NO']}: <font color="red">*</font>');
							addToValidate('EditView','till_no','varchar',true,'{$mod_strings['LBL_TILL_NO']}');                           
							$('#till_no_label').html('{$mod_strings['LBL_TILL_NO']}: <font color="red">*</font>');
							addToValidate('EditView','expiry_date','varchar',true,'{$mod_strings['LBL_EXPIRY_DATE']}');                           
							$('#expiry_date_label').html('{$mod_strings['LBL_EXPIRY_DATE']}: <font color="red">*</font>');
							addToValidate('EditView','nature_of_complaint','varchar',true,'{$mod_strings['LBL_NATURE_OF_COMPLAINT']}');                           
							$('#nature_of_complaint_label').html('{$mod_strings['LBL_NATURE_OF_COMPLAINT']}: <font color="red">*</font>');
							//addToValidate('EditView','credit_note','varchar',true,'{$mod_strings['LBL_CREDIT_NOTE']}');                           
						   // $('#credit_note_label').html('{$mod_strings['LBL_CREDIT_NOTE']}: <font color="red">*</font>');
							addToValidate('EditView','date_sent_to_supplier','varchar',true,'{$mod_strings['LBL_DATE_SENT_TO_SUPPLIER']}');                           
							$('#date_sent_to_supplier_label').html('{$mod_strings['LBL_DATE_SENT_TO_SUPPLIER']}: <font color="red">*</font>');
							addToValidate('EditView','branch_manager_comments','varchar',true,'{$mod_strings['LBL_BRANCH_MANAGER_COMMENTS']}');                           
							$('#branch_manager_comments_label').html('{$mod_strings['LBL_BRANCH_MANAGER_COMMENTS']}: <font color="red">*</font>');
							
							
						   
							if($('#credit_note').val() !=''){
								 $("#credit_note").closest("td").show();
								$('#credit_note').show();
								$("#credit_note_label").show();
								addToValidate('EditView','credit_note','varchar',true,'{$mod_strings['LBL_CREDIT_NOTE']}');                           
								$('#credit_note_label').html('{$mod_strings['LBL_CREDIT_NOTE']}: <font color="red">*</font>');
							}else{
							   $("#credit_note").closest("td").hide();
							   $('#credit_note').hide();
								$("#credit_note_label").hide();
								removeFromValidate('EditView','credit_note'); 
								$('#credit_note_label').html('{$mod_strings['LBL_CREDIT_NOTE']}: ');
							}
								 
							if($('#date_sent_to_supplier').val() !=''){
								$("#date_sent_to_supplier").closest("td").show();
								$('#date_sent_to_supplier').show();
								$("#date_sent_to_supplier_label").show();
								$('#date_sent_to_supplier_trigger').hide();
								addToValidate('EditView','date_sent_to_supplier','varchar',true,'{$mod_strings['LBL_DATE_SENT_TO_SUPPLIER']}');                           
								$('#credit_note_label').html('{$mod_strings['LBL_DATE_SENT_TO_SUPPLIER']}: <font color="red">*</font>');
							}else{
								 $("#date_sent_to_supplier").closest("td").hide();
								$('#date_sent_to_supplier').hide();
								$("#date_sent_to_supplier_label").hide();
								$('#date_sent_to_supplier_trigger').hide();
								removeFromValidate('EditView','date_sent_to_supplier'); 
								$('#date_sent_to_supplier_label').html('{$mod_strings['LBL_DATE_SENT_TO_SUPPLIER']}:');
							}
							$("#repair_delivery_note_no").css({"background-color": "#DEDEDE", "pointer-events": "none"});
							$('#credit_repair').css({"background-color": "#DEDEDE", "pointer-events": "none" ,"width":"inherit !important"});  
							$("input[name=product_replaced]:radio").change(function () {
								if(this.value =='Yes'){ 
										
										$('#credit_repair').val('replaced').trigger("change");
										$('#credit_repair').css({"background-color": "#DEDEDE", "pointer-events": "none"});
										$("#date_sent_to_supplier").closest("td").hide();
										$('#date_sent_to_supplier_label').hide();
										$('#date_sent_to_supplier').hide();
										$('#date_sent_to_supplier_trigger').hide();
										removeFromValidate('EditView','date_sent_to_supplier');
										 $('#date_sent_to_supplier_label').html('{$mod_strings['LBL_DATE_SENT_TO_SUPPLIER']}:');
										
										$("#credit_note").closest("td").hide();
										$('#credit_note').hide();
										$("#credit_note_label").hide();
										removeFromValidate('EditView','credit_note'); 
										$('#credit_repair_label').html('{$mod_strings['LBL_CREDIT_REPAIR']}:');
										
										//When product is replaced, the case status should be resolved and resolution field should appear
									   
										$('#status').val('Resolved').trigger("change");
										$("#resolution_label").show();
										$("#resolution").show();      
										
										
										$("#LBL_EDITVIEW_PANEL_PRODUCT_REPAIR").hide();
										$("#LBL_EDITVIEW_PANEL_SUPPLIER_INFO").hide();
										$("#LBL_EDITVIEW_PANEL_PRODUCT_RECEIVED").hide();
										$("#detailpanel_8").hide();
										$("#detailpanel_9").hide();
										$("#detailpanel_10").hide();
										//Remove mandatory 
										removeFromValidate('EditView','repair_tag_no');
											removeFromValidate('EditView','bill_amount');
										   // removeFromValidate('EditView','receipt_no_repair');
											removeFromValidate('EditView','prod_repair_status');
											removeFromValidate('EditView','prod_repair_sku');
											removeFromValidate('EditView','repair_supplier_name');
											removeFromValidate('EditView','complaint_date');
											removeFromValidate('EditView','repair_product_code');
											removeFromValidate('EditView','product_repair_description');
											removeFromValidate('EditView','repair_serial_no');
											removeFromValidate('EditView','repair_model_no');
											removeFromValidate('EditView','repair_nature_of_fault');
											removeFromValidate('EditView','repair_date_to_supplier');
											removeFromValidate('EditView','supplier_comments_repair');
											removeFromValidate('EditView','customer_approval_date');
										   // removeFromValidate('EditView','till_no_repair');
											removeFromValidate('EditView','purchase_date_repair');
											removeFromValidate('EditView','date_of_faxed_email');
											removeFromValidate('EditView','school_points_redeemed');
											removeFromValidate('EditView','suppliers_delivery_note_no');
											removeFromValidate('EditView','suppliers_comments_repair');
											removeFromValidate('EditView','date_of_collection_repair');
											removeFromValidate('EditView','branch_manager_name_repair');
											removeFromValidate('EditView','verified_in_fully');
											removeFromValidate('EditView','released_by_repair');
											removeFromValidate('EditView','branch_mg_pr');
											removeFromValidate('EditView','verified_in_pr_no');
											removeFromValidate('EditView','released_pr_no');

										
								} else if(this.value=='No') {
										
									$('select[name="credit_repair"] option[value="replaced"]').hide();
									$('#credit_repair').val('').css({"background-color": "#FFFFFF", "pointer-events": "fill"});  
									addToValidate('EditView','credit_repair','varchar',true,'{$mod_strings['LBL_CREDIT_REPAIR']}');                           
									$('#credit_repair_label').html('{$mod_strings['LBL_CREDIT_REPAIR']}: <font color="red">*</font>');
									
								} 
							});
									
							if($('#credit_repair').val() == 'credit'){ 
									$("#date_sent_to_supplier").closest("td").hide();
									$('#date_sent_to_supplier').hide();
									$('#date_sent_to_supplier_label').hide();
									$("#date_sent_to_supplier_trigger").hide();
									removeFromValidate('EditView','date_sent_to_supplier');
								   // $('#date_sent_to_supplier_label').html('{$mod_strings['LBL_DATE_SENT_TO_SUPPLIER']}:');
									
									//When issue credit is selected, the case status should be resolved and resolution field should appear
									$('#status').val('Resolved').trigger("change");
									$("#resolution_label").show();
									$("#resolution").show(); 
										
							}else if($('#credit_repair').val() == 'repair'){
									$("#date_sent_to_supplier").closest("td").show();
									$('#date_sent_to_supplier').show();
									$('#date_sent_to_supplier_label').show();
									$("#date_sent_to_supplier_trigger").show();
									addToValidate('EditView','date_sent_to_supplier','varchar',true,'{$mod_strings['LBL_DATE_SENT_TO_SUPPLIER']}');                           
									$('#date_sent_to_supplier_label').html('{$mod_strings['LBL_DATE_SENT_TO_SUPPLIER']}: <font color="red">*</font>');
							}
							
							//on change on credit or repair 
							$('#credit_repair').change(function () {
								if($('#credit_repair').val() == 'credit'){
									$("#date_sent_to_supplier").closest("td").hide();
									$('#date_sent_to_supplier').hide();
									$('#date_sent_to_supplier_label').hide();
									$("#date_sent_to_supplier_trigger").hide();
									removeFromValidate('EditView','date_sent_to_supplier');
								   
									$("#credit_note").closest("td").show();
									$("#credit_note_label").show(); 
									$('#credit_note').show();
									addToValidate('EditView','credit_note','varchar',true,'{$mod_strings['LBL_CREDIT_NOTE']}');                           
									$('#credit_note_label').html('{$mod_strings['LBL_CREDIT_NOTE']}: <font color="red">*</font>');
								   
								   //hide repair form 
									$("#LBL_EDITVIEW_PANEL_PRODUCT_REPAIR").hide();
									$("#LBL_EDITVIEW_PANEL_SUPPLIER_INFO").hide();
									$("#LBL_EDITVIEW_PANEL_PRODUCT_RECEIVED").hide();
									$("#detailpanel_8").hide();
									$("#detailpanel_9").hide();
									$("#detailpanel_10").hide();
									//Remove mandatory 
									removeFromValidate('EditView','repair_tag_no');
									removeFromValidate('EditView','bill_amount');
									removeFromValidate('EditView','prod_repair_status');
									removeFromValidate('EditView','prod_repair_sku');
									removeFromValidate('EditView','repair_supplier_name');
									removeFromValidate('EditView','complaint_date');
									removeFromValidate('EditView','repair_product_code');
									removeFromValidate('EditView','product_repair_description');
									removeFromValidate('EditView','repair_serial_no');
									removeFromValidate('EditView','repair_model_no');
									removeFromValidate('EditView','repair_nature_of_fault');
									removeFromValidate('EditView','repair_date_to_supplier');
									removeFromValidate('EditView','supplier_comments_repair');
									removeFromValidate('EditView','customer_approval_date');
									removeFromValidate('EditView','purchase_date_repair');
									removeFromValidate('EditView','date_of_faxed_email');
									removeFromValidate('EditView','school_points_redeemed');
									removeFromValidate('EditView','suppliers_delivery_note_no');
									removeFromValidate('EditView','suppliers_comments_repair');
									removeFromValidate('EditView','date_of_collection_repair');
									removeFromValidate('EditView','branch_manager_name_repair');
									removeFromValidate('EditView','verified_in_fully');
									removeFromValidate('EditView','released_by_repair');
									removeFromValidate('EditView','branch_mg_pr');
									removeFromValidate('EditView','verified_in_pr_no');
									removeFromValidate('EditView','released_pr_no');
									
									//When issue credit is selected, the case status should be resolved and resolution field should appear
									$('#status').val('Resolved').trigger("change");
									$("#resolution_label").show();
									$("#resolution").show();
								   
								}else if($('#credit_repair').val() == 'repair'){ 
									$("#date_sent_to_supplier").closest("td").show();
									$('#date_sent_to_supplier').show();
									$("#date_sent_to_supplier_trigger").show();
									$('#date_sent_to_supplier_label').show();
									addToValidate('EditView','date_sent_to_supplier','varchar',true,'{$mod_strings['LBL_DATE_SENT_TO_SUPPLIER']}');                           
									$('#date_sent_to_supplier_label').html('{$mod_strings['LBL_DATE_SENT_TO_SUPPLIER']}: <font color="red">*</font>');
									
								   $("#repair_delivery_note_no_label").show();
								   $("#repair_delivery_note_no").show();  
								   $("#repair_delivery_note_no").css({"background-color": "#DEDEDE", "pointer-events": "none"});
								   removeFromValidate('EditView','repair_delivery_note_no');
								   
									$("#credit_note").closest("td").hide();
									$('#credit_note').hide();
									$("#credit_note_label").hide();
									removeFromValidate('EditView','credit_note');
									$('#credit_note_label').html('{$mod_strings['LBL_CREDIT_NOTE']}:');
								   
									$("#LBL_EDITVIEW_PANEL_PRODUCT_REPAIR").show();
									$("#LBL_EDITVIEW_PANEL_SUPPLIER_INFO").hide();
									$("#detailpanel_8").show();
									$("#detailpanel_9").hide();
                                                                        
                                    //display field during create
                                   // $("select[name*='prod_repair_status'] option[value!='']").show();
																		
									//product repair status @01-jun-2017
									if($('#prod_repair_status').val() ==''){
										$('select[name="prod_repair_status"] option[value!=""][value!="Recieved"][value!="Delivered"]').show();	
									}
									
                                                                        
									$("#detailpanel_9").show();
									$("#LBL_EDITVIEW_PANEL_SCHOOL").hide();
									$("#detailpanel_3").hide();
									$("#LBL_EDITVIEW_PANEL_CHEQUE").hide();
									$("#detailpanel_4").hide();
								   
									//Make field mandatory for complaint form
									addToValidate('EditView','prod_repair_status','varchar',true,'{$mod_strings['LBL_REPAIR_STATUS']}');                           
									$('#prod_repair_status_label').html('{$mod_strings['LBL_REPAIR_STATUS']}: <font color="red">*</font>');            
									addToValidate('EditView','prod_repair_sku','varchar',true,'{$mod_strings['LBL_PROD_REPAIR_SKU']}');                           
									$('#prod_repair_sku_label').html('{$mod_strings['LBL_PROD_REPAIR_SKU']}: <font color="red">*</font>');
									addToValidate('EditView','repair_supplier_name','varchar',true,'{$mod_strings['LBL_REPAIR_SUPPLIER_NAME']}');                           
									$('#repair_supplier_name_label').html('{$mod_strings['LBL_REPAIR_SUPPLIER_NAME']}: <font color="red">*</font>');
									addToValidate('EditView','complaint_date','varchar',true,'{$mod_strings['LBL_COMPLAINT_DATE']}');                           
									$('#complaint_date_label').html('{$mod_strings['LBL_COMPLAINT_DATE']}: <font color="red">*</font>');
									addToValidate('EditView','repair_product_code','varchar',true,'{$mod_strings['LBL_REPAIR_PRODUCT_CODE']}');                           
									$('#repair_product_code_label').html('{$mod_strings['LBL_REPAIR_PRODUCT_CODE']}: <font color="red">*</font>');
									addToValidate('EditView','product_repair_description','varchar',true,'{$mod_strings['LBL_PRODUCT_REPAIR_DESCRIPTION']}');                           
									$('#product_repair_description_label').html('{$mod_strings['LBL_PRODUCT_REPAIR_DESCRIPTION']}: <font color="red">*</font>');
									addToValidate('EditView','repair_serial_no','varchar',true,'{$mod_strings['LBL_SERIAL_NO']}');                           
									$('#repair_serial_no_label').html('{$mod_strings['LBL_SERIAL_NO']}: <font color="red">*</font>');
									addToValidate('EditView','repair_model_no','varchar',true,'{$mod_strings['LBL_REPAIR_MODEL_NO']}');                           
									$('#repair_model_no_label').html('{$mod_strings['LBL_REPAIR_MODEL_NO']}: <font color="red">*</font>');
									addToValidate('EditView','repair_tag_no','varchar',true,'{$mod_strings['LBL_REPAIR_TAG_NO']}');                           
									$('#repair_tag_no_label').html('{$mod_strings['LBL_REPAIR_TAG_NO']}: <font color="red">*</font>');
									addToValidate('EditView','repair_nature_of_fault','varchar',true,'{$mod_strings['LBL_NATURE_OF_FAULT']}');                           
									$('#repair_nature_of_faultlabel').html('{$mod_strings['LBL_NATURE_OF_FAULT']}: <font color="red">*</font>');
									addToValidate('EditView','purchase_date_repair','varchar',true,'{$mod_strings['LBL_PURCHASE_DATE_REPAIR']}');                           
									$('#purchase_date_repair_label').html('{$mod_strings['LBL_PURCHASE_DATE_REPAIR']}: <font color="red">*</font>');
									addToValidate('EditView','suppliers_comments_repair','varchar',true,'{$mod_strings['LBL_SUPPLIERS_COMMENTS_REPAIR']}');                           
									$('#suppliers_comments_repair_label').html('{$mod_strings['LBL_SUPPLIERS_COMMENTS_REPAIR']}: <font color="red">*</font>');
									addToValidate('EditView','date_of_collection_repair','varchar',true,'{$mod_strings['LBL_DATE_OF_COLLECTION']}'); 
									
									//hide resolution
									$("#resolution_label").hide();
									$("#resolution").hide();
									$("#resolution").val();
									$('#status').val('Created');
									removeFromValidate('EditView','resolution');                       
									$('#resolution_label').html('{$mod_strings['LBL_RESOLUTION']}');
									
									//product repair status @01-jun-2017
									var repStaVal = $('#prod_repair_status').val();
									
									//Solve defect D461 by Ashok on 19-07-2017
									if(repStaVal ==''){
										//$('select[name=\'prod_repair_status\'] option[value!=\'\']').show();
										$('select[name=\'prod_repair_status\'] option[value!=\'InProgress\']').hide();
										 
									}else if(repStaVal =='InProgress'){
										$('select[name=\'prod_repair_status\'] option[value!=\'InProgress\'][value!=\'Recieved\']').hide();
									}else if(repStaVal =='Recieved'){
										$('select[name=\'prod_repair_status\'] option[value!=\'Recieved\'][value!=\'Delivered\']').hide();
									}else if(repStaVal =='Delivered'){
										$('select[name=\'prod_repair_status\'] option[value!=\'Delivered\']').hide();
									}
									
								 }else if($('#credit_repair').val() == 'replaced'){ 
									//When issue credit is selected, the case status should be resolved and resolution field should appear
									$('#status').val('Resolved').trigger("change");
									$("#resolution_label").show();
									$("#resolution").show();
									removeFromValidate('EditView','resolution'); 
								 }
							});
									
						/*	//Functionality in case customer says NO for the bill 
								removeFromValidate('EditView','suppliers_delivery_note_no');
                                $('#suppliers_delivery_note_no_label').html('{$mod_strings['LBL_SUPPLIERS_DELIVERY_NOTE_NO']}: ');
                                removeFromValidate('EditView','date_of_faxed_email');
                                $('#date_of_faxed_email_label').html('{$mod_strings['LBL_DATE_OF_FAXED_EMAIL']}: ');

								$('#customer_approved').change(function () {
									if($('#customer_approved').val() == 'Yes' ){
										addToValidate('EditView','suppliers_delivery_note_no','varchar',true,'{$mod_strings['LBL_SUPPLIERS_DELIVERY_NOTE_NO']}');                           
										$('#suppliers_delivery_note_no_label').html('{$mod_strings['LBL_SUPPLIERS_DELIVERY_NOTE_NO']}: <font color="red">*</font>');
										addToValidate('EditView','date_of_faxed_email','varchar',true,'{$mod_strings['LBL_DATE_OF_FAXED_EMAIL']}');                           
										$('#date_of_faxed_email_label').html('{$mod_strings['LBL_DATE_OF_FAXED_EMAIL']}: <font color="red">*</font>');
									
									}else if($('#customer_approved').val() == 'No'){
										removeFromValidate('EditView','suppliers_delivery_note_no');
										$('#suppliers_delivery_note_no_label').html('{$mod_strings['LBL_SUPPLIERS_DELIVERY_NOTE_NO']}: ');
										removeFromValidate('EditView','date_of_faxed_email');
										$('#date_of_faxed_email_label').html('{$mod_strings['LBL_DATE_OF_FAXED_EMAIL']}: ');
									}
								});
							//EOC 
							*/
							if($('#date_of_collection_repair').val() !=''){
								 $("#prod_repair_status").val().css({"background-color": "#DEDEDE", "pointer-events": "none"});
							}
							//onchange of repair status display the form
							$('#prod_repair_status').change(function () {
								if($('#prod_repair_status').val() == 'InProgress' || $('#prod_repair_status').val() =='' ){
									$("#LBL_EDITVIEW_PANEL_PRODUCT_RECEIVED").hide();
									$("#detailpanel_9").hide();  
										
									removeFromValidate('EditView','date_of_collection_repair');
									$('#date_of_collection_repair_label').html('{$mod_strings['LBL_DATE_OF_COLLECTION']}: ');
									removeFromValidate('EditView','repair_date_to_supplier');
									$('#repair_date_to_supplier_label').html('{$mod_strings['LBL_DATE_TO_SUPPLIER']}: ');

									removeFromValidate('EditView','supplier_comments_repair');
									$('#supplier_comments_repair_label').html('{$mod_strings['LBL_SUPPLIER_COMMENTS_REPAIR']}: ');

									removeFromValidate('EditView','customer_approval_date');
									$('#customer_approval_date_label').html('{$mod_strings['LBL_CUSTOMER_APPROVAL_DATE']}: ');
									removeFromValidate('EditView','bill_amount');
									$('#bill_amount_label').html('{$mod_strings['LBL_BILL_AMOUNT']}: ');
									//removeFromValidate('EditView','suppliers_delivery_note_no');
									//$('#suppliers_delivery_note_no_label').html('{$mod_strings['LBL_SUPPLIERS_DELIVERY_NOTE_NO']}: ');
									//removeFromValidate('EditView','date_of_faxed_email');
									//$('#date_of_faxed_email_label').html('{$mod_strings['LBL_DATE_OF_FAXED_EMAIL']}: ');
									
									$("#resolution_label").hide();
									$("#resolution").hide();
									$("#resolution").val('');
									//var prev_val_status = $('#status').val();
									//$('#status').val(prev_val_status);
									removeFromValidate('EditView','resolution');                       
									$('#resolution_label').html('{$mod_strings['LBL_RESOLUTION']} ');

									//$("#status").val('InProgress');//make mandatory
								}else if($('#prod_repair_status').val() == 'Recieved'){ 
									$("#LBL_EDITVIEW_PANEL_PRODUCT_RECEIVED").show();
									$("#detailpanel_9").show(); 
									//$("#detailpanel_10").show();
									
									//$('#status').val('Resolved').trigger("change");
									
									$("#resolution_label").hide();
									$("#resolution").hide();
									$("#resolution").val('');
									
									//$("#resolution_label").show();
									//$("#resolution").show();
									//addToValidate('EditView','resolution','varchar',true,'{$mod_strings['LBL_RESOLUTION']}');                           
									//$('#resolution_label').html('{$mod_strings['LBL_RESOLUTION']} <font color="red">*</font>'); 
									
									//addToValidate('EditView','date_of_collection_repair','varchar',true,'{$mod_strings['LBL_DATE_OF_COLLECTION']}');                           
									//$('#date_of_collection_repair_label').html('{$mod_strings['LBL_DATE_OF_COLLECTION']}: <font color="red">*</font>');
									addToValidate('EditView','repair_date_to_supplier','varchar',true,'{$mod_strings['LBL_DATE_TO_SUPPLIER']}');                           
									$('#repair_date_to_supplier_label').html('{$mod_strings['LBL_DATE_TO_SUPPLIER']}: <font color="red">*</font>');
									addToValidate('EditView','supplier_comments_repair','varchar',true,'{$mod_strings['LBL_SUPPLIER_COMMENTS_REPAIR']}');                           
									$('#supplier_comments_repair_label').html('{$mod_strings['LBL_SUPPLIER_COMMENTS_REPAIR']}: <font color="red">*</font>');
									addToValidate('EditView','customer_approval_date','varchar',true,'{$mod_strings['LBL_CUSTOMER_APPROVAL_DATE']}');                           
									$('#customer_approval_date_label').html('{$mod_strings['LBL_CUSTOMER_APPROVAL_DATE']}: <font color="red">*</font>');
									addToValidate('EditView','bill_amount','varchar',true,'{$mod_strings['LBL_BILL_AMOUNT']}');                           
									$('#bill_amount_label').html('{$mod_strings['LBL_BILL_AMOUNT']}: <font color="red">*</font>');
									//addToValidate('EditView','suppliers_delivery_note_no','varchar',true,'{$mod_strings['LBL_SUPPLIERS_DELIVERY_NOTE_NO']}');                           
									//$('#suppliers_delivery_note_no_label').html('{$mod_strings['LBL_SUPPLIERS_DELIVERY_NOTE_NO']}: <font color="red">*</font>');
									//addToValidate('EditView','date_of_faxed_email','varchar',true,'{$mod_strings['LBL_DATE_OF_FAXED_EMAIL']}');                           
									//$('#date_of_faxed_email_label').html('{$mod_strings['LBL_DATE_OF_FAXED_EMAIL']}: <font color="red">*</font>');									
								}else if($('#prod_repair_status').val() == 'Delivered'){ 
									$("#LBL_EDITVIEW_PANEL_PRODUCT_RECEIVED").show();
									$("#detailpanel_9").show(); 
									$("#detailpanel_10").show();
									
									$('#status').val('Resolved').trigger("change");
									//$("#resolution_label").show();
									//$("#resolution").show();
									//addToValidate('EditView','resolution','varchar',true,'{$mod_strings['LBL_RESOLUTION']}');                           
									//$('#resolution_label').html('{$mod_strings['LBL_RESOLUTION']} <font color="red">*</font>'); 
									
									addToValidate('EditView','date_of_collection_repair','varchar',true,'{$mod_strings['LBL_DATE_OF_COLLECTION']}');                           
									$('#date_of_collection_repair_label').html('{$mod_strings['LBL_DATE_OF_COLLECTION']}: <font color="red">*</font>');
									addToValidate('EditView','repair_date_to_supplier','varchar',true,'{$mod_strings['LBL_DATE_TO_SUPPLIER']}');                           
									$('#repair_date_to_supplier_label').html('{$mod_strings['LBL_DATE_TO_SUPPLIER']}: <font color="red">*</font>');
									addToValidate('EditView','supplier_comments_repair','varchar',true,'{$mod_strings['LBL_SUPPLIER_COMMENTS_REPAIR']}');                           
									$('#supplier_comments_repair_label').html('{$mod_strings['LBL_SUPPLIER_COMMENTS_REPAIR']}: <font color="red">*</font>');
									addToValidate('EditView','customer_approval_date','varchar',true,'{$mod_strings['LBL_CUSTOMER_APPROVAL_DATE']}');                           
									$('#customer_approval_date_label').html('{$mod_strings['LBL_CUSTOMER_APPROVAL_DATE']}: <font color="red">*</font>');
									addToValidate('EditView','bill_amount','varchar',true,'{$mod_strings['LBL_BILL_AMOUNT']}');                           
									$('#bill_amount_label').html('{$mod_strings['LBL_BILL_AMOUNT']}: <font color="red">*</font>');
									//addToValidate('EditView','suppliers_delivery_note_no','varchar',true,'{$mod_strings['LBL_SUPPLIERS_DELIVERY_NOTE_NO']}');                           
									//$('#suppliers_delivery_note_no_label').html('{$mod_strings['LBL_SUPPLIERS_DELIVERY_NOTE_NO']}: <font color="red">*</font>');
									//addToValidate('EditView','date_of_faxed_email','varchar',true,'{$mod_strings['LBL_DATE_OF_FAXED_EMAIL']}');                           
									//$('#date_of_faxed_email_label').html('{$mod_strings['LBL_DATE_OF_FAXED_EMAIL']}: <font color="red">*</font>');
								}
							});

						}else{
                    
                            $("#LBL_EDITVIEW_PANEL_PRODUCT_QUALITY_COMPLAINT").hide();
                            $("#LBL_EDITVIEW_PRODUCT_BRANCH").hide();
                            $("#LBL_EDITVIEW_PRODUCT_SUPPLIER").hide();
                            $("#LBL_EDITVIEW_PANEL_PRODUCT_REPAIR").hide();
							$("#LBL_EDITVIEW_PANEL_SUPPLIER_INFO").hide();
                            $("#LBL_EDITVIEW_PANEL_PRODUCT_RECEIVED").hide();
                            $("#detailpanel_5").hide();
                            $("#detailpanel_6").hide();
                            $("#detailpanel_7").hide();
                            $("#detailpanel_8").hide();
                            $("#detailpanel_9").hide();
							$("#detailpanel_10").hide();

                            $("#LBL_EDITVIEW_PANEL_SCHOOL").hide();
                            $("#detailpanel_3").hide();

                            $("#LBL_EDITVIEW_PANEL_CHEQUE").hide();
                            $("#detailpanel_4").hide();

                            $("#school_cheque_status_label").hide();
                            $("#school_cheque_status").hide();   
                            removeFromValidate('EditView','school_cheque_status'); 

                            $("#school_parent_name_label").hide();
                            $("#school_parent_name").hide();  
                            $("#school_parent_name").val('');  
                            removeFromValidate('EditView','school_parent_name');    
                            $("#school_points_redeemed_label").hide();
                            $("#school_points_redeemed").hide();  
                            $("#school_points_redeemed").val(''); 
                            removeFromValidate('EditView','school_points_redeemed');
                            $("#school_school_name_label").hide();
                            $("#school_school_name").hide();  
                            $("#school_school_name").val('');
                            removeFromValidate('EditView','school_school_name');
                            $("#school_redemption_rate_label").hide();
                            $("#school_redemption_rate").hide(); 
                            $("#school_redemption_rate").val('');
                            removeFromValidate('EditView','school_redemption_rate');

                            $("#school_amount_payable_label").hide();
                            $("#school_amount_payable").hide();  
                            $("#school_amount_payable").val('');
                            removeFromValidate('EditView','school_amount_payable');

                            $("#school_child_name_label").hide();
                            $("#school_child_name").hide();  
                            $("#school_child_name").val('');
                            removeFromValidate('EditView','school_child_name');

                            ////08-02-2017 by Ashok for receipt and till no in loyalty school fees redemtion
                            $("#school_receipt_no_label").hide();
                            $("#school_receipt_no").hide();  
                            $("#school_receipt_no").val('');
                            removeFromValidate('EditView','school_receipt_no');

                            $("#school_till_no_label").hide();
                            $("#school_till_no").hide();  
                            $("#school_till_no").val('');
                            removeFromValidate('EditView','school_till_no');
                        }
                }          
                function memberType()
                {
                    var member = $('#member_type_c').val();
                    if(member == 'guest'){               
                        $("#loyalty_id_c").val("Guest");
                        $("#loyalty_id_c").prop('readonly',true);
                        $('#loyalty_id_c').css('background-color' , '#DEDEDE');
						
						$('#mobile_number_c').css('background-color' , '#ffffff');
						$('#email_c').css('background-color' , '#ffffff');
						
						
                        $('#customer_name_c').focus();
                        $('#member_tier_c').prop('readonly', true);
                        $('#member_tier_c').val('');
                        $('#member_tier_c').css('background-color' , '#DEDEDE');  
                        $('.btn_customer').hide();//for hide Customer Lookup
                        $('.btn_clr').hide();//for hide Reset button
                        removeFromValidate('EditView','dob_c');                       
                        $('#dob_c_label').html('{$mod_strings['LBL_DOB']}: '); 

                        addToValidate('EditView','customer_name_c','varchar',true,'{$mod_strings['LBL_CUSTOMER_NAME']}');                           
                        $('#customer_name_c_label').html('{$mod_strings['LBL_CUSTOMER_NAME']}: <font color="red">*</font>');
                        
                        //16-03-2017 - remove validation from mobile number for guest user
                        removeFromValidate('EditView','mobile_number_c');
                        $('#mobile_number_c_label').html('{$mod_strings['LBL_MOBILE_NUMBER']}: '); 

                    }else{
                        if($("#loyalty_id_c").val()=='Guest'){
                            $("#loyalty_id_c").val('');
                        }else{
                            $("#loyalty_id_c").val();
                        }
                        $('.btn_customer').show();//for show Customer Lookup
                        $('.btn_clr').show();//for hide Reset button
                        $("#loyalty_id_c").prop('readonly',false);
                        $('#loyalty_id_c').css('background-color' , 'orange');
						$('#mobile_number_c').css('background-color' , 'orange');
						$('#email_c').css('background-color' , 'orange');
						
                        //Code commented for making memberTier non mandatory @Ashok Dated:19-04-2017
                       // $('#member_tier_c').prop('readonly', false);
                      //  $('#member_tier_c').css('background-color' , '#ffffff');

                        removeFromValidate('EditView','dob_c');                       
                        $('#dob_c_label').html('{$mod_strings['LBL_DOB']}: '); 
                        $('#dob_c').css('background-color' , '#ffffff');

                        removeFromValidate('EditView','customer_name_c');                       
                        $('#customer_name_c_label').html('{$mod_strings['LBL_CUSTOMER_NAME']}: ');
                        
                        addToValidate('EditView','mobile_number_c','varchar',true,'{$mod_strings['LBL_MOBILE_NUMBER']}');                           
                        $('#mobile_number_c_label').html('{$mod_strings['LBL_MOBILE_NUMBER']}: <font color="red">*</font>');
                    }
                }
        
                //Resolution Validation 
                $("#resolution_label").hide();
                $("#resolution").hide();

                var prev_val_status = $('#status').val();
                var record_val = $('#edit_record').val();   
                if(record_val != null){ 
					$("#description").prop('readonly', true);
					
                    var statusVal = $('#status').val();
					if(statusVal =='Created'){
					  $('select[name="status"] option[value!=""][value!="InProgress"][value!="UnderResearch"][value!="Resolved"]').hide();
					}
					if(statusVal =='InProgress'){
					  $('select[name="status"] option[value!="InProgress"][value!="UnderResearch"][value!="Resolved"]').hide();
					}
					if(statusVal =='UnderResearch'){
						//[value!=""]
					  $('select[name="status"] option[value!="UnderResearch"][value!="Resolved"]').hide();
					}
					if(statusVal =='Resolved'){
					  $('select[name="status"] option[value!="Closed"][value!="Reopen"][value!="Resolved"]').hide();
					}
					
					
					addToValidate('EditView','case_comments','varchar',true,'{$mod_strings['LBL_CASE_COMMENTS']}');                           
                    $('#case_comments_label').html('{$mod_strings['LBL_CASE_COMMENTS']}: <font color="red">*</font>');
					
				
                }else{
                    $('#status').val('Created');
				    $('select[name="status"] option[value!=""][value!="Created"]').hide();					
					removeFromValidate('EditView','case_comments');                       
                    $('#customer_name_c_label').html('{$mod_strings['LBL_CUSTOMER_NAME']}: ');
					
                }
				
                 $('#status').change(function() { 
				   var subcat = $("#subcategory_c option:selected").text();
				   var catstr = $("#category_c option:selected").text();
				   var cat = catstr.toUpperCase();
				   var cat_product_str = 'Product';
				   var cat_product = cat_product_str.toUpperCase();
				    
                    if(record_val != null){ 
                        var success = confirm('Are you sure you want to change the status?');
                        if (success == true) {
                                statusnow(); 
                        }else{ 
                            $('#status').val(prev_val_status);
                        }
                    }else if( (cat == cat_product) && (subcat != '')){
                       
                        $("#resolution_label").show();
                        $("#resolution").show();
                        addToValidate('EditView','resolution','varchar',true,'{$mod_strings['LBL_RESOLUTION']}');                           
                        $('#resolution_label').html('{$mod_strings['LBL_RESOLUTION']}<font color="red">*</font>'); 
                    }else{
                         $('#status').val('Created');
                         alert('Status change during creation is not allowed.');
                    }

                });
                function statusnow()
                { 
                    var status = $('#status').val(); 
                    subcat_str = $("#subcategory_c option:selected").text(); 
					
					var subcat = subcat_str.toUpperCase();
					
					var subcat_school_str = 'School fee redemption';
				    var subcat_school = subcat_school_str.toUpperCase();
					
					var catstr = $("#category_c option:selected").text();
					var cat = catstr.toUpperCase();
				    var cat_product_str = 'Product';
				    var cat_product = cat_product_str.toUpperCase();
				   
				   
                    var school_cheque_status = $('#school_cheque_status').val();  
                    var prod_repair_status = $('#prod_repair_status').val(); 
                    if(subcat == subcat_school ){
                        if( status  =='Resolved' && school_cheque_status != 'Delivered'){
                            $('#status').val(prev_val_status);
                            alert ("Case cannot be resolved until cheque has been issued to the customer.");
                            return false;
                        }
                    }

                    if(cat == cat_product && subcat != ''){ 
                        var prev_val_status = $('#status').val();
                        if( status  =='Resolved' && prod_repair_status == 'InProgress'){
                            $('#status').val('InProgress');
                            alert ("Case cannot be resolved until product is received.");
                            return false;
                        }else if(status  =='Resolved' && prod_repair_status == 'Delivered'){ //validation error is fixed
                            $('#status').val('Resolved').css('pointer-events','none');
                        }else{
							 $('#status').val().css('pointer-events','fill');
						}
                    } 
                    //if status is resolved then open resolution button
                    //Author:Ashok Dated: 13-04-2017 Desc: show resolution for closed 
                    if(status == 'Resolved' || status == 'Closed'){
                        $("#resolution_label").show();
                        $("#resolution").show();

                        addToValidate('EditView','resolution','varchar',true,'{$mod_strings['LBL_RESOLUTION']}');                           
                        $('#resolution_label').html('{$mod_strings['LBL_RESOLUTION']}<font color="red">*</font>'); 
                    }else{                      
                        $("#resolution_label").hide();
                        $("#resolution").hide();
                        $("#resolution").val();
                        removeFromValidate('EditView','resolution');                       
                        $('#resolution_label').html('{$mod_strings['LBL_RESOLUTION']}: ');
                    }

                }
                
                //if status is resolved then open resolution button @Ashok Dated: 31-03-2017
                    var status = $('#status').val();
                    if(status == 'Resolved' || status == 'Closed'){ 
                        $("#resolution_label").show();
                        $("#resolution").show();

                        addToValidate('EditView','resolution','varchar',true,'{$mod_strings['LBL_RESOLUTION']}');                           
                        $('#resolution_label').html('{$mod_strings['LBL_RESOLUTION']} <font color="red">*</font>'); 
                    }else{                      
                        $("#resolution_label").hide();
                        $("#resolution").hide();
                        $("#resolution").val();
                        removeFromValidate('EditView','resolution');                       
                        $('#resolution_label').html('{$mod_strings['LBL_RESOLUTION']}: ');
                    }            
            </script>
EOQ;
        


        //Category display none in dropdown of category dated:  25-10-2016 
        $cat[''] = 'Select';
        $query_cat = "SELECT name,id FROM naku_casecategory WHERE deleted =0 order by name";
        $result = $GLOBALS['db']->query($query_cat, false);
        while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
            $cat[$row['id']] = $row['name'];
        }
        $this->ss->assign("CATEGORY", get_select_options_with_id($cat, $this->bean->category_c));
        //display select in dropdown of subcategory dated: 25-10-2016  
        if (isset($this->bean->subcategory_c)) {
            $subcat[''] = 'Select';
            $query_subcat = "SELECT name,id FROM naku_casesubcategory WHERE deleted =0 order by name";
            $result_sub = $GLOBALS['db']->query($query_subcat, false);
            while ($row_sub = $GLOBALS['db']->fetchByAssoc($result_sub)) {
                $subcat[$row_sub['id']] = $row_sub['name'];
            }
            $this->ss->assign("SUBCATEGORY", get_select_options_with_id($subcat, $this->bean->subcategory_c));
        } else {
            $this->ss->assign("SUBCATEGORY", '--Select--');
        }
        //Create objects
        $myCategory = new naku_CaseCategory();
        $mySubCategory = new naku_CaseSubCategory();
        
        //start Roles and Permission Hacks by Akhilesh
        $uid = $current_user->id; //Logged in User ID
        $category_module = "Cases"; //Module name
        $type = "module"; //Nochnage
        $rootAction = "case"; //Root or Parent Action name according to magento Root action name i.e. if rootAction is true then all subAction is true no need to check subAction is true or false. Nakumatt_CaseManagement::case, Nakumatt_Campaign::markiting_list, Nakumatt_Campaign::markiting_calendar, Nakumatt_Campaign::campaign_asset, Nakumatt_Campaign::campaign

        $subActionAssign  = "assign"; //assign ICON
        $assignIcon = RoleHack::getCustomRole($uid, $category_module, $rootAction, $subActionAssign, $type);
        //Funtionality to assign case to other users by admin only
        if (($assignIcon == true) || ($current_user->isAdmin() == 1)) {
            echo '<script type="text/javascript">
                 $(document).ready(function(){
                    $("#btn_assigned_user_name").show();
                    $("#btn_clr_assigned_user_name").show();
                    $("#assigned_user_name").css("background-color" , "#ffffff");
                    $("#assigned_user_name").prop("readonly", false);
                    $("#assigned_user_id").css("background-color", "#ffffff");
                    $("#assigned_user_id").prop("readonly", false);
                 });
                 </script>';
        } else {
            echo '<script type="text/javascript" >
                         $(document).ready(function(){
                            $("#btn_assigned_user_name").hide();
                            $("#btn_clr_assigned_user_name").hide();
                            $("#assigned_user_name").css("background-color" , "#DEDEDE");
                            $("#assigned_user_name").prop("readonly", true);
                            $("#assigned_user_id").css("background-color", "#DEDEDE");
                            $("#assigned_user_id").prop("readonly", true);
                         });
                         </script>';
        }
        //end Roles and Permission Hacks by Akhilesh
        
        //Check in case record is saved and edit is in progress 
        if (isset($this->bean->id)) {
          
            $this->bean->name = isset($this->bean->name) ? $this->bean->name : '';
            //To fetch the record ifd in editview
            echo '<input type ="hidden" name="edit_record" id ="edit_record" value ="' . $this->bean->id . '" >';
            $this->bean->origin_c =  $this->bean->origin_c;
            //To display cat and sub cat 
            $loyalty_id = $this->bean->loyalty_id_c;
            $mobNum = $this->bean->mobile_number_c;
            if ($loyalty_id != 'Guest') {
                //query to fetch the detail based on loyalty id
                $query_caseHist = "SELECT cases.case_number, cases_cstm.customer_name_c,cases.id,cases_cstm.origin_c,"
                        . " cases.priority, cases.status, cases.assigned_user_id, cases.date_entered, cases_cstm.member_tier_c  "
                        . " FROM cases JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " WHERE cases.deleted =0 AND cases_cstm.loyalty_id_c = '" . $loyalty_id . "' limit 5 ";
                $result = $GLOBALS['db']->query($query_caseHist);
                //$count = $result->num_rows;  
                $count = isset($result->num_rows) ? $result->num_rows : '';
            } else {
                 
                //query to fetch the detail based on mobile number and for guest users
                $query_caseHist = "SELECT cases.case_number, cases_cstm.customer_name_c,cases.id,cases_cstm.origin_c,"
                        . " cases.priority, cases.status, cases.assigned_user_id, cases.date_entered, cases_cstm.member_tier_c  "
                        . " FROM cases JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " WHERE cases.deleted =0 AND cases_cstm.mobile_number_c = '" . $mobNum . "'  AND cases_cstm.loyalty_id_c = 'Guest' limit 5 ";

                $result = $GLOBALS['db']->query($query_caseHist);
                $count = '-1'; //isset($result->num_rows) ? $result->num_rows : '';
            }
            // $count = isset($result->num_rows) ? $result->num_rows : '';
            //Display template or table stucture
            if ($count > 0) {
                $field_query_caseHist = '<style>.case-history-layout{width:100%;}#case_history{border-collapse:collapse;}#case_history,#case_history td, #case_history th{border: 1px solid black;}#case_history th{background-color:#FDE848;}</style><tr id="global_id"><td class="case-history-layout"><table width="100%" id="case_history" border="1">';
                $field_query_caseHist .= '<tr><th>Case ID</th><th>Customer Name</th><th>Origin</th><th>Priority</th><th>Status</th>';
                $field_query_caseHist .= '<th>Agent ID</th><th>Created On</th><th>Member Tier</th></tr>';
                while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
                    $originname = $app_list_strings['origin_list'][$row['origin_c']];
                    $priorityname = $app_list_strings['case_priority_dom'][$row['priority']];
                    $userid = $row['assigned_user_id'];
                    $myUser->retrieve($userid);
                    $assignedName = $myUser->full_name;
                    $caseID = $row['id'];
                    $caseNum = $row['case_number'];
                    $link = '<a href="index.php?module=Cases&return_module=Cases&action=DetailView&record=' . $caseID . '">' . $caseNum . '</a>';

                    $field_query_caseHist .= '<tr>';
                    $field_query_caseHist .= '<td align="center"><div>' . $link . '</div></td>';
                    $field_query_caseHist .= '<td align="center"><div>' . $row['customer_name_c'] . '</div></td>';
                    $field_query_caseHist .= '<td align="center"><div>' . $originname . '</div></td>';
                    $field_query_caseHist .= '<td align="center"><div>' . $priorityname . '</div></td>';
                    $field_query_caseHist .= '<td align="center"><div>' . $row['status'] . '</div></td>';
                    $field_query_caseHist .= '<td align="center"><div>' . $assignedName . '</div></td>';
                    $field_query_caseHist .= '<td align="center"><div>' . $row['date_entered'] . '</div></td>';
                    $field_query_caseHist .= '<td align="center"><div>' . $row['member_tier_c'] . '</div></td>';
                    $field_query_caseHist .= '</tr>';
                }
                $field_query_caseHist .= '</td></table></tr><br />';
                $this->ss->assign('CASEHISTORY', $field_query_caseHist);
            }
            //Similar Cases to display based on subcategory

            $simcat = $this->bean->subcategory_c;
            $query_Simcase = "SELECT cases.case_number, cases_cstm.customer_name_c, cases_cstm.category_c,cases_cstm.subcategory_c,cases.id, cases_cstm.origin_c,"
                    . " cases.priority, cases.status, cases.assigned_user_id, cases.date_entered, cases_cstm.member_tier_c  "
                    . " FROM cases JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                    . " WHERE cases.deleted =0  AND cases.status ='Resolved' AND cases_cstm.id_c != '" . $this->bean->id . "' AND cases_cstm.subcategory_c = '" . $simcat . "' limit 5 ";

            $resultSimcase = $GLOBALS['db']->query($query_Simcase);
            $count = $resultSimcase->num_rows;
            $field_query_simcaseHist = '';
            if ($count > 0) {
                $field_query_simcaseHist .= '<style>.case-history-layout{width:100%;}#case_history{border-collapse:collapse;}#case_history,#case_history td, #case_history th{border: 1px solid black;}#case_history th{background-color:#FDE848;}</style><tr id="global_id"><td class="case-history-layout"><table width="100%" id="case_history" border="1">';
                $field_query_simcaseHist .= '<tr><th>Case ID</th><th>Customer Name</th><th>Category</th><th>SubCategory</th><th>Origin</th><th>Priority</th><th>Status</th>';
                $field_query_simcaseHist .= '<th>Agent ID</th><th>Created On</th><th>Member Tier</th></tr>';

                while ($rowsimcase = $GLOBALS['db']->fetchByAssoc($resultSimcase)) {
                    $originname = $app_list_strings['origin_list'][$rowsimcase['origin_c']];
                    $priorityname = $app_list_strings['case_priority_dom'][$rowsimcase['priority']];
                    $userid = $rowsimcase['assigned_user_id'];
                    $myUser->retrieve($userid);
                    $assignedName = $myUser->full_name;
                    $caseID = $rowsimcase['id'];
                    $caseNum = $rowsimcase['case_number'];

                    $myCategory->retrieve($rowsimcase['category_c']);
                    $catName = $myCategory->name;

                    $mySubCategory->retrieve($rowsimcase['subcategory_c']);
                    $subCatName = $mySubCategory->name;
                    $link = '<a href="index.php?module=Cases&return_module=Cases&action=DetailView&record=' . $caseID . '">' . $caseNum . '</a>';

                    $field_query_simcaseHist .= '<tr>';
                    $field_query_simcaseHist .= '<td align="center"><div>' . $link . '</div></td>';
                    $field_query_simcaseHist .= '<td align="center"><div>' . $rowsimcase['customer_name_c'] . '</div></td>';
                    $field_query_simcaseHist .= '<td align="center"><div>' . $catName . '</div></td>';
                    $field_query_simcaseHist .= '<td align="center"><div>' . $subCatName . '</div></td>';
                    $field_query_simcaseHist .= '<td align="center"><div>' . $originname . '</div></td>';
                    $field_query_simcaseHist .= '<td align="center"><div>' . $priorityname . '</div></td>';
                    $field_query_simcaseHist .= '<td align="center"><div>' . $rowsimcase['status'] . '</div></td>';
                    $field_query_simcaseHist .= '<td align="center"><div>' . $assignedName . '</div></td>';
                    $field_query_simcaseHist .= '<td align="center"><div>' . $rowsimcase['date_entered'] . '</div></td>';
                    $field_query_simcaseHist .= '<td align="center"><div>' . $rowsimcase['member_tier_c'] . '</div></td>';

                    $field_query_simcaseHist .= '</tr>';
                }
                $field_query_simcaseHist .= '</td></table></tr><br />';
                $this->ss->assign('SIMILARCASES', $field_query_simcaseHist);
            } else {
                $field_query_simcaseHist = '<tr id="global_id"><td class="case-history-layout"><table width="100%" >';
                $field_query_simcaseHist .= 'NO SIMILAR CASES RESOLVED';
                $field_query_simcaseHist .= '</table></tr><br />';
                $this->ss->assign('SIMILARCASES', $field_query_simcaseHist);
            }
            
            //Funtionality to assign case to other users by admin only
            if (($assignIcon == true) || ($current_user->isAdmin() == 1)) {
                echo '<script type="text/javascript" >
                     $(document).ready(function(){
                        $("#btn_assigned_user_name").show();
                        $("#btn_clr_assigned_user_name").show();
                        $("#assigned_user_name").css("background-color" , "#ffffff");
                        $("#assigned_user_name").prop("readonly", false);
                        $("#assigned_user_id").css("background-color", "#ffffff");
                        $("#assigned_user_id").prop("readonly", false);
                     });
                     </script>';
            } else {
                echo '<script type="text/javascript" >
                             $(document).ready(function(){
                                $("#btn_assigned_user_name").hide();
                                $("#btn_clr_assigned_user_name").hide();
                                $("#assigned_user_name").css("background-color" , "#DEDEDE");
                                $("#assigned_user_name").prop("readonly", true);
                                $("#assigned_user_id").css("background-color", "#DEDEDE");
                                $("#assigned_user_id").prop("readonly", true);
                             });
                             </script>';
            }
            //end Roles and Permission Hacks by Akhilesh
            
            if($this->bean->credit_repair =='credit' && $this->bean->product_replaced=='No' ){ 
                 echo "<script type='text/javascript' >
                             $(document).ready(function(){
                                $('#LBL_EDITVIEW_PANEL_PRODUCT_REPAIR').hide();
								$('#LBL_EDITVIEW_PANEL_SUPPLIER_INFO').hide();
                                $('#LBL_EDITVIEW_PANEL_PRODUCT_RECEIVED').hide();
                                $('#detailpanel_8').hide();
                                $('#detailpanel_9').hide();    
								$('#detailpanel_10').hide();
                                //Remove mandatory 
                                        removeFromValidate('EditView','repair_tag_no');
                                        removeFromValidate('EditView','bill_amount');
                                       // removeFromValidate('EditView','receipt_no_repair');
                                        removeFromValidate('EditView','prod_repair_status');
                                        removeFromValidate('EditView','prod_repair_sku');
                                        removeFromValidate('EditView','repair_supplier_name');
                                        removeFromValidate('EditView','complaint_date');
                                        removeFromValidate('EditView','repair_product_code');
                                        removeFromValidate('EditView','product_repair_description');
                                        removeFromValidate('EditView','repair_serial_no');
                                        removeFromValidate('EditView','repair_model_no');
                                        removeFromValidate('EditView','repair_nature_of_fault');
                                        removeFromValidate('EditView','repair_date_to_supplier');
                                        removeFromValidate('EditView','supplier_comments_repair');
                                        removeFromValidate('EditView','customer_approval_date');
                                       // removeFromValidate('EditView','till_no_repair');
                                        removeFromValidate('EditView','purchase_date_repair');
                                        removeFromValidate('EditView','date_of_faxed_email');
                                        removeFromValidate('EditView','school_points_redeemed');
                                        removeFromValidate('EditView','suppliers_delivery_note_no');
                                        removeFromValidate('EditView','suppliers_comments_repair');
                                        removeFromValidate('EditView','date_of_collection_repair');
                                        removeFromValidate('EditView','branch_manager_name_repair');
                                        removeFromValidate('EditView','verified_in_fully');
                                        removeFromValidate('EditView','released_by_repair');
                                        removeFromValidate('EditView','branch_mg_pr');
                                        removeFromValidate('EditView','verified_in_pr_no');
                                        removeFromValidate('EditView','released_pr_no');

                            });
                     </script>";
            }else if($this->bean->credit_repair =='repair' && $this->bean->product_replaced=='No'){ 
                echo "<script type='text/javascript' >
                             $(document).ready(function(){
                                $('#LBL_EDITVIEW_PANEL_PRODUCT_REPAIR').show();
								$('#LBL_EDITVIEW_PANEL_SUPPLIER_INFO').show();
                                $('#LBL_EDITVIEW_PANEL_PRODUCT_RECEIVED').show();
                                $('#detailpanel_8').show();
                                
                                 //display field during Edit
                                $('select[name=\'prod_repair_status\'] option[value!=\'\']').show();
								
								
								//product repair status @01-jun-2017
									var repStaVal = $('#prod_repair_status').val();
									if(repStaVal ==''){
										$('select[name=\'prod_repair_status\'] option[value!=\'\']').show();	
									}else if(repStaVal =='InProgress'){
										$('select[name=\'prod_repair_status\'] option[value!=\'InProgress\'][value!=\'Recieved\']').hide();
									}else if(repStaVal =='Recieved'){
										$('select[name=\'prod_repair_status\'] option[value!=\'Recieved\'][value!=\'Delivered\']').hide();
									}else if(repStaVal =='Delivered'){
										$('select[name=\'prod_repair_status\'] option[value!=\'Delivered\']').hide();
									}
									

                                $('#detailpanel_9').show();
								$('#detailpanel_10').show();
								
                                //Make field mandatory for complaint form
                                    addToValidate('EditView','prod_repair_status','varchar',true,'{$mod_strings['LBL_REPAIR_STATUS']}');                           
                                    $('#prod_repair_status_label').html('{$mod_strings['LBL_REPAIR_STATUS']}: <font color=\'red\'>*</font>');  
                                    addToValidate('EditView','repair_serial_no','varchar',true,'{$mod_strings['LBL_SERIAL_NO']}');                           
                                    $('#repair_serial_no_label').html('{$mod_strings['LBL_SERIAL_NO']}: <font color=\'red\'>*</font>');
   
                                    addToValidate('EditView','repair_model_no','varchar',true,'{$mod_strings['LBL_REPAIR_MODEL_NO']}');                           
                                    $('#repair_model_no_label').html('{$mod_strings['LBL_REPAIR_MODEL_NO']}: <font color=\'red\'>*</font>');
                                    addToValidate('EditView','repair_tag_no','varchar',true,'{$mod_strings['LBL_REPAIR_TAG_NO']}');                           
                                    $('#repair_tag_no_label').html('{$mod_strings['LBL_REPAIR_TAG_NO']}: <font color=\'red\'>*</font>');
                                    addToValidate('EditView','repair_nature_of_fault','varchar',true,'{$mod_strings['LBL_NATURE_OF_FAULT']}');                           
                                    $('#repair_nature_of_faultlabel').html('{$mod_strings['LBL_NATURE_OF_FAULT']}: <font color=\'red\'>*</font>');
//                                    addToValidate('EditView','repair_date_to_supplier','varchar',true,'{$mod_strings['LBL_DATE_TO_SUPPLIER']}');                           
//                                    $('#repair_date_to_supplier_label').html('{$mod_strings['LBL_DATE_TO_SUPPLIER']}: <font color=\'red\'>*</font>');
//                                   
//                                    addToValidate('EditView','supplier_comments_repair','varchar',true,'{$mod_strings['LBL_SUPPLIER_COMMENTS_REPAIR']}');                           
//                                    $('#supplier_comments_repair_label').html('{$mod_strings['LBL_SUPPLIER_COMMENTS_REPAIR']}: <font color=\'red\'>*</font>');
//                                    addToValidate('EditView','customer_approval_date','varchar',true,'{$mod_strings['LBL_CUSTOMER_APPROVAL_DATE']}');                           
//                                    $('#customer_approval_date_label').html('{$mod_strings['LBL_CUSTOMER_APPROVAL_DATE']}: <font color=\'red\'>*</font>');
//                                    addToValidate('EditView','bill_amount','varchar',true,'{$mod_strings['LBL_BILL_AMOUNT']}');                           
//                                    $('#bill_amount_label').html('{$mod_strings['LBL_BILL_AMOUNT']}: <font color=\'red\'>*</font>');
                                    
                                    addToValidate('EditView','purchase_date_repair','varchar',true,'{$mod_strings['LBL_PURCHASE_DATE_REPAIR']}');                           
                                    $('#purchase_date_repair_label').html('{$mod_strings['LBL_PURCHASE_DATE_REPAIR']}: <font color=\'red\'>*</font>');
//                                    addToValidate('EditView','date_of_faxed_email','varchar',true,'{$mod_strings['LBL_DATE_OF_FAXED_EMAIL']}');                           
//                                    $('#date_of_faxed_email_label').html('{$mod_strings['LBL_DATE_OF_FAXED_EMAIL']}: <font color=\'red\'>*</font>');
//addToValidate('EditView','suppliers_delivery_note_no','varchar',true,'{$mod_strings['LBL_SUPPLIERS_DELIVERY_NOTE_NO']}');                           
//  $('#suppliers_delivery_note_no_label').html('{$mod_strings['LBL_SUPPLIERS_DELIVERY_NOTE_NO']}: <font color=\'red\'>*</font>');                                 addToValidate('EditView','date_of_collection_repair','varchar',true,'{$mod_strings['LBL_DATE_OF_COLLECTION']}');
// $('#date_of_collection_repair_label').html('{$mod_strings['LBL_DATE_OF_COLLECTION']}: <font color=\'red\'>*</font>');
                            });
                     </script>";
            }else if($this->bean->credit_repair =='replaced' && $this->bean->product_replaced=='Yes'){  
                 echo "<script type='text/javascript' >
                             $(document).ready(function(){   
                                $('#LBL_EDITVIEW_PANEL_PRODUCT_REPAIR').hide();
								$('#LBL_EDITVIEW_PANEL_SUPPLIER_INFO').hide();
                                $('#detailpanel_8').hide();
                                $('#LBL_EDITVIEW_PANEL_DELIVERY_NOTE').hide();
                                $('#detailpanel_9').hide(); 
								 $('#detailpanel_10').hide();
                                    $('#credit_repair').css({'background-color': '#DEDEDE', 'pointer-events': 'none'});
                                    $('#product_replaced').css({'background-color': '#DEDEDE', 'pointer-events': 'none'});
                                    //Remove mandatory 
                                        removeFromValidate('EditView','repair_tag_no');
                                        removeFromValidate('EditView','bill_amount');
                                        removeFromValidate('EditView','prod_repair_status');
                                        removeFromValidate('EditView','prod_repair_sku');
                                        removeFromValidate('EditView','repair_supplier_name');
                                        removeFromValidate('EditView','complaint_date');
                                        removeFromValidate('EditView','repair_product_code');
                                        removeFromValidate('EditView','product_repair_description');
                                        removeFromValidate('EditView','repair_serial_no');
                                        removeFromValidate('EditView','repair_model_no');
                                        removeFromValidate('EditView','repair_nature_of_fault');
                                        removeFromValidate('EditView','repair_date_to_supplier');
                                        removeFromValidate('EditView','supplier_comments_repair');
                                        removeFromValidate('EditView','customer_approval_date');
                                        removeFromValidate('EditView','purchase_date_repair');
                                        removeFromValidate('EditView','date_of_faxed_email');
                                        removeFromValidate('EditView','school_points_redeemed');
                                        removeFromValidate('EditView','suppliers_delivery_note_no');
                                        removeFromValidate('EditView','suppliers_comments_repair');
                                        removeFromValidate('EditView','date_of_collection_repair');
                                        removeFromValidate('EditView','branch_manager_name_repair');
                                        removeFromValidate('EditView','verified_in_fully');
                                        removeFromValidate('EditView','released_by_repair');
                                        removeFromValidate('EditView','branch_mg_pr');
                                        removeFromValidate('EditView','verified_in_pr_no');
                                        removeFromValidate('EditView','released_pr_no');

                            });
                     </script>";
            }else if($this->bean->credit_repair ==''){
                  echo "<script type='text/javascript' >
                             $(document).ready(function(){
                                $('#LBL_EDITVIEW_PANEL_PRODUCT_REPAIR').hide();
								$('#LBL_EDITVIEW_PANEL_SUPPLIER_INFO').hide();
                                $('#LBL_EDITVIEW_PANEL_PRODUCT_RECEIVED').hide();
                                $('#detailpanel_8').hide();
                                $('#detailpanel_9').hide();   
								$('#detailpanel_10').hide(); 								
                                //Remove mandatory 
                                        removeFromValidate('EditView','repair_tag_no');
                                        removeFromValidate('EditView','bill_amount');
                                       // removeFromValidate('EditView','receipt_no_repair');
                                        removeFromValidate('EditView','prod_repair_status');
                                        removeFromValidate('EditView','prod_repair_sku');
                                        removeFromValidate('EditView','repair_supplier_name');
                                        removeFromValidate('EditView','complaint_date');
                                        removeFromValidate('EditView','repair_product_code');
                                        removeFromValidate('EditView','product_repair_description');
                                        removeFromValidate('EditView','repair_serial_no');
                                        removeFromValidate('EditView','repair_model_no');
                                        removeFromValidate('EditView','repair_nature_of_fault');
                                        removeFromValidate('EditView','repair_date_to_supplier');
                                        removeFromValidate('EditView','supplier_comments_repair');
                                        removeFromValidate('EditView','customer_approval_date');
                                       // removeFromValidate('EditView','till_no_repair');
                                        removeFromValidate('EditView','purchase_date_repair');
                                        removeFromValidate('EditView','date_of_faxed_email');
                                        removeFromValidate('EditView','school_points_redeemed');
                                        removeFromValidate('EditView','suppliers_delivery_note_no');
                                        removeFromValidate('EditView','suppliers_comments_repair');
                                        removeFromValidate('EditView','date_of_collection_repair');
                                        removeFromValidate('EditView','branch_manager_name_repair');
                                        removeFromValidate('EditView','verified_in_fully');
                                        removeFromValidate('EditView','released_by_repair');
                                        removeFromValidate('EditView','branch_mg_pr');
                                        removeFromValidate('EditView','verified_in_pr_no');
                                        removeFromValidate('EditView','released_pr_no');

                            });
                     </script>";
            }
            if($this->bean->school_redemption_rate !=''){ 
                 $this->ss->assign('REDEMTION_RATE_SAVED', $this->bean->school_redemption_rate);
            }
        }
        echo'<link rel="stylesheet" href="custom/include/css/common.css" /><style>#back_link,#btn_view_change_log{display:none !important;}</style>';
		
			
			
		//if (($assignIcon == true) || ($current_user->isAdmin() == 1)) {
			$curr_user = $current_user->id;
            $assignedcases = $this->bean->assigned_user_id;
			if($curr_user == $assignedcases){
			
				echo "<script>
						$('#status').css({'pointer-events':'none','background-color':'#DEDEDE'});
					</script>";
					
			}else{
				echo "<script>
					$('#status').css({'pointer-events':'fill','background-color':'#FFFFFF'});
				</script>";
			}
		 
		//}
		
		
		 
        parent::display();
        echo $jsscript;
        
        
    }
}
?>
