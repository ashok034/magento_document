<?php
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/
/**
 * Cases SugarCRM volumesupplier 
 * 
 */
class CasesViewVolumeSupplier extends SugarView{
    public function display() {
       global $app_list_strings,$sugar_config;
       $smarty = new Sugar_Smarty();

	  
	    $smarty->assign('site_url', $sugar_config['site_url']);
		
	   $smarty->assign('getAllSupplier',$this->view_object_map['getAllSupplier']);//supplier popup @Ashok Dated: 25-04-2017
       $getAllSupplier = $this->view_object_map['getAllSupplier'];
       $smarty->assign('volumesupplier',$this->view_object_map['volumesupplier']);
       $getAllCaseCategory = $this->view_object_map['getAllCaseCategory'];
	   $smarty->assign('site_url', $this->view_object_map['site_url']);       
       $smarty->assign('getAllCaseCategory',$getAllCaseCategory);
       $getAllSupplierDetails = $this->view_object_map['getAllSupplierDetails'];
       $smarty->assign('getAllSupplierDetails',$getAllSupplierDetails);
       $getAllSupplierDepartment = $this->view_object_map['getAllSupplierDepartment'];
       $smarty->assign('getAllSupplierDepartment',$getAllSupplierDepartment);
	   
	   $getAllSupplierFromCases = $this->view_object_map['getAllSupplierFromCases'];
       $smarty->assign('getAllSupplierFromCases',$getAllSupplierFromCases);
	   
	    $getAllSKUFromCases = $this->view_object_map['getAllSKUFromCases'];
       $smarty->assign('getAllSKUFromCases',$getAllSKUFromCases);
	   
	   
	   $smarty->assign('getTimePeriod',$this->view_object_map['getTimePeriod']);
       
       $smarty->assign('origin_list',$app_list_strings['origin_list_report']);
       $smarty->assign('case_priority_list',$app_list_strings['case_priority_report']);
       $smarty->assign('case_status_list',$app_list_strings['case_status_report']);
       $smarty->assign('total_cases',$this->view_object_map['total_cases']);
	   
		
		
	   //new change
	   $smarty->assign('getSubCategory',$this->view_object_map['getSubCategory']); // get subcategory
	   $smarty->assign('getcreateMonthdd',$this->view_object_map['createMonthdd']);
	   $smarty->assign('getStartmonth',$this->view_object_map['getStartmonth']);
	   $smarty->assign('getEndmonth',$this->view_object_map['getEndmonth']);
	   $smarty->assign('getcreatWeeklydd',$this->view_object_map['creatWeeklydd']);
	   
	   $smarty->assign('creatQudd',$this->view_object_map['creatQudd']);
	   $smarty->assign('getcreatQuadd',$this->view_object_map['periodquasdd']);
	   $smarty->assign('periodquaedd',$this->view_object_map['periodquaedd']);
	   $smarty->assign('creatQudd',$this->view_object_map['creatQudd']);
	   $smarty->assign('getStartweek',$this->view_object_map['getStartweek']);
	   $smarty->assign('getEndweek',$this->view_object_map['getEndweek']);
	   $smarty->assign('sub_category_id',$this->view_object_map['sub_category_id']); // get subcategory
	   //EOC
	   $smarty->assign('getYearDd',$this->view_object_map['getYearDd']);
	   if(isset($this->view_object_map['getFromDate'])):
		$smarty->assign('getFromDate',$this->view_object_map['getFromDate']);
	   endif;
	   if(isset($this->view_object_map['getToDate'])):
		$smarty->assign('getToDate',$this->view_object_map['getToDate']);
	   endif;
	   
	   if(isset($this->view_object_map['getPeriod'])):
		$smarty->assign('getPeriod',$this->view_object_map['getPeriod']);
	   endif;
	   
	   
	   if(isset($this->view_object_map['getOrigin'])):
		$smarty->assign('getOrigin',$this->view_object_map['getOrigin']);
	   endif;
	   if(isset($this->view_object_map['getCategory'])):
		$smarty->assign('getCategory',$this->view_object_map['getCategory']);
	   endif;
	   
	   if(isset($this->view_object_map['getSupplierid'])):
		$smarty->assign('getSupplierid',$this->view_object_map['getSupplierid']);
	   endif;
	   
	   if(isset($this->view_object_map['getSupplierDeptid'])):
		$smarty->assign('getSupplierDeptid',$this->view_object_map['getSupplierDeptid']);
	   endif;
	   
	   if(isset($this->view_object_map['getStatus'])):
		$smarty->assign('getStatus',$this->view_object_map['getStatus']);
	   endif;
	   
	    if(isset($this->view_object_map['getSupplierandsku'])):
		$smarty->assign('getSupplierandsku',$this->view_object_map['getSupplierandsku']);
	   endif;
	   
	    if(isset($this->view_object_map['getSupplierSKU'])):
		$smarty->assign('getSupplierSKU',$this->view_object_map['getSupplierSKU']);
	   endif;
	   
        $smarty->assign('branchName',$this->view_object_map['branch_store_name']);
        $smarty->assign('getBranchName',$this->view_object_map['getBranchName']);
		
	   if(isset($this->view_object_map['getFromyear'])):
		$smarty->assign('getFromyear',$this->view_object_map['getFromyear']);
	   endif;
	   
	   if(isset($this->view_object_map['getToyear'])):
		$smarty->assign('getToyear',$this->view_object_map['getToyear']);
	   endif;
		
		if(count($_POST['supplier_id']) > 0):
		$smarty->assign('selectedoptionsup',$_POST['supplier_id']);
		endif;

		if(count($_POST['suppliersku']) > 0):
		$smarty->assign('selectedoption',$_POST['suppliersku']);
		endif;
		
		$smarty->assign('volumesupplierrecord',$this->view_object_map['volumesupplierrecord']);
		
	   ?>
	   <link rel="stylesheet" href="custom/include/css/common.css">
	   <link rel="stylesheet" href="custom/include/css/reporttpl.css">
	   <script type="text/javascript" src ="custom/modules/Cases/js/casesexport.js"></script>
	  <?php
	   if(!empty($_POST))
       {
         $smarty->assign('post_data',$_POST);
       }
	  
	   $smarty->display("custom/modules/Cases/tpl/servicevolumesupplier.tpl");  
    }
}
?>