<?php
ini_set("display_errors",0);
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/
require_once('include/MVC/View/views/view.detail.php');
require_once('custom/include/rolehack.php');
class CasesViewDetail extends ViewDetail{
    
     function _displaySubPanels(){
        require_once ('include/SubPanel/SubPanelTiles.php');
        $subpanel = new SubPanelTiles($this->bean, $this->module);
        global $current_user;
        if($subpanel->focus->status == 'Closed'){
            $subpanel->subpanel_definitions->layout_defs['subpanel_setup']['documents']['top_buttons']=array();
            $subpanel->subpanel_definitions->layout_defs['subpanel_setup']['cases_notes']['top_buttons']=array();
            $subpanel->subpanel_definitions->layout_defs['subpanel_setup']['cases_cases_1cases_ida']['top_buttons']=array();
            $th = new TemplateHandler();
            $th->clearCache($this->module);
            
        }else{
           
            $th = new TemplateHandler();
            $th->clearCache($this->module);
        }
       
        echo $subpanel->display();
        
    }
    public function display() {
        //start Roles and Permission Hacks by Akhilesh
        global $current_user; 
        $uid = $current_user->id; //Logged in User ID
        $category_module = "Cases"; //Module name
        $type = "module"; //Nochnage
        $rootAction = "case"; //Root or Parent Action name according to magento Root action name i.e. if rootAction is true then all subAction is true no need to check subAction is true or false. Nakumatt_CaseManagement::case, Nakumatt_Campaign::markiting_list, Nakumatt_Campaign::markiting_calendar, Nakumatt_Campaign::campaign_asset, Nakumatt_Campaign::campaign
	
        $subActionEscalate   = "escalate"; //Escalate ICON
        $escalateIcon = RoleHack::getCustomRole($uid, $category_module, $rootAction, $subActionEscalate, $type);
        
        $subActionDelete  = "delete"; //Delete ICON
        $deleteIcon = RoleHack::getCustomRole($uid, $category_module, $rootAction, $subActionDelete, $type);
        
        $subActionEdit  = "edit"; //Edit ICON
        $editIcon = RoleHack::getCustomRole($uid, $category_module, $rootAction, $subActionEdit, $type);
        
        $subActionRoot  = "case"; //Root action ICON
        $rootIcon = RoleHack::getCustomRole($uid, $category_module, $rootAction, $subActionRoot, $type);

        $adminRole = $current_user->isAdmin();
        //end Roles and Permission Hacks by Akhilesh
        
        global $app_list_strings;  
        $myUser = new User(); 
        
        echo '<link rel="stylesheet" href="custom/include/css/common.css" /><style type="text/css">#create_link,#create_image{display:none;}</style>';//to hide create link
		//@Ashok@Dated: 23-08-2017 Desc: On click of back button takes to myDashboard
		 echo '<script type="text/javascript" >
                $(document).ready(function(){
					$("#back_link").attr(\'href\',\'index.php?module=Cases&action=list_case_dashlet\');
                });
                </script>';
				
		// echo '<a id="back_link" href="index.php?module=Cases&amp;action=list_case_dashlet" class="utilsLink">Back</a>';
		
        //To display the action button in detail view and rest of the fields
        $recordid = isset($this->bean->id) ? $this->bean->id :'' ;
        
         echo '<script type="text/javascript" >
                $(document).ready(function(){
                $("#escalate_button").click(function() {
                  if (confirm("Are you sure you want to escalate the case?")) {
                      return escalate_check = document.location.href = \'index.php?module=cases&escalate=Escalate&action=DetailView&entryPoint=customEscalateEntryPoint&record='.$this->bean->id.'\';
                  }
                  });
                });
                </script>';
        //document.location.href = \'index.php?module=cases&escalate=Escalate&action=DetailView&entryPoint=customEscalateEntryPoint&record='.$this->bean->id.'\'
        if(($escalateIcon === true) || ($adminRole == 1)){ //Escalate Action
            $escbutton = '<input title="Escalate"  class="button" type="button" name="Escalate" id="escalate_button" value="Escalate" >';
            //Author: Ashok Dated: 20-04-2017 Desc: Change of the code for No escalation of resolved and closed case
            if($this->bean->status=='Resolved' || $this->bean->status=='Closed' ){
                $this->dv->ss->assign('ESCALATE', '');
                $th = new TemplateHandler();
                $th->clearCache($this->module);
            }else{
                $this->dv->ss->assign('ESCALATE', $escbutton);
                $th = new TemplateHandler();
                $th->clearCache($this->module);
            }
        }
        if((($editIcon === true) || ($adminRole == 1)) || ($current_user->id == $this->bean->assigned_user_id)){
            if($this->bean->status !='Closed' ){
                //if($current_user->id == $this->bean->assigned_user_id){
                    //Edit Action 
                    $custome_edit_action ='<input title="Edit" accesskey="" class="button primary" onclick="var _form = document.getElementById(\'formDetailView\'); _form.return_module.value=\'Cases\'; _form.return_action.value=\'DetailView\'; _form.return_id.value=\''.$recordid.'\'; _form.action.value=\'EditView\';SUGAR.ajaxUI.submitForm(_form);" type="button" name="Edit" id="edit_button_old" value="Edit" >';
                    $this->dv->ss->assign('EDIT', $custome_edit_action);
                //}
            }
        }
            $custome_clone_action ='<input title="Duplicate" accesskey="" class="button" onclick="var _form = document.getElementById(\'formDetailView\'); _form.return_module.value=\'Cases\'; _form.return_action.value=\'DetailView\'; _form.isDuplicate.value=true; _form.action.value=\'EditView\'; _form.return_id.value=\''.$recordid.'\';SUGAR.ajaxUI.submitForm(_form);" type="button" name="Duplicate" value="Clone" id="duplicate_button_old" >';
            $this->dv->ss->assign('CLONE', $custome_clone_action);
        if(($deleteIcon === true) || ($adminRole == 1)){ //Delete Action  
            $custome_delete_action ='<input title="Delete" accesskey="" class="button" onclick="var _form = document.getElementById(\'formDetailView\'); _form.return_module.value=\'Cases\'; _form.return_action.value=\'ListView\'; _form.action.value=\'Delete\'; if(confirm(\'Are you sure you want to delete this record?\')) SUGAR.ajaxUI.submitForm(_form);" type="submit" name="Delete" value="Delete" id="delete_button_old">';
            $this->dv->ss->assign('DELETE', $custome_delete_action);
        }    
        $caserelation = isset($this->bean->caserelation_c) ? $this->bean->caserelation_c :'' ;
        if($caserelation !='' && $caserelation=='Child'){
            $custome_find_dublicate_action ='';
        }else{
            $custome_find_dublicate_action ='<a id="merge_duplicate_button"></a><input title="Find Duplicates" class="button" onclick="var _form = document.getElementById(\'formDetailView\'); _form.return_module.value=\'Cases\'; _form.return_action.value=\'DetailView\'; _form.return_id.value=\''.$recordid.'\'; _form.action.value=\'Step1\'; _form.module.value=\'MergeRecords\';SUGAR.ajaxUI.submitForm(_form);" type="button" name="Merge" value="Find Duplicates" id="merge_duplicate_button_old">';
        }
        if(($rootIcon === true) || ($adminRole == 1)){//Root Action
            $this->dv->ss->assign('FIND_DUBLICATE', $custome_find_dublicate_action);
        }
        if (empty($this->bean->school_cheque_no)){ 
            $this->dv->ss->assign('CHEQUE', 'hide');
        }else{ 
            $this->dv->ss->assign('CHEQUE', 'show');
        }
		
		
		echo "<style type='text/css'>#case_comments,#description {   display: block;   word-break: break-all; }; </style>";
		
        //PDF button to be displayed to create and save
       // $custome_pdf_action ='<input title="PDF" accesskey="" class="button" onclick="generate_pdf();" type="button" name="PDF" value="PDF" id="pdf_button_old>';
        $custome_pdf_action = '<a href="?entryPoint=create_pdf&module=Cases&record='.$recordid.'" title="PDF [new window]" target="_blank">Print Payment Voucher</a>';
        $this->dv->ss->assign('CUSTOM_PDF', $custome_pdf_action);
        
        //on product repair display delivery note
        $delivery_note_pdf_action = '<a href="?entryPoint=delivery_note_pdf&module=Cases&record='.$recordid.'" title="PDF [new window]" target="_blank">Print Delivery Note</a>';
        $this->dv->ss->assign('REPAIR_DELIVER_NOTE_PDF', $delivery_note_pdf_action);
        
        
         //on product repair display delivery note
        $customer_ack_pdf_action = '<a href="?entryPoint=customer_ack_pdf&module=Cases&record='.$recordid.'" title="PDF [new window]" target="_blank">Print Customer Ack Form</a>';
        $this->dv->ss->assign('CUSTOMER_ACK_PDF', $customer_ack_pdf_action);
        
        
        $isEscalated = isset($_REQUEST['escalate']) ? $_REQUEST['escalate'] : '';
        if($isEscalated == 1 ){
            
           echo '<script type="text/javascript" >
                $(document).ready(function(){
                        var msg="<span class=message_case >The case has been escalated to : '.$this->bean->assigned_user_name.'</span>";			
                        $(".moduleTitle").append(msg);
                        $(".message_case").css("color","red");
                        $(".message_case").css("font-size","15px");
                        $(".message_case").css("font-weigh","bold");
                        $(".message_case").delay(7000).fadeOut();				 
                });
                </script>';
            
        }else if( $isEscalated == 2 ){
               echo '<script type="text/javascript" >
                    $(document).ready(function(){
                            var msg="<span class=message_case >You cannot escalate this case</span>";			
                            $(".moduleTitle").append(msg);
                            $(".message_case").css("color","green");
                            $(".message_case").css("font-size","15px");
                            $(".message_case").css("font-weigh","bold");
                            $(".message_case").delay(5000).fadeOut();				 
                    });
                    </script>';
            
        }else if( $isEscalated == 11 ){
              echo '<script type="text/javascript" >
                    $(document).ready(function(){
                            var msg="<span class=message_case >You cannot escalate this case due to inproper data, please contact Super Admin</span>";			
                            $(".moduleTitle").append(msg);
                            $(".message_case").css("color","red");
                            $(".message_case").css("font-size","15px");
                            $(".message_case").css("font-weigh","bold");
                            $(".message_case").delay(5000).fadeOut();				 
                    });
                    </script>';
            
        }
        //Display Validation on message as Case cannot be created for child case
        if(!empty($_REQUEST['message'])){
            if($_REQUEST['message']==1 && !empty($_REQUEST['record'])){
             echo '<script type="text/javascript" >
                    $(document).ready(function(){
                        alert("Case cannot be created for child case");			 
                    });
                    </script>';
            }
            if($_REQUEST['message']== 3){
                echo '<script type="text/javascript" >
                    $(document).ready(function(){
                       	 alert("Record deleted sucessfully");	 		 
                    });
                    </script>';
            }
            if($_REQUEST['message']== 4){
                 echo '<script type="text/javascript" >
                    $(document).ready(function(){
                       alert("Cannot delete a case having unresolved child case");		 
                    });
                    </script>';
            }            
        }   
       
        
        
        
        //Category
        $query_cat = "SELECT naku_casecategory.name from naku_casecategory join cases_cstm on naku_casecategory.id = cases_cstm.category_c "
                . " WHERE naku_casecategory.deleted =0 AND naku_casecategory.id ='".$this->bean->category_c."'";
        $result = $GLOBALS['db']->query($query_cat, false);
        $row = $GLOBALS['db']->fetchByAssoc($result);
        $category = $row['name'];
        $this->ss->assign('CATEGORY', $category);
        
        //Sub Category
        $query_subcat = "SELECT naku_casesubcategory.name from naku_casesubcategory join cases_cstm on naku_casesubcategory.id = cases_cstm.subcategory_c "
                . " WHERE naku_casesubcategory.deleted =0 AND naku_casesubcategory.id ='".$this->bean->subcategory_c."'";
        $result_sub = $GLOBALS['db']->query($query_subcat, false);
        $row_sub = $GLOBALS['db']->fetchByAssoc($result_sub);
        $subcategory = $row_sub['name'];
        $this->ss->assign('SUBCATEGORY', $subcategory);
        
        if($this->bean->id){
            $loyalty_id = $this->bean->loyalty_id_c;	
            $mobNum = $this->bean->mobile_number_c;
            if($loyalty_id != 'Guest'){
                $query_caseHist = "SELECT cases.case_number, cases_cstm.customer_name_c,cases.id,  cases_cstm.origin_c,"
                . " cases.priority, cases.status, cases.assigned_user_id, cases.date_entered, cases_cstm.member_tier_c  "
                . " FROM cases JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " WHERE cases.deleted =0 AND cases_cstm.loyalty_id_c = '".$loyalty_id."' AND cases.id != '".$this->bean->id."' limit 5 ";
                
            }else{
                 $query_caseHist = "SELECT cases.case_number, cases_cstm.customer_name_c,cases.id,  cases_cstm.origin_c,"
                . " cases.priority, cases.status, cases.assigned_user_id, cases.date_entered, cases_cstm.member_tier_c  "
                . " FROM cases JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " WHERE cases.deleted =0 AND cases_cstm.mobile_number_c = '".$mobNum."' AND cases.id != '".$this->bean->id."' AND  cases_cstm.loyalty_id_c = 'Guest'  limit 5 ";
            }
            $result = $GLOBALS['db']->query($query_caseHist);
            $count = $result->num_rows; 
            if($count > 0){
                $field_query_caseHist = '<style>.case-history-layout{width:100%;}#case_history{border-collapse:collapse;}#case_history,#case_history td, #case_history th{border: 1px solid black;}#case_history th{background-color:#FDE848;}</style><tr id="global_id"><td class="case-history-layout"><table width="100%" id="case_history" border="1">';
                $field_query_caseHist .= '<tr><th>Case ID</th><th>Customer Name</th><th>Origin</th><th>Priority</th><th>Status</th>';
                $field_query_caseHist .= '<th>Agent ID</th><th>Created On</th><th>Member Tier</th></tr>';
                while($row = $GLOBALS['db']->fetchByAssoc($result)){
                     $originname = $app_list_strings['origin_list'][$row['origin_c']];      
                     $priorityname = $app_list_strings['case_priority_dom'][$row['priority']];
                     $userid = $row['assigned_user_id'];
                     $myUser->retrieve($userid);
                     $assignedName = $myUser->full_name;
                     $caseID =$row['id'];
                     $caseNum =$row['case_number'];
                     $link ='<a href="index.php?module=Cases&return_module=Cases&action=DetailView&record='.$caseID.'">'.$caseNum.'</a>';

                    $field_query_caseHist .= '<tr>';

                     $field_query_caseHist .= '<td align="center"><div>'.$link.'</div></td>';
                     $field_query_caseHist .= '<td align="center"><div>'.$row['customer_name_c'].'</div></td>';
                     $field_query_caseHist .= '<td align="center"><div>'.$originname.'</div></td>';
                     $field_query_caseHist .= '<td align="center"><div>'.$priorityname.'</div></td>';
                     $field_query_caseHist .= '<td align="center"><div>'.$row['status'].'</div></td>';
                     $field_query_caseHist .= '<td align="center"><div>'.$assignedName.'</div></td>';
                     $field_query_caseHist .= '<td align="center"><div>'.$row['date_entered'].'</div></td>';
                     $field_query_caseHist .= '<td align="center"><div>'.$row['member_tier_c'].'</div></td>';
                    $field_query_caseHist .= '</tr>';
                }
                $field_query_caseHist .= '</td></table></tr><br />';
                $this->ss->assign('CASEHISTORY', $field_query_caseHist);
            }else {
                 $field_query_caseHist = '<style>.case-history-layout{width:100%;}#case_history{border-collapse:collapse;}#case_history,#case_history td, #case_history th{border: 1px solid black;}#case_history th{background-color:#FDE848;}</style><tr id="global_id"><td class="case-history-layout"><table width="100%" id="case_history" border="1">';
                 $field_query_caseHist .= '<tr><div>NO RECORD FOUND</div></tr>';
                 $field_query_caseHist .= '</td></table></tr><br />';
                $this->ss->assign('CASEHISTORY', $field_query_caseHist);
            }
           
           /*Similar Cases to display based on subcategory
            *Modieied By:Ashok 
            * Desc: added so that it do not displays its own data
            */
            //$myUser = new User();
            $myCategory = new naku_CaseCategory();
            $mySubCategory = new naku_CaseSubCategory();
            $simcat = $this->bean->subcategory_c;
            $query_Simcase = "SELECT cases.case_number, cases_cstm.customer_name_c, cases_cstm.category_c,cases_cstm.subcategory_c,cases.id, cases_cstm.origin_c,"
            . " cases.priority, cases.status, cases.assigned_user_id, cases.date_entered, cases_cstm.member_tier_c  "
            . " FROM cases JOIN cases_cstm ON cases.id = cases_cstm.id_c "
            . " WHERE cases.deleted =0 AND cases.status ='Resolved' AND cases_cstm.id_c != '".$this->bean->id."' AND cases_cstm.subcategory_c = '".$simcat."' limit 5 ";

            $resultSimcase = $GLOBALS['db']->query($query_Simcase);
            $count = $resultSimcase->num_rows;
            $field_query_simcaseHist ='';
            if($count > 0){ 
                $field_query_simcaseHist .= '<style>.case-history-layout{width:100%;}#case_history{border-collapse:collapse;}#case_history,#case_history td, #case_history th{border: 1px solid black;}#case_history th{background-color:#FDE848;}</style><tr id="global_id"><td class="case-history-layout"><table width="100%" id="case_history" border="1">';
                $field_query_simcaseHist .= '<tr><th>Case ID</th><th>Customer Name</th><th>Category</th><th>SubCategory</th><th>Origin</th><th>Priority</th><th>Status</th>';
                $field_query_simcaseHist .= '<th>Agent ID</th><th>Created On</th><th>Member Tier</th></tr>';
                while($rowsimcase = $GLOBALS['db']->fetchByAssoc($resultSimcase)){
                        $originname = $app_list_strings['origin_list'][$rowsimcase['origin_c']];
                        $priorityname = $app_list_strings['case_priority_dom'][$rowsimcase['priority']];
                        $userid = $rowsimcase['assigned_user_id'];
                        $myUser->retrieve($userid);
                        $assignedName = $myUser->full_name;
                        $caseID =$rowsimcase['id'];
                        $caseNum =$rowsimcase['case_number'];

                        $myCategory->retrieve($rowsimcase['category_c']);
                        $catName = $myCategory->name;

                        $mySubCategory->retrieve($rowsimcase['subcategory_c']);
                        $subCatName = $mySubCategory->name;
                        $link ='<a href="index.php?module=Cases&return_module=Cases&action=DetailView&record='.$caseID.'">'.$caseNum.'</a>';

                        $field_query_simcaseHist .= '<tr>';

                        $field_query_simcaseHist .= '<td align="center"><div>'.$link.'</div></td>';
                        $field_query_simcaseHist .= '<td align="center"><div>'.$rowsimcase['customer_name_c'].'</div></td>';
                        $field_query_simcaseHist .= '<td align="center"><div>'.$catName.'</div></td>';
                        $field_query_simcaseHist .= '<td align="center"><div>'.$subCatName.'</div></td>';
                        $field_query_simcaseHist .= '<td align="center"><div>'.$originname.'</div></td>';
                        $field_query_simcaseHist .= '<td align="center"><div>'.$priorityname.'</div></td>';
                        $field_query_simcaseHist .= '<td align="center"><div>'.$rowsimcase['status'].'</div></td>';
                        $field_query_simcaseHist .= '<td align="center"><div>'.$assignedName.'</div></td>';
                        $field_query_simcaseHist .= '<td align="center"><div>'.$rowsimcase['date_entered'].'</div></td>';
                        $field_query_simcaseHist .= '<td align="center"><div>'.$rowsimcase['member_tier_c'].'</div></td>';
                        $field_query_simcaseHist .= '</tr>';
                }
                $field_query_simcaseHist .= '</td></table></tr><br />';
                $this->ss->assign('SIMILARCASES', $field_query_simcaseHist);  
            }else{
                  $field_query_simcaseHist = '<tr id="global_id"><td class="case-history-layout"><table width="100%" >';
                  $field_query_simcaseHist .= 'NO SIMILAR CASES RESOLVED';
                  $field_query_simcaseHist .= '</table></tr><br />';
                $this->ss->assign('SIMILARCASES', $field_query_simcaseHist);
            }
            //Hide/Display resolution button based on condition and clear the cache
            if($this->bean->status == 'InProgress'){ 
                unset($this->dv->defs['panels']['lbl_case_information'][7]);
                unset($this->dv->defs['panels']['lbl_case_information'][9]);
                $th = new TemplateHandler();
                $th->clearCache($this->module);
            }else if($this->bean->status == 'Created'){ 
                unset($this->dv->defs['panels']['lbl_case_information'][7]);
                unset($this->dv->defs['panels']['lbl_case_information'][9]);
                $th = new TemplateHandler();
                $th->clearCache($this->module);
            }else if($this->bean->status == 'UnderResearch'){ 
                unset($this->dv->defs['panels']['lbl_case_information'][7]);
                unset($this->dv->defs['panels']['lbl_case_information'][9]);
                $th = new TemplateHandler();
                $th->clearCache($this->module);
            }else if($this->bean->status == 'Reopen'){ //new type of status has been introduce on 15-04-2017 Dated: 15-04-2017
                unset($this->dv->defs['panels']['lbl_case_information'][7]);
                unset($this->dv->defs['panels']['lbl_case_information'][9]);
                $th = new TemplateHandler();
                $th->clearCache($this->module);
            }else if($this->bean->status == ''){ 
                unset($this->dv->defs['panels']['lbl_case_information'][7]);
                unset($this->dv->defs['panels']['lbl_case_information'][9]);
                $th = new TemplateHandler();
                $th->clearCache($this->module);
            }else{ 
                $th = new TemplateHandler();
                $th->clearCache($this->module);
            }
            //Display or hide parent fields and layout 
            $parent_cases = isset($this->bean->cases_cases_1_name) ? $this->bean->cases_cases_1_name:'';
       
            if($parent_cases =='' || $parent_cases ==NULL && $this->bean->id == $this->bean->cases_cases_1cases_ida){
            
                unset($this->dv->defs['panels']['lbl_editview_panel_parent']);
                
                $th = new TemplateHandler();
                $th->clearCache($this->module);
                
            }else{ 
                $th = new TemplateHandler();
                $th->clearCache($this->module);
            }
           //School fees redemption dated 24-11-2016 by ashok desc: to hide the panel based on subcategory
            $mySubCategory->retrieve($this->bean->subcategory_c);
			$subCatName = $mySubCategory->name;
			$subcat_service = strtoupper('School fee redemption');
			//Author: Ashok DAted: 28-04-2017 desc : check condition for category and subcateogry 
			$myCategory->retrieve($this->bean->category_c);
			$catName = $myCategory->name;
			$category_product = strtoupper('Product');
			$cat_service = strtoupper('Service');
			
            if(strtoupper($catName) == $cat_service && strtoupper($subCatName) == $subcat_service){
                unset($this->dv->defs['panels']['lbl_editview_product_supplier']);
                unset($this->dv->defs['panels']['lbl_editview_product_branch']);
                unset($this->dv->defs['panels']['lbl_editview_panel_product_quality_complaint']);
                    
                unset($this->dv->defs['panels']['lbl_editview_panel_product_repair']);
				unset($this->dv->defs['panels']['lbl_editview_panel_supplier_info']);//new section @ASHOK Dated:21-04-2017
                unset($this->dv->defs['panels']['lbl_editview_panel_product_received']);
                
                unset($this->dv->defs['panels']['lbl_editview_panel_product_actions']);
                unset($this->dv->defs['panels']['lbl_editview_panel_delivery_note']);
                 $th = new TemplateHandler();
                 $th->clearCache($this->module);
            }elseif(strtoupper($catName) == $category_product && $mySubCategory->name != ''){
                  unset($this->dv->defs['panels']['lbl_editview_panel_school']);
                  unset($this->dv->defs['panels']['lbl_editview_panel_cheque']);
                  
                  if($this->bean->product_replaced == 'Yes' ){ 
                    unset($this->dv->defs['panels']['lbl_editview_panel_product_repair']);
                    unset($this->dv->defs['panels']['lbl_editview_panel_product_received']);
                    
                   // unset($this->dv->defs['panels']['lbl_editview_panel_product_actions']);
                    unset($this->dv->defs['panels']['lbl_editview_panel_delivery_note']);
                    
                    unset($this->dv->defs['panels']['lbl_editview_panel_product_actions'][1][1]);
                    unset($this->dv->defs['panels']['lbl_editview_panel_product_actions'][1][0]);
                    
                    $th = new TemplateHandler();
                    $th->clearCache($this->module);
                }else if($this->bean->product_replaced == 'No'  && $this->bean->credit_repair =='credit' ){ 
                    unset($this->dv->defs['panels']['lbl_editview_panel_product_repair']);
                    unset($this->dv->defs['panels']['lbl_editview_panel_product_received']);
                    unset($this->dv->defs['panels']['lbl_editview_panel_supplier_info']);//new section @ASHOK Dated:21-04-2017
                    unset($this->dv->defs['panels']['lbl_editview_panel_delivery_note']);
                    unset($this->dv->defs['panels']['lbl_editview_panel_product_actions'][1][0]);
                    
                    $th = new TemplateHandler();
                    $th->clearCache($this->module);
                }else if($this->bean->product_replaced == 'No'  && $this->bean->credit_repair =='repair' ){ 
                     unset($this->dv->defs['panels']['lbl_editview_panel_product_actions'][1][1]);
                    
                    $th = new TemplateHandler();
                    $th->clearCache($this->module);
                }else{ 
                    
                     unset($this->dv->defs['panels']['lbl_editview_panel_product_actions'][1][0]);
                     unset($this->dv->defs['panels']['lbl_editview_panel_product_repair']);
                     unset($this->dv->defs['panels']['lbl_editview_panel_product_received']);
                     unset($this->dv->defs['panels']['lbl_editview_panel_delivery_note']);
                     unset($this->dv->defs['panels']['lbl_editview_panel_product_actions'][1][1]);
                }
                $th = new TemplateHandler();
                $th->clearCache($this->module);
             
            }else{
                 unset($this->dv->defs['panels']['lbl_editview_panel_school']);
                 unset($this->dv->defs['panels']['lbl_editview_panel_cheque']);
                 
                 unset($this->dv->defs['panels']['lbl_editview_product_supplier']);
                 unset($this->dv->defs['panels']['lbl_editview_product_branch']);
                 unset($this->dv->defs['panels']['lbl_editview_panel_product_quality_complaint']);
                    
                 unset($this->dv->defs['panels']['lbl_editview_panel_product_repair']);
				 unset($this->dv->defs['panels']['lbl_editview_panel_supplier_info']);//new section @ASHOK Dated:21-04-2017
                 unset($this->dv->defs['panels']['lbl_editview_panel_product_received']);
                 
                unset($this->dv->defs['panels']['lbl_editview_panel_product_actions']);
                unset($this->dv->defs['panels']['lbl_editview_panel_delivery_note']);
                
                $th = new TemplateHandler();
                $th->clearCache($this->module);
            }
          
            if($this->bean->prod_repair_status == 'InProgress'){
                unset($this->dv->defs['panels']['lbl_editview_panel_delivery_note']);
                $th = new TemplateHandler();
                $th->clearCache($this->module);
            }
			if($this->bean->prod_repair_status == 'Recieved'){
               unset($this->dv->defs['panels']['lbl_editview_panel_delivery_note']);
                $th = new TemplateHandler();
                $th->clearCache($this->module);
            }
            //eoc 
            $parentId =  isset($this->bean->cases_cases_1cases_ida) ? $this->bean->cases_cases_1cases_ida:''; 
         
            global $sugar_config;
            $bean_parent_cases = BeanFactory::getBean('Cases',$parentId);
            $caseno = isset($bean_parent_cases->case_number)? $bean_parent_cases->case_number :'';
            $this->ss->assign('PCASENUM', $caseno);
     
            $parentlink = "<a href={$sugar_config['site_url']}/index.php?module=Cases&action=DetailView&record={$bean_parent_cases->id}>{$bean_parent_cases->name}</a>";
            $this->ss->assign('MYPARENT', $parentlink);
            if($this->bean->school_cheque_status == 'Delivered'){
                $th = new TemplateHandler();
                $th->clearCache($this->module);
            }
            if($this->bean->school_cheque_status == 'Dispatched'){
                 
                 $th = new TemplateHandler();
                 $th->clearCache($this->module);
            }
            if($this->bean->school_cheque_status == 'Inprogress'){
                 unset($this->dv->defs['panels']['lbl_editview_panel_cheque'][0][1]);
                 unset($this->dv->defs['panels']['lbl_editview_panel_cheque'][1]);
                 unset($this->dv->defs['panels']['lbl_editview_panel_cheque'][2]);

                 $th = new TemplateHandler();
                 $th->clearCache($this->module);
            }
             if($this->bean->school_cheque_status == 'Ready'){
                 unset($this->dv->defs['panels']['lbl_editview_panel_cheque'][2][0]);
                 $th = new TemplateHandler();
                 $th->clearCache($this->module);
            }
            if($this->bean->school_cheque_status == null){
                unset($this->dv->defs['panels']['lbl_editview_panel_cheque']);
                $th = new TemplateHandler();
                $th->clearCache($this->module);
            }
		
         $this->ss->assign('DISPDFCOND',$mySubCategory->name);
         $this->ss->assign('REPAIR',$this->bean->credit_repair);
         
          $this->ss->assign('COLLECTION_DATE',$this->bean->date_of_collection_repair);
         //School fees scenarion and cheque
        if($mySubCategory->name == $subcat_service){ //change for dynamic
            $js =<<<EOF
                <script>
                   
                  var cheque = $('#school_cheque_status').val();
                    if(cheque == 'Inprogress'){
                        $("#school_particulars_label").hide();
                        $("#school_particulars").hide();  
                      
                        $("#school_voucher_No_label").hide();
                        $("#school_voucher_No").hide();  
                       

                        $("#school_cheque_dispatch_label").hide();
                        $("#school_cheque_dispatch").hide(); 
                        

                        $("#school_cheque_issuedate_label").hide();
                        $("#school_cheque_issuedate").hide();  

                        $("#school_cheque_no_label").hide();
                        $("#school_cheque_no").hide(); 
                    }
                if(cheque == 'Ready'){
                        $("#school_particulars_label").show();
                        $("#school_particulars").show();  

                        $("#school_voucher_No_label").show();
                        $("#school_voucher_No").show();  

                        $("#school_cheque_issuedate_label").show();
                        $("#school_cheque_issuedate").show();  

                        $("#school_cheque_no_label").show();
                        $("#school_cheque_no").show();  

                        $("#school_cheque_dispatch_label").hide();
                        $("#school_cheque_dispatch").hide(); 
                           
                    }
                 if(cheque == 'Dispatched'){
                        $("#school_particulars_label").show();
                        $("#school_particulars").show();  
                      
                        $("#school_voucher_No_label").show();
                        $("#school_voucher_No").show();  
                       

                        $("#school_cheque_dispatch_label").show();
                        $("#school_cheque_dispatch").show(); 
                
                        $("#school_cheque_issuedate_label").show();
                        $("#school_cheque_issuedate").show();  


                        $("#school_cheque_no_label").show();
                        $("#school_cheque_no").show(); 
                
                        $("#school_cheque_dispatch_label").show();
                        $("#school_cheque_dispatch").show();  
                 }
                 if(cheque == 'Delivered'){
                        $("#school_particulars_label").show();
                        $("#school_particulars").show();  
                      
                        $("#school_voucher_No_label").show();
                        $("#school_voucher_No").show();  
                       

                        $("#school_cheque_dispatch_label").show();
                        $("#school_cheque_dispatch").show(); 
                
                        $("#school_cheque_issuedate_label").show();
                        $("#school_cheque_issuedate").show();  


                        $("#school_cheque_no_label").show();
                        $("#school_cheque_no").show(); 
                
                        $("#school_cheque_dispatch_label").show();
                        $("#school_cheque_dispatch").show();  

                 }
                </script>
                
EOF;
        }else{
            $js ='';
        }
        //Branch Name validations   value is 2 now earlier it was 1
        if($this->bean->origin_c != '2'){
            unset($this->dv->defs['panels']['lbl_case_information'][3][1]);
            $th = new TemplateHandler();
            $th->clearCache($this->module);
        }else{
             $th = new TemplateHandler();
            $th->clearCache($this->module);
        }
        if($this->bean->bill_amount == ''){
            unset($this->dv->defs['panels']['lbl_editview_panel_supplier_info']);            
            $th = new TemplateHandler();
            $th->clearCache($this->module);
        } else{
             $th = new TemplateHandler();
             $th->clearCache($this->module);
        }    
   }      
         $this->dv->defs['templateMeta']['form']['hideAudit']=false;//changed the code to hide the view change log
         
         
         //File upload functionality
        
         $link = '<a href="'.$sugar_config['site_url'].'/upload/cases_files/'.$this->bean->filename.'">'.$this->bean->filename.'</a>';
         $this->dv->ss->assign('IMGPPP', $link);	
         
         //Author: Ashok DAted: 14/04/2017 Desc: Calculate the field based on closed BRD point no 20

        if($this->bean->status != 'Closed'){ 
            unset($this->dv->defs['panels']['lbl_case_information'][8][1]);
            $th = new TemplateHandler();
            $th->clearCache($this->module);
        }else{
            $this->bean->calculate_case = $this->view_object_map['calculate_days'];
            $th = new TemplateHandler();
            $th->clearCache($this->module);
        }
        
        parent::display();  
        echo $js;
    }	
}
?>