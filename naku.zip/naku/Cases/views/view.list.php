<?php

/* * *******************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 * ****************************************************************************** */
/**
 * Cases SugarCRM ViewList
 * @api
 */
class CasesViewList extends SugarView {
    public function display() {
        global $mod_strings;
				 
        $smarty = new Sugar_Smarty();
		$smarty->assign('loggedin_user',$this->view_object_map['loggedin_user']);
		//Ashok define all users
		$smarty->assign('allusers', $this->view_object_map['allUsers']);
		
        //Define languange variables
        $smarty->assign('LBL_SEARCH_CASES', $mod_strings['LBL_SEARCH_CASES']);
        $smarty->assign('list_case', $this->view_object_map['list_case']);
       
        $smarty->assign('search_first_name', $this->view_object_map['search_first_name']);
        $smarty->assign('search_value', $this->view_object_map['search_value']);
        $smarty->assign('search_lookup_type', $this->view_object_map['search_lookup_type']);
        $smarty->assign('search_lookup_date', $this->view_object_map['search_lookup_date']);
        
        //Start Roles and Permission Hacks by Akhilesh
        $smarty->assign('editIcon', $this->view_object_map['editIcon']);
        $smarty->assign('createIcon', $this->view_object_map['createIcon']);
        $smarty->assign('createCategoryIcon', $this->view_object_map['createCategoryIcon']);
        $smarty->assign('viewIcon', $this->view_object_map['viewIcon']);
        $smarty->assign('searchIcon', $this->view_object_map['searchIcon']);
        $smarty->assign('assignIcon', $this->view_object_map['assignIcon']);
        $smarty->assign('adminRole', $this->view_object_map['adminRole']);
        $smarty->assign('exportIcon', $this->view_object_map['exportIcon']);
        //End Roles and Permission Hacks by Akhilesh
        $smarty->display("custom/modules/Cases/tpl/listview.tpl");
        // echo '<pre>'; print_r($this->view_object_map['list_case']);
    }
}                       
?>