<?php

/* * *******************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 * ****************************************************************************** */
/**
 * Cases SugarCRM controller
 * @api
 */
require_once('include/MVC/Controller/SugarController.php');
require_once('custom/include/rolehack.php');

class CasesController extends SugarController {

    public $module = 'Cases';

    /**
     * This method is Get All users name, id from table 'users'
     *
     */
    public function getAllUsers() {
        $bean = BeanFactory::getBean('Users');
        $usersFullList = $bean->get_full_list('', 'users.deleted =0 AND users.status="Active"');
        $getAllUsers = array();
        if (count($usersFullList) > 0) {
            foreach ($usersFullList as $usersValue) {
                $data['first_name'] = $usersValue->first_name . " " . $usersValue->last_name . "(" . $usersValue->user_name . ")";
                $data['id'] = $usersValue->id;
                $data['name'] = $usersValue->first_name . " " . $usersValue->last_name;
                $getAllUsers[] = $data;
            }
            return $getAllUsers;
        }
    }

    /**
     * This method is Display to list of all Cases
     *
     */
    public function action_listView() {
        global $db, $app_list_strings, $sugar_config;

        $this->view = 'list';
        $bean = BeanFactory::getBean($this->module);
        $case_full_list = $bean->get_full_list();
        $list_case = array();
        $condition = '';

        if (isset($_REQUEST['query']) == 'true') {
            if ((!empty($_REQUEST['lookup_value']) || !empty($_REQUEST['lookup_date']))) {//!empty($_REQUEST['lookup_first_name']) && 
                $customer_name_c = $_REQUEST['lookup_first_name'] . "%";
                $condition .= " cases_cstm.customer_name_c like '" . $customer_name_c . "' AND ";
                if ($_REQUEST['lookup_type'] == 'loyalty_id') {
                    $condition .= " cases_cstm.loyalty_id_c = '" . $_REQUEST['lookup_value'] . "' ";
                }if ($_REQUEST['lookup_type'] == 'mobile_number') {
                    $condition .= " cases_cstm.mobile_number_c = '" . $_REQUEST['lookup_value'] . "' ";
                }
                if ($_REQUEST['lookup_type'] == 'case_id') {
                    $condition .= " cases.case_number = '" . $_REQUEST['lookup_value'] . "' ";
                }
                if ($_REQUEST['lookup_type'] == 'email_id') {
                    $condition .= " cases_cstm.email_c = '" . $_REQUEST['lookup_value'] . "' ";
                }
                if ($_REQUEST['lookup_type'] == 'dob') {
                    $condition .= " cases_cstm.dob_c = '" . $_REQUEST['lookup_date'] . "' ";
                }
                $condition .=" AND ";
                $default_query_case = "SELECT cases.branch_store_name,cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_input,naku_casesubcategory.estimate_resolution_date, LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , cases.date_entered , cases.assigned_user_id FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0"
                        . " where " . $condition . " cases.deleted=0 ORDER BY cases.date_entered DESC";
//naku_casesubcategory.estimate_resolution_input  naku_casesubcategory.estimate_resolution_date 
                $result = $db->query($default_query_case);
                while ($row = $db->fetchByAssoc($result)) {

                    // start sla checking
                    $current_time = $sugar_config['current_sla_time']; // date('Y-m-d H:i:s',strtotime('-3 hours'));
                    if (!empty($row['estimate_resolution_input']) && !empty($row['date_entered'])) {
                        if ($row['estimate_resolution_date'] == 'min') {

                            $estimate_date = date('Y-m-d H:i:s', strtotime('+' . $row['estimate_resolution_input'] . ' minute', strtotime($row['date_entered'])));
                        } else if ($row['estimate_resolution_date'] == 'hrs') {
                            $estimate_date = date('Y-m-d H:i:s', strtotime('+' . $row['estimate_resolution_input'] . ' hour', strtotime($row['date_entered'])));
                        } else if ($row['estimate_resolution_date'] == 'days') {
                            $estimate_date = date('Y-m-d H:i:s', strtotime('+' . $row['estimate_resolution_input'] . ' day', strtotime($row['date_entered'])));
                        }
                    }

                    if ($estimate_date < $current_time && $row['status'] != 'Resolved')
                        $row['sla_status'] = "No";
                    else
                        $row['sla_status'] = "";
                    // end sla checking

                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['subcategory_c'] = $this->getCaseSubCategoryName($row['subcategory_c']);
                    if (count($row['origin_c']) > 0) {
                        //$row['origin_c'] = translate('origin_list', '', $row['origin_c']);
                        $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    }
                    $row['priority'] = translate('case_priority_dom', '', $row['priority']);

                    $date = date('Y-m-d', strtotime('+ 0 days', strtotime($row['date_entered'])));
                    $row['date_entered'] = $date;

                    $list_case[] = $row;
                }
                //Author: Akhilesh Dated: 12-04-2017 Desc: Case list filter
                $this->view_object_map['search_first_name'] = $_REQUEST['lookup_first_name'];
                $this->view_object_map['search_value'] = $_REQUEST['lookup_value'];
                $this->view_object_map['search_lookup_type'] = $_REQUEST['lookup_type'];
                $this->view_object_map['search_lookup_date'] = $_REQUEST['lookup_date'];
            }
        } else {
            $default_query_case = "SELECT cases.branch_store_name,cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , naku_casesubcategory.sla ,naku_casesubcategory.estimate_resolution_input,naku_casesubcategory.estimate_resolution_date, LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , cases.date_entered , cases.assigned_user_id FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0"
                    . " where " . $condition . " cases.deleted=0 ORDER BY cases.date_entered DESC";
            $result = $db->query($default_query_case);
            $estimate_date = '';

            $current_time = $sugar_config['current_sla_time']; // date('Y-m-d H:i:s',strtotime('-3 hours'));
            while ($row = $db->fetchByAssoc($result)) {
                if (!empty($row['estimate_resolution_input']) && !empty($row['date_entered'])) {
                    if ($row['estimate_resolution_date'] == 'min') {

                        $estimate_date = date('Y-m-d H:i:s', strtotime('+' . $row['estimate_resolution_input'] . ' minute', strtotime($row['date_entered'])));
                    } else if ($row['estimate_resolution_date'] == 'hrs') {
                        $estimate_date = date('Y-m-d H:i:s', strtotime('+' . $row['estimate_resolution_input'] . ' hour', strtotime($row['date_entered'])));
                    } else if ($row['estimate_resolution_date'] == 'days') {
                        $estimate_date = date('Y-m-d H:i:s', strtotime('+' . $row['estimate_resolution_input'] . ' day', strtotime($row['date_entered'])));
                    }
                }

                if ($estimate_date < $current_time && $row['status'] != 'Resolved')
                    $row['sla_status'] = "No";
                else
                    $row['sla_status'] = "";


                // end sla checking
                $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                $row['subcategory_c'] = $this->getCaseSubCategoryName($row['subcategory_c']);
                if (count($row['origin_c']) > 0) {
                    //$row['origin_c'] = translate('origin_list', '', $row['origin_c']);
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                }
				
				$aa = $row['priority_id']= $row['priority'];
                $row['priority'] = translate('case_priority_dom', '', $row['priority']);
				$row['priority'] = "". $aa." - ".$row['priority'];
				
                $date = date('Y-m-d', strtotime('+ 0 days', strtotime($row['date_entered'])));
                $row['date_entered'] = $date;

                $list_case[] = $row;
            }
        }
        //echo'<pre>';  print_r($list_case); //This is for DEBUG Code
        $this->view_object_map['list_case'] = $list_case;
        //start Roles and Permission Hacks by Akhilesh
        global $current_user;
        $uid = $current_user->id; //Logged in User ID
        $category = "Cases"; //Module name
        $type = "module"; //Nochnage
        $rootAction = "case"; //Root or Parent Action name according to magento Root action name i.e. if rootAction is true then all subAction is true no need to check subAction is true or false. Nakumatt_CaseManagement::case, Nakumatt_Campaign::markiting_list, Nakumatt_Campaign::markiting_calendar, Nakumatt_Campaign::campaign_asset, Nakumatt_Campaign::campaign

        $subActionEdit = "edit"; //Edit ICON
        $editIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionEdit, $type);
        $this->view_object_map['editIcon'] = $editIcon;

        $subActionCreate = "create"; //Create ICON
        $createIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionCreate, $type);
        $this->view_object_map['createIcon'] = $createIcon;

        $subActionCreateCategory = "case"; //All Acttion Rights
        $createCategoryIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionCreateCategory, $type);
        $this->view_object_map['createCategoryIcon'] = $createCategoryIcon;

        $subActionView = "view"; //View ICON
        $viewIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionView, $type);
        $this->view_object_map['viewIcon'] = $viewIcon;

        $subActionSearch = "search"; //Search ICON
        $searchIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionSearch, $type);
        $this->view_object_map['searchIcon'] = $searchIcon;

        $subActionAssign = "assign"; //assign ICON
        $assignIcon = RoleHack::getCustomRole($uid, $category_module, $rootAction, $subActionAssign, $type);
        $this->view_object_map['assignIcon'] = $assignIcon;

        $subActionExport = "export"; //Export ICON
        $exportIcon = RoleHack::getCustomRole($uid, $category_module, $rootAction, $subActionExport, $type);
        $this->view_object_map['exportIcon'] = $exportIcon;

        $this->view_object_map['adminRole'] = $current_user->isAdmin(); //$GLOBALS['current_user']
        //end Roles and Permission Hacks by Akhilesh

        $this->view_object_map['allUsers'] = $this->getAllUsers();
        $this->view_object_map['loggedin_user'] = $uid;
    }

    /**
     * This method is Get Category name through ID from table 'nakum_casecategory'
     *
     */
    public function getCaseCategoryName($categoryID) {
        $bean = BeanFactory::getBean('naku_CaseCategory');
        $categoryName = $bean->get_full_list('', 'naku_casecategory.id ="' . $categoryID . '"');
        if (count($categoryName) > 0) {
            foreach ($categoryName as $catValue) {
                $data = $catValue->name;
            }
            return $data;
        }
    }

    /**
     * This method is Get Sub Category name through ID from table 'nakum_casesubcategory'
     *
     */
    public function getCaseSubCategoryName($subCategoryID) {
        $bean = BeanFactory::getBean('naku_CaseSubCategory');
        $subcategoryName = $bean->get_full_list('', 'naku_casesubcategory.id ="' . $subCategoryID . '"');
        if (count($subcategoryName) > 0) {
            foreach ($subcategoryName as $subcatValue) {
                $data = $subcatValue->name;
            }
            return $data;
        }
    }

    /**
     * This method is Get Origin name through ID from table 'nakum_cstm
     *
     */
    public function getCaseOriginName($categoryID) {
        global $app_list_strings;
        return $app_list_strings['origin_list_report'][$categoryID];
    }

    /**
     * This method is display list of case export
     *
     */
    public function action_export() {
        global $db, $app_list_strings, $current_user;
        //start Roles and Permission Hacks by Akhilesh
        $uid = $current_user->id; //Logged in User ID
        $category = "Cases"; //Module name
        $type = "module"; //Nochnage
        $rootAction = "case"; //Root or Parent Action name according to magento Root action name i.e. if rootAction is true then all subAction is true no need to check subAction is true or false. Nakumatt_CaseManagement::case, Nakumatt_Campaign::markiting_list, Nakumatt_Campaign::markiting_calendar, Nakumatt_Campaign::campaign_asset, Nakumatt_Campaign::campaign
        $subActionExport = "export"; //Edit ICON
        $exportIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionExport, $type);
        $this->view_object_map['exportIcon'] = $exportIcon;
        $this->view_object_map['adminRole'] = $current_user->isAdmin();
        //end Roles and Permission Hacks by Akhilesh
        $this->view = 'export';
        $this->view_object_map['getAllCaseCategory'] = $this->getAllCaseCategory();
        $list_case = array();
        $condition = '';

        if (isset($_REQUEST['query']) == 'true') {
            //if( (!empty($_REQUEST['priority']) && !empty($_REQUEST['category_id']) 
            //&& !empty($_REQUEST['origin']) && !empty($_REQUEST['status'])) ) {
            if ($_REQUEST['priority'] || $_REQUEST['category_id'] || $_REQUEST['origin'] || $_REQUEST['status'] ||
                    $_REQUEST['created_on'] || $_REQUEST['get_agent_id'] || $_REQUEST['from_date'] || $_REQUEST['to_date'] ||
                    $_REQUEST['mobile_number']) {
                if ($_REQUEST['priority']) {
                    $condition .= " cases.priority = '" . $_REQUEST['priority'] . "' AND ";
                }
                if ($_REQUEST['category_id']) {
                    $condition .= "  cases_cstm.category_c = '" . $_REQUEST['category_id'] . "' AND ";
                }
                if ($_REQUEST['origin']) {
                    $condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
                }
                if ($_REQUEST['status']) {
                    $condition .= "  cases.status = '" . $_REQUEST['status'] . "' AND ";
                }
                if ($_REQUEST['created_on']) {
                    $condition .= "  DATE(cases.date_entered) = '" . date("Y-m-d", strtotime($_REQUEST['created_on'])) . "' AND ";
                }
                if ($_REQUEST['get_agent_id']) {
                    $condition .= "  cases.created_by = '" . $_REQUEST['get_agent_id'] . "' AND ";
                }
                if ($_REQUEST['from_date'] && $_REQUEST['to_date']) {
                    $condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($_REQUEST['from_date'])) . "' AND '" . date("Y-m-d", strtotime($_REQUEST['to_date'])) . "' AND ";
                }
                if ($_REQUEST['mobile_number']) {
                    $condition .= "  cases_cstm.mobile_number_c = '" . $_REQUEST['mobile_number'] . "' AND ";
                }
                //$condition .=" AND ";
                $default_query_case = "SELECT cases.id, cases.name, cases_cstm.category_c, cases_cstm.origin_c, cases.case_number, cases.priority, cases.status, LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, cases.date_entered, cases.assigned_user_id, cases_cstm.loyalty_id_c, cases_cstm.mobile_number_c FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0"
                        . " where " . $condition . " cases.deleted=0 ORDER BY cases.date_entered DESC";
                $result = $db->query($default_query_case);
                while ($row = $db->fetchByAssoc($result)) {
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                    $list_case[] = $row;
                }
            }
        }
        // echo'<pre>';  print_r($list_case); //This is for DEBUG Code
        $this->view_object_map['list_case'] = $list_case;
    }

    /**
     * This method is Get All Case Category name, id from table 'nakum_casecategory'
     *
     */
    public function getAllCaseCategory() {
        $bean = BeanFactory::getBean('naku_CaseCategory');
        $categoryFullList = $bean->get_full_list('', 'naku_casecategory.deleted =0');
        $getAllCategory = array();
        if (count($categoryFullList) > 0) {
            foreach ($categoryFullList as $catValue) {
                $data['id'] = $catValue->id;
                $data['name'] = $catValue->name;
                $getAllCategory[] = $data;
            }
            return $getAllCategory;
        }
    }

    /**
     * This method is genrate CSV/XLS/PDF file and download
     *
     */
    public function action_exportData() {
        global $db, $app_list_strings;
        if (!isset($_POST['chk']) OR ! is_array($_POST['chk'])) {
            //echo 'No rows selected for export';
            SugarApplication::appendErrorMessage('<span class="msg-error">No rows selected for export.</span>');
            $queryParams = array(
                'module' => 'Cases',
                'action' => 'export'
            );
            SugarApplication::redirect('index.php?' . http_build_query($queryParams));
        } else {
            if ($_POST['file_type'] == 'csv') { //Export CSV
                //CSV File name and Header
                $filename = "CS" . date('Y-m-d:H:i:s') . ".csv";
                $fp = fopen('php://output', 'w');
                $header = array('Loyalty ID', 'Mobile', 'Case ID', 'Case Title', 'Category', 'Origin', 'Priority', 'Status', 'Assigned To', 'Created On');
                header('Content-type: application/csv');
                header('Content-Disposition: attachment; filename=' . $filename);
                fputcsv($fp, $header);

                //Fetch data
                $caseIDs = implode("','", $_POST['chk']);
                $condition = " cases.id IN ('" . $caseIDs . "')";
                $export_list_case = array();
                $default_query_case = "SELECT cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c,cases.case_number,cases.name,cases_cstm.category_c,cases_cstm.origin_c,cases.priority,cases.status, LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, cases.date_entered FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 "
                        . " where " . $condition . " AND cases.deleted=0 ORDER BY cases.date_entered DESC";
                $result = $db->query($default_query_case);
                while ($row = $db->fetchByAssoc($result)) {
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                    $export_list_case[] = $row;
                    fputcsv($fp, $row); //Genrate CSV
                }
                fclose($fp);
                exit;
            } elseif ($_POST['file_type'] == 'xls') { //Export XLS
                $list = array();
                $list['tableheading'] = array('Loyalty ID', 'Mobile', 'Case ID', 'Case Title', 'Category', 'Origin', 'Priority', 'Status', 'Assigned To', 'Created On');
                $fichier = "CS" . date('Y-m-d:H:i:s') . ".xls";
                header("Content-Type: text/csv;charset=utf-8");
                header("Content-Disposition: attachment;filename=\"$fichier\"");
                header("Pragma: no-cache");
                header("Expires: 0");
                $fp = fopen('php://output', 'w');
                fputcsv($fp, $list['tableheading']);
                //Fetch data
                $caseIDs = implode("','", $_POST['chk']);
                $condition = " cases.id IN ('" . $caseIDs . "')";
                $default_query_case = "SELECT cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c,cases.case_number,cases.name,cases_cstm.category_c,cases_cstm.origin_c,cases.priority,cases.status, LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, cases.date_entered FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 "
                        . " where " . $condition . " AND cases.deleted=0 ORDER BY cases.date_entered DESC";
                $result = $db->query($default_query_case);
                while ($row = $db->fetchByAssoc($result)) {
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                    $data['list'] = array($row['loyalty_id_c'], $row['mobile_number_c'], $row['case_number'], $row['name'], $row['category_c'], $row['origin_c'], $row['priority'], $row['status'], $row['created_by_name'], $row['date_entered']);
                    fputcsv($fp, $data['list']); //Genrate XLS
                }
                fclose($fp);
                exit();
            } else { //Export PDF
                // instantiate and use the dompdf class
                include 'create_pdf/caseexport.php';
            }
        }
    }

    /**
     * This method is set Priority based on Subcategory nature
     *
     */
    public function action_getPriority() {
        if (!empty($_POST['subcatid'])) {
            $subcatid = $_POST['subcatid'];
            $sql = "SELECT priority FROM `naku_casesubcategory` WHERE deleted=0 AND id = '$subcatid'";
            $priority = $GLOBALS['db']->getOne($sql);
            echo $priority;
            exit();
        }
    }

    /**
     * This method gives Case Priority
     */
    public function getCasepriority() {
        return [
            "" => "Select",
            "daily" => "High",
            "weekly" => "Medium",
            "monthly" => "Low",
        ];
    }

    /**
     * This method is get Customer Information when click to LookUP
     *
     */
    public function action_getCustomerInfo() {
        global $db;
        if (!empty($_POST['loyalty_id']) || !empty($_POST['mobile_number']) || !empty($_POST['email'])) {
            $loyalty_id = $_POST['loyalty_id'];
            $mobile_number = $_POST['mobile_number'];
            $email = $_POST['email'];
            $data = array();
            $sql = "SELECT first_name,last_name,phone_mobile,email,loyalty_id,member_tier,birthdate,member_type,title,customer_id FROM `contacts` WHERE deleted=0 AND loyalty_id = '$loyalty_id' OR phone_mobile='$mobile_number' OR email='$email'";
            $result = $db->query($sql);
            while ($row = $db->fetchByAssoc($result)) {
                $row['birthdate'] = date('m/d/Y', strtotime($row['birthdate']));
                $data[] = $row;
            }
            if (count($data) > 0) {
                //print_r($data[0]);
                //$_SESSION['lookup_customer_id'] = $data[0]['customer_id']; comment by akhilesh 29-08-2017
                echo json_encode($data[0]);
            } else {
                echo json_encode(array('flag' => '0'));
            }
            exit();
        }
    }
    
    /**
     * This method is get Inactive Customer Information when click to Lookup
     *
    */
    public function action_getInactiveCustomerInfo() {
        global $db;
        if (!empty($_POST['loyalty_id']) || !empty($_POST['mobile_number']) || !empty($_POST['email'])) {
            $loyalty_id = $_POST['loyalty_id'];
            $mobile_number = $_POST['mobile_number'];
            $email = $_POST['email'];
            $data = array();
            $sql = "SELECT first_name,last_name,phone_mobile,email,loyalty_id,member_tier,birthdate,member_type,title,customer_id FROM `contacts_inactive` WHERE deleted=0 AND loyalty_id = '$loyalty_id' OR phone_mobile='$mobile_number' OR email='$email'";
            $result = $db->query($sql);
            while ($row = $db->fetchByAssoc($result)) {
                $row['birthdate'] = date('m/d/Y', strtotime($row['birthdate']));
                $data[] = $row;
            }
            if (count($data) > 0) {
                //print_r($data[0]);
                $_SESSION['lookup_customer_id'] = $data[0]['customer_id'];
                echo json_encode($data[0]);
            } else {
                echo json_encode(array('flag' => '0'));
            }
            exit();
        }
    }

    /**
     * This method is DB connection of CRM Magento 
     *
     */
    public function connectionCRMDB() {
        global $sugar_config;
        $servername = $sugar_config['crm_host'];
        $username = $sugar_config['crm_user'];
        $password = $sugar_config['crm_password'];
        $dbname = $sugar_config['crm_db'];
        $conn = new mysqli($servername, $username, $password, $dbname);
        return $conn;
    }

    /**
     * This method is get list of Cases by CRM Magento
     *
     */
    public function action_FeedbackCases() {
        global $db;
        $conn = $this->connectionCRMDB();
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $list_cases = array();
        $sql = "SELECT * FROM nakumatt_feedback WHERE others !=''";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            /* $sql_cases    = "SELECT customer_id FROM cases WHERE deleted=0 AND customer_id=". $row['id'];
              $row_cases    = $db->getOne($sql_cases);
              $row['case_customer_id'] = $row_cases; */
            //echo $row['id'].'<br/>';
            $row['branch'] = htmlspecialchars(trim($row['branch']), ENT_IGNORE);
            $row['others'] = htmlspecialchars(trim($row['others']), ENT_IGNORE);
            $caseDetails = $this->getCaseDetailsByCustomer($row['id']);
            $row['case_id'] = $caseDetails['id'];
            $row['case_customer_id'] = $caseDetails['customer_id'];
            $list_cases[] = $row;
        }
        //echo'<pre>';print_r($list_cases);// THIS IS FOR DEBUG CODE
        $conn->close();
        $this->view = 'listfeedbackcases';
        $this->view_object_map['list_case'] = $list_cases;
    }

    /**
     * This method is Create case to Customer Feedbacks CRM Magento
     *
     */
    public function action_CreatefeedbackCases() {
        global $current_user, $sugar_config;
        //Get Category ID by Name
        $cat_id = $this->getCategoryByName($sugar_config['crm_category']);
        //Get SubCategory ID & Priority by CategoryID
        $subcategoryDetails = $this->getSubCategoryByCatID($cat_id, $sugar_config['crm_subcategory']);
        //Fetch customer_id and other BY primary id
        $table_id = $_REQUEST['id'];
        $conn = $this->connectionCRMDB();
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql = "SELECT customer_id,others,branch FROM nakumatt_feedback WHERE id=" . $table_id;
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();

        $case_title = htmlspecialchars(trim($row['others']), ENT_IGNORE);
        $case_desc = '';
        $category = $cat_id;
        $sub_category = $subcategoryDetails['id'];
        $origin = $sugar_config['crm_origin'];
        $status = $sugar_config['status'];
        $case_type = $sugar_config['case_type'];
        $assigned_user_id = $sugar_config['crm_assigned_user_id'];
        $created_by_id = $sugar_config['crm_created_by_id'];
        $date_entered = date('Y-m-d H:i:s');
        $date_modified = date('Y-m-d H:i:s');
        $brach_name = htmlspecialchars(trim($row['branch']), ENT_IGNORE);

        //Get Customer Data by CustomerID
        $customerData = $this->getCustomerByID($row['customer_id']);
        if (!empty($customerData)) {
            if ($customerData['member_type'] == 0) {
                $member_type = 'member';
            } elseif ($customerData['member_type'] == 1) {
                $member_type = 'corporate';
            } else {
                $member_type = 'guest';
            }
            if ($customerData['title'] == 1) {
                $gender = 'male';
            } else {
                $gender = 'female';
            }
            $customer_name = $customerData['first_name'] . '&nbsp;' . $customerData['last_name'];
            $mobile_number = ($customerData['phone_mobile']) ? $customerData['phone_mobile'] : '';
            $email = ($customerData['email']) ? $customerData['email'] : '';
            $loyalty_id = ($customerData['loyalty_id']) ? $customerData['loyalty_id'] : '';
            $member_tier = ($customerData['member_tier']) ? $customerData['member_tier'] : '';
            $birthdate = ($customerData['birthdate']) ? $customerData['birthdate'] : '';
        } else {
            $mobile_number = '';
            $member_type = 'guest';
            $loyalty_id = '';
            $member_tier = '';
            $birthdate = '';
            $gender = '';
        }
        //Define priority High when memeber is Gold
        if ($customerData['member_tier'] == 'Gold' || $customerData['member_tier'] == 'gold') {
            $priority = 'P1';
        } else {
            $priority = $subcategoryDetails['priority'];
        }
        //Create bean(Create case)
        $bean = BeanFactory::newBean('Cases');
        $bean->customer_id = $table_id;
        $bean->name = $case_title;
        $bean->description = $case_desc;
        $bean->member_type_c = $member_type;
        $bean->customer_name_c = $customer_name;
        $bean->mobile_number_c = $mobile_number;
        $bean->email_c = $email;
        $bean->loyalty_id_c = $loyalty_id;
        $bean->member_tier_c = $member_tier;
        $bean->dob_c = $birthdate;
        $bean->gender_c = $gender;
        $bean->category_c = $category;
        $bean->subcategory_c = $sub_category;
        $bean->priority = $priority;
        $bean->origin_c = $origin;
        $bean->status = $status;
        $bean->caserelation_c = $case_type;
        $bean->date_entered = $date_entered;
        $bean->date_modified = $date_modified;
        $bean->assigned_user_id = $assigned_user_id;
        $bean->created_by = $created_by_id;
        $bean->branch_store_name = $brach_name;
        $bean->save();

        //Redirect after create case
        if (!empty($bean->id)) {
            SugarApplication::appendErrorMessage('<span class="msg-success" style="color:green;">Case created.</span>');
            $queryParams = array(
                'module' => 'Cases',
                'action' => 'feedbackCases'
            );
            SugarApplication::redirect('index.php?' . http_build_query($queryParams));
        }
    }

    /**
     * This method is Create case to Customer Feedbacks CRM Magento
     *
     */
    public function action_CreateMultiplefeedbackCases() {
        global $current_user, $sugar_config;
        if (!isset($_POST['chk']) OR ! is_array($_POST['chk'])) {
            SugarApplication::appendErrorMessage('<span class="msg-error">No rows selected for export.</span>');
            $queryParams = array(
                'module' => 'Cases',
                'action' => 'FeedbackCases'
            );
            SugarApplication::redirect('index.php?' . http_build_query($queryParams));
        } else {
            if (!empty($_POST['chk'])) {
                $conn = $this->connectionCRMDB();
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                //Get Category ID by Name
                $cat_id = $this->getCategoryByName($sugar_config['crm_category']);
                //Get SubCategory ID & Priority by CategoryID
                $subcategoryDetails = $this->getSubCategoryByCatID($cat_id, $sugar_config['crm_subcategory']);
                //Fetch customer_id and other BY primary id
                $case_desc = '';
                $category = $cat_id;
                $sub_category = $subcategoryDetails['id'];
                $origin = $sugar_config['crm_origin'];
                $status = $sugar_config['status'];
                $case_type = $sugar_config['case_type'];
                $assigned_user_id = $sugar_config['crm_assigned_user_id'];
                $created_by_id = $sugar_config['crm_created_by_id'];
                $date_entered = date('Y-m-d H:i:s');
                $date_modified = date('Y-m-d H:i:s');
                //print_r($_POST['chk']);die;
                $IDs = implode('","', $_POST['chk']);
                $condition = ' id IN ("' . $IDs . '")';
                $sql = 'SELECT id,customer_id,others,branch FROM nakumatt_feedback WHERE ' . $condition;
                $result = $conn->query($sql);
                while ($row = $result->fetch_assoc()) {
                    $case_title = htmlspecialchars(trim($row['others']), ENT_IGNORE);
                    $brach_name = htmlspecialchars(trim($row['branch']), ENT_IGNORE);
                    //Get Customer Data by CustomerID
                    $customerData = $this->getCustomerByID($row['customer_id']);
                    if (!empty($customerData)) {
                        if ($customerData['member_type'] == 0) {
                            $member_type = 'member';
                        } elseif ($customerData['member_type'] == 1) {
                            $member_type = 'corporate';
                        } else {
                            $member_type = 'guest';
                        }
                        if ($customerData['title'] == 1) {
                            $gender = 'male';
                        } else {
                            $gender = 'female';
                        }
                        $customer_name = $customerData['first_name'] . '&nbsp;' . $customerData['last_name'];
                        $mobile_number = ($customerData['phone_mobile']) ? $customerData['phone_mobile'] : '';
                        $email = ($customerData['email']) ? $customerData['email'] : '';
                        $loyalty_id = ($customerData['loyalty_id']) ? $customerData['loyalty_id'] : '';
                        $member_tier = ($customerData['member_tier']) ? $customerData['member_tier'] : '';
                        $birthdate = ($customerData['birthdate']) ? $customerData['birthdate'] : '';
                    } else {
                        $mobile_number = '';
                        $member_type = 'guest';
                        $loyalty_id = '';
                        $member_tier = '';
                        $birthdate = '';
                        $gender = '';
                    }
                    //Define priority High when memeber is Gold
                    if ($customerData['member_tier'] == 'Gold' || $customerData['member_tier'] == 'gold') {
                        $priority = 'P1';
                    } else {
                        $priority = $subcategoryDetails['priority'];
                    }
                    //Create bean(Create case)
                    $bean = BeanFactory::newBean('Cases');
                    $bean->customer_id = $row['id'];
                    $bean->name = $case_title;
                    $bean->description = $case_desc;
                    $bean->member_type_c = $member_type;
                    $bean->customer_name_c = $customer_name;
                    $bean->mobile_number_c = $mobile_number;
                    $bean->email_c = $email;
                    $bean->loyalty_id_c = $loyalty_id;
                    $bean->member_tier_c = $member_tier;
                    $bean->dob_c = $birthdate;
                    $bean->gender_c = $gender;
                    $bean->category_c = $category;
                    $bean->subcategory_c = $sub_category;
                    $bean->priority = $priority;
                    $bean->origin_c = $origin;
                    $bean->status = $status;
                    $bean->caserelation_c = $case_type;
                    $bean->date_entered = $date_entered;
                    $bean->date_modified = $date_modified;
                    $bean->assigned_user_id = $assigned_user_id;
                    $bean->created_by = $created_by_id;
                    $bean->branch_store_name = $brach_name;
                    //echo'<pre>'; print_r($bean);die;
                    $bean->save();
                }
                //Redirect after create case
                if (!empty($bean->id)) {
                    SugarApplication::appendErrorMessage('<span class="msg-success" style="color:green;">Case created.</span>');
                    $queryParams = array(
                        'module' => 'Cases',
                        'action' => 'FeedbackCases'
                    );
                    SugarApplication::redirect('index.php?' . http_build_query($queryParams));
                }
            }
        }
    }

    //function to get Case ID and Customer ID
    public function getCaseDetailsByCustomer($feedback_id) {
        global $db;
        if (!empty($feedback_id)) {
            $data = array();
            $sql = "SELECT id,customer_id FROM `cases` WHERE deleted=0 AND customer_id=" . $feedback_id;
            $result = $db->query($sql);
            while ($row = $db->fetchByAssoc($result)) {
                $data[] = $row;
            }
            if (count($data) > 0) {
                return $data[0];
            } else {
                return false;
            }
        }
    }

    //function to get customer information by email
    public function getCustomerByID($id) {
        global $db;
        if (!empty($id)) {
            $data = array();
            $sql = "SELECT first_name,last_name,phone_mobile,email,loyalty_id,member_tier,birthdate,member_type FROM `contacts` WHERE deleted=0 AND customer_id='$id'";
            $result = $db->query($sql);
            while ($row = $db->fetchByAssoc($result)) {
                $row['birthdate'] = date('d/m/Y', strtotime($row['birthdate']));
                $data[] = $row;
            }
            if (count($data) > 0) {
                return $data[0];
            } else {
                return false;
            }
        }
    }

    //function to get category id By category name
    public function getCategoryByName($name) {
        global $db;
        if (!empty($name)) {
            $sql = "SELECT id FROM `naku_casecategory` WHERE deleted=0 AND name LIKE '$name'";
            $result = $db->getOne($sql);
            return $result;
        }
    }

    //function to get subcategory_id and priority by category id
    public function getSubCategoryByCatID($catid, $subcategory) {
        global $db;
        if (!empty($catid)) {
            $data = array();
            $sql = "SELECT id,priority FROM `naku_casesubcategory` WHERE deleted=0 AND category_id='$catid' AND name LIKE '$subcategory'";
            $result = $db->query($sql);
            while ($row = $db->fetchByAssoc($result)) {
                $data[] = $row;
            }
            if (count($data) > 0) {
                return $data[0];
            } else {
                return false;
            }
        }
    }

    public function action_list_case_dashlet() {
        global $db, $current_user, $app_list_strings;
        $this->view = 'listcustomdashlet';

        $bean = BeanFactory::getBean($this->module);
        if ($current_user->isAdmin() == 1) {
            $this->view_object_map['admin'] = 'admin';
        } else {
            $this->view_object_map['admin'] = '';
        }

        $query_fetch_users = "select distinct(cases.assigned_user_id)as user_id , CONCAT_WS(' ',users.first_name, users.last_name) AS assigned_user from users users join cases cases on cases.assigned_user_id = users.id where cases.deleted =0 AND users.deleted=0 ";
        $result_assigned = $db->query($query_fetch_users);
        $alluserAssigned = array();
        while ($row_assigned = $db->fetchByAssoc($result_assigned)) {
            $alluserAssigned[] = $row_assigned;
        }
        $this->view_object_map['assigned_users'] = $alluserAssigned;

        // start get all subtype record
        $fetchColumn = '';
        $condition = '';
        $limit = ' '; //' limit 30 ';
        if (($current_user->reports_to_name != '' || $current_user->reports_to_id != '') && ($current_user->isAdmin() != 1)) {
            $query_on = "select id from users where reports_to_id !='' AND id IN (select id from users where reports_to_id ='" . $current_user->id . "' AND deleted =0) ";
            $result_on = $db->query($query_on);
            $alluser = array();
            while ($row_on = $db->fetchByAssoc($result_on)) {
                array_push($alluser, $row_on['id']);
            }
            $agentIDs = implode("','", $alluser);
            if (count($alluser) > 0) {
                $fetchColumn = '';
                $condition = " cases.assigned_user_id IN ('" . $agentIDs . "') AND ";

                $query_fetch_users = "select distinct(cases.assigned_user_id)as user_id , CONCAT_WS(' ',users.first_name, users.last_name) AS assigned_user from users users join cases cases on cases.assigned_user_id = users.id where cases.deleted =0 AND users.deleted=0 AND cases.assigned_user_id IN ('" . $agentIDs . "') ";
                $result_assigned = $db->query($query_fetch_users);
                $alluserAssigned = array();
                while ($row_assigned = $db->fetchByAssoc($result_assigned)) {
                    $alluserAssigned[] = $row_assigned;
                }
                $this->view_object_map['assigned_users'] = $alluserAssigned;
                $this->view_object_map['agent_user'] = 'supervisor';
            } else {
                $condition = ' cases.assigned_user_id = "' . $current_user->id . '" AND ';
                $this->view_object_map['agent_user'] = 'agent';
            }
            $limit = ''; //'limit 50';
        } elseif (($current_user->reports_to_name == '' || $current_user->reports_to_id == '') && ($current_user->isAdmin() == 1)) {
            $condition = '';
            $limit = ''; //'limit 50';
            //for admin
            $query_fetch_users = "select distinct(cases.assigned_user_id)as user_id , CONCAT_WS(' ',users.first_name, users.last_name) AS assigned_user from users users join cases cases on cases.assigned_user_id = users.id where cases.deleted =0 AND users.deleted=0 ";
            $result_assigned = $db->query($query_fetch_users);
            $alluserAssigned = array();
            while ($row_assigned = $db->fetchByAssoc($result_assigned)) {
                $alluserAssigned[] = $row_assigned;
            }
            $this->view_object_map['assigned_users'] = $alluserAssigned;
            $this->view_object_map['agent_user'] = 'admin';
        }
        $condition_org = '';
        if (isset($_REQUEST['query']) == 'true') {
            if ($_REQUEST['member_tier_c'] || $_REQUEST['origin'] || $_REQUEST['status'] || $_REQUEST['priority'] || $_REQUEST['assigned_case']) {

                if ($_REQUEST['origin'] != '') {
                    $condition .= " cases_cstm.origin_c = '" . $_REQUEST['origin'] . "' AND ";
                }
                if ($_REQUEST['status']) {
                    $condition .= "  cases.status = '" . $_REQUEST['status'] . "' AND ";
                }
                if ($_REQUEST['priority']) {
                    $condition .= "  cases.priority = '" . $_REQUEST['priority'] . "' AND ";
                }
                if ($_REQUEST['member_tier_c']) {
                    $condition .= " cases_cstm.member_tier_c = '" . $_REQUEST['member_tier_c'] . "' AND ";
                }
                if ($_REQUEST['assigned_case']) {
                    $condition .= " cases.assigned_user_id = '" . $_REQUEST['assigned_case'] . "' AND ";
                }
            }
        }
        $query = "SELECT cases.id,"
                . " cases.name,"
                . " cases.customer_id,"
                . " cases_cstm.category_c,"
                . " cases_cstm.customer_name_c,"
                . " cases_cstm.email_c,"
                . " cases_cstm.member_tier_c,"
                . " cases_cstm.mobile_number_c,"
                . " cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c, "
                . " cases_cstm.subcategory_c, "
                . " cases.case_number , "
                . " cases.priority , "
                . " cases.status ,"
                . " cases.date_entered , "
                . " users.user_name , "
                . " users.first_name , "
                . " users.last_name , "
                . " cases.assigned_user_id "
                . " FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN users ON cases.assigned_user_id=users.id AND cases.deleted=0 AND users.deleted=0 "
                . " where " . $condition . "  cases.deleted=0  ORDER BY cases.date_entered DESC " . $limit;
        //AND cases.status !='Resolved'
        $result = $db->query($query);
        $custom_dashlet = array();
        while ($row = $db->fetchByAssoc($result)) {
            //$row['origin_c'] = translate('origin_list', '', $row['origin_c']);
            $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$aa = $row['priority_id']= $row['priority'];
            $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$row['priority'] = "". $aa." - ".$row['priority'];			
            $custom_dashlet[] = $row;
        }

        // $custom_dashlet[] = array($row['case_number'], $row['name'], $row['category_c'], $row['origin_c'], $row['priority'], $row['status'], $row['user_name'], $row['date_entered'],$row['member_tier_c'],);
        if (count($custom_dashlet) > 0) {
            $this->view_object_map['custom_dashlet'] = $custom_dashlet;
        } else {
            $this->view_object_map['custom_dashlet'] = array();
        }
        
        //start Roles and Permission Hacks by Akhilesh Date 23/08/2017
        $uid        = $current_user->id; //Logged in User ID
        $category   = "Cases"; //Module name
        $type       = "module"; //Nochnage
        $rootAction = "case"; //Root or Parent Action name according to magento Root action name i.e. if rootAction is true then all subAction is true no need to check subAction is true or false. Nakumatt_CaseManagement::case, Nakumatt_Campaign::markiting_list, Nakumatt_Campaign::markiting_calendar, Nakumatt_Campaign::campaign_asset, Nakumatt_Campaign::campaign
        $subActionCreate = "create"; //Create ICON
        
        $createIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionCreate, $type);
        $this->view_object_map['createIcon'] = $createIcon;
        $this->view_object_map['adminRole'] = $current_user->isAdmin();
        
        $subActionView = "view"; //View ICON
        $viewIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionView, $type);
        $this->view_object_map['viewIcon'] = $viewIcon;
        //end Roles and Permission Hacks by Akhilesh
    }

    
	
	//escalation report
	 //Reports Escalation
    public function action_servicereportescalation() {  
	    global $db, $app_list_strings,$sugar_config;
        $this->view = 'servicereportescalation';
        $this->view_object_map['getAllCaseCategory'] = $this->getAllCaseCategory();
        $this->view_object_map['getTimePeriod'] = $this->getTimePeriod();
		$this->view_object_map['getCasepriority'] = $this->getCasepriority();
		$this->view_object_map['site_url'] = $sugar_config['site_url'];
		//get branch store name
		$this->view_object_map['branch_store_name'] = $this->getAllBranchName();
        $escalated_case = array();
        $this->view_object_map['getTimePeriod'] = $this->getTimePeriod();
		$this->view_object_map['site_url'] = $sugar_config['site_url'];
        $volumecc = $queryCase = $_Yearquery= $_ColumnsDate=$volumeDate=$_DailyLoopC=$_DateEnteredArray
		=$volumecc_grid=$_NoOfQuarters=$_GetOneQuarters=array();
		$_WeeklyGlobal = $_QuaterlyGlobal = $_MonthGlobal = 0;
        $condition = $condition_group=$_BranchStore = '';
		
        if (isset($_REQUEST['query']) == 'true') {
            if ($_REQUEST['member_tier_c'] || $_REQUEST['category_id'] || $_REQUEST['origin'] || $_REQUEST['branch_store_name'] || $_REQUEST['status'] ||
                    $_REQUEST['from_date'] || $_REQUEST['to_date']) {
					
			    if ($_REQUEST['category_id'] == "all") {
                    $condition .= "";
					$condition_group .= "";
				 }else
				 {
				     $condition .= "  cases_cstm.category_c = '" . $_REQUEST['category_id'] . "' AND ";
					$condition_group .= ",cases_cstm.category_c";
				 }
				 
				 
				if ($_REQUEST['origin'] == "all")  {
                    $condition .= " ";
					$condition_group .= "";
                }else
				 {
				    $condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
					$condition_group .= ",cases_cstm.origin_c";
				 }
				 
				 if ($_REQUEST['branch_store_name'] == "all" || $_REQUEST['branch_store_name'] == "")  {
                    $condition .= " ";
					$condition_group .= "";
                }else
				 {
				    $condition .= "  cases.branch_store_name = '" . $_REQUEST['branch_store_name'] . "'  AND ";
					$condition_group .= ",cases.branch_store_name";
				 }
				 
				 if ($_REQUEST['sub_category_id']  == "all") {
                    $condition .= " ";
					$condition_group .= "";
                }else
				 {
				    $condition .= "  cases_cstm.subcategory_c = '" . $_REQUEST['sub_category_id'] . "'  AND ";
					$condition_group .= ",cases_cstm.subcategory_c";
				 }
				 
				
				if ($_REQUEST['member_tier_c'] == "all") {
                    $condition .= "";
					$condition_group .= "";
				 }else
				 {
				    $condition .= "  cases_cstm.member_tier_c = '" . $_REQUEST['member_tier_c'] . "' AND ";
					$condition_group .= ",cases_cstm.member_tier_c";
				 }
				 
				if ($_REQUEST['status']  == "all") {
                    $condition .= " ";
					$condition_group .= "";
                }else
				 {
				    $condition .= "  cases.status = '" . $_REQUEST['status'] . "'  AND ";
					$condition_group .= ",cases.status";
				 }
				 
				 
				 $_Status =  $_REQUEST['status'];
				 $_Membertier = $_REQUEST['member_tier_c'];
				 
                /*checking query starting*/
			    $start_date = date("Y-m-d",strtotime($_REQUEST['from_date']));
			    $end_date = date("Y-m-d",strtotime($_REQUEST['to_date']));
                $start_date = $_REQUEST['from_date']; //fromdate for post
				$this->view_object_map['getFromDate'] = $start_date;
				$end_date = $_REQUEST['to_date']; //todate for post
				$this->view_object_map['getToDate'] = $end_date;
				$_Periodpost = $_REQUEST['period']; //period for post
				$this->view_object_map['getPeriod'] = $_Periodpost;
				$_Oroginpost = $_REQUEST['origin']; //origin for post
				$this->view_object_map['getOrigin'] = $_Oroginpost;
				$_Categorypost = $_REQUEST['category_id']; //categoryid for post
				$this->view_object_map['getCategory'] = $_Categorypost;
			    $_Statuspost = $_REQUEST['status']; //status for post
				$this->view_object_map['getStatus'] = $_Statuspost;
				$_Membertierpost = $_REQUEST['member_tier_c']; //member tier for post
				$this->view_object_map['member_tier_c'] = $_Membertierpost;
				$this->view_object_map['sub_category_id'] = $_POST['sub_category_id']; // selected subcat
				
				$_BranchStore = $_REQUEST['branch_store_name']; //branch_store_name for post
                $this->view_object_map['getBranchName'] = $_BranchStore;
				
			    if($_REQUEST['period'] == "daily"):
						
						$_DailyLoopCount = $this->datediff('d',date("y-m-d",strtotime($_REQUEST['from_date'])),date("y-m-d",strtotime($_REQUEST['to_date'])));				 

						for($i=0;$i<=$_DailyLoopCount;$i++)
						{
						$_DailyLoopC[] =  date ("Y-m-d", strtotime("+$i day", strtotime($start_date)));
						}
						
						if ($_REQUEST['from_date'] && $_REQUEST['to_date']) {
								$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";
						}
								
								
                       $query_query = "SELECT cases.id,cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, 
						LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,cases.assigned_user_id,
						cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases 
						LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c 
						LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id 
						LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id  AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition . " cases.deleted=0 and cases.caseescalate_c > 0 AND cases.status NOT IN('Resolved','Closed') group by date(cases.date_entered)".$condition_group."  ORDER BY cases.date_entered DESC";
						
						
						$result = $db->query($query_query);
						$total = $result->num_rows;
						
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['case_id'] = $row['cases_id'];
						$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecc[] = $row;
					    $volumeDate[] = date("Y-m-d",strtotime($row['date_entered']));
						}
						else:
						$row['emptyrecord'] = "N/A";
                       // $volumecc[] = $row;
						endif;
				
				endif;
				
				
			
				if(count($volumecc)):
						 foreach($volumecc as $volumeccData)
						 {
							$_DateEnteredArray[] = $volumeccData['date_entered'];
							$_DateEntered1Array[$volumeccData['date_entered']] = array($volumeccData['cases_id'],$volumeccData['date_entered'],$volumeccData['category_c'],$volumeccData['priority'],$volumeccData['origin_c'],$volumeccData['status'],$volumeccData['count(cases.id)']);
						 }
			    endif;
				
				if($_REQUEST['category_id'] == 'all'):
				$_Catname = 'All';
				else:
				$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
				endif;
						
				$i = 0;
                if(count($_DailyLoopC) > 0):
			     foreach($_DailyLoopC as $_DailyLoopCDataKey => $_DailyLoopCData)
					 { 
						if (in_array($_DailyLoopCData,$_DateEnteredArray))
						 {
							/*script for showing daily wise record*/
							 $_DailSSdate = $_DailyLoopCData; //start date
							 $_DailESdate =  date ("Y-m-d", strtotime("+1 day", strtotime($_DailyLoopCData))); //end date
							 
							$_DailyRowrecord =  $this->dailydataDailywiseEsca($_REQUEST['sub_category_id'] ,$_REQUEST['origin'],$_REQUEST['branch_store_name'],$_REQUEST['category_id'],$_DailSSdate, $_DailESdate,$_Status,$_Membertier);
							

							/*script for showing daily wise record*/
							 foreach($_DailyRowrecord  as $_DailyRowrecord1):
							 $escalated_case[] = "<tr style=padding:20px;>";
							 $escalated_case[] = "<td >".$_DailyRowrecord1['date_entered']."</td>";
							 $escalated_case[] = "<td >".$_DailyRowrecord1['case_number']."</td>";
							 $escalated_case[] = "<td >".$_DailyRowrecord1['category_c']."</td>";
							  $escalated_case[] = "<td >".ucfirst($_DailyRowrecord1['priority'])."</td>";
							 $escalated_case[] = "<td >".ucfirst($_DailyRowrecord1['status'])."</td>";
							 //$escalated_case[] = "<td >1</td>";
							 $escalated_case[] = "</tr>";
							 endforeach;
						}else{
							 $escalated_case[] = "<tr>";
							 $escalated_case[] =  "<td>".$_DailyLoopCData."</td>
							 <td>NA</td>
							 
							 <td>NA</td>
							 <td>NA</td>
							 <td>NA</td>";
							
							 $escalated_case[] = "</tr>";
							 //<td>".$_Catname."</td> <td>".ucfirst($_POST['status'])."</td>";

						}
					}
                endif;	
			
            }
        }
		
			//echo "<pre>";
			//print_r($escalated_case);
				
        $this->view_object_map['escalated_cases'] = $escalated_case;
    }
    
	public function action_exportDataReportEsclation() {
        global $db, $app_list_strings;
		$condition =$_QueryMt = $_QueryFD =$_QueryTD =$_QueryPer= $_QueryReportStatus = $_QueryORI =$_QueryReportBranchStore = $_QueryCat =$_QueryReportType= $_QuerySubCat =$start_date=$end_date="";
		
		  
			
	      if(isset($_REQUEST['queryfromdate']))
          {
		   $_QueryFD =  $_REQUEST['queryfromdate'];
          }
		  
          if(isset($_REQUEST['querytodate']))
          {
		  $_QueryTD =  $_REQUEST['querytodate'];
          }

          if(isset($_REQUEST['queryPeriod']))
          {
		  $_QueryPer =  $_REQUEST['queryPeriod'];
          }

          if(isset($_REQUEST['queryorigin']))
          {
		  $_QueryORI=  $_REQUEST['queryorigin'];
          }

          if(isset($_REQUEST['querycategory']))
          {
		  $_QueryCat =  $_REQUEST['querycategory'];
          }
		  
		  if(isset($_REQUEST['querysubcategory']))
          {
		  $_QuerySubCat =  $_REQUEST['querysubcategory'];
          }
          
		  if(isset($_POST['report_type']))
          {
		  $_QueryReportType =  $_POST['report_type'];
          }
          if(isset($_POST['getMemberTier']))
          {
		  $_QueryMt =  $_POST['getMemberTier'];
          }
		  
		   if(isset($_POST['queryBranchStore']))
          {
		  $_QueryReportBranchStore =  $_POST['queryBranchStore'];
          }
		  

		  if(isset($_POST['queryStatus']))
		  {
		   $_QueryReportStatus =  $_POST['queryStatus'];
		  }
     	  
	   if( $_QueryReportType == "detailsreport"){ // summery report
	   
		  $_dataColumns = $this->getExportContentEsca($_QueryFD,$_QueryTD,$_QueryPer,$_QueryMt ,$_QueryORI, $_QueryReportBranchStore,$_QueryCat,$_QuerySubCat,$_QueryReportType
		  ,$_QueryReportStatus);  //calling function to get export data

              if ($_POST['file_type'] == 'csv') { //Export CSV
                //CSV File name and Header
                $filename = "case_escalation_report_" . date('Y-m-d:H:i:s') . ".csv";
                $fp = fopen('php://output', 'w');
                $header = array('Case Id','Date','Case Category','Case Origin','Case Status');
                header('Content-type: application/csv');
                header('Content-Disposition: attachment; filename=' . $filename);
                fputcsv($fp, $header);
				$condition ="";
				$export_list_case = array();
				foreach($_dataColumns as $_dataColumns1Val):
				$row['case_number'] = $_dataColumns1Val['case_number'];
				$row['date_entered'] = $_dataColumns1Val['date_entered'];
				$row['category_c'] = $_dataColumns1Val['category_c'];
				$row['origin_c'] = $_dataColumns1Val['origin_c'];
				$row['status'] = $_dataColumns1Val['status'];
				$export_list_case[] = $row;
			    fputcsv($fp, $row); //Genrate CSV
				endforeach;
				fclose($fp);
                exit;
            } elseif ($_POST['file_type'] == 'xls') { //Export XLS
                $list = array();
                $list['tableheading'] = array('Case Id','Date','Case Category', 'Case Origin','Case Priority');
                $fichier = "case_escalation_report_" . date('Y-m-d:H:i:s') . ".xls";
                header("Content-Type: text/csv;charset=utf-8");
                header("Content-Disposition: attachment;filename=\"$fichier\"");
                header("Pragma: no-cache");
                header("Expires: 0");
                $fp = fopen('php://output', 'w');
                fputcsv($fp, $list['tableheading']);
                //Fetch data
                foreach($_dataColumns as $_dataColumns1Val):
				$row['case_number'] = $_dataColumns1Val['case_number'];
				$row['date_entered'] = $_dataColumns1Val['date_entered'];
				$row['category_c'] = $_dataColumns1Val['category_c'];
				$row['origin_c'] = $_dataColumns1Val['origin_c'];
				$row['priority'] = $_dataColumns1Val['priority'];
				$data['list'] = $row;
				//$export_list_case[] = $row;
			    fputcsv($fp, $data['list']); //Genrate CSV
				endforeach;
				fclose($fp);
                exit();
            }elseif($_POST['file_type'] == 'pdf')
			{
               require_once 'include/dompdf/dompdf_config.inc.php';
			   global $current_user;
			   $name = $current_user->first_name . '&nbsp;' . $current_user->last_name;
			   $current_date = date('d/m/Y  h:i A');
			   $dompdf = new Dompdf();
			   //echo '<pre>';
			   //print_r($_dataColumns);
			  // die;
			  
			  if($_QueryPer  == 'daily'):
			   $start_date =$_QueryFD;
			   $end_date =$_QueryTD;
			  elseif($_QueryPer  == 'monthly'):
			   $start_date =$_QueryReportMonthStart;
			   $end_date =$_QueryReportMonthEnd;
			  elseif($_QueryPer  == 'quarterly'):
			   $start_date = "Quarter ".$this->Quarterlabelreportpdf($_Qstart);
			   $end_date = "Quarter ".$this->Quarterlabelreportpdf($_Qend);
			  elseif($_QueryPer  == 'weekly'):
			   $start_date =  $_Wstart;
			   $end_date =  $_Wend;
				
			  else:
			      if(date("m") <= 06){
						$_CurrentYear = date("Y"); // current year
						$_NextYears =  date("Y")-1; //previous year 
						
						$start_date =  date($_NextYears.'-07-01'); //common from date
						$end_date =  date($_CurrentYear.'-06-30'); 

						}
						else{
						$_CurrentYear =  date("Y"); // current year
						$_NextYears  =  date("Y") + 1;  // post year
						$start_date =  date($_CurrentYear.'-07-01'); //common from date
						$end_date =  date($_NextYears.'-06-30'); 
						}
				endif;		
				
			   $_CaseOriginPdf = $_CaseOriginCat = "";
			   if($_QueryORI == 'all'):
			    $_CaseOriginPdf = 'All';
			   else:
			    $_CaseOriginPdf = $this->getCaseOriginName($_QueryORI);
			   endif;
			   
			   if($_QueryCat == 'all'):
			    $_CaseOriginCat = 'All';
			   else:
			    $_CaseOriginCat = $this->getCaseCategoryName($_QueryCat);
			   endif;
			   
			   if($_QuerySubCat == 'all'):
			    $_CaseOriginSubCat = 'All';
			   else:
			    $_CaseOriginSubCat = $this->getCaseSubCategoryName($_QuerySubCat);
			   endif;
			   
			   
			    $_QueryStore = "";
				if($_QueryReportBranchStore == 'all'):
				$_QueryStore = 'All';
				else:
				$_QueryStore = $_QueryReportBranchStore;
				endif;
			   
			    $_QueryStatus = "";
				if($_QueryReportStatus == 'all'):
				$_QueryStatus = 'All';
				else:
				$_QueryStatus = $_QueryReportStatus;
				endif;
				
			   $header = '<html>
            <body>
                <div style="width:100%;color:#fff;background:#17479d;padding:5px 0px;margin:0px;text-align:center;">
                    <img src="custom/include/images/logo.png" style="padding: 7px;position: absolute;left: 10px;"><h2>Case Escalation </h2>
                </div>
				<br />
				<table style="width:450px; margin:0 auto; text-align:left;">
				    <tr>
						<td style="width="20%"><b>From  - </b></td>
						<td style="width="10%">'.$start_date.'</td>
						<td style="width="20%"><b>To  - </b></td>
						<td style="width="10%">'.$end_date.'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Period  - </b></td>
						<td style="width="50%">'.ucfirst($_QueryPer).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Origin  - </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginPdf).'</td>
					</tr>
					';
					 if($_QueryStore == 'all'):
						 $header .= '<tr>
						<td style="width="50%"><b>Branch Store - </b></td>
						<td style="width="50%">All</td>
					</tr>';
						elseif($_QueryStore == ''):
							 $header .= ''; 
					   else:
						 $header .= '<tr>
						<td style="width="50%"><b>Branch Store  - </b></td>
						<td style="width="50%">'.ucfirst($_QueryStore).'</td>
					</tr>'; 
					   endif;
					   
					  $header .= ' 
					  
					<tr>
						<td style="width="50%"><b>Case Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginCat).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Sub Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginSubCat).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Status  -  </b></td>
						<td style="width="50%">'.ucfirst($_QueryStatus).'</td>
					</tr>
				</table>';
				
			    $content .= '<table border="1" cellspacing="0" cellpadding="5" width="100%">  
                    <thead>
                        <tr>
                            <th nowrap>Case Id</th>
                            <th nowrap>Date</th>
                            <th nowrap>Case Origin</th> 
                            <th nowrap>Case Category</th>  
							<th nowrap>Case Priority</th> 
                        </tr>
                </thead>';
				
				foreach($_dataColumns as $_dataColumns1Val):
				    $content .= '<tbody>
                        <tr>
                          <td>' . $_dataColumns1Val["case_number"] . '</td>
                          <td>' . $_dataColumns1Val["date_entered"] . '</td>
                          <td>' . $_dataColumns1Val["origin_c"] . '</td>
                          <td>' . $_dataColumns1Val["category_c"] . '</td>
						  ';
						  $prio = "";
						  if( $_dataColumns1Val["priority"] == "P3"){
							$prio = "Low";
						  }else if($_dataColumns1Val["priority"] == "P2"){
								$prio = "Medium";
						  }else if($_dataColumns1Val["priority"] == "P1"){
							$prio = "High";
						  }else{
							$prio = "NA";
						  }
						  
                          $content .=  '<td>' . $prio . '</td>
                     </tr>
                    <tbody>';
				
				endforeach;
				$content .= '</table>';
				$footer = '<table style="width:100%;color:#ccc;background:#17479d;padding:5px 0px;margin:0px;">
								<tr>
							<td width="30%"><span style="float:left!important;margin-left:10px;">Printed by: ' . $name . '&nbsp;' . $current_date . '</span></td>
							<td style="text-align:center;width:30%;">www.nakumatt.net</td>
							<td  width="30%">&nbsp;</td>
								</tr>
							</table>
							<h4 style="color:red;">The content is confidential and not meant to be shared in any form with any external persons / entities.</h4>
							</body>
							</html>';
				$html = $header . $content . $footer;
				$dompdf->load_html($html);
				// (Optional) Setup the paper size and orientation
				$dompdf->set_paper('A4', 'landscape');
				// Render the HTML as PDF
				$dompdf->render();
				// Output the generated PDF to Browser
				$filename = "Case Escalation " . date('Y-m-d:H:i:s') . ".pdf";
				$dompdf->stream($filename);			
			   //pdf report
			
		   }  
		}   
	   elseif( $_QueryReportType == "summeryreport" ){  // details report
  	   $_dataColumns = $this->getExportContentsummeryreport($_QueryFD,$_QueryTD,$_QueryPer,$_QueryORI,$_QueryCat,$_QuerySubCat,$_QueryReportType,$_QueryReportMonthStart,$_QueryReportMonthEnd
		  ,$_Wstart,$_Wend, $_Qstart,$_Qend);  //calling function to get export data
       //echo "<pre>";
	    $_Period = "";
	 if ($_POST['file_type'] == 'csv') { //Export CSV
                //CSV File name and Header
                $filename = "volumecc_summery_report" . date('Y-m-d:H:i:s') . ".csv";
                $fp = fopen('php://output', 'w');
				
				if($_QueryPer == 'daily'):
				 $_Period = "Daily";
				elseif($_QueryPer =='weekly'):
				 $_Period = "Weekly";
				elseif($_QueryPer == 'monthly'):
				 $_Period = "Monthly";
				elseif($_QueryPer == 'quarterly'):
				 $_Period = "Quarterly";
				elseif($_QueryPer == 'annual'):
				 $_Period = "Annual";
				endif;
                $header = array($_Period,'Count');
                header('Content-type: application/csv');
                header('Content-Disposition: attachment; filename=' . $filename);
                fputcsv($fp, $header);
				$condition ="";
				$export_list_case = array();
				foreach($_dataColumns as $_dataColumns1Key => $_dataColumns1Val):
				$row['period'] =  $_dataColumns1Val[0];
				$row['count'] = $_dataColumns1Val[1];
				$export_list_case[] = $row;
			    fputcsv($fp, $row); //Genrate CSV
				endforeach;
				fclose($fp);
                exit;
            } elseif ($_POST['file_type'] == 'xls') { //Export XLS
                $list = array();
				if($_QueryPer == 'daily'):
				 $_Period = "Daily";
				elseif($_QueryPer =='weekly'):
				 $_Period = "Weekly";
				elseif($_QueryPer == 'monthly'):
				 $_Period = "Monthly";
				elseif($_QueryPer == 'quarterly'):
				 $_Period = "Quarterly";
				elseif($_QueryPer == 'annual'):
				 $_Period = "Annual";
				endif;
				
                $list['tableheading'] = array($_Period,'Count');
                $fichier = "CS" . date('Y-m-d:H:i:s') . ".xls";
                header("Content-Type: text/csv;charset=utf-8");
                header("Content-Disposition: attachment;filename=\"$fichier\"");
                header("Pragma: no-cache");
                header("Expires: 0");
                $fp = fopen('php://output', 'w');
                fputcsv($fp, $list['tableheading']);
                //Fetch data
                foreach($_dataColumns as $_dataColumns1Val):
				$row['week'] =  $_dataColumns1Val[0];
				$row['count'] = $_dataColumns1Val[1];
				$data['list'] = $row;
				//$export_list_case[] = $row;
			    fputcsv($fp, $data['list']); //Genrate CSV
				endforeach;
				fclose($fp);
                exit();
            }elseif($_POST['file_type'] == 'pdf')
			{
			require_once 'include/dompdf/dompdf_config.inc.php';
			   global $current_user;
			   
			  if($_QueryPer  == 'daily'):
			   $_Period = "Daily";
			   $start_date =$_QueryFD;
			   $end_date =$_QueryTD;
			  elseif($_QueryPer  == 'monthly'):
			   $_Period = "Monthly";
			   $start_date =$_QueryReportMonthStart;
			   $end_date =$_QueryReportMonthEnd;
			  elseif($_QueryPer  == 'quarterly'):
			   $_Period = "Quarter";
			   $start_date = "Quarter ".$this->Quarterlabelreportpdf($_Qstart);
			   $end_date = "Quarter ".$this->Quarterlabelreportpdf($_Qend);
			  elseif($_QueryPer  == 'weekly'):
			   $_Period = "Weekly";
			   $start_date =  $_Wstart;
			   $end_date =  $_Wend;
				
			  else:
			      if(date("m") <= 06){
						$_CurrentYear = date("Y"); // current year
						$_NextYears =  date("Y")-1; //previous year 
						
						$start_date =  date($_NextYears.'-07-01'); //common from date
						$end_date =  date($_CurrentYear.'-06-30'); 

						}
						else{
						$_CurrentYear =  date("Y"); // current year
						$_NextYears  =  date("Y") + 1;  // post year
						$start_date =  date($_CurrentYear.'-07-01'); //common from date
						$end_date =  date($_NextYears.'-06-30'); 
						}
				endif;	
				
			   $name = $current_user->first_name . '&nbsp;' . $current_user->last_name;
			   $current_date = date('d/m/Y  h:i A');
			   $dompdf = new Dompdf();
			   //echo '<pre>';
			   //print_r($_dataColumns);
			  // die;
			    $_CaseOriginPdf = $_CaseOriginCat = "";
			   if($_QueryORI == 'all'):
			    $_CaseOriginPdf = 'All';
			   else:
			    $_CaseOriginPdf = $this->getCaseOriginName($_QueryORI);
			   endif;
			   
			   if($_QueryCat == 'all'):
			    $_CaseOriginCat = 'All';
			   else:
			    $_CaseOriginCat = $this->getCaseCategoryName($_QueryCat);
			   endif;
			   
			   if($_QuerySubCat == 'all'):
			    $_CaseOriginSubCat = 'All';
			   else:
			    $_CaseOriginSubCat = $this->getCaseSubCategoryName($_QuerySubCat);
			   endif;
			   
			   $header = '<html>
            <body>
                <div style="width:100%;color:#fff;background:#17479d;padding:5px 0px;margin:0px;text-align:center;">
                    <img src="custom/include/images/logo.png" style="padding: 7px;position: absolute;left: 10px;"><h2> Case Escalation </h2>
                </div>
				<br />
				<table style="width:450px; margin:0 auto; text-align:left;">
				    <tr>
						<td style="width="20%"><b>From  - </b></td>
						<td style="width="10%">'.$start_date.'</td>
						<td style="width="20%"><b>To  - </b></td>
						<td style="width="10%">'.$end_date.'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Period  - </b></td>
						<td style="width="50%">'.ucfirst($_QueryPer).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Origin  - </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginPdf ).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginCat).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Sub Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginSubCat).'</td>
					</tr>
				</table>';
			    $content .= '<table border="1" cellspacing="0" cellpadding="5" width="100%">  
                    <thead>
                        <tr>
                            <th nowrap>'.$_Period.'</th>
                            <th nowrap>Count</th>
                        </tr>
                </thead>';
				
				foreach($_dataColumns as $_dataColumns1Val):
				    $content .= '<tbody>
                        <tr>
                          <td>' .$_dataColumns1Val[0]. '</td>
                          <td>' .$_dataColumns1Val[1]. '</td>
                     </tr>
                    <tbody>';
				
				endforeach;
				$content .= '</table>';
				$footer = '<table style="width:100%;color:#ccc;background:#17479d;padding:5px 0px;margin:0px;">
								<tr>
							<td width="30%"><span style="float:left!important;margin-left:10px;">Printed by: ' . $name . '&nbsp;' . $current_date . '</span></td>
							<td style="text-align:center;width:30%;">www.nakumatt.net</td>
							<td  width="30%">&nbsp;</td>
								</tr>
							</table>
							<h4 style="color:red;">The content is confidential and not meant to be shared in any form with any external persons / entities.</h4>
							</body>
							</html>';
				$html = $header . $content . $footer;
				$dompdf->load_html($html);
				// (Optional) Setup the paper size and orientation
				$dompdf->set_paper('A4', 'landscape');
				// Render the HTML as PDF
				$dompdf->render();
				// Output the generated PDF to Browser
				$filename = "Case Escalation" . date('Y-m-d:H:i:s') . ".pdf";
				$dompdf->stream($filename);			
			   //pdf report
			 //pdf report
			
		   }  
	   
		  
	   }
		 
		 
    }
	
	public function getExportContentEsca($_QueryFD,$_QueryTD,$_QueryPer,$_QueryMt,$_QueryORI,$_QueryBranchStore,$_QueryCat,$_QuerySubCat,$_QueryReportType,
		  $_QueryReportStatus)
	{
	    global $db, $app_list_strings;
		global $sugar_config;
		 $volumecc = $queryCase = $_Yearquery= $_ColumnsDate=$volumeDate=$_DailyLoopC=$_DateEnteredArray
		=$volumecc_grid=$_NoOfQuarters=$_GetOneQuarters=$volumecc_grid1=array();
		$_WeeklyGlobal = $_QuaterlyGlobal = $_MonthGlobal = $_DailyGlobal = $_YearlyGlobal=0;
        $condition = $condition_group=$_StartMonth=$_EndMonth= $_StartW= $_EndW=$_StartQ=$_EndQ='';
		
				if ($_QueryCat == "all") {
				$condition .= "";
				}else
				{
				$condition .= "  cases_cstm.category_c = '" . $_QueryCat . "' AND ";
				}

				if ($_QueryORI == "all")  {
				$condition .= " ";
				}else
				{
				$condition .= "  cases_cstm.origin_c = '" . $_QueryORI . "'  AND ";
				}

				if ($_QuerySubCat  == "all") {
				$condition .= " ";
				}else
				{
				$condition .= "  cases_cstm.subcategory_c = '" . $_QuerySubCat . "'  AND ";
				}

			    if ($_QueryReportStatus  == "all") {
                    $condition .= " ";
                }else
				 {
				    $condition .= "  cases.status = '" . $_QueryReportStatus . "'  AND ";
				 }
				 
				 if ($_QueryMt == "all") {
                    $condition .= "";
				 }else
				 {
				    $condition .= "  cases_cstm.member_tier_c = '" . $_QueryMt . "' AND ";
				 }
				 
				if ($_QueryBranchStore == "all" || $_QueryBranchStore == "")  {
				$condition .= " ";
				}else
				{
				$condition .= "  cases.branch_store_name = '" . $_QueryBranchStore . "'  AND ";
				}
			
            /*checking query starting*/
			$start_date = date("Y-m-d",strtotime($_QueryFD));
			$end_date = date("Y-m-d",strtotime($_QueryTD));
	   
	       if($_QueryPer == "daily"):
				$_DailyLoopCount = $this->datediff('d',$start_date ,$end_date);				 

				for($i=0;$i<=$_DailyLoopCount;$i++)
				{
				$_DailyLoopC[] =  date ("Y-m-d", strtotime("+$i day", strtotime($start_date)));
				}

				if ($start_date && $end_date) {
					$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";
				}
					
					
				
			    $query_query = "SELECT cases.id,cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, 
						LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,cases.assigned_user_id,
						cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases 
						LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c 
						LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id 
						LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id  AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition . " cases.deleted=0 and cases.caseescalate_c > 0 AND cases.status != 'Resolved'  ORDER BY cases.date_entered DESC";
	
	
				$result = $db->query($query_query);
				$total = $result->num_rows;
				if($total > 0):
				while ($row = $db->fetchByAssoc($result)) {
				$row['case_id'] = $row['cases_id'];
				$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
				$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
				$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
				$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
				$volumecc[] = $row;
				$volumeDate[] = date("Y-m-d",strtotime($row['date_entered']));
				}
				else:
				$row['emptyrecord'] = "N/A";
				// $volumecc[] = $row;
				endif;
		   
		   endif;
		  

			$i = 0;
			if(count($volumecc) > 0):
			 foreach($volumecc as $_DailyLoopCDataKey => $_DailyLoopCData)
				 { 
					
					    if($_REQUEST['category_id'] == 'all'):
						$_Catname = 'All';
						else:
						$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
						endif;
					 
						/*script for showing daily wise record*/
						$volumecc_grid1["case_number"] = $_DailyLoopCData['case_number'];
						$volumecc_grid1["date_entered"] = $_DailyLoopCData['date_entered'];
						$volumecc_grid1["category_c"] = $_DailyLoopCData['category_c'];
						$volumecc_grid1["origin_c"] = $_DailyLoopCData['origin_c'];
						$volumecc_grid1["status"] = $_DailyLoopCData['status'];
						$escalated_case[] = $volumecc_grid1;
					}
			else:
			            $volumecc_grid1["case_number"] = "";
						$volumecc_grid1["date_entered"] = "";
						$volumecc_grid1["category_c"] = "";
						$volumecc_grid1["origin_c"] = "";
						$volumecc_grid1["status"] = "";
						$escalated_case[] = $volumecc_grid1;
			endif;
			
			
	return $escalated_case;
	}
	
	
    public function checkReportPeriodEscweek($condition, $condition_group, $dateform, $dateto) {
        global $db, $app_list_strings;
        $_Wrow = array();
        $conditionW = " DATE(cases.date_entered) BETWEEN '" . $dateform . "' AND '" . $dateto . "' AND ";
        $query_query_w = "SELECT count(cases.id),cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition . $conditionW . " cases.deleted=0 and cases.caseescalate_c > 0 AND cases.status != 'Resolved' group by week(cases.date_entered)" . $condition_group . " ORDER BY cases.date_entered DESC";
        $result = $db->query($query_query_w);
        foreach ($result as $resultw) {
            $_Wrow[] = $resultw['count(cases.id)'];
        }
        return array_sum($_Wrow);
    }

    public function action_getdailydataescalation() {
        global $db, $app_list_strings;
        $condition = $conditionY = $conditiondAILY = "";
        $volumecc = array();
        if (!empty($_POST['membertier'])) {
            $condition .= " cases_cstm.member_tier_c = '" . $_POST['membertier'] . "' AND ";
        }
        if (!empty($_POST['getcategory'])) {
            $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
        }
        if (!empty($_POST['origin'])) {
            $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
        }
        if (!empty($_POST['getstatus'])) {
            $condition .= "  cases.status = '" . $_POST['getstatus'] . "' AND ";
        }

        if ($_POST['getperiod'] == 'daily'):
            $_EndDate = date("y-m-d", strtotime("+ 1 day", strtotime($_POST['daily'])));
            $conditiondAILY = " date(cases.date_entered) = '" . $_POST['daily'] . "' AND date(cases.date_entered) <= '" . date("Y-m-d", strtotime($_POST['enddate'])) . "' AND date(cases.date_entered) >= '" . date("Y-m-d", strtotime($_POST['fromdate'])) . "' AND";
        elseif ($_POST['getperiod'] == 'weekly'):
            $_EndDate = date("y-m-d", strtotime("+ 1 week", strtotime($_POST['daily'])));
            $_EndDate = date("y-m-d", strtotime("- 1 day", strtotime($_EndDate)));
            $conditiondAILY = "  DATE(cases.date_entered) BETWEEN '" . date("y-m-d", strtotime($_POST['daily'])) . "' AND '" . date("y-m-d", strtotime($_EndDate)) . "' AND date(cases.date_entered) <= '" . date("Y-m-d", strtotime($_POST['enddate'])) . "' AND date(cases.date_entered) >= '" . date("Y-m-d", strtotime($_POST['fromdate'])) . "' AND ";
        elseif ($_POST['getperiod'] == 'annual'):
            $conditiondAILY = " year(cases.date_entered) = '" . $_POST['daily'] . "' AND date(cases.date_entered) <= '" . date("Y-m-d", strtotime($_POST['enddate'])) . "' AND date(cases.date_entered) >= '" . date("Y-m-d", strtotime($_POST['fromdate'])) . "' AND";
        elseif ($_POST['getperiod'] == 'quarterly'):
            $_CheckQuarters = $this->getQuarters(date("m-d-Y", strtotime($_POST['fromdate'])), date("m-d-Y", strtotime($_POST['enddate'])));
            $_EndDate = date("Y-m-d", strtotime("+ 3 month", strtotime($_POST['daily'])));
            if ($_CheckQuarters == 'no-quarters'):
                $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" . date("y-m-d", strtotime($_POST['fromdate'])) . "' AND '" . date("y-m-d", strtotime($_POST['enddate'])) . "' AND ";
            else:
                $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" . date("y-m-d", strtotime($_POST['daily'])) . "' AND '" . $_EndDate . "' AND ";
            endif;
        elseif ($_POST['getperiod'] == 'monthly'):
            $_Dailypost = explode("-", $_POST['daily']);
            $month = $_Dailypost[0];
            $year = $_Dailypost[1];
            $_Days = cal_days_in_month(CAL_GREGORIAN, $month, $year) - 1;
            $_fromdate = $year . "-" . $month . "-" . '01';
            $_EndDate = date("Y-m-d", strtotime("+ " . $_Days . " days", strtotime($_fromdate)));
            $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" . date("y-m-d", strtotime($_fromdate)) . "' AND '" . $_EndDate . "' AND date(cases.date_entered) <= '" . date("y-m-d", strtotime($_POST['enddate'])) . "' AND date(cases.date_entered) >= '" . date("y-m-d", strtotime($_POST['fromdate'])) . "' AND";
        else:
            $_EndDate = date("y-m-d", strtotime("+ 1 day", strtotime($_POST['daily'])));
            $conditiondAILY = " date(cases.date_entered) = '" . $_POST['daily'] . "' AND date(cases.date_entered) <= '" . date("Y-m-d", strtotime($_POST['enddate'])) . "' AND date(cases.date_entered) >= '" . date("Y-m-d", strtotime($_POST['fromdate'])) . "' AND";

        endif;


        echo $query_query = "SELECT cases.id,cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
        . " where " . $condition . $conditiondAILY . " cases.deleted=0 and cases.caseescalate_c > 0 AND cases.status != 'Resolved' ORDER BY cases.date_entered DESC";

        $result = $db->query($query_query);
        $total = $result->num_rows;
        if ($total > 0):
            while ($row = $db->fetchByAssoc($result)) {
                $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                $volumecc[] = $row;
                $volumeDate[] = date("Y-m-d", strtotime($row['date_entered']));
            }
        else:
            $row['emptyrecord'] = "N/A";
        // $volumecc[] = $row;
        endif;

        echo "<td colspan='5' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
		<tr>
		<td><strong>Case ID</strong></td>
		<td><strong>Date</strong></td>
		<td><strong>Member Tier</strong></td>
		<td><strong>Case Origin</strong></td>
		<td><strong>Case Category</strong></td>
		<td><strong>Case Status</strong></td>
		<td><strong>Case Priority</strong></td>
		</tr>";
        foreach ($volumecc as $volumecc1) {
            echo "<tr>";
            echo "<td>" . $volumecc1['case_number'] . "</td>";
            echo "<td>" . $volumecc1['date_entered'] . "</td>";
            echo "<td>" . $volumecc1['member_tier_c'] . "</td>";
            echo "<td>" . $volumecc1['origin_c'] . "</td>";
            echo "<td>" . $volumecc1['category_c'] . "</td>";
            echo "<td>" . $volumecc1['status'] . "</td>";
            echo "<td>" . $volumecc1['priority'] . "</td>";
            echo "</tr>";
        }
        echo "</table></td>";
        exit();
    }

    public function action_exportDataReport() {
        global $db, $app_list_strings;
        if (!isset($_POST['chk']) OR ! is_array($_POST['chk'])) {
            //echo 'No rows selected for export';
            SugarApplication::appendErrorMessage('<span class="msg-error">No rows selected for export.</span>');
            $queryParams = array(
                'module' => 'Cases',
                'action' => 'servicereportescalation'
            );
            SugarApplication::redirect('index.php?' . http_build_query($queryParams));
        } else {
            if ($_POST['file_type'] == 'csv') { //Export CSV
                //CSV File name and Header
                $filename = "Escalated" . date('Y-m-d:H:i:s') . ".csv";
                $fp = fopen('php://output', 'w');
                $header = array('Case ID', 'Case Title', 'Category', 'Origin', 'Member Tier', 'Priority', 'Status', 'Assigned To', 'Created On');
                header('Content-type: application/csv');
                header('Content-Disposition: attachment; filename=' . $filename);
                fputcsv($fp, $header);

                //Fetch data
                $caseIDs = implode("','", $_POST['chk']);
                $condition = " cases.id IN ('" . $caseIDs . "')";
                $export_list_case = array();
                $default_query_case = "SELECT cases.case_number,cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.priority,cases.status, LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, cases.date_entered FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition . " AND cases.deleted=0 ORDER BY cases.date_entered DESC";
                $result = $db->query($default_query_case);
                while ($row = $db->fetchByAssoc($result)) {
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                    $export_list_case[] = $row;
                    fputcsv($fp, $row); //Genrate CSV
                }
                fclose($fp);
                exit;
            } elseif ($_POST['file_type'] == 'xls') { //Export XLS
                $list = array();
                $list['tableheading'] = array('Case ID', 'Case Title', 'Category', 'Origin', 'Member Tier', 'Priority', 'Status', 'Assigned To', 'Created On');
                $fichier = "CS" . date('Y-m-d:H:i:s') . ".xls";
                header("Content-Type: text/csv;charset=utf-8");
                header("Content-Disposition: attachment;filename=\"$fichier\"");
                header("Pragma: no-cache");
                header("Expires: 0");
                $fp = fopen('php://output', 'w');
                fputcsv($fp, $list['tableheading']);
                //Fetch data
                $caseIDs = implode("','", $_POST['chk']);
                $condition = " cases.id IN ('" . $caseIDs . "')";
                $default_query_case = "SELECT cases.case_number,cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.priority,cases.status, LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, cases.date_entered FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition . " AND cases.deleted=0 ORDER BY cases.date_entered DESC";
                $result = $db->query($default_query_case);
                while ($row = $db->fetchByAssoc($result)) {
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['origin_c'] = '';
                    $row['priority'] = '';
                    $data['list'] = array($row['case_number'], $row['name'], $row['category_c'], $row['origin_c'], $row['member_tier_c'], $row['priority'], $row['status'], $row['created_by_name'], $row['date_entered']);
                    fputcsv($fp, $data['list']); //Genrate XLS
                }
                fclose($fp);
                exit();
            }
        }
    }

    public function action_servicereportcasemembertier() {
        global $db, $app_list_strings,$sugar_config;
	    $Reportname = "membertier";
        $this->view = 'servicereportcasemembertier';
        $this->view_object_map['getAllCaseCategory'] = $this->getAllCaseCategory();
        $this->view_object_map['site_url'] = $sugar_config['site_url'];
		$this->view_object_map['createMonthdd'] = $this->createMonthdd();
		$this->view_object_map['creatWeeklydd'] = $this->creatWeeklydd();
		$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
		//get branch store name
		$this->view_object_map['branch_store_name'] = $this->getAllBranchName();
		$this->view_object_map['getYearDd'] = $this->creatYearsdd();
		$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
		$end_date = $_curdate;
		$start_date = date('Y-m-1', strtotime("-1 year"));
		$this->view_object_map['creatQudd'] = $this->creatQuarterdd($start_date,$end_date);
        $membertier_cases = array();
		$volumecmt = $queryCase = $_Yearquery= $_ColumnsDate=$volumeDate=$_DailyLoopC=$_DateEnteredArray
		=$volumecc_grid=$_NoOfQuarters=$_GetOneQuarters=array();
		$_WeeklyGlobal = $_QuaterlyGlobal = $_MonthGlobal = 0;
        $condition = $condition_group= $_emptyGlobal=$_AnnualGlobal = '';

        if (isset($_REQUEST['query']) == 'true') {
            if ($_REQUEST['member_tier_c'] || $_REQUEST['category_id'] || $_REQUEST['origin'] || $_REQUEST['branch_store_name'] || $_REQUEST['status'] ||
                    $_REQUEST['from_date'] || $_REQUEST['to_date'] || $_REQUEST['period']) {
                
				 if ($_REQUEST['category_id'] == "all") {
                    $condition .= "";
					$condition_group .= "";
				 }else
				 {
				     $condition .= "  cases_cstm.category_c = '" . $_REQUEST['category_id'] . "' AND ";
					$condition_group .= ",cases_cstm.category_c";
				 }
				 
			     if ($_REQUEST['member_tier_c'] == "all") {
                    $condition .= "";
					$condition_group .= "";
				 }else
				 {
				    $condition .= "  cases_cstm.member_tier_c = '" . $_REQUEST['member_tier_c'] . "' AND ";
					$condition_group .= ",cases_cstm.member_tier_c";
				 }
				 
				 
                if ($_REQUEST['origin'] == "all")  {
                    $condition .= " ";
					$condition_group .= "";
                }else
				 {
				    $condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
					$condition_group .= ",cases_cstm.origin_c";
				 }
				 
				 if ($_REQUEST['branch_store_name'] == "all" || $_REQUEST['branch_store_name'] == "")  {
                    $condition .= " ";
					$condition_group .= "";
					}else
					 {
						$condition .= "  cases.branch_store_name = '" . $_REQUEST['branch_store_name'] . "'  AND ";
						$condition_group .= ",cases.branch_store_name";
					 }
					 
					 
				if ($_REQUEST['sub_category_id']  == "all") {
                    $condition .= " ";
					$condition_group .= "";
                }else
				 {
				    $condition .= "  cases_cstm.subcategory_c = '" . $_REQUEST['sub_category_id'] . "'  AND ";
					$condition_group .= ",cases_cstm.subcategory_c";
				 }
				 
				 if ($_REQUEST['status']  == "all") {
                    $condition .= " ";
					$condition_group .= "";
                }else
				 {
				    $condition .= "  cases.status = '" . $_REQUEST['status'] . "'  AND ";
					$condition_group .= ",cases.status";
				 }
				 
				 if(!empty($_POST['periodmonthsdd'])):
				  $_StartMonth = $_POST['periodmonthsdd'];
				endif;
				
				if(!empty($_POST['periodmonthedd'])):
				  $_EndMonth = $_POST['periodmonthedd'];
				endif;
				
				if(!empty($_POST['periodquasdd'])):
				  $_StartQ = $_POST['periodquasdd'];
				endif;
				
				if(!empty($_POST['periodquaedd'])):
				  $_EndQ = $_POST['periodquaedd'];
				endif;
				
				
				/*checking query starting*/
		     	$start_date = date("Y-m-d",strtotime($_REQUEST['from_date']));
		    	$end_date = date("Y-m-d",strtotime($_REQUEST['to_date']));
			
				$start_date = $_REQUEST['from_date']; //fromdate for post
				$this->view_object_map['getFromDate'] = $start_date;
				$end_date = $_REQUEST['to_date']; //todate for post
				$this->view_object_map['getToDate'] = $end_date;
				$_Periodpost = $_REQUEST['period']; //period for post
				
				$this->view_object_map['getPeriod'] = $_Periodpost;
				$_Oroginpost = $_REQUEST['origin']; //origin for post
				$this->view_object_map['getOrigin'] = $_Oroginpost;
				$_Categorypost = $_REQUEST['category_id']; //categoryid for post
				$this->view_object_map['getCategory'] = $_Categorypost;
				$_Statuspost = $_REQUEST['status']; //status for post
				$this->view_object_map['getStatus'] = $_Statuspost;
				
				$_Membertierpost = $_REQUEST['member_tier_c']; //member tier for post
				$this->view_object_map['member_tier_c'] = $_Membertierpost;
				
				$_Subcatgorypost = $_REQUEST['sub_category_id']; //sucategoryid for post
			    $this->view_object_map['getSubCategory'] = $_Subcatgorypost;
				
				$this->view_object_map['getStartmonth'] =  $_StartMonth; // selected month start
				$this->view_object_map['getEndmonth'] = $_EndMonth ; // selected month end
				$this->view_object_map['periodquasdd'] =  $_StartQ; // selected month start
				$this->view_object_map['periodquaedd'] = $_EndQ ; // selected month end
			    $this->view_object_map['sub_category_id'] = $_POST['sub_category_id']; // selected subcat
				
				$_BranchStore = $_REQUEST['branch_store_name']; //branch_store_name for post
				$this->view_object_map['getBranchName'] = $_BranchStore;
				$this->view_object_map['getFromyear'] = $_POST['getYearsDd']; // selected from year
				$this->view_object_map['getToyear'] = $_POST['getYeareDd']; // selected  to year
				/*quater logic start*/
				$_Start_Q = explode("_",$_StartQ);
				$_OpenQ = $_Start_Q[2];
				$_End_Q = explode("_",$_EndQ);
				$_EndQ = $_End_Q[2];
				/* end */
				
			    /*period logic starts from here*/
				if($_REQUEST['period'] == "monthly"):
				$_MonthGlobal = 1;
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
				$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
				$start_date  = $_Year."-".$_Month."-"."1";  //start date
				$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
				$_MonthLoopCount = $this->datediff('m',date("y-m-d",strtotime($start_date )),date("y-m-d",strtotime($end_date)));				 
				/*month logic end */
				for($i=0;$i<=$_MonthLoopCount+1;$i++)
				{
				$_DailyLoopC[] =  date ("M-Y", strtotime("+ $i month", strtotime($start_date)));
				}
				$default_query_case = "SELECT count(cases.id),cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, 
				                      LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,
									  cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT 
									  JOIN users jt0 ON cases.assigned_user_id=jt0.id   LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id AND jt0.deleted=0 AND jt0.deleted=0"
                                      . " where " . $condition . " cases.deleted=0 group by month(cases.date_entered)".$condition_group." ORDER BY cases.date_entered DESC";

				$result = $db->query($default_query_case);
				$total = $result->num_rows;
				if($total > 0):
				while ($row = $db->fetchByAssoc($result)) {
				$row['date_entered'] = date("M-Y",strtotime($row['date_entered']));
				$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
				$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
				$volumecmt[] = $row;
				}
				else:
				$row['emptyrecord'] = "N/A";
				// $volumecc[] = $row;
				endif;
			  elseif($_REQUEST['period'] == "quarterly"):

			    $_QuaterlyGlobal =1;
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
				$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
			    $start_date  = $_Year."-".$_Month."-"."1";  //start date
				$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
				$_CurrentYear = date("Y"); // current year
				$_PreviousYears = date("Y")-1; //previous year 
				
				
				$from = $_POST['getYearsDd'];
				$to = $_POST['getYeareDd'];
				
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				
				$this->view_object_map['creatQudd'] = $this->creatQuarterdd($start_date,$end_date);
				//echo "<pre>";
				//print_r($this->view_object_map['creatQudd'] );
                $_Startq = explode("_",$_StartQ); 
				$_Endq = explode("_",$_EndQ); 
				$_GetQuarters = $this->creatQuarterdd($start_date,$end_date);
				foreach($_GetQuarters as $_GetQuarters1Key=>$_GetQuarters1)
				{
				
				$_Startq = explode("_",$_GetQuarters1Key); 
				$_DailyLoopC[$_GetQuarters1Key] = $_GetQuarters1;
				$_GetPeroid[$_GetQuarters1Key."_".$_GetQuarters1] = $this->checkReportPeriodQuarter($condition,$condition_group,$_Startq[0],$_Startq[1],"membertier");

                }	
					
				$default_query_case = "SELECT count(cases.id),cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, 
				                      LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,
									  cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT 
									  JOIN users jt0 ON cases.assigned_user_id=jt0.id  LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id AND jt0.deleted=0 AND jt0.deleted=0"
                                      . " where " . $condition . " cases.deleted=0 group by QUARTER(cases.date_entered)".$condition_group." ORDER BY cases.date_entered DESC";

				$result = $db->query($default_query_case);
				$total = $result->num_rows;
				if($total > 0):
				while ($row = $db->fetchByAssoc($result)) {
				$row['date_entered'] = date("m-Y",strtotime($row['date_entered']));
				$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
				$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
				$volumecmt[] = $row;
				}
				else:
				$row['emptyrecord'] = "N/A";
				// $volumecc[] = $row;
				endif;				
			  
			  elseif($_REQUEST['period'] == "annual"):
			    $_AnnualGlobal = 1;
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
				$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
			    $start_date  = $_Year."-".$_Month."-"."1";  //start date
				$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
				$_CurrentYear = date("Y"); // current year
				$_PreviousYears = date("Y")-1; //previous year 
				if ($_POST['getYearsDd'] != $_POST['getYeareDd']) {
					$_Year =  array($_PreviousYears,$_CurrentYear);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}else{
				    $_Year =  array($_POST['getYearsDd']);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}
				
				$from = $_POST['getYearsDd'];
				$to = $_POST['getYeareDd'];
				
				if ($_POST['getYearsDd'] != $_POST['getYeareDd']) {
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				} else {
				$start_date = date('Y-m-d', strtotime("$from-01-01"));
				$end_date = date('Y-m-d', strtotime("$from-12-31"));
				}
				
			$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d", strtotime($start_date)) . "' AND '" . date("y-m-d", strtotime($end_date)) . "' AND ";
						
							
			  $default_query_case = "SELECT count(cases.id),cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, 
				                      LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,
									  cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases 
									  LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c 
									  LEFT  JOIN users jt0 ON cases.assigned_user_id=jt0.id 
									  LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id 
									  AND jt0.deleted=0 AND jt0.deleted=0"
                                      . " where " . $condition . " cases.deleted=0 group by year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered DESC";

				$result = $db->query($default_query_case);
				$total = $result->num_rows;
				if($total > 0):
				while ($row = $db->fetchByAssoc($result)) {
				$row['date_entered'] = date("Y",strtotime($row['date_entered']));
				$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
				$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
				$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
				$volumecmt[] = $row;
				}
				else:
				$row['emptyrecord'] = "N/A";
				// $volumecc[] = $row;
				endif;		
			  else:
			   $_emptyGlobal = 1;
			   $_DailyLoopCount = $this->datediff('d',date("y-m-d",strtotime($_REQUEST['from_date'])),date("y-m-d",strtotime($_REQUEST['to_date'])));				 

			    for($i=0;$i<=$_DailyLoopCount;$i++)
				{
				  $_DailyLoopC[] =  date ("Y-m-d", strtotime("+$i day", strtotime($start_date)));
				}
				
			    $default_query_case = "SELECT count(cases.id),cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, 
				                      LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,
									  cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT 
									  JOIN users jt0 ON cases.assigned_user_id=jt0.id LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id   AND jt0.deleted=0 AND jt0.deleted=0"
                                      . " where " . $condition . " cases.deleted=0 group by year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered DESC";

				$result = $db->query($default_query_case);
				$total = $result->num_rows;
				if($total > 0):
				while ($row = $db->fetchByAssoc($result)) {
				$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
				$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
				$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
				$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
				$volumecmt[] = $row;
				}
				else:
				$row['emptyrecord'] = "N/A";
				// $volumecc[] = $row;
				endif;	

              endif;
			 /*period logic end here*/
            }else{
                $default_query_case = "SELECT cases.id,cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where  cases.deleted=0 ORDER BY cases.date_entered DESC";
                $result = $db->query($default_query_case);
                $total = $result->num_rows;
                while ($row = $db->fetchByAssoc($result)) {
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                  //  $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                    $membertier_cases[] = $row;
                }
            }
			
			if($_POST['period'] == 'monthly'){//for month start

			     $_MonthStartArray = array_keys($_DailyLoopC,$_StartMonth);
				 $_MonthEndArray =  array_keys($_DailyLoopC,$_EndMonth);
				 $_Totvalue = $_MonthEndArray[0]-$_MonthStartArray[0];
			     $_DailyLoopC = array_slice($_DailyLoopC,$_MonthStartArray[0],$_Totvalue+1);
				 //for month end
				}
				
				if($_WeeklyGlobal == 1)
				{
					if(count($volumecmt)):
						 foreach($volumecmt as $volumeccData)
						 {
							$_DateEntered1Array[$volumeccData['date_entered']] = $volumeccData['date_entered']."_".$volumeccData['category_c']."_".$volumeccData['origin_c']."_".$volumeccData['count(cases.id)'];
						 }
					endif;
				}
				else{
					if(count($volumecmt)):
						 foreach($volumecmt as $volumeccData)
						 {
							$_DateEnteredArray[] = $volumeccData['date_entered'];
							$_DateEntered1Array[$volumeccData['date_entered']] = array($volumeccData['date_entered'],$volumeccData['category_c'],$volumeccData['origin_c'],$volumeccData['count(cases.id)']);
						 }
					endif;
				}
			if(!empty($_DateEntered1Array)):	
			 foreach($_DateEntered1Array as $_DateEntered1Array1)
			 {
			  $_yearRecord[]  = $_DateEntered1Array1[3];
			 }
			 endif;
				 
		   $i = 1;	
		   
		  // echo "<pre>";
		   //print_r($_GetPeroid);die;
		   if(count($_DailyLoopC) > 0):
		   
		   if($_QuaterlyGlobal ==1):
		   $temp2 = array();
				//for($p = $_StartQ; $p <= $_EndQ; $p++){
				//$temp2[] = $p;
				//}
			$_OpenQua = array();
            for($_OpenQ;$_OpenQ<=$_EndQ;$_OpenQ++){
			  $_OpenQua[] = $_OpenQ;
				}
		    foreach($_GetPeroid as $_GetPeroidKey => $_GetPeroidData)
						{ 
					   $_GetPeroidDisaply = $_GetPeroidKey;
					   $_GetPeroidDisaply =  explode("_",$_GetPeroidDisaply);
					  // echo $_GetPeroidDisaply[2];
					// if(in_array($_GetPeroidDisaply[2],$_OpenQua)):
					//echo  $_GetPeroidDisaply[2]  ;
					
					// endif;
				    //if($_POST['period'] == 'quarterly'):
					 //if(!in_array($i,$temp2)){
					 //$i++;
						//continue;
						
					// }
					// endif;
					$_Qendate = date ("Y-m-d", strtotime("+ 2 month", strtotime($_GetPeroidKey)));
					$_GetPeroidSd = date("M y",strtotime($_GetPeroidKey));
					$_GetPeroided = date("M y",strtotime($_Qendate));
					if($_REQUEST['category_id'] == 'all'):
					$_Catname = 'All';
					else:
					$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
					endif;
					 
					  if(in_array($_GetPeroidDisaply[2],$_OpenQua)):
					   $_GetPeroidKey = explode("_",$_GetPeroidKey);
					      if($_GetPeroidData==0):
							$membertier_cases[] = "<tr><td>".$_GetPeroidKey[3]."</td>
							 <td>".ucfirst($_REQUEST['member_tier_c'])."</td>
							 <td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>
							 <td>".$_Catname."</td>
							 <td>".ucfirst($_POST['status'])."</td>
							 <td>0</td>
							</tr>";
							else:
							$membertier_cases[] = "<tr><td>".$_GetPeroidKey[3]."</td>
							<td>".ucfirst($_REQUEST['member_tier_c'])."</td>
							<td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>
							<td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>
							<td>".ucfirst($_POST['status'])."</td>
							<td onclick='checkclick(this.title)' class=counter id=Dailydata_".$_GetPeroidKey." title=daily_".$_GetPeroidKey[0]."_".$_GetPeroidKey[1].">".$_GetPeroidData."</td>
							</tr>";
							endif;
							
							$membertier_cases[] = "</tr>";
							$membertier_cases[] ="<tr class=dailyresulthide id=dailyresult_".$_GetPeroidKey[0]."_".$_GetPeroidKey[1]." style=display:none>
							<td colspan='4' class='parent-TD'>
							</td></tr>";
						endif;	
					$i++;	}
		   else:
		   
		    foreach($_DailyLoopC as $_DailyLoopCDataKey => $_DailyLoopCData)
					 {
					  if($_MonthGlobal ==1):
					  if($_REQUEST['category_id'] == 'all'):
						$_Catname = 'All';
					 else:
						$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
					 endif;
					 
							$membertier_cases[] = "<tr>";
							if (in_array($_DailyLoopCData,$_DateEnteredArray))
							{
							//$key = array_search($_DailyLoopCData, $_DateEnteredArray);
							$membertier_cases[] = "<td>".$_DateEntered1Array[$_DailyLoopCData][0]."</td>";
							$membertier_cases[] = "<td>".ucfirst($_REQUEST['member_tier_c'])."</td>";
							$membertier_cases[] = "<td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>";
							$membertier_cases[] = "<td>".$_Catname	."</td>";
							$membertier_cases[] = "<td>".ucfirst($_POST['status'])."</td>";	
							$membertier_cases[] = "<td class=counter onclick='checkclick(this.title)' id=Dailydata_".$_DateEntered1Array[$_DailyLoopCData][0]." title=daily_".$_DateEntered1Array[$_DailyLoopCData][0].">".$_DateEntered1Array[$_DailyLoopCData][3]."</td>";
							}
							else
							{
							$membertier_cases[] =  "<td>".$_DailyLoopCData."</td>
							<td>".ucfirst($_REQUEST['member_tier_c'])."</td>
							<td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>
							<td>".$_Catname ."</td>
							<td>".ucfirst($_POST['status']) ."</td>
							<td colspan=4>0</td>";
							}
							$membertier_cases[] = "</tr>";
							$membertier_cases[] ="<tr class=dailyresulthide id=dailyresult_".$_DailyLoopCData." style=display:none>
							<td colspan='4' class='parent-TD'>
							</td></tr>";
						
                    elseif($_AnnualGlobal ==1):
	
						if($_REQUEST['category_id'] == 'all'):
						$_Catname = 'All';
						else:
						$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
						endif;
						$membertier_cases[] = "<tr>";
					   
						if (in_array($_DailyLoopCData,$_DateEnteredArray))
						{
						$membertier_cases[] = "<td>".$_DailyLoopCDataKey."</td>";
						$membertier_cases[] = "<td>".ucfirst($_POST['member_tier_c'])."</td>";
						$membertier_cases[] = "<td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>";
						$membertier_cases[] = "<td>".$_Catname."</td>";
						$membertier_cases[] = "<td>".ucfirst($_POST['status'])."</td>";
						$membertier_cases[] = "<td class=counter onclick='checkclick(this.title)' id=Dailydata_".$_DateEntered1Array[$_DailyLoopCData][0]." title=daily_".$_DailyLoopCDataKey.">".array_sum( $_yearRecord)."</td>";
						}
						else{
					    $membertier_cases[] = "<td>".$_DailyLoopCDataKey."</td>
						<td>".ucfirst($_POST['member_tier_c'])."</td>;
						<td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>
						<td>".$_Catname."</td>
						<td>".ucfirst($_POST['status'])."</td>
						<td>0</td>";

						}
						$membertier_cases[] = "</tr>";

						$membertier_cases[] ="<tr class=dailyresulthide id=dailyresult_".$_DailyLoopCData." style=display:none>
						<td colspan='5' class='parent-TD'>
						</td></tr>"; 
					  $i++;      
                    endif;					  
					 }
			  endif;
			    
			endif;		 
		  }
		//echo "<pre>";
		//print_r($membertier_cases);
        if (isset($total) > 0) {
            $this->view_object_map['total_cases'] = $total;
        } else {
            $this->view_object_map['total_cases'] = 0;
        }
        $this->view_object_map['membertier_cases'] = $membertier_cases;
    }
    
    public function getExportContentCmt($_QueryPer,$_QueryMt,$_QueryCat,$_QueryORI,$_QueryReportBranchStore,$_QuerySubCat,$_QueryStatus,$_QueryReportType,$_QueryReportMonthStart,$_QueryReportMonthEnd
,$_Qstart,$_Qend,$_Qfromyear,$_Qtoyear)
	{  
	
        global $db, $app_list_strings;
		global $sugar_config;
		
        $volumecc = $queryCase = $_Yearquery= $_ColumnsDate=$volumeDate=$_DailyLoopC=$_DateEnteredArray
		=$volumecc_grid=$_NoOfQuarters=$_GetOneQuarters=$volumecc_grid1=$volumecmt=array();
		$_WeeklyGlobal = $_QuaterlyGlobal = $_MonthGlobal = $_DailyGlobal = $_YearlyGlobal;
        $condition = $condition_group='';
           if ($_Qfromyear && $_Qtoyear) {
		    $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
			$from = $_Qfromyear;
			$to = $_Qtoyear;		
			if ($_Qfromyear != $_Qtoyear) {
			$end_date = $_curdate;
			$start_date = date('Y-m-1', strtotime("-1 year"));
			} else {
			$start_date = date('Y-m-d', strtotime("$from-01-01"));
			$end_date = date('Y-m-d', strtotime("$from-12-31"));
			}
			$condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($start_date)) . "' AND '" . date("Y-m-d", strtotime($end_date)) . "' AND ";
			}else
		{
			if ($_QueryFD && $_QueryTD) {
			$condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($_QueryFD)) . "' AND '" . date("Y-m-d", strtotime($_QueryTD)) . "' AND ";
			}
		}
		
		
	
				if ($_QueryCat == "all") {
				$condition .= "";
				$condition_group .= "";
				}else
				{
				$condition .= "  cases_cstm.category_c = '" . $_QueryCat . "' AND ";
				$condition_group .= ",cases_cstm.category_c";
				}

				if ($_QueryORI == "all")  {
				$condition .= " ";
				$condition_group .= "";
				}else
				{
				$condition .= "  cases_cstm.origin_c = '" . $_QueryORI . "'  AND ";
				$condition_group .= ",cases_cstm.origin_c";
				}
				
				if ($_QueryReportBranchStore == "all" || $_QueryReportBranchStore == "") {
					$condition .= "";
				}else
				{
					$condition .= "  cases.branch_store_name = '" . $_QueryReportBranchStore . "' AND ";
				}
				

				if ($_QuerySubCat  == "all") {
				$condition .= " ";
				$condition_group .= "";
				}else
				{
				$condition .= "  cases_cstm.subcategory_c = '" . $_QuerySubCat . "'  AND ";
				$condition_group .= ",cases_cstm.subcategory_c";
				}

				if ($_QueryMt  == "all") {
				$condition .= " ";
				$condition_group .= "";
				}else
				{
				$condition .= "  cases_cstm.member_tier_c = '" . $_QueryMt . "'  AND ";
				$condition_group .= ",cases_cstm.member_tier_c";
				}
			 
			 
			    if(!empty($_QueryReportMonthStart)):
				   $_StartMonth = $_QueryReportMonthStart;
				endif;
				
				if(!empty($_QueryReportMonthEnd)):
				   $_EndMonth = $_QueryReportMonthEnd;
				endif;
				
			
		
				
				if(!empty($_Qstart)):
				  $_StartQ = $_Qstart;
				  $_StartQ = explode("_",$_Qastart);
				  $_StartQ = $_StartQ[0];
				endif;
				
				if(!empty($_Qend)):
				  $_EndQ = $_Qend;
				  $_EndQ = explode("_",$_EndQ);
				  $_EndQ = $_EndQ[1];
				endif;
				
      
               
				
			    /*period logic starts from here*/
				if($_QueryPer == "monthly"):
				$_MonthGlobal = 1;
				$_StartMonth =  date('Y-m-d',strtotime($_StartMonth));
				$_EndMonth = date('Y-m-d',strtotime($_EndMonth ));
				$a_date = $_EndMonth; 
				$date = new DateTime($a_date);
				$date->modify('last day of this month');
				$_EndMonth = $date->format('Y-m-d');
						
                $_MonthLoopCount = $this->datediff('m',date("y-m-d",strtotime($_StartMonth)),date("y-m-d",strtotime($_EndMonth)));				 
				for($i=0;$i<=$_MonthLoopCount+1;$i++)
				{
				$_DailyLoopC[] =  date ("m-Y", strtotime("+ $i month", strtotime($start_date)));
				}
				if ($_QueryFD && $_QueryTD) {
					$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_StartMonth)) . "' AND '" . date("y-m-d",strtotime($_EndMonth)) . "' AND ";
				}
			   $default_query_case = "SELECT cases.id,cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, 
				                      LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,
									  cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT 
									  JOIN users jt0 ON cases.assigned_user_id=jt0.id   LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id AND jt0.deleted=0 AND jt0.deleted=0"
                                      . " where " . $condition . " cases.deleted=0  ORDER BY cases.date_entered DESC";
									  
				$result = $db->query($default_query_case);
				$total = $result->num_rows;
				if($total > 0):
				while ($row = $db->fetchByAssoc($result)) {
				$row['date_entered'] = date("d-m-Y",strtotime($row['date_entered']));
				$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
				$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
				$volumecmt[] = $row;
				}
				else:
				$row['emptyrecord'] = "N/A";
				// $volumecc[] = $row;
				endif;
			  elseif($_QueryPer == "quarterly"):
			    $_QuaterlyGlobal =1;
                
			     $condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_StartQ)) . "' AND '" . date("y-m-d",strtotime($_EndQ)) . "' AND ";
				 
               $default_query_case = "SELECT cases.id,cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, 
				                      LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,
									  cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT 
									  JOIN users jt0 ON cases.assigned_user_id=jt0.id  LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id AND jt0.deleted=0 AND jt0.deleted=0"
                                      . " where " . $condition . " cases.deleted=0  ORDER BY cases.date_entered DESC";
				$result = $db->query($default_query_case);
				$total = $result->num_rows;
				if($total > 0):
				while ($row = $db->fetchByAssoc($result)) {
				$row['date_entered'] = date("m-Y",strtotime($row['date_entered']));
				$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
				$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
				$volumecmt[] = $row;
				}
				else:
				$row['emptyrecord'] = "N/A";
				// $volumecc[] = $row;
				endif;				
			  
			  elseif($_QueryPer == "annual"):
			    $_AnnualGlobal = 1;
				$_YearlyGlobal = 1;
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
				$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
			    $start_date  = $_Year."-".$_Month."-"."1";  //start date
				$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
				$_CurrentYear = date("Y"); // current year
				$_PreviousYears = date("Y")-1; //previous year 
				if ($_POST['getYearsDd'] != $_POST['getYeareDd']) {
					$_Year =  array($_PreviousYears,$_CurrentYear);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}else{
				    $_Year =  array($_POST['getYearsDd']);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}
				
				$from = $_POST['getYearsDd'];
				$to = $_POST['getYeareDd'];
				
				if ($_POST['getYearsDd'] != $_POST['getYeareDd']) {
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				} else {
				$start_date = date('Y-m-d', strtotime("$from-01-01"));
				$end_date = date('Y-m-d', strtotime("$from-12-31"));
				}
	
							
			    $default_query_case = "SELECT cases.id,cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, 
				                      LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,
									  cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT 
									  JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                                      . " where " . $condition . " cases.deleted=0  ORDER BY cases.date_entered DESC";
				$result = $db->query($default_query_case);
				$total = $result->num_rows;
				if($total > 0):
				while ($row = $db->fetchByAssoc($result)) {
				$row['date_entered'] = date("Y",strtotime($row['date_entered']));
				$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
				$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
				$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
				$volumecmt[] = $row;
				}
				else:
				$row['emptyrecord'] = "N/A";
				// $volumecc[] = $row;
				endif;		
			   	
              endif;
			 /*period logic end here*/
            
			
			if(count($volumecmt)):
						 foreach($volumecmt as $volumeccData)
						 {
							$_DateEnteredArray[] = $volumeccData['date_entered'];
							$_DateEntered1Array[$volumeccData['date_entered']] = array($volumeccData['date_entered'],$volumeccData['category_c'],$volumeccData['origin_c'],$volumeccData['count(cases.id)']);
						 }
			endif;
				
		   $i = 0;	
		   if(count($volumecmt) > 0):
				foreach($volumecmt as $volumecc1):
				    $volumecc_grid1["case_number"] = $volumecc1['case_number'];
					$volumecc_grid1["date_entered"] = $volumecc1['date_entered'];
					$volumecc_grid1["member_tier_c"] = $volumecc1['member_tier_c'];
					$volumecc_grid1["origin_c"] = $volumecc1['origin_c'];
					$volumecc_grid1["category_c"] = $volumecc1['category_c'];
					$volumecc_grid1["status"] = $volumecc1['status'];
					$membertier_cases[] = $volumecc_grid1;
					$i++;
				endforeach; 
			else:
			        $volumecc_grid1["case_number"] =0;
					$volumecc_grid1["date_entered"] = 0;
					$volumecc_grid1["member_tier_c"] = $_POST['getMemberTier'];
					$volumecc_grid1["origin_c"] =$this->getCaseOriginName($_POST['queryorigin']);
					$volumecc_grid1["category_c"] = $_POST['querycategory'];
					$volumecc_grid1["status"] = $_POST['queryStatus'];
					$membertier_cases[] = $volumecc_grid1;
		   endif;
		   
			
	   return $membertier_cases;
	}
	
    public function action_exportvolumecmt() {
	
        global $db, $app_list_strings;
		$condition =$_QueryFD =$_QueryTD =$_MemberTier=$_QueryPer= $_QueryORI = $_QueryCat =$_QueryReportType= $_QuerySubCat =$start_date=$end_date= $_QueryReportMonthStart=$_QueryReportMonthEnd=$_QueryStatus=$_QueryReportBranchStore="";


		
          if(isset($_REQUEST['queryPeriod']))
          {
		  $_QueryPer =  $_REQUEST['queryPeriod'];
          }
          
		   if(isset($_REQUEST['getMemberTier']))
          {
		  $_MemberTier =  $_REQUEST['getMemberTier'];
          }
		  
          if(isset($_REQUEST['queryorigin']))
          {
		  $_QueryORI=  $_REQUEST['queryorigin'];
          }
		  
		  if(isset($_POST['queryBranchStore']))
		{
		$_QueryReportBranchStore =  $_POST['queryBranchStore'];
		} 

          if(isset($_REQUEST['querycategory']))
          {
		  $_QueryCat =  $_REQUEST['querycategory'];
          }
		  
		  if(isset($_REQUEST['querysubcategory']))
          {
		  $_QuerySubCat =  $_REQUEST['querysubcategory'];
          }
          
		  if(isset($_POST['report_type']))
          {
		  $_QueryReportType =  $_POST['report_type'];
          }
          
		  if(isset($_POST['querySmonth']))
		 {
		   $_QueryReportMonthStart =  $_POST['querySmonth'];
		 }

		 if(isset($_POST['queryEmonth']))
		 {
		  $_QueryReportMonthEnd =  $_POST['queryEmonth'];
		} 		  
	
		 if(isset($_POST['queryeQs']))
		 {
		  $_Qstart =  $_POST['queryeQs'];
		} 
		 if(isset($_POST['queryeQe']))
		 {
		  $_Qend =  $_POST['queryeQe'];
		} 
		
		if(isset($_POST['getFromyear']))
		 {
		  $_Qfromyear =  $_POST['getFromyear'];
		} 
		if(isset($_POST['getToyear']))
		 {
		  $_Qtoyear =  $_POST['getToyear'];
		} 
		
		 $_record = ""; 
		    if( $_QueryReportType == "detailsreport"){ // summery report
			
		  $_dataColumns = $this->getExportContentCmt($_QueryPer,$_MemberTier,$_QueryCat,$_QueryORI,$_QueryReportBranchStore,$_QuerySubCat,$_QueryStatus,$_QueryReportType,$_QueryReportMonthStart,$_QueryReportMonthEnd
		  ,$_Qstart,$_Qend,$_Qfromyear,$_Qtoyear);  //calling function to get export data
		  if(empty($_dataColumns)):
		  $_record =0;
		  else:
		  $_record = 1;
		  endif;
		  // echo "<pre>";
		  //print_r( $_dataColumns);die;

			  if ($_POST['file_type'] == 'csv') { //Export CSV
                //CSV File name and Header
                $filename = "volumemembertier_" . date('Y-m-d:H:i:s') . ".csv";
                $fp = fopen('php://output', 'w');
                $header = array('Case ID','Date','Member Tier','Case Origin', 'Case Category','Case Status');
                header('Content-type: application/csv');
                header('Content-Disposition: attachment; filename=' . $filename);
                fputcsv($fp, $header);
				$condition ="";
				$export_list_case = array();
				foreach($_dataColumns as $_dataColumns1Val):
				$row['case_number'] = $_dataColumns1Val['case_number'];
				$row['date_entered'] = $_dataColumns1Val['date_entered'];
				$row['member_tier_c']   = $_dataColumns1Val['member_tier_c'];
				$row['origin_c'] = $_dataColumns1Val['origin_c'];
				$row['category_c'] = $_dataColumns1Val['category_c'];
				$row['status'] = $_dataColumns1Val['status'];
				$export_list_case[] = $row;
			    fputcsv($fp, $row); //Genrate CSV
				endforeach;
				fclose($fp);
                exit;
            } elseif ($_POST['file_type'] == 'xls') { //Export XLS
                $list = array();
                $list['tableheading'] = array('Case Id','Date','Member Tier', 'Case Origin', 'Case Category', 'Case Status');
                $fichier = "volumemembertier_" . date('Y-m-d:H:i:s') . ".xls";
                header("Content-Type: text/csv;charset=utf-8");
                header("Content-Disposition: attachment;filename=\"$fichier\"");
                header("Pragma: no-cache");
                header("Expires: 0");
                $fp = fopen('php://output', 'w');
                fputcsv($fp, $list['tableheading']);
                //Fetch data
                foreach($_dataColumns as $_dataColumns1Val):
				$row['case_number'] = $_dataColumns1Val['case_number'];
				$row['date_entered'] = $_dataColumns1Val['date_entered'];
				$row['member_tier_c']   = $_dataColumns1Val['member_tier_c'];
				$row['origin_c'] = $_dataColumns1Val['origin_c'];
				$row['category_c'] = $_dataColumns1Val['category_c'];
				$row['status'] = $_dataColumns1Val['status'];
				$data['list'] = $row;
				//$export_list_case[] = $row;
			    fputcsv($fp, $data['list']); //Genrate CSV
				endforeach;
				fclose($fp);
                exit();
            }elseif($_POST['file_type'] == 'pdf')
			{
               require_once 'include/dompdf/dompdf_config.inc.php';
			   global $current_user;
			   $name = $current_user->first_name . '&nbsp;' . $current_user->last_name;
			   $current_date = date('d/m/Y  h:i A');
			   $dompdf = new Dompdf();
			   //echo '<pre>';
			   //print_r($_dataColumns);
			  // die;
			  
			  if($_QueryPer  == 'monthly'):
			   $start_date =$_QueryReportMonthStart;
			   $end_date =$_QueryReportMonthEnd;
			  elseif($_QueryPer  == 'quarterly'):
			   $start_date = "Quarter ".$this->Quarterlabelreportpdf($_Qstart);
			   $end_date = "Quarter ".$this->Quarterlabelreportpdf($_Qend);
			  else:
			      if(date("m") <= 06){
						$_CurrentYear = date("Y"); // current year
						$_NextYears =  date("Y")-1; //previous year 
						
						$start_date =  date($_NextYears.'-07-01'); //common from date
						$end_date =  date($_CurrentYear.'-06-30'); 

						}
						else{
						$_CurrentYear =  date("Y"); // current year
						$_NextYears  =  date("Y") + 1;  // post year
						$start_date =  date($_CurrentYear.'-07-01'); //common from date
						$end_date =  date($_NextYears.'-06-30'); 
						}
				endif;
			   $_CaseOriginPdf = $_CaseOriginCat = "";
			   if($_QueryORI == 'all'):
			    $_CaseOriginPdf = 'All';
			   else:
			    $_CaseOriginPdf = $this->getCaseOriginName($_QueryORI);
			   endif;
			   
			   if($_QueryCat == 'all'):
			    $_CaseOriginCat = 'All';
			   else:
			    $_CaseOriginCat = $this->getCaseCategoryName($_QueryCat);
			   endif;
			   
			   if($_QuerySubCat == 'all'):
			    $_CaseOriginSubCat = 'All';
			   else:
			    $_CaseOriginSubCat = $this->getCaseSubCategoryName($_QuerySubCat);
			   endif;
			   
			   if($_POST['queryStatus'] == 'all'):
			    $_CaseStatus = 'All';
			   else:
			    $_CaseStatus = $_POST['queryStatus'];
			   endif;
			    $_CaseBranchStorePdf = "";
				if($_QueryReportBranchStore == 'all'):
				$_CaseBranchStorePdf = 'All';
				else:
				$_CaseBranchStorePdf = $_QueryReportBranchStore;
				endif;
			   $header = '<html>
            <body>
                <div style="width:100%;color:#fff;background:#17479d;padding:5px 0px;margin:0px;text-align:center;">
                    <img src="custom/include/images/logo.png" style="padding: 7px;position: absolute;left: 10px;"><h2>Volume of Cases by Member Tier </h2>
                </div>
				<br />
				<table style="width:450px; margin:0 auto; text-align:left;">
				    <tr>
						<td style="width="20%"><b>From  - </b></td>
						<td style="width="10%">'.$start_date.'</td>
						<td style="width="20%"><b>To  - </b></td>
						<td style="width="10%">'.$end_date.'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Period  - </b></td>
						<td style="width="50%">'.ucfirst($_QueryPer).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Origin  - </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginPdf).'</td>
					</tr>
					';
					 if($_QueryReportBranchStore == 'all'):
						 $header .= '<tr>
						<td style="width="50%"><b>Branch Store - </b></td>
						<td style="width="50%">All</td>
					</tr>';
						elseif($_QueryReportBranchStore == ''):
							 $header .= ''; 
					   else:
						 $header .= '<tr>
						<td style="width="50%"><b>Branch Store  - </b></td>
						<td style="width="50%">'.ucfirst($_QueryReportBranchStore).'</td>
					</tr>'; 
					   endif;
					   
					  $header .= ' 
					<tr>
						<td style="width="50%"><b>Case Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginSubCat).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Sub Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginCat).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Status  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseStatus).'</td>
					</tr>
				</table>';
				
			    $content .= '<table border="1" cellspacing="0" cellpadding="5" width="100%">  
                    <thead>
                        <tr>
                            <th nowrap>Case Id</th>
                            <th nowrap>Date</th>
							<th nowrap>Member Tier</th>
                            <th nowrap>Case Origin</th> 
                            <th nowrap>Case Category</th>  
							<th nowrap>Case Status</th> 
                        </tr>
                </thead>';
				
				foreach($_dataColumns as $_dataColumns1Val):
				    $content .= '<tbody>
                        <tr>
                          <td>' . $_dataColumns1Val["case_number"] . '</td>
                          <td>' . $_dataColumns1Val["date_entered"] . '</td>
						  <td>' . $_dataColumns1Val["member_tier_c"] . '</td>
                          <td>' . $_dataColumns1Val["origin_c"] . '</td>
                          <td>' . $_dataColumns1Val["category_c"] . '</td>
                          <td>' . $_dataColumns1Val["status"] . '</td>
                     </tr>
                    <tbody>';
				
				endforeach;
				$content .= '</table>';
				$footer = '<table style="width:100%;color:#ccc;background:#17479d;padding:5px 0px;margin:0px;">
								<tr>
							<td width="30%"><span style="float:left!important;margin-left:10px;">Printed by: ' . $name . '&nbsp;' . $current_date . '</span></td>
							<td style="text-align:center;width:30%;">www.nakumatt.net</td>
							<td  width="30%">&nbsp;</td>
								</tr>
							</table>
							<h4 style="color:red;">The content is confidential and not meant to be shared in any form with any external persons / entities.</h4>
							</body>
							</html>';
				$html = $header . $content . $footer;
				$dompdf->load_html($html);
				// (Optional) Setup the paper size and orientation
				$dompdf->set_paper('A4', 'landscape');
				// Render the HTML as PDF
				$dompdf->render();
				// Output the generated PDF to Browser
				$filename = "Volume of Cases by Member Tier " . date('Y-m-d:H:i:s') . ".pdf";
				$dompdf->stream($filename);			
			   //pdf report
			
		   }  
		}   
	   elseif( $_QueryReportType == "summeryreport" ){  // details report
	   
	   $_dataColumns = $this->getExportContentsummeryreportmt($_QueryPer,$_MemberTier,$_QueryCat,$_QueryORI,$_QueryReportBranchStore,$_QuerySubCat,$_QueryStatus,$_QueryReportType,$_QueryReportMonthStart,$_QueryReportMonthEnd
		  ,$_Qstart,$_Qend,$_Qfromyear,$_Qtoyear);  //calling function to get export data
	// echo "<pre>";
//print_r(  $_dataColumns);
	 //die;
	    $_Period = "";
	 if ($_POST['file_type'] == 'csv') { //Export CSV
                //CSV File name and Header
                $filename = "volumecc_summery_report" . date('Y-m-d:H:i:s') . ".csv";
                $fp = fopen('php://output', 'w');
				
				if($_QueryPer == 'monthly'):
				 $_Period = "Monthly";
				elseif($_QueryPer == 'quarterly'):
				 $_Period = "Quarterly";
				elseif($_QueryPer == 'annual'):
				 $_Period = "Annual";
				endif;
                $header = array($_Period,'Count');
                header('Content-type: application/csv');
                header('Content-Disposition: attachment; filename=' . $filename);
                fputcsv($fp, $header);
				$condition ="";
				$export_list_case = array();
				foreach($_dataColumns as $_dataColumns1Key => $_dataColumns1Val):
				$row['period'] =  $_dataColumns1Val[0];
				$row['count'] = $_dataColumns1Val[1];
				$export_list_case[] = $row;
			    fputcsv($fp, $row); //Genrate CSV
				endforeach;
				fclose($fp);
                exit;
            } elseif ($_POST['file_type'] == 'xls') { //Export XLS
                $list = array();
				if($_QueryPer == 'monthly'):
				 $_Period = "Monthly";
				elseif($_QueryPer == 'quarterly'):
				 $_Period = "Quarterly";
				elseif($_QueryPer == 'annual'):
				 $_Period = "Annual";
				endif;
				
                $list['tableheading'] = array($_Period,'Count');
                $fichier = "CS" . date('Y-m-d:H:i:s') . ".xls";
                header("Content-Type: text/csv;charset=utf-8");
                header("Content-Disposition: attachment;filename=\"$fichier\"");
                header("Pragma: no-cache");
                header("Expires: 0");
                $fp = fopen('php://output', 'w');
                fputcsv($fp, $list['tableheading']);
                //Fetch data
                foreach($_dataColumns as $_dataColumns1Val):
				$row['week'] =  $_dataColumns1Val[0];
				$row['count'] = $_dataColumns1Val[1];
				$data['list'] = $row;
				//$export_list_case[] = $row;
			    fputcsv($fp, $data['list']); //Genrate CSV
				endforeach;
				fclose($fp);
                exit();
            }elseif($_POST['file_type'] == 'pdf')
			{
			require_once 'include/dompdf/dompdf_config.inc.php';
			   global $current_user;
			   
			  if($_QueryPer == 'monthly'):
				 $_Period = "Monthly";
				 $start_date =$_QueryReportMonthStart;
			     $end_date =$_QueryReportMonthEnd;
				elseif($_QueryPer == 'quarterly'):
				 $_Period = "Quarterly";
				 $start_date = "Quarter ".$_Qstart;
				 $end_date = "Quarter ".$_Qend;
				elseif($_QueryPer == 'annual'):
				 $_Period = "Annual";
				 if(date("m") <= 06){
						$_CurrentYear = date("Y"); // current year
						$_NextYears =  date("Y")-1; //previous year 
						
						$start_date =  date($_NextYears.'-07-01'); //common from date
						$end_date =  date($_CurrentYear.'-06-30'); 

						}
						else{
						$_CurrentYear =  date("Y"); // current year
						$_NextYears  =  date("Y") + 1;  // post year
						$start_date =  date($_CurrentYear.'-07-01'); //common from date
						$end_date =  date($_NextYears.'-06-30'); 
						}
						
						$_pdffrom = $_NextYears;
						$_pdfto = $_CurrentYear;
				endif;
				
			   $name = $current_user->first_name . '&nbsp;' . $current_user->last_name;
			   $current_date = date('d/m/Y  h:i A');
			   $dompdf = new Dompdf();
			   //echo '<pre>';
			   //print_r($_dataColumns);
			  // die;
			  $_CaseOriginPdf = $_CaseOriginCat = "";
			   if($_QueryORI == 'all'):
			    $_CaseOriginPdf = 'All';
			   else:
			    $_CaseOriginPdf = $this->getCaseOriginName($_QueryORI);
			   endif;
			   
			   if($_QueryCat == 'all'):
			    $_CaseOriginCat = 'All';
			   else:
			    $_CaseOriginCat = $this->getCaseCategoryName($_QueryCat);
			   endif;
			   
			   if($_QuerySubCat == 'all'):
			    $_CaseOriginSubCat = 'All';
			   else:
			    $_CaseOriginSubCat = $this->getCaseSubCategoryName($_QuerySubCat);
			   endif;
			   
			   if($_POST['queryStatus'] == 'all'):
			    $_CaseStatus = 'All';
			   else:
			    $_CaseStatus = $_POST['queryStatus'];
			   endif;
			   
			    $_CaseBranchStorePdf = "";
				if($_QueryReportBranchStore == 'all'):
				$_CaseBranchStorePdf = 'All';
				else:
				$_CaseBranchStorePdf = $_QueryReportBranchStore;
				endif;
				
			   $header = '<html>
            <body>
                <div style="width:100%;color:#fff;background:#17479d;padding:5px 0px;margin:0px;text-align:center;">
                    <img src="custom/include/images/logo.png" style="padding: 7px;position: absolute;left: 10px;"><h2>Volume of Cases By Member Tier </h2>
                </div><table style="width:450px; margin:0 auto; text-align:left;">
				    <tr>
						<td style="width="20%"><b>From  - </b></td>
						<td style="width="10%">'.$start_date.'</td>
						<td style="width="20%"><b>To  - </b></td>
						<td style="width="10%">'.$end_date.'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Period  - </b></td>
						<td style="width="50%">'.ucfirst($_QueryPer).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Origin  - </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginPdf ).'</td>
					</tr>
					';
					 if($_QueryReportBranchStore == 'all'):
						 $header .= '<tr>
						<td style="width="50%"><b>Branch Store - </b></td>
						<td style="width="50%">All</td>
					</tr>';
						elseif($_QueryReportBranchStore == ''):
							 $header .= ''; 
					   else:
						 $header .= '<tr>
						<td style="width="50%"><b>Branch Store  - </b></td>
						<td style="width="50%">'.ucfirst($_QueryReportBranchStore).'</td>
					</tr>'; 
					   endif;
					   
					  $header .= ' 
					<tr>
						<td style="width="50%"><b>Case Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginCat ).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Sub Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginCat).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Status  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseStatus).'</td>
					</tr>
				</table>';
				
			    $content .= '<table border="1" cellspacing="0" cellpadding="5" width="100%">  
                    <thead>
                        <tr>
                            <th nowrap>'.$_Period.'</th>
                            <th nowrap>Count</th>
                        </tr>
                </thead>';
				
				foreach($_dataColumns as $_dataColumns1Val):
				    $content .= '<tbody>
                        <tr>
                          <td>' .$_dataColumns1Val[0]. '</td>
                          <td>' .$_dataColumns1Val[1]. '</td>
                     </tr>
                    <tbody>';
				
				endforeach;
				$content .= '</table>';
				$footer = '<table style="width:100%;color:#ccc;background:#17479d;padding:5px 0px;margin:0px;">
								<tr>
							<td width="30%"><span style="float:left!important;margin-left:10px;">Printed by: ' . $name . '&nbsp;' . $current_date . '</span></td>
							<td style="text-align:center;width:30%;">www.nakumatt.net</td>
							<td  width="30%">&nbsp;</td>
								</tr>
							</table>
							<h4 style="color:red;">The content is confidential and not meant to be shared in any form with any external persons / entities.</h4>
							</body>
							</html>';
				$html = $header . $content . $footer;
				$dompdf->load_html($html);
				// (Optional) Setup the paper size and orientation
				$dompdf->set_paper('A4', 'landscape');
				// Render the HTML as PDF
				$dompdf->render();
				// Output the generated PDF to Browser
				$filename = "Volume of Cases by Member Tier " . date('Y-m-d:H:i:s') . ".pdf";
				$dompdf->stream($filename);			
			   //pdf report
			 //pdf report
			
		   }  
	   
		  
	   }
		 
		 
		 /*
	     
		  $_dataColumns = $this->getExportContentCmt($_QueryFD,$_QueryTD,$_QueryPer,$_QueryMt,$_QueryCat,$_QueryORI,$_QueryStatus);  //calling function to get export data
	    
		 
          if ($_POST['file_type'] == 'csv') { //Export CSV
                //CSV File name and Header
                $filename = "volumecasemembertier_" . date('Y-m-d:H:i:s') . ".csv";
                 $fp = fopen('php://output', 'w');
                 $header = array('Case ID','Date','Member Tier','Case Origin', 'Case Category', 'Case Status','Case Priority');
                 header('Content-type: application/csv');
                 header('Content-Disposition: attachment; filename=' . $filename);
                 fputcsv($fp, $header);
				$condition ="";
				$export_list_case = array();
				foreach($_dataColumns as $_dataColumns1Val):
				$row['case'] = $_dataColumns1Val['case_id'];
				$row['date_entered'] = $_dataColumns1Val['date_entered'];
				$row['member_tier'] = $_dataColumns1Val['member_tier'];
				$row['origin_c'] = $_dataColumns1Val['origin_c'];
				$row['category_c'] = $_dataColumns1Val['category_c'];
				$row['status'] = $_dataColumns1Val['status'];
				$row['priority'] = $_dataColumns1Val['priority'];
				$export_list_case[] = $row;
			    fputcsv($fp, $row); //Genrate CSV
				endforeach;
				fclose($fp);
                exit;
            } elseif ($_POST['file_type'] == 'xls') { //Export XLS
                $list = array();
                $list['tableheading'] =  array('Case ID','Date','Member Tier','Case Origin', 'Case Category', 'Case Status','Case Priority');
                $fichier = "volumecasemembertier" . date('Y-m-d:H:i:s') . ".xls";
                header("Content-Type: text/csv;charset=utf-8");
                header("Content-Disposition: attachment;filename=\"$fichier\"");
                header("Pragma: no-cache");
                header("Expires: 0");
                $fp = fopen('php://output', 'w');
                fputcsv($fp, $list['tableheading']);
                //Fetch data
                foreach($_dataColumns as $_dataColumns1Val):
				$row['case'] = $_dataColumns1Val['case_id'];
				$row['date_entered'] = $_dataColumns1Val['date_entered'];
				$row['member_tier'] = $_dataColumns1Val['member_tier'];
				$row['origin_c'] = $_dataColumns1Val['origin_c'];
				$row['category_c'] = $_dataColumns1Val['category_c'];
				$row['status'] = $_dataColumns1Val['status'];
				$row['priority'] = $_dataColumns1Val['priority'];
				$data['list'] = $row;
				//$export_list_case[] = $row;
			    fputcsv($fp, $data['list']); //Genrate CSV
				endforeach;
				fclose($fp);
                exit();
            }*/
	}
     public function getExportContent($_QueryFD,$_QueryTD,$_QueryPer,$_QueryORI,$_QueryCat,$_QuerySubCat,$_QueryReportType,$_Mstart,
	 $_Start,$_Wstart ,$_Wend,$_Qastart,$_QaEnd,$_Branchstore,$_Qfromyear,$_Qtoyear)
	{  
        global $db, $app_list_strings;
		global $sugar_config;
        $this->view = 'volumecsa';
        $volumecc = $queryCase = $_Yearquery= $_ColumnsDate=$volumeDate=$_DailyLoopC=$_DateEnteredArray
		=$volumecc_grid=$_NoOfQuarters=$_GetOneQuarters=$volumecc_grid1=array();
		$_WeeklyGlobal = $_QuaterlyGlobal = $_MonthGlobal = $_DailyGlobal = $_YearlyGlobal=0;
        $condition = $condition_group=$_StartMonth=$_EndMonth= $_StartW= $_EndW=$_StartQ=$_EndQ='';
 
            if ($_QueryFD || $_QueryPer || $_QueryORI ||
                    $_QueryTD || $_QueryCat || $_QuerySubCat || $_Branchstore) {
                /*
                if ($_QueryCat  && empty($_QueryORI)) {
                    $condition .= "  cases_cstm.category_c = '" . $_QueryCat  . "' AND ";
					$condition_group .= ",cases_cstm.category_c";
				}
				
                if ($_QueryORI && empty($_QueryCat)) {
                    $condition .= "  cases_cstm.origin_c = '" . $_QueryORI . "'  AND ";
					$condition_group .= ",cases_cstm.origin_c";
                }
                
			    if (!empty($_QueryORI) && !empty($_QueryCat)) {
					$condition .= "  cases_cstm.origin_c = '" . $_QueryORI . "'  AND  cases_cstm.category_c = '" . $_QueryCat . "' AND";
					$condition_group .= ",cases_cstm.origin_c,cases_cstm.category_c";
                }*/
				
				if ($_Qfromyear && $_Qtoyear) {
		    $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
			$from = $_Qfromyear;
			$to = $_Qtoyear;		
			if ($_Qfromyear != $_Qtoyear) {
			$end_date = $_curdate;
			$start_date = date('Y-m-1', strtotime("-1 year"));
			} else {
			$start_date = date('Y-m-d', strtotime("$from-01-01"));
			$end_date = date('Y-m-d', strtotime("$from-12-31"));
			}
			$condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($start_date)) . "' AND '" . date("Y-m-d", strtotime($end_date)) . "' AND ";
			}else
		{
			if ($_QueryFD && $_QueryTD) {
			$condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($_QueryFD)) . "' AND '" . date("Y-m-d", strtotime($_QueryTD)) . "' AND ";
			}
		}
		
				if ($_QueryCat == "all") {
				$condition .= "";
				$condition_group .= "";
				}else
				{
				$condition .= "  cases_cstm.category_c = '" . $_QueryCat . "' AND ";
				$condition_group .= ",cases_cstm.category_c";
				}

				if ($_QueryORI == "all")  {
				$condition .= " ";
				$condition_group .= "";
				}else
				{
				$condition .= "  cases_cstm.origin_c = '" . $_QueryORI . "'  AND ";
				$condition_group .= ",cases_cstm.origin_c";
				}
				if ($_Branchstore == "all"  || $_Branchstore == "" )  {
				$condition .= " ";
				}else
				{
				$condition .= "  cases.branch_store_name = '" . $_Branchstore . "'  AND ";
				}
				

				if ($_QuerySubCat  == "all") {
				$condition .= " ";
				$condition_group .= "";
				}else
				{
				$condition .= "  cases_cstm.subcategory_c = '" . $_QuerySubCat . "'  AND ";
				$condition_group .= ",cases_cstm.subcategory_c";
				}

			
			if(!empty($_Mstart)):
				   $_StartMonth = $_Mstart;
				endif;
				
				if(!empty($_Start)):
				   $_EndMonth = $_Start;
				endif;
				
				if(!empty($_Wstart)):
				  $_StartW = $_Wstart;
				endif;
				
				if(!empty($_Wend)):
				  $_EndW = $_Wend;
				endif;
				
				if(!empty($_Qastart)):
				  $_StartQ = $_Qastart;
				endif;
				
				if(!empty($_QaEnd)):
				  $_EndQ = $_QaEnd;
				endif;
				
            /*checking query starting*/
			$start_date = date("Y-m-d",strtotime($_QueryFD));
			$end_date = date("Y-m-d",strtotime($_QueryTD));
	 
	 
			if($_QueryPer == "daily"):
			$_DailyGlobal=1;
						$_DailyLoopCount = $this->datediff('d',$start_date ,$end_date);				 

						for($i=0;$i<=$_DailyLoopCount;$i++)
						{
						 $_DailyLoopC[] =  date ("Y-m-d", strtotime("+$i day", strtotime($start_date)));
						}
						
						if ($start_date && $end_date) {
								$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";
						}
								
								
				        $query_query = "SELECT cases.id,cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where " . $condition . " cases.deleted=0  ORDER BY cases.date_entered ASC";
						$result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecc[] = $row;
					    $volumeDate[] = date("Y-m-d",strtotime($row['date_entered']));
						}
						else:
						$row['emptyrecord'] = "N/A";
                       // $volumecc[] = $row;
						endif;
					
                elseif($_QueryPer== "weekly"):
					    $_WeekLoopCount = $this->datediff('ww',date("y-m-d",strtotime($_QueryFD)),date("y-m-d",strtotime($_QueryTD)));				 
						
						for($i=0;$i<=$_WeekLoopCount;$i++)
						{
					   // echo $this->week_date_start($i,2016);
						$_DailyLoopC[] =  date ("Y-m-d", strtotime("+ $i week", strtotime($start_date)));
						echo "<br>";	
						}
						
						$_WeeklyGlobal = 1;
						if ($_QueryFD && $_QueryTD) {
							$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";
						}
					    $query_query = "SELECT cases.id,cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
							. "cases_cstm.member_tier_c,"
							. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
							. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
							. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
							. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
							. " cases.date_entered , cases.assigned_user_id FROM cases "
							. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
							. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
							. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
							. " where " . $condition . " cases.deleted=0 ORDER BY cases.date_entered ASC";

						$result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['case_number'] = $row['case_number'];
						$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
						$volumecc[] = $row;
						}
						else:
						$row['emptyrecord'] = "N/A";
						// $volumecc[] = $row;
						endif;
				 
				elseif($_QueryPer== "monthly"):
				        $_StartMonth =  date('Y-m-d',strtotime($_StartMonth));
				        $_EndMonth = date('Y-m-d',strtotime($_EndMonth ));
						$a_date = $_EndMonth; 
						$date = new DateTime($a_date);
						$date->modify('last day of this month');
						$_EndMonth = $date->format('Y-m-d');
						$_MonthGlobal = 1;
				        $_MonthLoopCount = $this->datediff('m',date("y-m-d",strtotime($_StartMonth)),date("y-m-d",strtotime($_EndMonth)));				 
						for($i=0;$i<=$_MonthLoopCount+1;$i++)
						{
						$_DailyLoopC[] =  date ("m-Y", strtotime("+ $i month", strtotime($start_date)));
						}
						if ($_QueryFD && $_QueryTD) {
							$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_StartMonth)) . "' AND '" . date("y-m-d",strtotime($_EndMonth)) . "' AND ";
						}
						
					   $query_query = "SELECT cases.id,cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
							. "cases_cstm.member_tier_c,"
							. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
							. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
							. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
							. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
							. " cases.date_entered , cases.assigned_user_id FROM cases "
							. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
							. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
							. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
							. " where " . $condition . " cases.deleted=0 ORDER BY cases.date_entered ASC";

						$result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['date_entered'] = date("d-m-Y",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
						$volumecc[] = $row;
						}
						else:
						$row['emptyrecord'] = "N/A";
						// $volumecc[] = $row;
						endif;
				elseif($_QueryPer == "quarterly"):
				 $_QuaterlyGlobal =1;
				 $condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_Qastart)) . "' AND '" . date("y-m-d",strtotime($_QaEnd)) . "' AND ";
				 
			     $query_query = "SELECT cases.id,cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where " . $condition . " cases.deleted=0 ORDER BY cases.date_entered ASC";
			
					 $result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecc[] = $row;
						}
						else:
						$row['emptyrecord'] = "N/A";
                       // $volumecc[] = $row;
						endif;
			    elseif($_QueryPer == "annual"):
                $_YearlyGlobal = 1;
				$_YearlyGlobal = 1;
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
				$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
			    $start_date  = $_Year."-".$_Month."-"."1";  //start date
				$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
				$_CurrentYear = date("Y"); // current year
				$_PreviousYears = date("Y")-1; //previous year 
				if ($_POST['getYearsDd'] != $_POST['getYeareDd']) {
					$_Year =  array($_PreviousYears,$_CurrentYear);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}else{
				    $_Year =  array($_POST['getYearsDd']);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}
				
				$from = $_POST['getYearsDd'];
				$to = $_POST['getYeareDd'];
				
				if ($_POST['getYearsDd'] != $_POST['getYeareDd']) {
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				} else {
				$start_date = date('Y-m-d', strtotime("$from-01-01"));
				$end_date = date('Y-m-d', strtotime("$from-12-31"));
				}
					
				//$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . //date("y-m-d",strtotime($end_date)) . "' AND ";
			    $query_query = "SELECT cases.id,cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where " . $condition . " cases.deleted=0 ORDER BY cases.date_entered ASC";
				$result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecc[] = $row;
						}
						else:
						$row['emptyrecord'] = "N/A";
                       // $volumecc[] = $row;
						endif;
				else:
				if ($_QueryCat && empty($_QueryORI)) {
				$condition .= "  cases_cstm.category_c = '" . $_QueryCat . "' AND ";
				$condition_group .= ",cases_cstm.category_c";
				}
				if ($_QueryORI && empty($_QueryCat)) {
				$condition .= "  cases_cstm.origin_c = '" . $_QueryORI . "'  AND ";
				$condition_group .= ",cases_cstm.origin_c";
				}

				if (!empty($_QueryORI) && !empty($_QueryCat)) {
				$condition .= "  cases_cstm.origin_c = '" . $_QueryORI . "'  AND  cases_cstm.category_c = '" . $_QueryCat . "' AND";
				$condition_group .= ",cases_cstm.origin_c,cases_cstm.category_c";
				}

				/*checking query starting*/
				$start_date = date("Y-m-d",strtotime($_QueryFD));
				$end_date = date("Y-m-d",strtotime($_QueryTD));
				$_DailyLoopCount = $this->datediff('d',date("y-m-d",strtotime($_QueryFD)),date("y-m-d",strtotime($_QueryTD)));				 

			    for($i=0;$i<=$_DailyLoopCount;$i++)
				{
				  $_DailyLoopC[] =  date ("Y-m-d", strtotime("+$i day", strtotime($start_date)));
				}
						
				if ($_QueryFD && $_QueryTD) {
				  $condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";
				}
								
								
				$query_query = "SELECT cases.id,cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where " . $condition . " cases.deleted=0  group by date(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
								
						$result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecc[] = $row;
					    $volumeDate[] = date("Y-m-d",strtotime($row['date_entered']));
						}
						else:
						$row['emptyrecord'] = "N/A";
                       // $volumecc[] = $row;
						endif;
				endif;
			
			    
			   if($_QueryPer == 'weekly'){//for month start
				$temp2 = array();
				for($p = $_StartW ; $p <= $_EndW ; $p++){
				$temp2w[] = $p;
				}
				
			     //$_MonthStartArray = array_keys($_DailyLoopC,$_StartMonth);
				 //$_MonthEndArray =  array_keys($_DailyLoopC,$_EndMonth);
				 //$_Totvalue = $_MonthEndArray[0]-$_MonthStartArray[0];
			    /// $_DailyLoopC = array_slice($_DailyLoopC,$_MonthStartArray[0],$_Totvalue+1);
				 //for month end
				}
				//echo "<br>";
				// echo "<br>";
				if($_DailyGlobal==1 || $_YearlyGlobal == 1 || $_MonthGlobal == 1 || $_WeeklyGlobal==1 || $_QuaterlyGlobal ==1):
				
					$i = 0;
					foreach($volumecc as $volumecc1):
					 if($_QueryPer == 'weekly'):
					 if(!in_array($i,$temp2w)){
					 $i++;
						continue;
						
					 }
					  endif;
					  
					  
					    $volumecc_grid1["case_number"] = $volumecc1['case_number'];
						$volumecc_grid1["date_entered"] = $volumecc1['date_entered'];
						$volumecc_grid1["origin_c"] = $volumecc1['origin_c'];
						$volumecc_grid1["category_c"] = $volumecc1['category_c'];
						$volumecc_grid1["priority"] = $volumecc1['priority'];
						$volumecc_grid[] = $volumecc_grid1;
						$i++;
					endforeach; 
				endif;
            }
			
		return $volumecc_grid;
		
        if (isset($total) > 0) {
            $this->view_object_map['total_cases'] = $total;
        } else {
            $this->view_object_map['total_cases'] = 0;
        }
    
	}
	
	public function getDateRange($quarter, $fin_year)
    {
       $temp = explode('-', $fin_year); //2012-2013
        $start_date = date('');
        $end_date = date('');
        $range = array();
	
        if( $quarter == 1 ){

            if( $temp[0] == date('Y') ){
                $start_date = date('Y-07-01 00:00:00');
                $end_date = date('Y-09-30 23:59:59');

            }elseif( $temp[1] == date('Y') ){
                $start_date = date($temp[0] . '-07-01 00:00:00 ');
                $end_date = date($temp[0] . '-09-30 23:59:59');
            }

        }elseif( $quarter == 2 ){

            if( $temp[0] == date('Y') ){
                $start_date = date('Y-10-01 00:00:00');
                $end_date = date('Y-12-31 23:59:59');

            }elseif( $temp[1] == date('Y') ){
                $start_date = date($temp[0] . '-10-01 00:00:00');
                $end_date = date($temp[0] . '-12-31 23:59:59');
            }

        }elseif( $quarter == 3 ){

            if( $temp[0] == date('Y') ){
                $start_date = date('Y-01-01 00:00:00');
                $end_date = date('Y-03-31 23:59:59');

            }elseif( $temp[1] == date('Y') ){
                $start_date = date($temp[1] . '-01-01 00:00:00');
                $end_date = date($temp[1] . '-03-31 23:59:59');
            }

        }elseif( $quarter == 4 ){

            if( $temp[0] == date('Y') ){
                $start_date = date($temp[1] . '-04-01 00:00:00');
                $end_date = date($temp[1] . '-06-30 23:59:59');

            }elseif( $temp[1] == date('Y') ){
                $start_date = date('Y-04-01 00:00:00');
                $end_date = date('Y-06-30 23:59:59');
            }
        }

        $return['start_date'] = $start_date;
        $return['end_date'] = $end_date;

        return $return;
    }
	
	
	 public function week_date_start($week, $year){
      $date = new DateTime();
      return "first day of the week is ".$date->setISODate($year, $week, "1")->format('Y-m-d')
     ."and last day of the week is ".$date->setISODate($year, $week, "7")->format('Y-m-d'); 
    }

     public function action_exportvolumecc() {
        global $db, $app_list_strings;
		$condition =$_QueryFD =$_QueryTD =$_QueryPer= $_QueryORI = $_QueryCat =$_QueryReportType= $_QuerySubCat =$start_date=$end_date= $_QueryReportMonthStart=$_QueryReportMonthEnd="";
		
		  /*  if ($_POST['querycategory'] && empty($_POST['queryorigin'])) {
			$condition .= "  cases_cstm.category_c = '" . $_POST['querycategory'] . "' AND ";
			}
			if ($_POST['queryorigin'] && empty($_POST['querycategory'])) {
			$condition .= "  cases_cstm.origin_c = '" . $_POST['queryorigin'] . "'  AND ";
			}

			if (!empty($_POST['queryorigin']) && !empty($_POST['querycategory'])) {
			$condition .= "  cases_cstm.origin_c = '" . $_POST['queryorigin'] . "'  AND  cases_cstm.category_c = '" . $_POST['querycategory'] . "' AND";
			}
		
			$default_query_case = "SELECT cases.case_number,cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.priority,cases.status, LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, cases.date_entered FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT JOIN users jt0 ON cases.created_by=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
            . " where " . $condition . " cases.deleted=0 ORDER BY cases.date_entered DESC";
            
		  */
			
	      if(isset($_REQUEST['queryfromdate']))
          {
		   $_QueryFD =  $_REQUEST['queryfromdate'];
          }
		  
          if(isset($_REQUEST['querytodate']))
          {
		  $_QueryTD =  $_REQUEST['querytodate'];
          }

          if(isset($_REQUEST['queryPeriod']))
          {
		  $_QueryPer =  $_REQUEST['queryPeriod'];
          }

          if(isset($_REQUEST['queryorigin']))
          {
		  $_QueryORI=  $_REQUEST['queryorigin'];
          }

          if(isset($_REQUEST['querycategory']))
          {
		  $_QueryCat =  $_REQUEST['querycategory'];
          }
		  
		  if(isset($_REQUEST['querysubcategory']))
          {
		  $_QuerySubCat =  $_REQUEST['querysubcategory'];
          }
          
		  if(isset($_POST['report_type']))
          {
		  $_QueryReportType =  $_POST['report_type'];
          }
          
		  if(isset($_POST['querySmonth']))
		 {
		   $_QueryReportMonthStart =  $_POST['querySmonth'];
		 }

		 if(isset($_POST['queryEmonth']))
		 {
		  $_QueryReportMonthEnd =  $_POST['queryEmonth'];
		} 		  
		   
		 // if(isset($_POST['querysWeek']))
		 //{
		 // $_Wstart =  $_POST['querysWeek'];
		//} 
		// if(isset($_POST['queryeWeek']))
		 //{
		 // $_Wend =  $_POST['queryeWeek'];
		//} 
		   if(isset($_POST['queryeQs']))
		 {
		  $_Qstart =  $_POST['queryeQs'];
		  $_Qstart_dis = explode("_",  $_Qstart);
		  $_Qstart = $_Qstart_dis[0];
		   $_Wstart = $_Qstart_dis[2]; // this is temprory using for quaarter cal
		} 
		 if(isset($_POST['queryeQe']))
		 {
		   $_Qend =  $_POST['queryeQe']."<br>";
		  $_Qend_dis = explode("_",  $_Qend);
		  $_Qend = $_Qend_dis[1];
		  $_Wend = $_Qend_dis[2];// this is temprory using for quaarter cal
		} 
		if(isset($_POST['queryBranchStore']))
		 {
		  $_Qbranchstore =  $_POST['queryBranchStore'];
		} 
		
     	
		if(isset($_POST['getFromyear']))
		 {
		  $_Qfromyear =  $_POST['getFromyear'];
		} 
		if(isset($_POST['getToyear']))
		 {
		  $_Qtoyear =  $_POST['getToyear'];
		} 
	   if( $_QueryReportType == "detailsreport"){ // summery report
	   
		  $_dataColumns = $this->getExportContent($_QueryFD,$_QueryTD,$_QueryPer,$_QueryORI,$_QueryCat,$_QuerySubCat,$_QueryReportType,$_QueryReportMonthStart,$_QueryReportMonthEnd
		  ,$_Wstart,$_Wend, $_Qstart,$_Qend,$_Qbranchstore,$_Qfromyear,$_Qtoyear);  //calling function to get export data
		//echo '<pre>';
	   //  print_r($_dataColumns);die;
              if ($_POST['file_type'] == 'csv') { //Export CSV
                //CSV File name and Header
                $filename = "volumecc_" . date('Y-m-d:H:i:s') . ".csv";
                $fp = fopen('php://output', 'w');
                $header = array('Case Id','Date', 'Case Origin', 'Case Category', 'Case Priority');
                header('Content-type: application/csv');
                header('Content-Disposition: attachment; filename=' . $filename);
                fputcsv($fp, $header);
				$condition ="";
				$export_list_case = array();
				foreach($_dataColumns as $_dataColumns1Val):
				$row['case_number'] = $_dataColumns1Val['case_number'];
				$row['date_entered'] = $_dataColumns1Val['date_entered'];
				$row['origin_c'] = $_dataColumns1Val['origin_c'];
				$row['category_c'] = $_dataColumns1Val['category_c'];
				$row['priority'] = $_dataColumns1Val['priority'];
				$export_list_case[] = $row;
			    fputcsv($fp, $row); //Genrate CSV
				endforeach;
				fclose($fp);
                exit;
            } elseif ($_POST['file_type'] == 'xls') { //Export XLS
                $list = array();
                $list['tableheading'] = array('Case Id','Date', 'Case Origin', 'Case Category', 'Case Priority');
                $fichier = "volumecc_" . date('Y-m-d:H:i:s') . ".xls";
                header("Content-Type: application/vnd.ms-excel;charset=utf-8");
                header("Content-Disposition: attachment;filename=\"$fichier\"");
                header("Pragma: no-cache");
                header("Expires: 0");
                $fp = fopen('php://output', 'w');
				$flag = false;
                //fputcsv($fp, $list['tableheading']);
                //Fetch data
				//echo "<pre>";
				//print_r($_dataColumns);
                foreach($_dataColumns as $_dataColumns1Val):
				if(!$flag) {
				$row['case_number'] = $_dataColumns1Val['case_number'];
				$row['date_entered'] = $_dataColumns1Val['date_entered'];
				$row['origin_c'] = $_dataColumns1Val['origin_c'];
				$row['category_c'] = $_dataColumns1Val['category_c'];
				$row['priority'] = $_dataColumns1Val['priority'];
				//$data['list'] = $row;
				//$export_list_case[] = $row;
				//echo "<pre>";
				//print_r($row);
				echo implode("\t", array_keys($row)) . "\n";
				$flag = true;
				}
				//echo "<pre>";
				echo implode("\t", array_values($row)) . "\n";
				endforeach;
                exit();
            }elseif($_POST['file_type'] == 'pdf')
			{
               require_once 'include/dompdf/dompdf_config.inc.php';
			   global $current_user;
			   $name = $current_user->first_name . '&nbsp;' . $current_user->last_name;
			   $current_date = date('d/m/Y  h:i A');
			   $dompdf = new Dompdf();
			   //echo '<pre>';
			   //print_r($_dataColumns);
			  // die;
			  
			  if($_QueryPer  == 'daily'):
			   $start_date =$_QueryFD;
			   $end_date =$_QueryTD;
			  elseif($_QueryPer  == 'monthly'):
			   $start_date =$_QueryReportMonthStart;
			   $end_date =$_QueryReportMonthEnd;
			  elseif($_QueryPer  == 'quarterly'):
			   $start_date = "Quarter ".$this->Quarterlabelreportpdf($_POST['queryeQs']);
			   $end_date = "Quarter ".$this->Quarterlabelreportpdf($_POST['queryeQe']);
			  elseif($_QueryPer  == 'weekly'):
			   $start_date =  $_Wstart;
			   $end_date =  $_Wend;
				
			  else:
			    $_Period = "Annual";
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$from = $_Qfromyear;
				$to = $_Qtoyear;

				if ($_Qfromyear != $_Qtoyear) {
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				} else {
				$start_date = date('Y-m-d', strtotime("$from-01-01"));
				$end_date = date('Y-m-d', strtotime("$from-12-31"));
				}
				endif;		
				
			   $_CaseOriginPdf = $_CaseOriginCat = "";
			   if($_QueryORI == 'all'):
			    $_CaseOriginPdf = 'All';
			   else:
			    $_CaseOriginPdf = $this->getCaseOriginName($_QueryORI);
			   endif;
			   
			   if($_QueryCat == 'all'):
			    $_CaseOriginCat = 'All';
			   else:
			    $_CaseOriginCat = $this->getCaseCategoryName($_QueryCat);
			   endif;
			   
			   if($_QuerySubCat == 'all'):
			    $_CaseOriginSubCat = 'All';
			   else:
			    $_CaseOriginSubCat = $this->getCaseSubCategoryName($_QuerySubCat);
			   endif;
			   
			   $header = '<html>
            <body>
                <div style="width:100%;color:#fff;background:#17479d;padding:5px 0px;margin:0px;text-align:center;">
                    <img src="custom/include/images/logo.png" style="padding: 7px;position: absolute;left: 10px;"><h2>Volume of Cases by Category </h2>
                </div>
				<br />
				<table style="width:450px; margin:0 auto; text-align:left;">
				    <tr>
						<td style="width="20%"><b>From  - </b></td>
						<td style="width="10%">'.$start_date.'</td>
						<td style="width="20%"><b>To  - </b></td>
						<td style="width="10%">'.$end_date.'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Period  - </b></td>
						<td style="width="50%">'.ucfirst($_QueryPer).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Origin  - </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginPdf).'</td>
					</tr>';
					
						if($_Qbranchstore == 'all'):
				$header .= '<tr>
						<td style="width="50%"><b>Branch Store - </b></td>
						<td style="width="50%">All</td>
					</tr>';
					elseif($_Qbranchstore == ''):
				$header .= ''; 
					   else:
						 $header .= '<tr>
						<td style="width="50%"><b>Branch Store  - </b></td>
						<td style="width="50%">'.ucfirst($_Qbranchstore).'</td>
					</tr>'; 
					   endif;
				$header .='<tr>
						<td style="width="50%"><b>Case Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginCat).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Sub Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginSubCat).'</td>
					</tr>
				</table>';
				
			    $content .= '<table border="1" cellspacing="0" cellpadding="5" width="100%">  
                    <thead>
                        <tr>
                            <th nowrap>Case Id</th>
                            <th nowrap>Date</th>
                            <th nowrap>Case Origin</th> 
                            <th nowrap>Case Category</th>  
							<th nowrap>Case Priority</th> 
                        </tr>
                </thead>';
				
				foreach($_dataColumns as $_dataColumns1Val):
				    $content .= '<tbody>
                        <tr>
                          <td>' . $_dataColumns1Val["case_number"] . '</td>
                          <td>' . $_dataColumns1Val["date_entered"] . '</td>
                          <td>' . $_dataColumns1Val["origin_c"] . '</td>
                          <td>' . $_dataColumns1Val["category_c"] . '</td>
                          <td>' . $_dataColumns1Val["priority"] . '</td>
                     </tr>
                    <tbody>';
				
				endforeach;
				$content .= '</table>';
				$footer = '<table style="width:100%;color:#ccc;background:#17479d;padding:5px 0px;margin:0px;">
								<tr>
							<td width="30%"><span style="float:left!important;margin-left:10px;">Printed by: ' . $name . '&nbsp;' . $current_date . '</span></td>
							<td style="text-align:center;width:30%;">www.nakumatt.net</td>
							<td  width="30%">&nbsp;</td>
								</tr>
							</table>
							<h4 style="color:red;">The content is confidential and not meant to be shared in any form with any external persons / entities.</h4>
							</body>
							</html>';
				$html = $header . $content . $footer;
				$dompdf->load_html($html);
				// (Optional) Setup the paper size and orientation
				$dompdf->set_paper('A4', 'landscape');
				// Render the HTML as PDF
				$dompdf->render();
				// Output the generated PDF to Browser
				$filename = "Volume of Cases " . date('Y-m-d:H:i:s') . ".pdf";
				$dompdf->stream($filename);			
			   //pdf report
			
		   }  
		}   
	   elseif( $_QueryReportType == "summeryreport" ){  // details report
  	   $_dataColumns = $this->getExportContentsummeryreport($_QueryFD,$_QueryTD,$_QueryPer,$_QueryORI,$_QueryCat,$_QuerySubCat,$_QueryReportType,$_QueryReportMonthStart,$_QueryReportMonthEnd
		  ,$_Wstart,$_Wend, $_Qstart,$_Qend,$_Qbranchstore,$_Qfromyear,$_Qtoyear);  //calling function to get export data
	    $_Period = "";
	 if ($_POST['file_type'] == 'csv') { //Export CSV
                //CSV File name and Header
                $filename = "volumecc_summery_report" . date('Y-m-d:H:i:s') . ".csv";
                $fp = fopen('php://output', 'w');
				
				if($_QueryPer == 'daily'):
				 $_Period = "Daily";
				elseif($_QueryPer =='weekly'):
				 $_Period = "Weekly";
				elseif($_QueryPer == 'monthly'):
				 $_Period = "Monthly";
				elseif($_QueryPer == 'quarterly'):
				 $_Period = "Quarterly";
				elseif($_QueryPer == 'annual'):
				 $_Period = "Annual";
				endif;
                $header = array($_Period,'Count');
                header('Content-type: application/csv');
                header('Content-Disposition: attachment; filename=' . $filename);
                fputcsv($fp, $header);
				$condition ="";
				$export_list_case = array();
				foreach($_dataColumns as $_dataColumns1Key => $_dataColumns1Val):
				$row['period'] =  $_dataColumns1Val[0];
				$row['count'] = $_dataColumns1Val[1];
				$export_list_case[] = $row;
			    fputcsv($fp, $row); //Genrate CSV
				endforeach;
				fclose($fp);
                exit;
            } elseif ($_POST['file_type'] == 'xls') { //Export XLS
                $list = array();
				if($_QueryPer == 'daily'):
				 $_Period = "Daily";
				elseif($_QueryPer =='weekly'):
				 $_Period = "Weekly";
				elseif($_QueryPer == 'monthly'):
				 $_Period = "Monthly";
				elseif($_QueryPer == 'quarterly'):
				 $_Period = "Quarterly";
				elseif($_QueryPer == 'annual'):
				 $_Period = "Annual";
				endif;
				
                $list['tableheading'] = array($_Period,'Count');
                $fichier = "CS" . date('Y-m-d:H:i:s') . ".xls";
                header("Content-Type: application/vnd.ms-excel;charset=utf-8");
                header("Content-Disposition: attachment;filename=\"$fichier\"");
                header("Pragma: no-cache");
                header("Expires: 0");
                //$fp = fopen('php://output', 'w');
               // fputcsv($fp, $list['tableheading']);
			    $flag = false;
				
				 //Fetch data
                foreach($_dataColumns as $_dataColumns1Val):
				if(!$flag) {
				$row['week'] =  $_dataColumns1Val[0];
				$row['count'] = $_dataColumns1Val[1];
				//$data['list'] = $row;
				echo implode("\t", array_keys($row)) . "\r\n";
				$flag = true;
				}
				echo implode("\t", array_values($row)) . "\r\n";
				//$export_list_case[] = $row;
			  //  fputcsv($fp, $data['list']); //Genrate CSV
				endforeach;
				die;
				//fclose($fp);
                exit();
            }elseif($_POST['file_type'] == 'pdf')
			{
			require_once 'include/dompdf/dompdf_config.inc.php';
			   global $current_user;
			   
			  if($_QueryPer  == 'daily'):
			   $_Period = "Daily";
			   $start_date =$_QueryFD;
			   $end_date =$_QueryTD;
			  elseif($_QueryPer  == 'monthly'):
			   $_Period = "Monthly";
			   $start_date =$_QueryReportMonthStart;
			   $end_date =$_QueryReportMonthEnd;
			  elseif($_QueryPer  == 'quarterly'):
			   $_Period = "Quarter";
			   $start_date = "Quarter ".$this->Quarterlabelreportpdf($_POST['queryeQs']);
			   $end_date = "Quarter ".$this->Quarterlabelreportpdf($_POST['queryeQe']);
			  elseif($_QueryPer  == 'weekly'):
			   $_Period = "Weekly";
			   $start_date =  $_Wstart;
			   $end_date =  $_Wend;
				
			  else:
			    $_Period = "Annual";
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$from = $_Qfromyear;
				$to = $_Qtoyear;

				if ($_Qfromyear != $_Qtoyear) {
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				} else {
				$start_date = date('Y-m-d', strtotime("$from-01-01"));
				$end_date = date('Y-m-d', strtotime("$from-12-31"));
				}
				endif;	
			   $name = $current_user->first_name . '&nbsp;' . $current_user->last_name;
			   $current_date = date('d/m/Y  h:i A');
			   $dompdf = new Dompdf();
			   //echo '<pre>';
			   //print_r($_dataColumns);
			  // die;
			    $_CaseOriginPdf = $_CaseOriginCat = "";
			   if($_QueryORI == 'all'):
			    $_CaseOriginPdf = 'All';
			   else:
			    $_CaseOriginPdf = $this->getCaseOriginName($_QueryORI);
			   endif;
			   
			   if($_QueryCat == 'all'):
			    $_CaseOriginCat = 'All';
			   else:
			    $_CaseOriginCat = $this->getCaseCategoryName($_QueryCat);
			   endif;
			   
			   if($_QuerySubCat == 'all'):
			    $_CaseOriginSubCat = 'All';
			   else:
			    $_CaseOriginSubCat = $this->getCaseSubCategoryName($_QuerySubCat);
			   endif;
			   
			   $header = '<html>
            <body>
                <div style="width:100%;color:#fff;background:#17479d;padding:5px 0px;margin:0px;text-align:center;">
                    <img src="custom/include/images/logo.png" style="padding: 7px;position: absolute;left: 10px;"><h2>Volume of Cases by Category </h2>
                </div>
				<br />
				<table style="width:450px; margin:0 auto; text-align:left;">
				    <tr>
						<td style="width="20%"><b>From  - </b></td>
						<td style="width="10%">'.$start_date.'</td>
						<td style="width="20%"><b>To  - </b></td>
						<td style="width="10%">'.$end_date.'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Period  - </b></td>
						<td style="width="50%">'.ucfirst($_QueryPer).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Origin  - </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginPdf ).'</td>
					</tr>';
					if($_Qbranchstore == 'all'):
				   $header .= '<tr>
						<td style="width="50%"><b>Branch Store - </b></td>
						<td style="width="50%">All</td>
					</tr>';
					elseif($_Qbranchstore == ''):
				   $header .= ''; 
					   else:
						 $header .= '<tr>
						<td style="width="50%"><b>Branch Store  - </b></td>
						<td style="width="50%">'.ucfirst($_Qbranchstore).'</td>
					</tr>'; 
					   endif;
					$header .= '<tr>
						<td style="width="50%"><b>Case Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginCat).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Sub Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginSubCat).'</td>
					</tr>
				</table>';
			    $content .= '<table border="1" cellspacing="0" cellpadding="5" width="100%">  
                    <thead>
                        <tr>
                            <th nowrap>'.$_Period.'</th>
                            <th nowrap>Count</th>
                        </tr>
                </thead>';
				
				foreach($_dataColumns as $_dataColumns1Val):
				    $content .= '<tbody>
                        <tr>
                          <td>' .$_dataColumns1Val[0]. '</td>
                          <td>' .$_dataColumns1Val[1]. '</td>
                     </tr>
                    <tbody>';
				
				endforeach;
				$content .= '</table>';
				$footer = '<table style="width:100%;color:#ccc;background:#17479d;padding:5px 0px;margin:0px;">
								<tr>
							<td width="30%"><span style="float:left!important;margin-left:10px;">Printed by: ' . $name . '&nbsp;' . $current_date . '</span></td>
							<td style="text-align:center;width:30%;">www.nakumatt.net</td>
							<td  width="30%">&nbsp;</td>
								</tr>
							</table>
							<h4 style="color:red;">The content is confidential and not meant to be shared in any form with any external persons / entities.</h4>
							</body>
							</html>';
				$html = $header . $content . $footer;
				$dompdf->load_html($html);
				// (Optional) Setup the paper size and orientation
				$dompdf->set_paper('A4', 'landscape');
				// Render the HTML as PDF
				$dompdf->render();
				// Output the generated PDF to Browser
				$filename = "Volume of Cases " . date('Y-m-d:H:i:s') . ".pdf";
				$dompdf->stream($filename);			
			   //pdf report
			 //pdf report
			
		   }  
	   
		  
	   }
		 
		 
    }
  
    /////END of the code for report Member Tier
    
	 public function getExportContentsummeryreport($_QueryFD,$_QueryTD,$_QueryPer,$_QueryORI,$_QueryCat,$_QuerySubCat,$_QueryReportType,$_Mstart,$_Mend
		  ,$_Wstart,$_Wend, $_Qstart,$_Qend,$_Branchstore,$_Qfromyear,$_Qtoyear)
	 {
	    global $db, $app_list_strings;
		global $sugar_config;
		$ReportName = 'volumecc';
        $this->view = 'volumecc';
        $this->view_object_map['getAllCaseCategory'] = $this->getAllCaseCategory();
        $this->view_object_map['getTimePeriod'] = $this->getTimePeriod();
		$this->view_object_map['site_url'] = $sugar_config['site_url'];
        $volumecc = $queryCase = $_Yearquery= $_ColumnsDate=$volumeDate=$_DailyLoopC=$_DateEnteredArray
		=$volumecc_grid=$_NoOfQuarters=$_GetOneQuarters=array();
		$_WeeklyGlobal = $_QuaterlyGlobal = $_MonthGlobal = 0;
        $condition = $condition_group='';
		
		
		if ($_Qfromyear && $_Qtoyear) {
		    $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
			$from = $_Qfromyear;
			$to = $_Qtoyear;		
			if ($_Qfromyear != $_Qtoyear) {
			$end_date = $_curdate;
			$start_date = date('Y-m-1', strtotime("-1 year"));
			} else {
			$start_date = date('Y-m-d', strtotime("$from-01-01"));
			$end_date = date('Y-m-d', strtotime("$from-12-31"));
			}
			$condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($start_date)) . "' AND '" . date("Y-m-d", strtotime($end_date)) . "' AND ";
			}else
		{
			if ($_QueryFD && $_QueryTD) {
			$condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($_QueryFD)) . "' AND '" . date("Y-m-d", strtotime($_QueryTD)) . "' AND ";
			}
		}
		
		 if ($_QueryCat == "all") {
			$condition .= "";
			$condition_group .= "";
		 }else
		 {
			 $condition .= "  cases_cstm.category_c = '" . $_QueryCat . "' AND ";
			$condition_group .= ",cases_cstm.category_c";
		 }
		if ($_QueryORI == "all")  {
			$condition .= " ";
			$condition_group .= "";
		}else
		 {
			$condition .= "  cases_cstm.origin_c = '" . $_QueryORI . "'  AND ";
			$condition_group .= ",cases_cstm.origin_c";
		 }
		if ($_QuerySubCat  == "all") {
			$condition .= " ";
			$condition_group .= "";
		}else
		 {
			$condition .= "  cases_cstm.subcategory_c = '" . $_QuerySubCat. "'  AND ";
			$condition_group .= ",cases_cstm.subcategory_c";
		 }
		 
		 
		if ($_Branchstore == "all"  || $_Branchstore == "" )  {
		 $condition .= " ";
		 $condition_group .= " ";
		}else
		{
		 $condition .= "  cases.branch_store_name = '" . $_Branchstore . "'  AND ";
		 $condition_group .= ",cases.branch_store_name";
		}
				
		 if(!empty($_Mstart)):
				  $_StartMonth = $_Mstart;
				endif;
				
				if(!empty($_Mend)):
				   $_EndMonth = $_Mend;
				endif;
				
				if(!empty($_Wstart)):
				  $_StartW = $_Wstart;
				endif;
				
				if(!empty($_Wend)):
				 echo  $_EndW = $_Wend;
				endif;
				
				if(!empty($_Qstart)):
				  $_StartQ = $_Qstart;
				endif;
				
				if(!empty($_Qend)):
				  $_EndQ = $_Qend;
				endif;
		 
		 if($_QueryPer == "daily"):
		 
		  $_DailyLoopCount = $this->datediff('d',date("y-m-d",strtotime($_QueryFD)),date("y-m-d",strtotime($_QueryTD)));				 

						for($i=0;$i<=$_DailyLoopCount;$i++)
						{
						$_DailyLoopC[] =  date ("Y-m-d", strtotime("+$i day", strtotime($_QueryFD)));
						}
						
				     $condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_QueryFD)) . "' AND '" . date("y-m-d",strtotime($_QueryTD)) . "' AND ";
						
								
								
					  $query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where " . $condition . " cases.deleted=0  group by date(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
							
						$result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
                        $row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecc[] = $row;
					    $volumeDate[] = date("Y-m-d",strtotime($row['date_entered']));
						}
						else:
						$row['emptyrecord'] = "N/A";
                       // $volumecsa[] = $row;
						endif;
		  
		 
		 
		 elseif($_QueryPer == "weekly"):
		      
				
		 elseif($_QueryPer == "monthly"):
				        $_MonthGlobal = 1;
				        
						$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
						$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
						$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
						$start_date  = $_Year."-".$_Month."-"."1";  //start date
						$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
						$_MonthLoopCount = $this->datediff('m',date("y-m-d",strtotime($start_date )),date("y-m-d",strtotime($end_date)));				 
						/*month logic end */
						for($i=0;$i<=$_MonthLoopCount+1;$i++)
						{
						$_DailyLoopC[] =  date ("M-Y", strtotime("+ $i month", strtotime($start_date)));
						}
						
				       
						$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";
					    $query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
							. "cases_cstm.member_tier_c,"
							. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
							. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
							. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
							. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
							. " cases.date_entered , cases.assigned_user_id FROM cases "
							. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
							. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
							. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
							. " where " . $condition . " cases.deleted=0  group by month(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
						$result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['date_entered'] = date("M-Y",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
						$volumecc[] = $row;
						}
						else:
						$row['emptyrecord'] = "N/A";
						// $volumecc[] = $row;
						endif;
		 elseif($_QueryPer == "quarterly"):
				
		 $_QuaterlyGlobal =1;
				/*quater logic start*/
			    $_OpenQ =$_StartW ;
			    $_EndQ = $_EndW ;
				/* end */ 
				$_StartW = 
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				
				$this->view_object_map['creatQudd'] = $this->creatQuarterdd($start_date,$end_date);
				//echo "<pre>";
				//print_r($this->view_object_map['creatQudd'] );
                
				$_GetQuarters = $this->creatQuarterdd($start_date,$end_date);

				foreach($_GetQuarters as $_GetQuarters1Key=>$_GetQuarters1)
				{
				$_Startq = explode("_",$_GetQuarters1Key); 
				
				$_DailyLoopC[$_GetQuarters1Key] = $_GetQuarters1;
				$_GetPeroid[$_GetQuarters1Key."_".$_GetQuarters1]= $this->checkReportPeriodQuarter($condition,$condition_group,$_Startq[0],$_Startq[1],$ReportName);

                }	
				
					if(date("m") <= 06){
						$_CurrentYear = date("Y"); // current year
						$_NextYears =  date("Y")-1; //previous year 
						
						$start_date =  date($_NextYears.'-07-01'); //common from date
						$end_date =  date($_CurrentYear.'-06-30'); 

						}
						else{
						$_CurrentYear =  date("Y"); // current year
						$_NextYears  =  date("Y") + 1;  // post year
						$start_date =  date($_CurrentYear.'-07-01'); //common from date
						$end_date =  date($_NextYears.'-06-30'); 
						
					}
					
				
			    $query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where " . $condition . " cases.deleted=0  group by QUARTER(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
				
				        $result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['date_entered'] = date("Y",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecc[] = $row;
						}
						else:
						$row['emptyrecord'] = "N/A";
                       // $volumecc[] = $row;
						endif;
		 elseif($_QueryPer == "annual"):
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
				$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
			    $start_date  = $_Year."-".$_Month."-"."1";  //start date
				$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
				$_CurrentYear = date("Y"); // current year
				$_PreviousYears = date("Y")-1; //previous year 
				if ($_Qfromyear!= $_Qtoyear) {
					$_Year =  array($_PreviousYears,$_CurrentYear);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}else{
				    $_Year =  array($_Qfromyear);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}

				
                //$_YearlyLoopCount = $this->datediff('yyyy',date("y-m-d",strtotime($_REQUEST['from_date'])),date("y-m-d",strtotime($_REQUEST['to_date'])));
                
				$from = $_Qfromyear;
				$to = $_Qtoyear;
				
				if ($_Qfromyear != $_Qtoyear) {
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				} else {
				$start_date = date('Y-m-d', strtotime("$from-01-01"));
				$end_date = date('Y-m-d', strtotime("$from-12-31"));
				}
				
				
				 $query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where " . $condition . " cases.deleted=0  group by year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
				
				$result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['date_entered'] = date("Y",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecc[] = $row;
						}
						else:
						$row['emptyrecord'] = "N/A";
                       // $volumecc[] = $row;
						endif;
		 
		 
		 endif;

		$_DateEntered1ArrayMyt = array();
		$_DateEntered1ArrayTotalfor = "";
	    if($_WeeklyGlobal == 1)
		{
					if(count($volumecc)):
						 foreach($volumecc as $volumeccData)
						 {
							$_DateEntered1Array[$volumeccData['date_entered']] = $volumeccData['date_entered']."_".$volumeccData['category_c']."_".$volumeccData['origin_c']."_".$volumeccData['count(cases.id)'];
						 }
					endif;
				}
		else{
					if(count($volumecc)):
					
						 foreach($volumecc as $volumeccData)
						 {
							$_DateEnteredArray[] = $volumeccData['date_entered'];
							$_DateEntered1Array[$volumeccData['date_entered']] = array($volumeccData['date_entered'],$volumeccData['category_c'],$volumeccData['origin_c'],$volumeccData['count(cases.id)']);
						    $_DateEntered1ArrayMyt[$volumeccData['date_entered']]+= $volumeccData['count(cases.id)'];  //myt total arraycount
							$_DateEntered1ArrayTotalfor = $volumeccData['count(cases.id)']; 

						 }
					endif;
		}
						//print_r($volumecc);
						//print_r($_DateEntered1ArrayMyt);
		if($_QueryPer == 'monthly'){//for month start

			     $_MonthStartArray = array_keys($_DailyLoopC,$_StartMonth);
				 $_MonthEndArray =  array_keys($_DailyLoopC,$_EndMonth);
				 $_Totvalue = $_MonthEndArray[0]-$_MonthStartArray[0];
			     $_DailyLoopC = array_slice($_DailyLoopC,$_MonthStartArray[0],$_Totvalue+1);
				 //for month end
				}
		
		 if(!empty($_DateEntered1Array)):
				 foreach($_DateEntered1Array as $_DateEntered1Array1)
				 {
				  $_yearRecord[]  = $_DateEntered1Array1[3];
				 }
		 endif;
				 
		 $i = 1;
                if(count($_DailyLoopC) > 0):
				if($_QuaterlyGlobal==1):
				$_OpenQua = array();
				for($_OpenQ;$_OpenQ<=$_EndQ;$_OpenQ++){
				$_OpenQua[] = $_OpenQ;
				}
				$temp2 = array();
				//for($p = $_StartQ; $p <= $_EndQ; $p++){
				//$temp2[] = $p;
				//}
				foreach($_GetPeroid as $_GetPeroidKey => $_GetPeroidData)
					 { 
					// if($_QueryPer == 'quarterly'):
					 ////if(!in_array($i,$temp2)){
					// $i++;
						//continue;
						
					// }
					// endif;
					 $_GetPeroidDisaply = $_GetPeroidKey;
					 $_GetPeroidDisaply =  explode("_",$_GetPeroidDisaply);
					 
					 $_Qendate = date ("Y-m-d", strtotime("+ 3 month", strtotime($_GetPeroidKey)));
					 $_GetPeroidSd = date("M y",strtotime($_GetPeroidKey));
					 $_GetPeroided = date("M y",strtotime($_Qendate));
					 if($_REQUEST['category_id'] == 'all'):
						$_Catname = 'All';
					 else:
						$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
					 endif;
					 if(in_array($_GetPeroidDisaply[2],$_OpenQua)):
					 $_GetPeroidKey = explode("_",$_GetPeroidKey);
					 if($_GetPeroidData==0):
					 $volumecc_grid[] = array($_GetPeroidKey[3], 0);
					 else:
				     $volumecc_grid[] = array($_GetPeroidKey[3],$_GetPeroidData);
					 endif;
					  endif;
				     $i++;}
                else:
                   $temp2 = array();
						for($p = $_StartW ; $p <= $_EndW ; $p++){
						$temp2w[] = $p;
						}
						
						foreach($_DailyLoopC as $_DailyLoopCDataKey => $_DailyLoopCData)
					 { 
					 
					 if($_QueryPer == 'weekly'):
					 if(!in_array($i,$temp2w)){
					 $i++;
						continue;
						
					 }
					  endif;
				   if($_WeeklyGlobal == 1):
						/*weekly interval*/
						
					    $_WeekStartdate = $_DailyLoopCData; //weekly date start
					    $_WeekEnddate =  date("Y-m-d", strtotime("+ 1 week", strtotime($_DailyLoopCData))); //weekly date ended
					    $_WeekEnddate =  date("Y-m-d", strtotime("-1 day", strtotime($_WeekEnddate)));
						$_WeekDateInterval = $this->returnBetweenDates($_WeekStartdate, $_WeekEnddate); 
					    $_GetPeroid = $this->checkReportPeriodreportcc($condition,$condition_group,$_WeekStartdate,$_WeekEnddate);
						
						$_WeekStartdate = date("d M Y",strtotime($_WeekStartdate));
						$_WeekEnddate = date("d M Y",strtotime($_WeekEnddate));
						
						if($_REQUEST['category_id'] == 'all'):
						$_Catname = 'All';
						else:
						$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
						endif;
						if($_GetPeroid==0):
							$volumecc_grid[] = array("week ".$i." (".$_WeekStartdate." - ".$_WeekEnddate.")",0);
							
						else:
							$volumecc_grid[] = array("week ".$i." (".$_WeekStartdate." - ".$_WeekEnddate.")",$_GetPeroid);
							
						
                        endif;						
                      /*weekly interval*/
						
					elseif($_MonthGlobal ==1):

					if($_REQUEST['category_id'] == 'all'):
						$_Catname = 'All';
						else:
						$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
						endif;
						
						
						if (in_array($_DailyLoopCData,$_DateEnteredArray))
						{
						//$key = array_search($_DailyLoopCData, $_DateEnteredArray);
						 $volumecc_grid[] = array($_DailyLoopCData,$_DateEntered1Array[$_DailyLoopCData][3]);
						}
						else
						{
						 $volumecc_grid[] = array($_DailyLoopCData,0);  
						}
					
					
                    else:
						if($_REQUEST['category_id'] == 'all'):
						$_Catname = 'All';
						else:
						$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
						endif;
						
						
						if (in_array($_DailyLoopCData,$_DateEnteredArray))
						{
						
						  $volumecc_grid[] =  array($_DailyLoopCData,$_DateEntered1ArrayTotalfor);
						}else
						{
						  $volumecc_grid[] =  array($_DailyLoopCData,0);
						}
					endif;
					    //echo $_DailyLoopCData[$i]."checkarrayindex".$_DailyLoopCData[$i+1]."<br>"; 
						
					$i++;	}

				endif;
				else:
                   if($_QuaterlyGlobal==1):
				   foreach($_GetOneQuarters as $_GetPeroidKey=>$_GetPeroidVal):
                      if($_GetPeroidVal==0):
						$volumecc_grid[] = "<tr><td>".$_GetPeroidKey."</td>
						<td colspan=3>We can't find records for this period</td>
						</tr>";
					   else:
						$volumecc_grid[] = "<tr><td>".$_GetPeroidKey."</td>
						<td>".""."</td>
						<td>".""."</td>
						<td onclick='checkclick(this.title)' id=Dailydata_".$_GetPeroidKey." title=daily_".$_GetPeroidKey.">".$_GetPeroidVal."</td>
						</tr>";
					   endif;
						$volumecc_grid[] = "</tr>";
						$volumecc_grid[] ="<tr class=dailyresulthide id=dailyresult_".$_GetPeroidKey." style=display:none>
						<td colspan='4' class='parent-TD'>
						</td></tr>";
					endforeach;	
				   endif;
                endif;
				
				//die;
				///echo '<pre>';
				//print_r($volumecc_grid);die;
				 //$volumecc_grid = array_intersect_key($temp2, $volumecc_grid);
				 return $volumecc_grid;

		 }
	//Reports Unresolved cases
    
	public function getExportContentsummeryreportmt($_QueryPer,$_MemberTier,$_QueryCat,$_QueryORI,$_QueryReportBranchStore,$_QuerySubCat,$_QueryStatus,$_QueryReportType,$_QueryReportMonthStart,$_QueryReportMonthEnd
		,$_Qstart,$_Qend,$_Qfromyear,$_Qtoyear)
	{
	
        global $db, $app_list_strings,$sugar_config;
	    $Reportname = "membertier";
        $this->view = 'servicereportcasemembertier';
        $this->view_object_map['getAllCaseCategory'] = $this->getAllCaseCategory();
        $this->view_object_map['site_url'] = $sugar_config['site_url'];
        $membertier_cases = array();
		$volumecmt = $queryCase = $_Yearquery= $_ColumnsDate=$volumeDate=$_DailyLoopC=$_DateEnteredArray
		=$volumecc_grid=$_NoOfQuarters=$_GetOneQuarters=array();
		$_WeeklyGlobal = $_QuaterlyGlobal = $_MonthGlobal = 0;
        $condition = $condition_group= $_emptyGlobal=$_AnnualGlobal = '';

		   if ($_Qfromyear && $_Qtoyear) {
		    $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
			$from = $_Qfromyear;
			$to = $_Qtoyear;		
			if ($_Qfromyear != $_Qtoyear) {
			$end_date = $_curdate;
			$start_date = date('Y-m-1', strtotime("-1 year"));
			} else {
			$start_date = date('Y-m-d', strtotime("$from-01-01"));
			$end_date = date('Y-m-d', strtotime("$from-12-31"));
			}
			$condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($start_date)) . "' AND '" . date("Y-m-d", strtotime($end_date)) . "' AND ";
			}
			
			if ($_MemberTier == "all") {
				$condition .= "";
				$condition_group .= "";
				}else
				{
				$condition .= "  cases_cstm.member_tier_c = '" . $_MemberTier . "' AND ";
				$condition_group .= ",cases_cstm.member_tier_c";
				}
				
					
		
				if ($_QueryCat == "all") {
				$condition .= "";
				$condition_group .= "";
				}else
				{
				$condition .= "  cases_cstm.category_c = '" . $_QueryCat . "' AND ";
				$condition_group .= ",cases_cstm.category_c";
				}

				if ($_QueryORI == "all")  {
				$condition .= " ";
				$condition_group .= "";
				}else
				{
				$condition .= "  cases_cstm.origin_c = '" . $_QueryORI . "'  AND ";
				$condition_group .= ",cases_cstm.origin_c";
				}

				$_CaseBranchStorePdf = "";
				if($_QueryReportBranchStore == 'all' || $_QueryReportBranchStore == ""):
				$condition .= " ";
				$condition_group .= "";
				else:
				$condition .= "  cases.branch_store_name = '" . $_QueryReportBranchStore . "' AND ";
				$condition_group .= ",cases.branch_store_name";
				endif;
				
				
				if ($_QuerySubCat  == "all") {
				$condition .= " ";
				$condition_group .= "";
				}else
				{
				$condition .= "  cases_cstm.subcategory_c = '" . $_QuerySubCat. "'  AND ";
				$condition_group .= ",cases_cstm.subcategory_c";
				}


				if(!empty($_QueryReportMonthStart)):
				$_StartMonth = $_QueryReportMonthStart;
				endif;

				if(!empty($_QueryReportMonthEnd)):
				$_EndMonth = $_QueryReportMonthEnd;
				endif;

				if(!empty($_Wstart)):
				$_StartW = $_Wstart;
				endif;

				if(!empty($_Wend)):
				$_EndW = $_Wend;
				endif;

				if(!empty($_Qstart)):
				$_StartQ = $_Qstart;
				endif;

				if(!empty($_Qend)):
				$_EndQ = $_Qend;
				endif;
				
				

			    /*period logic starts from here*/
				if($_QueryPer == "monthly"):
				$_MonthGlobal = 1;
			    $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
				$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
				$start_date  = $_Year."-".$_Month."-"."1";  //start date
				$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
				$_MonthLoopCount = $this->datediff('m',date("y-m-d",strtotime($start_date )),date("y-m-d",strtotime($end_date)));				 
				/*month logic end */
				for($i=0;$i<=$_MonthLoopCount+1;$i++)
				{
				$_DailyLoopC[] =  date ("M-Y", strtotime("+ $i month", strtotime($start_date)));
				}
				
				$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";
			 	 $default_query_case = "SELECT count(cases.id),cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, 
				LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,
				cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT 
				JOIN users jt0 ON cases.assigned_user_id=jt0.id   LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id AND jt0.deleted=0 AND jt0.deleted=0"
				. " where " . $condition . " cases.deleted=0 group by month(cases.date_entered)".$condition_group." ORDER BY cases.date_entered DESC";
				$result = $db->query($default_query_case);
				$total = $result->num_rows;
				if($total > 0):
				while ($row = $db->fetchByAssoc($result)) {
				$row['date_entered'] = date("M-Y",strtotime($row['date_entered']));
				$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
				$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
				$volumecmt[] = $row;
				}
				else:
				$row['emptyrecord'] = "N/A";
				// $volumecc[] = $row;
				endif;
			  elseif($_QueryPer == "quarterly"):
			   /*quater logic start*/
				$_Start_Q = explode("_",$_StartQ);
				$_OpenQ = $_Start_Q[2];
				$_End_Q = explode("_",$_EndQ);
				$_EndQ = $_End_Q[2];
				/* end */ 
				$_QuaterlyGlobal =1;
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				
				$this->view_object_map['creatQudd'] = $this->creatQuarterdd($start_date,$end_date);
				//echo "<pre>";
				//print_r($this->view_object_map['creatQudd'] );
                
				$_GetQuarters = $this->creatQuarterdd($start_date,$end_date);

				foreach($_GetQuarters as $_GetQuarters1Key=>$_GetQuarters1)
				{
				$_Startq = explode("_",$_GetQuarters1Key); 
				
				$_DailyLoopC[$_GetQuarters1Key] = $_GetQuarters1;
				$_GetPeroid[$_GetQuarters1Key."_".$_GetQuarters1] = $this->checkReportPeriodQuarter($condition,$condition_group,$_Startq[0],$_Startq[1],'membertier');

                }	
				$default_query_case = "SELECT count(cases.id),cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, 
				                      LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,
									  cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT 
									  JOIN users jt0 ON cases.assigned_user_id=jt0.id  LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id AND jt0.deleted=0 AND jt0.deleted=0"
                                      . " where " . $condition . " cases.deleted=0 group by QUARTER(cases.date_entered)".$condition_group." ORDER BY cases.date_entered DESC";

							$result = $db->query($default_query_case);
							$total = $result->num_rows;
							if($total > 0):
							while ($row = $db->fetchByAssoc($result)) {
							$row['date_entered'] = date("m-Y",strtotime($row['date_entered']));
							$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
							$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
							$volumecmt[] = $row;
							}
							else:
							$row['emptyrecord'] = "N/A";
							// $volumecc[] = $row;
							endif;
			  
			  elseif($_QueryPer == "annual"):
			  $_AnnualGlobal = 1;	
			  
			         $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
				$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
			    $start_date  = $_Year."-".$_Month."-"."1";  //start date
				$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
				$_CurrentYear = date("Y"); // current year
				$_PreviousYears = date("Y")-1; //previous year 
				if ($_Qfromyear!= $_Qtoyear) {
					$_Year =  array($_PreviousYears,$_CurrentYear);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}else{
				    $_Year =  array($_Qfromyear);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}

				
                //$_YearlyLoopCount = $this->datediff('yyyy',date("y-m-d",strtotime($_REQUEST['from_date'])),date("y-m-d",strtotime($_REQUEST['to_date'])));
                
				$from = $_Qfromyear;
				$to = $_Qtoyear;
				
				if ($_Qfromyear != $_Qtoyear) {
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				} else {
				$start_date = date('Y-m-d', strtotime("$from-01-01"));
				$end_date = date('Y-m-d', strtotime("$from-12-31"));
				}
			     $default_query_case = "SELECT count(cases.id),cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, 
				                      LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,
									  cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases 
									  LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c 
									  LEFT  JOIN users jt0 ON cases.assigned_user_id=jt0.id 
									  LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id 
									  AND jt0.deleted=0 AND jt0.deleted=0"
                                      . " where " . $condition . " cases.deleted=0 group by year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered DESC";
					$result = $db->query($default_query_case);
					$total = $result->num_rows;
					if($total > 0):
					while ($row = $db->fetchByAssoc($result)) {
					$row['date_entered'] = date("Y",strtotime($row['date_entered']));
					$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
					$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
					$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
					$volumecmt[] = $row;
					}
					else:
					$row['emptyrecord'] = "N/A";
					// $volumecc[] = $row;
					endif;		
              endif;
			 /*period logic end here*/
				if($_QueryPer == 'monthly'){//for month start

			     $_MonthStartArray = array_keys($_DailyLoopC,$_StartMonth);
				 $_MonthEndArray =  array_keys($_DailyLoopC,$_EndMonth);
				 $_Totvalue = $_MonthEndArray[0]-$_MonthStartArray[0];
			     $_DailyLoopC = array_slice($_DailyLoopC,$_MonthStartArray[0],$_Totvalue+1);
				 //for month end
				}
			$_DateEntered1ArrayMyt = array();
		    $_DateEntered1ArrayTotalfor = "";
			if(!empty($_DateEntered1Array)):
				 foreach($_DateEntered1Array as $_DateEntered1Array1)
				 {
				  $_yearRecord[]  = $_DateEntered1Array1[3];
				 }
			endif;
			   if(count($volumecmt)):
						 foreach($volumecmt as $volumeccData)
						 {
							$_DateEnteredArray[] = $volumeccData['date_entered'];
							$_DateEntered1Array[$volumeccData['date_entered']] = array($volumeccData['date_entered'],$volumeccData['category_c'],$volumeccData['origin_c'],$volumeccData['count(cases.id)']);
							$_DateEntered1ArrayTotalfor = $volumeccData['count(cases.id)']; 

							$_DateEntered1ArrayMyt[$volumeccData['date_entered']]+= $volumeccData['count(cases.id)'];  //myt total arraycount
						 }
					endif;
				
			if(!empty($_DateEntered1Array)):	
			 foreach($_DateEntered1Array as $_DateEntered1Array1)
			 {
			  $_yearRecord[]  = $_DateEntered1Array1[3];
			 }
			 endif;
		   $i = 1;	
		   if(count($_DailyLoopC) > 0):
		   
		   if($_QuaterlyGlobal ==1):
		   $temp2 = array();
				//for($p = $_StartQ; $p <= $_EndQ; $p++){
				//$temp2[] = $p;
				//}
				$_OpenQua = array();
                for($_OpenQ;$_OpenQ<=$_EndQ;$_OpenQ++){
			     $_OpenQua[] = $_OpenQ;
				}
				
				$_GetPeroidDisaply = $_GetPeroidKey;
				$_GetPeroidDisaply =  explode("_",$_GetPeroidDisaply);
								
				foreach($_GetPeroid as $_GetPeroidKey => $_GetPeroidData)
					{
							//if($_QueryPer == 'quarterly'):
							// if(!in_array($i,$temp2)){
							 //$i++;
							//	continue;
								
							// }
							// endif;
							 
							 $_GetPeroidDisaply = $_GetPeroidKey;
					         $_GetPeroidDisaply =  explode("_",$_GetPeroidDisaply);
							 $_Qendate = date ("Y-m-d", strtotime("+ 2 month", strtotime($_GetPeroidKey)));
							 $_GetPeroidSd = date("M y",strtotime($_GetPeroidKey));
							 $_GetPeroided = date("M y",strtotime($_Qendate));
							 if($_REQUEST['category_id'] == 'all'):
								$_Catname = 'All';
							 else:
								$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
							 endif;
							if(in_array($_GetPeroidDisaply[2],$_OpenQua)):
							$_GetPeroidKey = explode("_",$_GetPeroidKey);
							if($_GetPeroidData==0):
							$membertier_cases[] = array($_GetPeroidKey[3], 0);
							else:
							$membertier_cases[] = array($_GetPeroidKey[3],$_GetPeroidData);
							endif;
							endif;
							 
							 $i++;
					 }
		   elseif($_MonthGlobal ==1):
		   
		   foreach($_DailyLoopC as $_DailyLoopCDataKey => $_DailyLoopCData)
			{
							if($_QuerySubCat == 'all'):
							$_Catname = 'All';
							else:
							$_Catname = $this->getCaseCategoryName($_QuerySubCat);
							endif;


							if (in_array($_DailyLoopCData,$_DateEnteredArray))
							{
							//$key = array_search($_DailyLoopCData, $_DateEnteredArray);
							$membertier_cases[] = array($_DailyLoopCData,$_DateEntered1ArrayMyt[$_DailyLoopCData]);
							}
							else
							{
							$membertier_cases[] = array($_DailyLoopCData,0);  
							}
							$i++; 
			}		
		 elseif($_AnnualGlobal == 1): 
			foreach($_DailyLoopC as $_DailyLoopCDataKey => $_DailyLoopCData)
						{
							if($_QuerySubCat == 'all'):
							$_Catname = 'All';
							else:
							$_Catname = $this->getCaseCategoryName($_QuerySubCat);
							endif;
							if (in_array($_DailyLoopCData,$_DateEnteredArray))
							{

							$membertier_cases[] =  array($_DailyLoopCData,$_DateEntered1ArrayTotalfor);
							}else
							{
							$membertier_cases[] =  array($_DailyLoopCData,0);
							}
							$i++;
			            }
		  endif;
		  
		endif;
	 
	// echo '<pre>';
	// print_r($membertier_cases);die;
	return $membertier_cases;
      
        $this->view_object_map['membertier_cases'] = $membertier_cases;
	  
	}
     
    //Reports Unresolved cases

    public function getExportContentCSR($_QueryFD, $_QueryTD, $_QueryPer, $_QueryORI,$_QueryReportBranchStore, $_QueryCat, $_QuerySta, $_QueryMem, $_Subcat ,$_QueryPri) {
	
        global $db, $app_list_strings, $sugar_config;
        $volumeucr = $queryCase = $_Yearquery = $_ColumnsDate = $volumeDate = $_DailyLoopC = $_DateEnteredArray = $volumeucr_grid = $_NoOfQuarters = $_GetOneQuarters = $volumeucr_grid1 = array();
        $_WeeklyGlobal = $_QuaterlyGlobal = $_MonthGlobal = $_DailyGlobal = $_YearlyGlobal = 0;
        $condition = $condition_group = '';
        $volumecsr_grid = array();
        if ($_QueryFD || $_QueryPer || $_QueryORI || $_QueryReportBranchStore || $_QueryTD || $_QueryCat || $_QuerySta || $_QueryMem || $_Subcat || $_QueryPri) {

           
		   if ($_QueryCat == "all") {
                    $condition .= "";
				 }else
				 {
				    $condition .= "  cases_cstm.category_c = '" . $_QueryCat . "' AND ";
				 }
				 
				 
				if ($_QueryORI  == "all")  {
                    $condition .= " ";
                }else
				 {
				    $condition .= "  cases_cstm.origin_c = '" . $_QueryORI  . "'  AND ";
				 }
				 
				 if ($_QueryReportBranchStore  == "all" || $_QueryReportBranchStore  == "")  {
                    $condition .= " ";
                }else
				 {
				    $condition .= "  cases.branch_store_name = '" . $_QueryReportBranchStore  . "'  AND ";
				 }
				 
				 
				 if ($_Subcat  == "all") {
                    $condition .= " ";
                }else
				 {
				    $condition .= "  cases_cstm.subcategory_c = '" . $_Subcat . "'  AND ";
				 }
				 
				
				if ($_QueryMem == "all") {
                    $condition .= "";
				 }else
				 {
				    $condition .= "  cases_cstm.member_tier_c = '" . $_QueryMem . "' AND ";
				 }
				 
				if ($_QuerySta  == "all") {
                    $condition .= " ";
                }else
				 {
				    $condition .= "  cases.status = '" . $_QuerySta . "'  AND ";
				 }
				 
				 
			     if ($_QueryPri  == "all") {
                    $condition .= " ";
                }else
				 {
				    $condition .= "  cases.priority = '" . $_QueryPri . "'  AND ";
				 }
				 
				$_Status = $_QuerySta;
				$_Membertier = $_QueryMem;


            /* checking query starting */
            $start_date = date("Y-m-d", strtotime($_QueryFD));
            $end_date = date("Y-m-d", strtotime($_QueryTD));

            if ($_QueryPer == "daily"):
                $_DailyGlobal = 1;
                $_DailyLoopCount = $this->datediff('d', $start_date, $end_date);

                for ($i = 0; $i <= $_DailyLoopCount; $i++) {
                    $_DailyLoopC[] = date("Y-m-d", strtotime("+$i day", strtotime($start_date)));
                }

                if ($start_date && $end_date) {
                    $condition .= "  DATE(cases.date_entered) BETWEEN '" . date("y-m-d", strtotime($start_date)) . "' AND '" . date("y-m-d", strtotime($end_date)) . "' AND ";
                }

				
                $query_query = "SELECT cases.id,cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority,cases.status,"
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where " . $condition . " cases.deleted=0  ORDER BY cases.date_entered ASC";
				
								
                $result = $db->query($query_query);
                $total = $result->num_rows;
                if ($total > 0):
                    while ($row = $db->fetchByAssoc($result)) {
                            $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                            $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                            $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                            $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                            $volumecsr[] = $row;
                            $volumeDate[] = date("Y-m-d", strtotime($row['date_entered']));
                        }
                else:
                    $row['emptyrecord'] = "N/A";
                endif;
              endif;
			  

              if(count($volumecsr) > 0):
			   foreach($volumecsr as $volumecsrData):
			            $volumecc_grid1["case_id"] = $volumecsrData['case_number'];
						$volumecc_grid1["date_entered"] = $volumecsrData['date_entered'];
						$volumecc_grid1["category_c"] = $volumecsrData['category_c'];
                        $volumecc_grid1["member_tier"] = $volumecsrData['member_tier_c'];
						$volumecc_grid1["origin_c"] = $volumecsrData['origin_c'];
						$volumecc_grid1["status"] = $volumecsrData['status'];
						$volumecc_grid1["priority"] = $volumecsrData['priority'];	
						$volumecsr_grid[] = $volumecc_grid1;
					
               endforeach;
              endif;			  
			
            /* checking query ending */
        }

        return $volumecsr_grid;

        if (isset($total) > 0) {
            $this->view_object_map['total_cases'] = $total;
        } else {
            $this->view_object_map['total_cases'] = 0;
        }
    }

    public function action_exportvolumecsr() {
        global $db, $app_list_strings;
        $condition = $_QueryFD =$_QueryPriority =  $_QueryTD = $_QueryPer = $_QueryORI = $_QueryCat = $_QuerySta = $_QueryMem = $_QuerySubcat=$_QueryReportBranchStore="";

        if (isset($_REQUEST['queryfromdate'])) {
            $_QueryFD = $_REQUEST['queryfromdate'];
        }

        if (isset($_REQUEST['querytodate'])) {
            $_QueryTD = $_REQUEST['querytodate'];
        }

        if (isset($_REQUEST['queryPeriod'])) {
            $_QueryPer = $_REQUEST['queryPeriod'];
        }

        if (isset($_REQUEST['queryorigin'])) {
            $_QueryORI = $_REQUEST['queryorigin'];
        }

        if (isset($_REQUEST['querycategory'])) {
            $_QueryCat = $_REQUEST['querycategory'];
        }
        if (isset($_REQUEST['querystatus'])) {
            $_QuerySta = $_REQUEST['querystatus'];
        }
        if (isset($_REQUEST['querymembertier'])) {
            $_QueryMem = $_REQUEST['querymembertier'];
        }
		if (isset($_REQUEST['querysubcategory'])) {
            $_QuerySubcat= $_REQUEST['querysubcategory'];
        }
		if (isset($_REQUEST['querypriority'])) {
            $_QueryPriority= $_REQUEST['querypriority'];
        }
		
		 if(isset($_POST['queryBranchStore']))
		 {
		  $_QueryReportBranchStore =  $_POST['queryBranchStore'];
		} 	
		

        $_dataColumns = $this->getExportContentCSR($_QueryFD, $_QueryTD, $_QueryPer, $_QueryORI,$_QueryReportBranchStore, $_QueryCat, $_QuerySta, $_QueryMem,$_QuerySubcat,$_QueryPriority);  //calling function to get export data
//echo "<pre>";
//print_r( $_dataColumns );die;
        if ($_POST['file_type'] == 'csv') { //Export CSV
            //CSV File name and Header
            $filename = "case_status_report" . date('Y-m-d:H:i:s') . ".csv";
            $fp = fopen('php://output', 'w');
            $header = array('Date', 'Case ID', 'Case Category', 'Case Origin','Case Priority', 'Case Status');
            header('Content-type: application/csv');
            header('Content-Disposition: attachment; filename=' . $filename);
            fputcsv($fp, $header);
            $condition = "";
            $export_list_case = array();
            foreach ($_dataColumns as $_dataColumns1Val):
                $row['date_entered'] = $_dataColumns1Val['date_entered'];
                $row['case_number'] = $_dataColumns1Val['case_id'];
                $row['category_c'] = $_dataColumns1Val['category_c'];
				$row['origin_c'] = $_dataColumns1Val['origin_c'];
                $row['priority'] = $_dataColumns1Val['priority'];
                $row['status'] = $_dataColumns1Val['status'];
                $row['estimate_resolution_date'] = $_dataColumns1Val['estimate_resolution_date'];
                $row['case_age'] = $_dataColumns1Val['case_age'];
                $export_list_case[] = $row;
                fputcsv($fp, $row); //Genrate CSV
            endforeach;
            fclose($fp);
            exit;
        } elseif ($_POST['file_type'] == 'xls') { //Export XLS
            $list = array();
            $list['tableheading'] =array('Date', 'Case ID', 'Case Category', 'Case Origin','Case Priority', 'Case Status');
            $fichier = "case_status_report" . date('Y-m-d:H:i:s') . ".xls";
            header("Content-Type: text/csv;charset=utf-8");
            header("Content-Disposition: attachment;filename=\"$fichier\"");
            header("Pragma: no-cache");
            header("Expires: 0");
            $fp = fopen('php://output', 'w');
            fputcsv($fp, $list['tableheading']);
            //Fetch data
            foreach ($_dataColumns as $_dataColumns1Val):
                $row['date_entered'] = $_dataColumns1Val['date_entered'];
                $row['case_number'] = $_dataColumns1Val['case_id'];
                $row['category_c'] = $_dataColumns1Val['category_c'];
				$row['origin_c'] = $_dataColumns1Val['origin_c'];
                $row['priority'] = $_dataColumns1Val['priority'];
                $row['status'] = $_dataColumns1Val['status'];
                $row['estimate_resolution_date'] = $_dataColumns1Val['estimate_resolution_date'];
                $row['case_age'] = $_dataColumns1Val['case_age'];
                $data['list'] = $row;
                //$export_list_case[] = $row;
                fputcsv($fp, $data['list']); //Genrate CSV
            endforeach;
            fclose($fp);
            exit();
        }else if($_POST['file_type'] == 'pdf')
		{
               require_once 'include/dompdf/dompdf_config.inc.php';
			   global $current_user;
			   $name = $current_user->first_name . '&nbsp;' . $current_user->last_name;
			   $current_date = date('d/m/Y  h:i A');
			   $dompdf = new Dompdf();
			   //echo '<pre>';
			   //print_r($_dataColumns);
			  // die;
			  
			
			   $_CaseOriginPdf = $_CaseOriginCat = "";
			   if($_QueryORI == 'all'):
			    $_CaseOriginPdf = 'All';
			   else:
			    $_CaseOriginPdf = $this->getCaseOriginName($_QueryORI);
			   endif;
			   
			   $_CaseBranchStorePdf = "";
			   if($_QueryReportBranchStore == 'all'):
			    $_CaseBranchStorePdf = 'All';
			   else:
			    $_CaseBranchStorePdf = $_QueryReportBranchStore;
			   endif;
			   
			   if($_QueryCat == 'all'):
			    $_CaseOriginCat = 'All';
			   else:
			    $_CaseOriginCat = $this->getCaseCategoryName($_QueryCat);
			   endif;
			   
			   if($_REQUEST['querysubcategory'] == 'all'):
			    $_CaseOriginSubCat = 'All';
			   else:
			    $_CaseOriginSubCat = $this->getCaseSubCategoryName($_REQUEST['querysubcategory']);
			   endif;

						   
			   if($_POST['querystatus'] == 'all'):
			    $_CaseStatus = 'All';
			   else:
			    $_CaseStatus = $_POST['querystatus'];
			   endif;
			   $header = '<html>
            <body>
                <div style="width:100%;color:#fff;background:#17479d;padding:5px 0px;margin:0px;text-align:center;">
                    <img src="custom/include/images/logo.png" style="padding: 7px;position: absolute;left: 10px;"><h2>Case Status Report </h2>
                </div>
				<br />
				<table style="width:450px; margin:0 auto; text-align:left;">
				    <tr>
						<td style="width="20%"><b>From  - </b></td>
						<td style="width="10%">'.$_QueryFD.'</td>
						<td style="width="20%"><b>To  - </b></td>
						<td style="width="10%">'.$_QueryTD.'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Period  - </b></td>
						<td style="width="50%">'.ucfirst($_QueryPer).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Origin  - </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginPdf).'</td>
					</tr>
					';
					 if($_QueryReportBranchStore == 'all'):
						 $header .= '<tr>
						<td style="width="50%"><b>Branch Store - </b></td>
						<td style="width="50%">All</td>
					</tr>';
						elseif($_QueryReportBranchStore == ''):
							 $header .= ''; 
					   else:
						 $header .= '<tr>
						<td style="width="50%"><b>Branch Store  - </b></td>
						<td style="width="50%">'.ucfirst($_QueryReportBranchStore).'</td>
					</tr>'; 
					   endif;
				 $header .= '
					<tr>
						<td style="width="50%"><b>Case Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginCat).'</td>
					</tr>

					<tr>
						<td style="width="50%"><b>Case Sub Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginSubCat).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Priority  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseStatus).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Status  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseStatus).'</td>
					</tr>
				</table>';
				
			    $content .= '<table border="1" cellspacing="0" cellpadding="5" width="100%">  
                    <thead>
                        <tr>
                            <th nowrap>Date</th>
							<th nowrap>Case Id</th>
							<th nowrap>Case Category</th>
							<th nowrap>Case Origin</th>
							<th nowrap>Case Priority</th> 
							<th nowrap>Case Status</th>
                        </tr>
                </thead>';
				
				foreach($_dataColumns as $_dataColumns1Val):
				    $content .= '<tbody>
                        <tr>
						  <td>' . $_dataColumns1Val["date_entered"] . '</td>
                          <td>' . $_dataColumns1Val["case_id"] . '</td>
						  <td>' . $_dataColumns1Val["category_c"] . '</td>
                          <td>' . $_dataColumns1Val["origin_c"] . '</td>
						  <td>' . $_dataColumns1Val["priority"] . '</td>
                          <td>' . $_dataColumns1Val["status"] . '</td>
                     </tr>
                    <tbody>';
				
				endforeach;
				$content .= '</table>';
				$footer = '<table style="width:100%;color:#ccc;background:#17479d;padding:5px 0px;margin:0px;">
								<tr>
							<td width="30%"><span style="float:left!important;margin-left:10px;">Printed by: ' . $name . '&nbsp;' . $current_date . '</span></td>
							<td style="text-align:center;width:30%;">www.nakumatt.net</td>
							<td  width="30%">&nbsp;</td>
								</tr>
							</table>
							<h4 style="color:red;">The content is confidential and not meant to be shared in any form with any external persons / entities.</h4>
							</body>
							</html>';
				$html = $header . $content . $footer;
				$dompdf->load_html($html);
				// (Optional) Setup the paper size and orientation
				$dompdf->set_paper('A4', 'landscape');
				// Render the HTML as PDF
				$dompdf->render();
				// Output the generated PDF to Browser
				$filename = "Case Status " . date('Y-m-d:H:i:s') . ".pdf";
				$dompdf->stream($filename);			
			   //pdf report
			
		  }
     }

    public function action_getdailydataucr() {
        global $db, $app_list_strings;
        $condition = "";
        if ($_POST['getperiod'] == 'daily'):
            //$_POST['daily'];
            if ($_POST['getcategory'] && empty($_POST['origin'])) {
                $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
            }
            if ($_POST['origin'] && empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
            }

            if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
            }
            if ($_POST['getmembertier']) {
                $condition .= " cases_cstm.member_tier_c = '" . $_POST['getmembertier'] . "' AND ";
            }
            if ($_POST['getstatus']) {
                $condition .= "  cases.status = '" . $_POST['getstatus'] . "'  AND ";
            }
            $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" . $_POST['daily'] . "' AND '" . $_POST['daily'] . "' AND";
            $queryDaily_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                    . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                    . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                    . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                    . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                    . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                    . " cases.date_entered , cases.assigned_user_id FROM cases "
                    . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                    . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                    . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                    . " where " . $condition . $conditiondAILY . " cases.status NOT IN('Resolved','Closed') AND  cases.deleted=0 ORDER BY cases.date_entered DESC";


            $result = $db->query($queryDaily_case);
            $total = $result->num_rows;
            if ($total > 0):
                while ($row = $db->fetchByAssoc($result)) {
                    $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';

                    $now = time(); // or your date as well
                    $your_date = strtotime($row['date_entered']);
                    $datediff = $now - $your_date;

                    $row['case_age'] = floor($datediff / (60 * 60 * 24));

                    $volumeucr[] = $row;
                }
            else:
                $row['emptyrecord'] = "N/A";
            // $volumecsa[] = $row;
            endif;
            echo "<td colspan='8' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
                <tr><td></td><td><strong>Case ID</strong></td><td><strong>Case Category</td></strong><td><strong>Case Priority</strong></td><td><strong>Case Status</strong></td><td><strong>Expected Resolution date(in Hrs)</strong></td><td><strong>Age of Case(in Days)</strong></td></tr>";
            //<td><strong>Priority</strong></td>
            foreach ($volumeucr as $volumeucr1) {
                echo "<tr>";
                echo "<td>" . $volumeucr1['date_entered'] . "</td>";
                echo "<td>" . $volumeucr1['case_number'] . "</td>";
                echo "<td>" . $volumeucr1['category_c'] . "</td>";
                echo "<td>" . $volumeucr1['priority'] . "</td>";
                echo "<td>" . $volumeucr1['status'] . "</td>";
                echo "<td>" . $volumeucr1['estimate_resolution_date'] . "</td>";
                echo "<td>" . $volumeucr1['case_age'] . "</td>";
                echo "</tr>";
            }
            echo "</table></td>";
        elseif ($_POST['getperiod'] == 'monthly'):

            $_Dailypost = explode("-", $_POST['daily']);
            $month = $_Dailypost[0];
            $year = $_Dailypost[1];
            $_Days = cal_days_in_month(CAL_GREGORIAN, $month, $year) - 1;
            $_fromdate = $year . "-" . $month . "-" . '01';
            $_EndDate = date("Y-m-d", strtotime("+ " . $_Days . " days", strtotime($_fromdate)));
            if ($_POST['getcategory'] && empty($_POST['origin'])) {
                $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
            }
            if ($_POST['origin'] && empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
            }
            if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
            }
            if ($_POST['getmembertier']) {
                $condition .= " cases_cstm.member_tier_c = '" . $_POST['getmembertier'] . "' AND ";
            }
            if ($_POST['getstatus']) {
                $condition .= "  cases.status = '" . $_POST['getstatus'] . "'  AND ";
            }
            if ($_POST['getpriority']) {
                $condition .= "  cases.priority = '" . $_POST['getpriority'] . "'  AND ";
            }
            $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" . date("y-m-d", strtotime($_fromdate)) . "' AND '" . $_EndDate . "' AND date(cases.date_entered) <= '" . date("y-m-d", strtotime($_POST['enddate'])) . "' AND date(cases.date_entered) >= '" . date("y-m-d", strtotime($_POST['fromdate'])) . "' AND";
            $queryDaily_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                    . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                    . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                    . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                    . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                    . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                    . " cases.date_entered , cases.assigned_user_id FROM cases "
                    . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                    . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                    . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                    . " where " . $condition . $conditiondAILY . " cases.status NOT IN('Resolved','Closed') AND cases.deleted=0 ORDER BY cases.date_entered ASC";
            $result = $db->query($queryDaily_case);
            $total = $result->num_rows;
            if ($total > 0):
                while ($row = $db->fetchByAssoc($result)) {
                    $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';

                    $now = time(); // or your date as well
                    $your_date = strtotime($row['date_entered']);
                    $datediff = $now - $your_date;

                    $row['case_age'] = floor($datediff / (60 * 60 * 24));
                    $volumeucr[] = $row;
                }
            else:
                $row['emptyrecord'] = "N/A";
            // $volumecsa[] = $row;
            endif;
            echo "<td colspan='8' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
                <tr><td></td><td><strong>Case ID</strong></td><td><strong>Case Category</td></strong><td><strong>Case Priority</strong></td><td><strong>Case Status</strong></td><td><strong>Expected Resolution date(in Hrs)</strong></td><td><strong>Age of Case(in Days)</strong></td></tr>";
            //<td><strong>Priority</strong></td>
            foreach ($volumeucr as $volumeucr1) {
                echo "<tr>";
                echo "<td>" . $volumeucr1['date_entered'] . "</td>";
                echo "<td>" . $volumeucr1['case_number'] . "</td>";
                echo "<td>" . $volumeucr1['category_c'] . "</td>";
                echo "<td>" . $volumeucr1['priority'] . "</td>";
                echo "<td>" . $volumeucr1['status'] . "</td>";
                echo "<td>" . $volumeucr1['estimate_resolution_date'] . "</td>";
                echo "<td>" . $volumeucr1['case_age'] . "</td>";
                echo "</tr>";
            }
            echo "</table></td>";
        elseif ($_POST['getperiod'] == 'annual'):
            if ($_POST['getcategory'] && empty($_POST['origin'])) {
                $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
            }
            if ($_POST['origin'] && empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
            }

            if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
            }
            if ($_POST['getmembertier']) {
                $condition .= " cases_cstm.member_tier_c = '" . $_POST['getmembertier'] . "' AND ";
            }
            if ($_POST['getstatus']) {
                $condition .= "  cases.status = '" . $_POST['getstatus'] . "'  AND ";
            }
            if ($_POST['getpriority']) {
                $condition .= "  cases.priority = '" . $_POST['getpriority'] . "'  AND ";
            }
            $conditiondAILY = " year(cases.date_entered) = '" . $_POST['daily'] . "' AND date(cases.date_entered) <= '" . date("y-m-d", strtotime($_POST['enddate'])) . "' AND date(cases.date_entered) >= '" . date("y-m-d", strtotime($_POST['fromdate'])) . "' AND";
            $queryQuarterly_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                    . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                    . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                    . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                    . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                    . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                    . " cases.date_entered , cases.assigned_user_id FROM cases "
                    . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                    . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                    . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                    . " where " . $conditiondAILY . $condition . " cases.status NOT IN('Resolved','Closed') AND cases.deleted=0 ORDER BY cases.date_entered ASC";
            $result = $db->query($queryQuarterly_case);
            $total = $result->num_rows;
            if ($total > 0):
                while ($row = $db->fetchByAssoc($result)) {
                    $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                    $now = time(); // or your date as well
                    $your_date = strtotime($row['date_entered']);
                    $datediff = $now - $your_date;

                    $row['case_age'] = floor($datediff / (60 * 60 * 24));
                    $volumeucr[] = $row;
                }
            else:
                $row['emptyrecord'] = "N/A";
            // $volumecsa[] = $row;
            endif;
            echo "<td colspan='8' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
                <tr><td></td><td><strong>Case ID</strong></td><td><strong>Case Category</td></strong><td><strong>Case Priority</strong></td><td><strong>Case Status</strong></td><td><strong>Expected Resolution date(in Hrs)</strong></td><td><strong>Age of Case(in Days)</strong></td></tr>";
            // <td><strong>Priority</strong></td>
            foreach ($volumeucr as $volumeucr1) {
                echo "<tr>";
                echo "<td>" . $volumeucr1['date_entered'] . "</td>";
                echo "<td>" . $volumeucr1['case_number'] . "</td>";
                echo "<td>" . $volumeucr1['category_c'] . "</td>";
                echo "<td>" . $volumeucr1['priority'] . "</td>";
                echo "<td>" . $volumeucr1['status'] . "</td>";
                echo "<td>" . $volumeucr1['estimate_resolution_date'] . "</td>";
                echo "<td>" . $volumeucr1['case_age'] . "</td>";

                echo "</tr>";
            }
            echo "</table></td>";
        elseif ($_POST['getperiod'] == 'weekly'):
            if ($_POST['getcategory'] && empty($_POST['origin'])) {
                $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
            }
            if ($_POST['origin'] && empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
            }

            if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
            }
            if ($_POST['getmembertier']) {
                $condition .= " cases_cstm.member_tier_c = '" . $_POST['getmembertier'] . "' AND ";
            }
            if ($_POST['getstatus']) {
                $condition .= "  cases.status = '" . $_POST['getstatus'] . "'  AND ";
            }

            $_EndDate = date("Y-m-d", strtotime("+ 1 week", strtotime($_POST['daily'])));

            $_Weekdate = date("Y-m-d", strtotime("-1 day", strtotime($_EndDate)));

            $conditionW = " DATE(cases.date_entered) BETWEEN '" . date("y-m-d", strtotime($_POST['daily'])) . "' AND '" . $_Weekdate . "' AND ";
            $query_query_W = "SELECT cases.id,cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
                    . "cases_cstm.member_tier_c,cases.status,"
                    . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
                    . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                    . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                    . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                    . " cases.date_entered , cases.assigned_user_id FROM cases "
                    . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                    . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                    . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                    . " where " . $condition . $conditionW . " cases.status NOT IN('Resolved','Closed')  AND cases.deleted=0 ORDER BY cases.date_entered ASC";
            $result = $db->query($query_query_W);
            $total = $result->num_rows;
            if ($total > 0):
                while ($row = $db->fetchByAssoc($result)) {
                    $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';

                    $now = time(); // or your date as well
                    $your_date = strtotime($row['date_entered']);
                    $datediff = $now - $your_date;
                    $row['case_age'] = floor($datediff / (60 * 60 * 24));
                    $volumeucr[] = $row;
                }
            else:
                $row['emptyrecord'] = "N/A";
            // $volumecsa[] = $row;
            endif;
            echo "<td colspan='8' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
                <tr><td></td><td><strong>Case ID</strong></td><td><strong>Case Category</td></strong><td><strong>Case Priority</strong></td><td><strong>Case Status</strong></td><td><strong>Expected Resolution date(in Hrs)</strong></td><td><strong>Age of Case(in Days)</strong></td></tr>";
            //<td><strong>Priority</strong></td>
            echo count($volumeucr);
            foreach ($volumeucr as $volumeucr1) {
                echo "<tr>";
                echo "<td>" . $volumeucr1['date_entered'] . "</td>";
                echo "<td>" . $volumeucr1['case_number'] . "</td>";
                echo "<td>" . $volumeucr1['category_c'] . "</td>";
                echo "<td>" . $volumeucr1['priority'] . "</td>";
                echo "<td>" . $volumeucr1['status'] . "</td>";
                echo "<td>" . $volumeucr1['estimate_resolution_date'] . "</td>";
                echo "<td>" . $volumeucr1['case_age'] . "</td>";
                echo "</tr>";
            }
            echo "</table></td>";
        elseif ($_POST['getperiod'] == 'quarterly'):
            if ($_POST['getcategory'] && empty($_POST['origin'])) {
                $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
            }
            if ($_POST['origin'] && empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
            }

            if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
            }
            if ($_POST['getmembertier']) {
                $condition .= " cases_cstm.member_tier_c = '" . $_POST['getmembertier'] . "' AND ";
            }
            if ($_POST['getstatus']) {
                $condition .= "  cases.status = '" . $_POST['getstatus'] . "'  AND ";
            }
            if ($_POST['getpriority']) {
                $condition .= "  cases.priority = '" . $_POST['getpriority'] . "'  AND ";
            }
            $_CheckQuarters = $this->getQuarters(date("m-d-Y", strtotime($_POST['fromdate'])), date("m-d-Y", strtotime($_POST['enddate'])));
            $_EndDate = date("Y-m-d", strtotime("+ 3 month", strtotime($_POST['daily'])));
            if ($_CheckQuarters == 'no-quarters'):
                $conditionY = " DATE(cases.date_entered) BETWEEN '" . date("y-m-d", strtotime($_POST['fromdate'])) . "' AND '" . date("y-m-d", strtotime($_POST['enddate'])) . "' AND ";
            else:
                $conditionY = " DATE(cases.date_entered) BETWEEN '" . date("y-m-d", strtotime($_POST['daily'])) . "' AND '" . $_EndDate . "' AND ";
            endif;
            //$conditionY = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_POST['daily'])) . "' AND '" .  $_EndDate . "' AND ";
            $query_query_Y = "SELECT cases.id,cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
                    . "cases_cstm.member_tier_c,"
                    . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
                    . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                    . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                    . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                    . " cases.date_entered , cases.assigned_user_id FROM cases "
                    . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                    . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                    . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                    . " where " . $condition . $conditionY . " cases.status NOT IN('Resolved','Closed') AND cases.deleted=0 ORDER BY cases.date_entered ASC";
            $result = $db->query($query_query_Y);
            $total = $result->num_rows;
            if ($total > 0):
                while ($row = $db->fetchByAssoc($result)) {
                    $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                    $now = time(); // or your date as well
                    $your_date = strtotime($row['date_entered']);
                    $datediff = $now - $your_date;
                    $row['case_age'] = floor($datediff / (60 * 60 * 24));
                    $volumeucr[] = $row;
                }
            else:
                $row['emptyrecord'] = "N/A";
            endif;
            echo "<td colspan='8' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
                <tr><td></td><td><strong>Case ID</strong></td><td><strong>Case Category</td></strong><td><strong>Case Priority</strong></td><td><strong>Case Status</strong></td><td><strong>Expected Resolution date(in Hrs)</strong></td><td><strong>Age of Case(in Days)</strong></td></tr>";
            //<td><strong>Priority</strong></td>
            foreach ($volumeucr as $volumeucr1) {
                echo "<tr>";
                echo "<td>" . $volumeucr1['date_entered'] . "</td>";
                echo "<td>" . $volumeucr1['case_number'] . "</td>";
                echo "<td>" . $volumeucr1['category_c'] . "</td>";
                echo "<td>" . $volumeucr1['priority'] . "</td>";
                echo "<td>" . $volumeucr1['status'] . "</td>";
                echo "<td>" . $volumeucr1['estimate_resolution_date'] . "</td>";
                echo "<td>" . $volumeucr1['case_age'] . "</td>";
                echo "</tr>";
            }
            echo "</table></td>";
        else:
            // echo $_POST['daily'];
            if ($_POST['getcategory'] && empty($_POST['origin'])) {
                $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
            }
            if ($_POST['origin'] && empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
            }

            if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
            }

            if ($_POST['getmembertier']) {
                $condition .= " cases_cstm.member_tier_c = '" . $_POST['getmembertier'] . "' AND ";
            }
            if ($_POST['getstatus']) {
                $condition .= "  cases.status = '" . $_POST['getstatus'] . "'  AND ";
            }
            if ($_POST['getpriority']) {
                $condition .= "  cases.priority = '" . $_POST['getpriority'] . "'  AND ";
            }
            $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" . $_POST['daily'] . "' AND '" . $_POST['daily'] . "' AND";
            $queryDaily_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                    . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                    . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                    . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                    . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                    . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                    . " cases.date_entered , cases.assigned_user_id FROM cases "
                    . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                    . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                    . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                    . " where " . $condition . $conditiondAILY . " cases.status NOT IN('Resolved','Closed') AND cases.deleted=0 ORDER BY cases.date_entered DESC";


            $result = $db->query($queryDaily_case);
            $total = $result->num_rows;
            if ($total > 0):
                while ($row = $db->fetchByAssoc($result)) {
                    $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                    $now = time(); // or your date as well
                    $your_date = strtotime($row['date_entered']);
                    $datediff = $now - $your_date;
                    $row['case_age'] = floor($datediff / (60 * 60 * 24));
                    $volumeucr[] = $row;
                }
            else:
                $row['emptyrecord'] = "N/A";
            // $volumecsa[] = $row;
            endif;
            echo "<td colspan='8' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
                <tr><td></td><td><strong>Case ID</strong></td><td><strong>Case Category</td></strong><td><strong>Case Priority</strong></td><td><strong>Case Status</strong></td><td><strong>Expected Resolution date(in Hrs)</strong></td><td><strong>Age of Case(in Days)</strong></td></tr>";
            //<td><strong>Priority</strong></td>
            foreach ($volumeucr as $volumeucr1) {
                echo "<tr>";
                echo "<td>" . $volumeucr1['date_entered'] . "</td>";
                echo "<td>" . $volumeucr1['case_number'] . "</td>";
                echo "<td>" . $volumeucr1['category_c'] . "</td>";
                echo "<td>" . $volumeucr1['priority'] . "</td>";
                echo "<td>" . $volumeucr1['status'] . "</td>";
                echo "<td>" . $volumeucr1['estimate_resolution_date'] . "</td>";
                echo "<td>" . $volumeucr1['case_age'] . "</td>";
                echo "</tr>";
            }
            echo "</table></td>";
        endif;
        exit;
    }

    public function action_unresolvedcases() {
        global $db, $app_list_strings, $sugar_config;
        $this->view = 'unresolvedcases';
        $ReportName = 'unresolvedcases';
        $this->view_object_map['getAllCaseCategory'] = $this->getAllCaseCategory();
        $this->view_object_map['getTimePeriod'] = $this->getTimePeriod();
		$this->view_object_map['getCasepriority'] = $this->getCasepriority();
        $this->view_object_map['site_url'] = $sugar_config['site_url'];
		
		
		//get branch store name
		$this->view_object_map['branch_store_name'] = $this->getAllBranchName();

        $volumeucr = $queryCase = $_Yearquery = $_ColumnsDate = $volumeDate = $_DailyLoopC = $_DateEnteredArray = $volumeucr_grid = $_NoOfQuarters = array();
        $_WeeklyGlobal = $_QuaterlyGlobal = $_MonthGlobal = 0;
        $condition = $condition_group = $_BranchStore = '';


        //$volumeucr = array();
        // $condition = '';

        if (isset($_REQUEST['query']) == 'true') {
            if ($_REQUEST['member_tier_c'] || $_REQUEST['category_id'] || $_REQUEST['origin'] || $_REQUEST['branch_store_name'] || $_REQUEST['period'] ||
                    $_REQUEST['status'] || $_REQUEST['from_date'] || $_REQUEST['to_date']) {
                
				if ($_REQUEST['category_id'] == "all") {
                    $condition .= "";
					$condition_group .= "";
				 }else
				 {
				     $condition .= "  cases_cstm.category_c = '" . $_REQUEST['category_id'] . "' AND ";
					$condition_group .= ",cases_cstm.category_c";
				 }
				 
				 
				if ($_REQUEST['origin'] == "all")  {
                    $condition .= " ";
					$condition_group .= "";
                }else
				 {
				    $condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
					$condition_group .= ",cases_cstm.origin_c";
				 }
				 
				if ($_POST['branch_store_name'] == "all"  || $_POST['branch_store_name'] == "" )  {
				$condition .= " ";
				}else
				{
				$condition .= "  cases.branch_store_name = '" . $_POST['branch_store_name'] . "'  AND ";
				}
			
			
				 
				 if ($_REQUEST['sub_category_id']  == "all") {
                    $condition .= " ";
					$condition_group .= "";
                }else
				 {
				    $condition .= "  cases_cstm.subcategory_c = '" . $_REQUEST['sub_category_id'] . "'  AND ";
					$condition_group .= ",cases_cstm.subcategory_c";
				 }
				 
				
				if ($_REQUEST['member_tier_c'] == "all") {
                    $condition .= "";
					$condition_group .= "";
				 }else
				 {
				    $condition .= "  cases_cstm.member_tier_c = '" . $_REQUEST['member_tier_c'] . "' AND ";
					$condition_group .= ",cases_cstm.member_tier_c";
				 }
				 
				if ($_REQUEST['status']  == "all") {
                    $condition .= " ";
					$condition_group .= "";
                }else
				 {
				    $condition .= "  cases.status = '" . $_REQUEST['status'] . "'  AND ";
					$condition_group .= ",cases.status";
				 }
				 
				$_Status =  $_REQUEST['status'];
				$_Membertier = $_REQUEST['member_tier_c'];
                /* checking query starting */
                $start_date = date("Y-m-d", strtotime($_REQUEST['from_date']));
                $end_date = date("Y-m-d", strtotime($_REQUEST['to_date']));
                $start_date = $_REQUEST['from_date']; //fromdate for post
                $this->view_object_map['getFromDate'] = $start_date;
                $end_date = $_REQUEST['to_date']; //todate for post
                $this->view_object_map['getToDate'] = $end_date;
                $_Periodpost = $_REQUEST['period']; //period for post
                $this->view_object_map['getPeriod'] = $_Periodpost;
                $_Oroginpost = $_REQUEST['origin']; //origin for post
                $this->view_object_map['getOrigin'] = $_Oroginpost;
                $_Categorypost = $_REQUEST['category_id']; //categoryid for post
                $this->view_object_map['getCategory'] = $_Categorypost;
                $_MemberTierpost = $_REQUEST['member_tier_c']; //origin for post
                $this->view_object_map['getMemberTier'] = $_MemberTierpost;
                $_Statuspost = $_REQUEST['status']; //status for post
                $this->view_object_map['getStatus'] = $_Statuspost;
				$this->view_object_map['sub_category_id'] = $_REQUEST['sub_category_id'];
				
				$_BranchStore = $_REQUEST['branch_store_name']; //branch_store_name for post
                $this->view_object_map['getBranchName'] = $_BranchStore;
				
                if ($_REQUEST['period'] == "daily"):

                    $_DailyLoopCount = $this->datediff('d', date("y-m-d", strtotime($_REQUEST['from_date'])), date("y-m-d", strtotime($_REQUEST['to_date'])));

                    for ($i = 0; $i <= $_DailyLoopCount; $i++) {
                        $_DailyLoopC[] = date("Y-m-d", strtotime("+$i day", strtotime($start_date)));
                    }

                    if ($_REQUEST['from_date'] && $_REQUEST['to_date']) {
                        $condition .= "  DATE(cases.date_entered) BETWEEN '" . date("y-m-d", strtotime($start_date)) . "' AND '" . date("y-m-d", strtotime($end_date)) . "' AND ";
                    }


                    $query_query = "SELECT cases.id, cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                    . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                    . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                    . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                    . " cases.date_entered , cases.assigned_user_id FROM cases "
                    . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                    . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                    . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                    . " where " . $condition . " cases.status NOT IN('Resolved','Closed') AND cases.deleted=0 ORDER BY cases.date_entered ASC";

					
					
					
                    $result = $db->query($query_query);
                    $total = $result->num_rows;
                    if ($total > 0):
                        while ($row = $db->fetchByAssoc($result)) {
                            $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                            $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                            $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                            $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                            $volumeucr[] = $row;
                            $volumeDate[] = date("Y-m-d", strtotime($row['date_entered']));
                        }
                    else:
                        $row['emptyrecord'] = "N/A";
                    // $volumecsa[] = $row;
                    endif;
                else:
                endif;
				
               
                if (count($volumeucr)):
                        foreach ($volumeucr as $volumeucrData) {
                            $_DateEnteredArray[] = $volumeucrData['date_entered'];
                            $_DateEntered1Array[$volumeucrData['date_entered']] = array($volumeucrData['date_entered'], $volumeucrData['category_c'], $volumeucrData['origin_c'], $volumeucrData['count(cases.id)']);
                        }
                endif;
                
                $i = 0;
                if (count($_DailyLoopC) > 0):
                   
                        foreach ($_DailyLoopC as $_DailyLoopCDataKey => $_DailyLoopCData) {
                            if ($_WeeklyGlobal == 1):
                                

                            elseif ($_MonthGlobal == 1):
                              
                            else:
								if($_REQUEST['category_id'] == 'all'):
								$_Catname = 'All';
								else:
								$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
								endif;

						
                                $volumeucr_grid[] = "<tr>";
                                if (in_array($_DailyLoopCData, $_DateEnteredArray)) {
                                    //$key = array_search($_DailyLoopCData, $_DateEnteredArray);
                                } else {
                                //echo  "norecord".$_DailyLoopCData."<br>";
						        $volumeucr_grid[] =  "<td>".$_DailyLoopCData."</td>
								<td>NA</td><td>NA</td>
							
								<td>NA</td><td>NA</td>
								
								<td>NA</td>
								<td>NA</td>";
								//	<td>".$_Catname."</td><td>".ucfirst($_POST['status'])."</td>	
                                }
                                $volumeucr_grid[] = "</tr>";

                                $volumeucr_grid[] = "<tr class=dailyresulthide id=dailyresult_" . $_DailyLoopCData . " style=display:none>
						 <td colspan='8' class='parent-TD'>
						 </td></tr>";
                            endif;
						if (in_array($_DailyLoopCData,$_DateEnteredArray))
						 {
						 /*script for showing daily wise record*/
								$_DailSSdate = $_DailyLoopCData; //start date
								$_DailESdate =  date ("Y-m-d", strtotime("+1 day", strtotime($_DailyLoopCData))); //end date
								$_DailyRowrecord =  $this->dailydataDailywiseUnresolvedcase($_REQUEST['sub_category_id'] ,$_REQUEST['origin'],$_REQUEST['branch_store_name'],$_REQUEST['category_id'],$_DailSSdate, $_DailESdate,$_Status,$_Membertier);
								/*script for showing daily wise record*/
								$_curdate = date("Y-m-d", strtotime(date("Y-m-d")));  // first get current date-1
								//echo "<pre>";
								//print_r($_DailyRowrecord);
								foreach($_DailyRowrecord  as $_DailyRowrecord1):
		                         //$now = date("Y-m-d", strtotime(date("Y-m-d"))); 
								$date1 = new DateTime($_curdate);
								$date2 = new DateTime($_DailyRowrecord1['date_entered']);
								if(isset($_DailyRowrecord1['estimate_resolution_input'])):
								$estimate_date = date('Y-m-d', strtotime('+' . $_DailyRowrecord1['estimate_resolution_input'] . ' minute', strtotime($_DailyRowrecord1['date_entered'])));
								else:
								$estimate_date  = date('Y-m-d',strtotime($_DailyRowrecord1['date_entered']));
								endif;
								$diff = $date2->diff($date1)->format("%a");
								$volumeucr_grid[] = "<tr style=padding:20px;>";
								$volumeucr_grid[] = "<td >".$_DailyRowrecord1['date_entered']."</td>";
								$volumeucr_grid[] = "<td >".$_DailyRowrecord1['case_number']."</td>";
								$volumeucr_grid[] = "<td >".$_DailyRowrecord1['category_c']."</td>";
								$volumeucr_grid[] = "<td >".$_DailyRowrecord1['priority']."</td>";
								$volumeucr_grid[] = "<td >".ucfirst($_DailyRowrecord1['status'])."</td>";
							    $volumeucr_grid[] = "<td >".$estimate_date."</td>";
								$volumeucr_grid[] = "<td>".$diff."</td>";
								$volumeucr_grid[] = "</tr>";
								endforeach;
						 }
						 
                        }

                endif;
            }
        }
		
		//echo "<pre>";
		//print_r($volumeucr_grid);
		
        $this->view_object_map['unresolved_cases'] = $volumeucr_grid;
    }

	public function dailydataDailywiseUnresolvedcase($_getSubcat,$_getOrigin,$_getBranchStore,$_getCat,$_StartDate , $_EndDate,$_Status,$Membertier)
	{
	global $db, $app_list_strings,$sugar_config;
			$volumecc = array();
			$condition="";
			if ($_getCat == "all") {
			 $condition .= "";
			}else
			{
			 $condition .= "  cases_cstm.category_c = '" . $_getCat . "' AND ";
			}


			if ($_getOrigin == "all")  {
			$condition .= " ";
			}else
			{
			$condition .= "  cases_cstm.origin_c = '" . $_getOrigin . "'  AND ";
			}
			


			if ($_getBranchStore == "all" || $_getBranchStore == "")  {
			$condition .= " ";
			}else
			{
			$condition .= "  cases.branch_store_name = '" . $_getBranchStore . "'  AND ";
			}
			

			
			if ($_getSubcat  == "all") {
			$condition .= " ";
			}else
			{
			$condition .= "  cases_cstm.subcategory_c = '" . $_getSubcat . "'  AND ";
			}
            
			if ($Membertier == "all") {
			$condition .= "";
			}else
			{
			$condition .= "  cases_cstm.member_tier_c = '" . $Membertier . "' AND ";
			}

			if ($_Status  == "all") {
			$condition .= " ";
			}else
			{
			$condition .= "  cases.status = '" . $_Status . "'  AND ";
			}
			
			$conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .$_StartDate. "' AND '" .  $_StartDate . "' AND";
		   
            $queryDaily_case = "SELECT cases.id, cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                    . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                    . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , 
					   naku_casesubcategory.estimate_resolution_input,naku_casesubcategory.estimate_resolution_date, "
                    . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                    . " cases.date_entered , cases.assigned_user_id FROM cases "
                    . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                    . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                    . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                    . " where " . $condition . $conditiondAILY." cases.status NOT IN('Resolved','Closed') AND cases.deleted=0  ORDER BY cases.date_entered ASC";
					
			$result = $db->query($queryDaily_case);
			$total = $result->num_rows;
			$current_time = $sugar_config['current_sla_time'];
			
			if($total > 0):
			while ($row = $db->fetchByAssoc($result)) {
			  // date('Y-m-d H:i:s',strtotime('-3 hours'));
                    if (!empty($row['date_entered'])) {
                        if ($row['estimate_resolution_date'] == 'min') {
                            $estimate_date = date('Y-m-d H:i:s', strtotime('+' . $row['estimate_resolution_input'] . ' minute', strtotime($row['date_entered'])));
						
						//echo $estimate_date = date('Y-m-d H:i:s',strtotime('+' .$estimate_date.',strtotime($current_time)));
							if( $estimate_date > $current_time):
								$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
								$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
								$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
								$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
								$volumecc[] = $row;
							else:
							    $row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
								$row['origin_c'] = "NA";
								$row['category_c'] = "NA";
								$row['priority'] = "NA";
								$volumecc[] = $row;
							
							endif;
						} else if ($row['estimate_resolution_date'] == 'hrs') {
                            $estimate_date = date('Y-m-d H:i:s', strtotime('+' . $row['estimate_resolution_input'] . ' hour', strtotime($row['date_entered'])));
                           
							if($estimate_date > $current_time):
								$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
								$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
								$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
								$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
									
								$volumecc[] = $row;
								else:
								$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
								$row['origin_c'] = "NA";
								$row['category_c'] = "NA";
								$row['priority'] = "NA";
									
								$volumecc[] = $row;
								
						    endif;
						} else if ($row['estimate_resolution_date'] == 'days') {
                           $estimate_date = date('Y-m-d H:i:s', strtotime('+' . $row['estimate_resolution_input'] . ' day', strtotime($row['date_entered'])));
                          
						   if($estimate_date > $current_time):
								$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
								$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
								$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
								$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
									
								$volumecc[] = $row;
							else:
                       			$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
								$row['origin_c'] = "NA";
								$row['category_c'] = "NA";
								$row['priority'] = "NA";
									
								$volumecc[] = $row;				
						     endif;
						}
						else{
						         $row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
								$row['origin_c'] = "NA";
								$row['category_c'] = "NA";
								$row['priority'] = "NA";
									
								$volumecc[] = $row;
						}
                    }
            }
			else:
			$row['emptyrecord'] = "N/A";
			// $volumecc[] = $row;
			endif;
			
			return $volumecc;
			
	}
	
    public function getExportContentUCR($_QueryFD, $_QueryTD, $_QueryPer, $_QueryORI,$_QueryReportBranchStore, $_QueryCat, $_QuerySta, $_QueryMem ,$_Subcat) {
        global $db, $app_list_strings, $sugar_config;

        $volumeucr = $queryCase = $_Yearquery = $_ColumnsDate = $volumeDate = $_DailyLoopC = $_DateEnteredArray = $volumeucr_grid = $_NoOfQuarters = $_GetOneQuarters = $volumeucr_grid1 = array();
        $_WeeklyGlobal = $_QuaterlyGlobal = $_MonthGlobal = $_DailyGlobal = $_YearlyGlobal = 0;
        $condition = $condition_group = '';

        if ($_QueryFD || $_QueryPer || $_QueryORI || $_QueryTD || $_QueryCat || $_QuerySta || $_QueryMem || $_Subcat) {

           
		   if ($_QueryCat == "all") {
                    $condition .= "";
				 }else
				 {
				     $condition .= "  cases_cstm.category_c = '" . $_QueryCat . "' AND ";
				 }
				 
				 
				if ($_QueryORI  == "all")  {
                    $condition .= " ";
                }else
				 {
				    $condition .= "  cases_cstm.origin_c = '" . $_QueryORI  . "'  AND ";
				 }
				 
				 
				if ($_QueryReportBranchStore == "all" || $_QueryReportBranchStore == "") {
					$condition .= "";
				}else
				{
					$condition .= "  cases.branch_store_name = '" . $_QueryReportBranchStore . "' AND ";
				}
				 
				 
				 if ($_Subcat  == "all") {
                    $condition .= " ";
                }else
				 {
				    $condition .= "  cases_cstm.subcategory_c = '" . $_Subcat . "'  AND ";
				 }
				 
				
				if ($_QueryMem == "all") {
                    $condition .= "";
				 }else
				 {
				    $condition .= "  cases_cstm.member_tier_c = '" . $_QueryMem . "' AND ";
				 }
				 
				if ($_QuerySta  == "all") {
                    $condition .= " ";
                }else
				 {
				    $condition .= "  cases.status = '" . $_QuerySta . "'  AND ";
				 }
				 
				$_Status = $_QuerySta;
				$_Membertier = $_QueryMem;


            /* checking query starting */
            $start_date = date("Y-m-d", strtotime($_QueryFD));
            $end_date = date("Y-m-d", strtotime($_QueryTD));

            if ($_QueryPer == "daily"):
                $_DailyGlobal = 1;
                $_DailyLoopCount = $this->datediff('d', $start_date, $end_date);

                for ($i = 0; $i <= $_DailyLoopCount; $i++) {
                    $_DailyLoopC[] = date("Y-m-d", strtotime("+$i day", strtotime($start_date)));
                }

                if ($start_date && $end_date) {
                    $condition .= "  DATE(cases.date_entered) BETWEEN '" . date("y-m-d", strtotime($start_date)) . "' AND '" . date("y-m-d", strtotime($end_date)) . "' AND ";
                }


                $query_query = "SELECT  cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                    . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                    . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                    . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                    . " cases.date_entered , cases.assigned_user_id FROM cases "
                    . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                    . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                    . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                    . " where " . $condition . " cases.status NOT IN('Resolved','Closed') AND cases.deleted=0   ORDER BY cases.date_entered ASC";

                $result = $db->query($query_query);
                $total = $result->num_rows;
                if ($total > 0):
                    while ($row = $db->fetchByAssoc($result)) {
                            $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                            $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                            $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                            $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                            $volumeucr[] = $row;
                            $volumeDate[] = date("Y-m-d", strtotime($row['date_entered']));
                        }
                else:
                    $row['emptyrecord'] = "N/A";
                endif;
              endif;
           //echo "<pre>";print_r($volumeucr);die;
            if ($_DailyGlobal == 1 || $_YearlyGlobal == 1 || $_MonthGlobal == 1 || $_WeeklyGlobal == 1 || $_QuaterlyGlobal == 1):

                foreach ($volumeucr as $volumeucr1):

                    $volumeucr_grid1["date_entered"] = $volumeucr1['date_entered'];
                    $volumeucr_grid1["case_number"] = $volumeucr1['case_number'];
                    $volumeucr_grid1["category_c"] = $volumeucr1['category_c'];
                    $volumeucr_grid1["priority"] = $volumeucr1['priority'];
                    $volumeucr_grid1["status"] = $volumeucr1['status'];
                    $volumeucr_grid1["estimate_resolution_date"] = $volumeucr1['estimate_resolution_date'];

                    $now = time(); // or your date as well
                    $your_date = strtotime($volumeucr1['date_entered']);
                    $datediff = $now - $your_date;
                    $row['case_age'] = floor($datediff / (60 * 60 * 24));

                    $volumeucr_grid1["case_age"] = $row['case_age'];

                    $volumeucr_grid[] = $volumeucr_grid1;

                endforeach;
            endif;
			
            $i = 0;
            /* checking query ending */
        }

        return $volumeucr_grid;

        if (isset($total) > 0) {
            $this->view_object_map['total_cases'] = $total;
        } else {
            $this->view_object_map['total_cases'] = 0;
        }
    }

    public function action_exportunresolvedcases() {
        global $db, $app_list_strings;
        $condition = $_QueryFD = $_QueryTD = $_QueryPer = $_QueryORI = $_QueryCat = $_QuerySta = $_QueryMem = $_QuerySubcat= "";

        if (isset($_REQUEST['queryfromdate'])) {
            $_QueryFD = $_REQUEST['queryfromdate'];
        }

        if (isset($_REQUEST['querytodate'])) {
            $_QueryTD = $_REQUEST['querytodate'];
        }

        if (isset($_REQUEST['queryPeriod'])) {
            $_QueryPer = $_REQUEST['queryPeriod'];
        }

        if (isset($_REQUEST['queryorigin'])) {
            $_QueryORI = $_REQUEST['queryorigin'];
        }

        if (isset($_REQUEST['querycategory'])) {
            $_QueryCat = $_REQUEST['querycategory'];
        }
        if (isset($_REQUEST['querystatus'])) {
            $_QuerySta = $_REQUEST['querystatus'];
        }
        if (isset($_REQUEST['querymembertier'])) {
            $_QueryMem = $_REQUEST['querymembertier'];
        }
		if (isset($_REQUEST['querysubcategory'])) {
            $_QuerySubcat= $_REQUEST['querysubcategory'];
        }
		
		if (isset($_REQUEST['queryBranchStore'])) {
            $_QueryReportBranchStore= $_REQUEST['queryBranchStore'];
        }
		

        $_dataColumns = $this->getExportContentUCR($_QueryFD, $_QueryTD, $_QueryPer, $_QueryORI,$_QueryReportBranchStore,$_QueryCat, $_QuerySta, $_QueryMem,$_QuerySubcat);  //calling function to get export data

        if ($_POST['file_type'] == 'csv') { //Export CSV
            //CSV File name and Header
            $filename = "unresolved_case_report_" . date('Y-m-d:H:i:s') . ".csv";
            $fp = fopen('php://output', 'w');
            $header = array('Date', 'Case ID', 'Case Category', 'Case Priority', 'Case Status', 'Expected Resolution date(in Hrs)', 'Age of Case(in Days)');
            header('Content-type: application/csv');
            header('Content-Disposition: attachment; filename=' . $filename);
            fputcsv($fp, $header);
            $condition = "";
            $export_list_case = array();
            foreach ($_dataColumns as $_dataColumns1Val):
                $row['date_entered'] = $_dataColumns1Val['date_entered'];
                $row['case_number'] = $_dataColumns1Val['case_number'];
                $row['category_c'] = $_dataColumns1Val['category_c'];
                $row['priority'] = $_dataColumns1Val['priority'];
                $row['status'] = $_dataColumns1Val['status'];
                $row['estimate_resolution_date'] = $_dataColumns1Val['estimate_resolution_date'];
                $row['case_age'] = $_dataColumns1Val['case_age'];
                $export_list_case[] = $row;
                fputcsv($fp, $row); //Genrate CSV
            endforeach;
            fclose($fp);
            exit;
        } elseif ($_POST['file_type'] == 'xls') { //Export XLS
            $list = array();
            $list['tableheading'] = array('Date', 'Case ID', 'Case Category', 'Case Priority', 'Case Status', 'Expected Resolution date(in Hrs)', 'Age of Case(in Days)');
            $fichier = "unresolved_case_report_" . date('Y-m-d:H:i:s') . ".xls";
            header("Content-Type: text/csv;charset=utf-8");
            header("Content-Disposition: attachment;filename=\"$fichier\"");
            header("Pragma: no-cache");
            header("Expires: 0");
            $fp = fopen('php://output', 'w');
            fputcsv($fp, $list['tableheading']);
            //Fetch data
            foreach ($_dataColumns as $_dataColumns1Val):
                $row['date_entered'] = $_dataColumns1Val['date_entered'];
                $row['case_number'] = $_dataColumns1Val['case_number'];
                $row['category_c'] = $_dataColumns1Val['category_c'];
                $row['priority'] = $_dataColumns1Val['priority'];
                $row['status'] = $_dataColumns1Val['status'];
                $row['estimate_resolution_date'] = $_dataColumns1Val['estimate_resolution_date'];
                $row['case_age'] = $_dataColumns1Val['case_age'];
                $data['list'] = $row;
                //$export_list_case[] = $row;
                fputcsv($fp, $data['list']); //Genrate CSV
            endforeach;
            fclose($fp);
            exit();
        }else if($_POST['file_type'] == 'pdf')
		{
               require_once 'include/dompdf/dompdf_config.inc.php';
			   global $current_user;
			   $name = $current_user->first_name . '&nbsp;' . $current_user->last_name;
			   $current_date = date('d/m/Y  h:i A');
			   $dompdf = new Dompdf();
			   //echo '<pre>';
			   //print_r($_dataColumns);
			  // die;
			  
			
			   $_CaseOriginPdf = $_CaseOriginCat = "";
			   if($_QueryORI == 'all'):
			    $_CaseOriginPdf = 'All';
			   else:
			    $_CaseOriginPdf = $this->getCaseOriginName($_QueryORI);
			   endif;
			   
			   $_CaseBranchStorePdf = "";
			   if($_QueryReportBranchStore == 'all'):
			    $_CaseBranchStorePdf = 'All';
			   else:
			    $_CaseBranchStorePdf = $_QueryReportBranchStore;
			   endif;
			   
			   
			   
			   
			   if($_QueryCat == 'all'):
			    $_CaseOriginCat = 'All';
			   else:
			    $_CaseOriginCat = $this->getCaseCategoryName($_QueryCat);
			   endif;
			   
			   if($_REQUEST['querysubcategory'] == 'all'):
			    $_CaseOriginSubCat = 'All';
			   else:
			    $_CaseOriginSubCat = $this->getCaseSubCategoryName($_REQUEST['querysubcategory']);
			   endif;

						   
			   if($_POST['querystatus'] == 'all'):
			    $_CaseStatus = 'All';
			   else:
			    $_CaseStatus = $_POST['querystatus'];
			   endif;
			   $header = '<html>
            <body>
                <div style="width:100%;color:#fff;background:#17479d;padding:5px 0px;margin:0px;text-align:center;">
                    <img src="custom/include/images/logo.png" style="padding: 7px;position: absolute;left: 10px;"><h2>Unresolved Case Report </h2>
                </div>
				<br />
				<table style="width:450px; margin:0 auto; text-align:left;">
				    <tr>
						<td style="width="20%"><b>From  - </b></td>
						<td style="width="10%">'.$_QueryFD.'</td>
						<td style="width="20%"><b>To  - </b></td>
						<td style="width="10%">'.$_QueryTD.'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Period  - </b></td>
						<td style="width="50%">'.ucfirst($_QueryPer).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Origin  - </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginPdf).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginCat).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Sub Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginSubCat).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Status  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseStatus).'</td>
					</tr>
				</table>';
				
			    $content .= '<table border="1" cellspacing="0" cellpadding="5" width="100%">  
                    <thead>
                        <tr>
                            <th nowrap>Case Id</th>
                            <th nowrap>Date</th>
							<th nowrap>Case Category</th>
                            <th nowrap>Case Priority</th> 
							<th nowrap>Case Status</th>
							<th nowrap>Expected Resolution date</th> 
							<th nowrap>Age of Case</th> 							
                        </tr>
                </thead>';
				
				foreach($_dataColumns as $_dataColumns1Val):
				    $content .= '<tbody>
                        <tr>
                          <td>' . $_dataColumns1Val["case_number"] . '</td>
                          <td>' . $_dataColumns1Val["date_entered"] . '</td>
						  <td>' . $_dataColumns1Val["category_c"] . '</td>
                          <td>' . $_dataColumns1Val["priority"] . '</td>
                          <td>' . $_dataColumns1Val["status"] . '</td>
						  <td>' . $_dataColumns1Val["estimate_resolution_date"] . '</td>
						  <td>' . $_dataColumns1Val["case_age"] . '</td>
                     </tr>
                    <tbody>';
				
				endforeach;
				$content .= '</table>';
				$footer = '<table style="width:100%;color:#ccc;background:#17479d;padding:5px 0px;margin:0px;">
								<tr>
							<td width="30%"><span style="float:left!important;margin-left:10px;">Printed by: ' . $name . '&nbsp;' . $current_date . '</span></td>
							<td style="text-align:center;width:30%;">www.nakumatt.net</td>
							<td  width="30%">&nbsp;</td>
								</tr>
							</table>
							<h4 style="color:red;">The content is confidential and not meant to be shared in any form with any external persons / entities.</h4>
							</body>
							</html>';
				$html = $header . $content . $footer;
				$dompdf->load_html($html);
				// (Optional) Setup the paper size and orientation
				$dompdf->set_paper('A4', 'landscape');
				// Render the HTML as PDF
				$dompdf->render();
				// Output the generated PDF to Browser
				$filename = "Unresolved Case " . date('Y-m-d:H:i:s') . ".pdf";
				$dompdf->stream($filename);			
			   //pdf report
			
		  }
    }

    /**
     * This method gives time period
     */
    public function getTimePeriod() {
        return [
            "" => "Select",
            "daily" => "Daily",
            "monthly" => "Monthly",
            "quarterly" => "Quarterly",
            "annual" => "Annual",
        ];
    }

    public function datediff($interval, $datefrom, $dateto, $using_timestamps = false) {
        /*
          $interval can be:
          yyyy - Number of full years
          q - Number of full quarters
          m - Number of full months
          y - Difference between day numbers
          (eg 1st Jan 2004 is "1", the first day. 2nd Feb 2003 is "33". The datediff is "-32".)
          d - Number of full days
          w - Number of full weekdays
          ww - Number of full weeks
          h - Number of full hours
          n - Number of full minutes
          s - Number of full seconds (default)
         */

        if (!$using_timestamps) {
            $datefrom = strtotime($datefrom, 0);
            $dateto = strtotime($dateto, 0);
        }
        $difference = $dateto - $datefrom; // Difference in seconds

        switch ($interval) {

            case 'yyyy': // Number of full years

                $years_difference = floor($difference / 31536000);
                if (mktime(date("H", $datefrom), date("i", $datefrom), date("s", $datefrom), date("n", $datefrom), date("j", $datefrom), date("Y", $datefrom) + $years_difference) > $dateto) {
                    $years_difference--;
                }
                if (mktime(date("H", $dateto), date("i", $dateto), date("s", $dateto), date("n", $dateto), date("j", $dateto), date("Y", $dateto) - ($years_difference + 1)) > $datefrom) {
                    $years_difference++;
                }
                $datediff = $years_difference;
                break;

            case "q": // Number of full quarters

                $quarters_difference = floor($difference / 8035200);
                while (mktime(date("H", $datefrom), date("i", $datefrom), date("s", $datefrom), date("n", $datefrom) + ($quarters_difference * 3), date("j", $dateto), date("Y", $datefrom)) < $dateto) {
                    $months_difference++;
                }
                $quarters_difference--;
                $datediff = $quarters_difference;
                break;

            case "m": // Number of full months

                $months_difference = floor($difference / 2678400);
                while (mktime(date("H", $datefrom), date("i", $datefrom), date("s", $datefrom), date("n", $datefrom) + ($months_difference), date("j", $dateto), date("Y", $datefrom)) < $dateto) {
                    $months_difference++;
                }
                $months_difference--;
                $datediff = $months_difference;
                break;

            case 'y': // Difference between day numbers

                $datediff = date("z", $dateto) - date("z", $datefrom);
                break;

            case "d": // Number of full days

                $datediff = floor($difference / 86400);
                break;

            case "w": // Number of full weekdays

                $days_difference = floor($difference / 86400);
                $weeks_difference = floor($days_difference / 7); // Complete weeks
                $first_day = date("w", $datefrom);
                $days_remainder = floor($days_difference % 7);
                $odd_days = $first_day + $days_remainder; // Do we have a Saturday or Sunday in the remainder?
                if ($odd_days > 7) { // Sunday
                    $days_remainder--;
                }
                if ($odd_days > 6) { // Saturday
                    $days_remainder--;
                }
                $datediff = ($weeks_difference * 5) + $days_remainder;
                break;

            case "ww": // Number of full weeks

                $datediff = floor($difference / 604800);
                break;




            default: // Number of full seconds (default)

                $datediff = $difference;
                break;
        }

        return $datediff;
    }

    public function checkReportPeriod($condition,$condition_group,$dateform,$dateto,$_volumeucrNull=null)
   {
    global $db, $app_list_strings;
	$_Wrow = array();
       $_Weekdate =   date("Y-m-d", strtotime("-1 day", strtotime($dateto)));
    $conditionW = " DATE(cases.date_entered) BETWEEN '" .$dateform . "' AND '" . $_Weekdate . "' AND ";
    $checknull = '';
    if(isset($_volumeucrNull)){
        $checknull .= "cases.status NOT IN('Resolved','Closed') AND ";
    }else{
         $checknull .='';
    }
    $query_query_w = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
							. "cases_cstm.member_tier_c,cases.status,"
							. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
							. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
							. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
							. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
							. " cases.date_entered , cases.assigned_user_id FROM cases "
							. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
							. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
							. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
							. " where " . $condition . $conditionW . $checknull. "  cases.deleted=0  group by week(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
	 $result = $db->query($query_query_w);
   foreach($result as $resultw)
   {
      $_Wrow[] = $resultw['count(cases.id)'];
   }
	
	return array_sum($_Wrow);
   }
   
   
   public function checkReportPeriodReportcsr($condition,$condition_group,$dateform,$dateto)
   {
    global $db, $app_list_strings;
	$_Wrow = array();
       $_Weekdate =   date("Y-m-d", strtotime("-1 day", strtotime($dateto)));
    $conditionW = " DATE(cases.date_entered) BETWEEN '" .$dateform . "' AND '" . $_Weekdate . "' AND ";
 
    $query_query_w = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
							. "cases_cstm.member_tier_c,cases.status,"
							. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
							. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
							. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
							. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
							. " cases.date_entered , cases.assigned_user_id FROM cases "
							. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
							. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
							. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
							. " where " . $condition . $conditionW . $checknull. " cases.deleted=0  group by week(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
	 $result = $db->query($query_query_w);
   foreach($result as $resultw)
   {
      $_Wrow[] = $resultw['count(cases.id)'];
   }
	
	return array_sum($_Wrow);
   }
   
   
   public function checkReportPeriodreportcc($condition,$condition_group,$dateform,$dateto)
   {
	
    global $db, $app_list_strings;
	$_Wrow = array();
    $conditionW = " DATE(cases.date_entered) BETWEEN '" .$dateform . "' AND '" . $dateto . "' AND ";
   
    $query_query_w = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
							. "cases_cstm.member_tier_c,cases.status,"
							. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
							. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
							. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
							. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
							. " cases.date_entered , cases.assigned_user_id FROM cases "
							. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
							. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
							. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
							. " where " . $condition . $conditionW. " cases.deleted=0  group by week(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
	//echo "<br><br><br><br>";
	$result = $db->query($query_query_w);
   foreach($result as $resultw)
   {
      $_Wrow[] = $resultw['count(cases.id)'];
   }
	
	return array_sum($_Wrow);
   }
   
    public function checkReportPeriodUCR($condition,$condition_group,$dateform,$dateto)
   {
    global $db, $app_list_strings;
	$_Wrow = array();
       $_Weekdate =   date("Y-m-d", strtotime("-1 day", strtotime($dateto)));
    $conditionW = " DATE(cases.date_entered) BETWEEN '" .$dateform . "' AND '" . $_Weekdate . "' AND ";
    
    $query_query_w = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
							. "cases_cstm.member_tier_c,cases.status,"
							. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
							. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
							. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
							. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
							. " cases.date_entered , cases.assigned_user_id FROM cases "
							. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
							. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
							. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
							. " where " . $condition . $conditionW. " cases.status NOT IN('Resolved','Closed') AND cases.deleted=0  group by week(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
	 $result = $db->query($query_query_w);
   foreach($result as $resultw)
   {
      $_Wrow[] = $resultw['count(cases.id)'];
   }
	
	return array_sum($_Wrow);
   }
   
   public function get_number_of_days_in_month($_Month, $_year) {
					// Using first day of the month, it doesn't really matter
					$date = $year."-".$month."-1";
					return date("t", strtotime($date));
	}
			
			
   public function createMonthdd()
   {
   
		/*if(date("m") <= 06){
		$_CurrentYear = date("Y"); // current year
		$_NextYears =  date("Y")-1; //previous year 
        $start_date =  date($_NextYears.'-07-01'); //common from date
		$end_date =  date($_CurrentYear.'-06-30'); 
		$_MonthLoopCount = $this->datediff('m',date("y-m-d",strtotime($start_date )),date("y-m-d",strtotime($end_date)));				 
        }
		else{
		$_CurrentYear =  date("Y"); // current year
		$_NextYears  =  date("Y") + 1;  // post year 
		$start_date =  date($_CurrentYear.'-07-01'); //common from date
		$end_date =  date($_NextYears.'-06-30'); 
		$_MonthLoopCount = $this->datediff('m',date("y-m-d",strtotime($start_date )),date("y-m-d",strtotime($end_date)));				 
		}*/
        /*month logic start */
		 $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
		 $_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
         $_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
         $start_date  = $_Year."-".$_Month."-"."1";  //start date
		 $end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
	     $_MonthLoopCount = $this->datediff('m',date("y-m-d",strtotime($start_date )),date("y-m-d",strtotime($end_date)));				 
        /*month logic end */
		for($i=0;$i<=$_MonthLoopCount+1;$i++)
		{
		 $_DailyLoopC[date ("M-Y", strtotime("+ $i month", strtotime($start_date)))] =  date ("M-Y", strtotime("+ $i month", strtotime($start_date)));
		}
		return  $_DailyLoopC;
   }
   
    public function creatWeeklydd()
   {
   
		if(date("m") <= 06){
		$_CurrentYear = date("Y"); // current year
		$_NextYears =  date("Y")-1; //previous year 

		$start_date =  date($_NextYears.'-07-01'); //common from date
		$end_date =  date($_CurrentYear.'-06-30'); 
		//$_WeekLoopCount = $this->datediff('ww',$start_date ,$end_date )." Week<br>";
		$_WeekLoopCount = $this->datediff('ww',$start_date ,$end_date )." Week<br>";
        }
		else{
		$_CurrentYear =  date("Y"); // current year
		$_NextYears  =  date("Y") + 1;  // post year 
		$start_date =  date($_CurrentYear.'-07-01'); //common from date
		$end_date =  date($_NextYears.'-06-30'); 
		$_WeekLoopCount = $this->datediff('ww',$start_date ,$end_date )." Week<br>";
		}
		
		


		for($i=1;$i<=$_WeekLoopCount;$i++)
		{
	//	$_DailyLoopC[date ("Y-m-d", strtotime("+ $i week", strtotime($start_date)))] =  "week ".$i ."  ".'('.date ("Y-m-d", strtotime("+ $i week", strtotime($start_date))).")";
	    $_DailyLoopC[$i] =  "Week ".$i;

		}
		return  $_DailyLoopC;
   }
   
   
   public function  creatQuarterdd($sdate, $edate) 
   {
   
 /*  if(date("m") <= 06){
						$_CurrentYear = date("Y"); // current year
						$_NextYears =  date("Y")-1; //previous year 
						$start_date =  date($_NextYears.'-07-01'); //common from date
						$end_date =  date($_CurrentYear.'-06-30'); 
						$_GetQuarters = $this->getQuarters(date("m-d-Y",strtotime($start_date)),date("m-d-Y",strtotime($end_date )));
                       }
						else{
						$_CurrentYear =  date("Y"); // current year
						$_NextYears  =  date("Y") + 1;  // post year
						$start_date =  date($_CurrentYear.'-07-01'); //common from date
						$end_date =  date($_NextYears.'-06-30'); 
						$_GetQuarters = $this->getQuarters(date("m-d-Y",strtotime($start_date)),date("m-d-Y",strtotime($end_date )));
					   } */
		      /* $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
				$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
				$start_date  = $_Year."-".$_Month."-"."1";  //start date
				$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
				$_GetQuarters = $this->getQuarters(date("m-d-Y",strtotime($start_date)),date("m-d-Y",strtotime($end_date )));
			

		if($_GetQuarters == 'no-quarters'):
				$_GetQuartersDate = date("Y-m-d",strtotime($start_date));
				$_GetQuartersEndDate = date("Y-m-d",strtotime($end_date));
				$_noQuarter = "no-quarters";
				$_GetOneQuarters[$_GetQuartersEndDate] = $this->checkReportPeriodQuarter($condition,$condition_group,$_GetQuartersDate,$_GetQuartersEndDate,$ReportName,$_noQuarter);
				
				else:
				foreach($_GetQuarters as $_GetQuarters1)
				{
				foreach($_GetQuarters1 as $_GetQuarters2)
				{
				 $_GetQuartersDate  = date("Y-m-d",strtotime(array_values((array)$_GetQuarters2)[0]));
				 $_DailyLoopC[] =  date("Y-m-d",strtotime(array_values((array)$_GetQuarters2)[0]));
				 $_GetQuartersEndDate = date ("Y-m-d", strtotime("+ 3 month", strtotime(array_values((array)$_GetQuarters2)[0])));
				 $_GetPeroid[date("Y-m-d",strtotime(array_values((array)$_GetQuarters2)[0]))] = $this->checkReportPeriodQuarter($condition,$condition_group,$_GetQuartersDate,$_GetQuartersEndDate,$ReportName);
				} 
				}
			    endif;	
				$i=1;
				$_GetPeroid[$end_date] = date ("Y-m-d", strtotime("+ 3 month", strtotime(end($_DailyLoopC))));
				// echo "<pre>";
				//print_r($_GetPeroid );
				 foreach($_GetPeroid as $_GetPeroidKey => $_GetPeroidData)
					 { 
					 $_Qendate = date ("Y-m-d", strtotime("+ 3 month", strtotime($_GetPeroidKey)));
					 $_GetPeroidSd = date("M y",strtotime($_GetPeroidKey));
					 $_GetPeroided = date("Y-m-d",strtotime($_Qendate));
					 $_GerQuaterdd[$i] = "Q ".$i ;
					 $i++;
					} 
					
			return $_GerQuaterdd;
		*/	
			
		//$current_date = date("Y-m-d");
			//$edate = date('Y-m-d', strtotime($current_date."-1 days"));
			//$sdate = date('Y-m-1', strtotime("-1 year", strtotime($edate)));
			$quarters = array();
			$month = date('m', strtotime($sdate));

			if( $month >=1 && $month <= 3){
			$sdate = date('Y-1-1', strtotime($sdate));
			} elseif($month >= 4 && $month <= 6){
			$sdate = date('Y-4-1', strtotime($sdate));
			} elseif($month >= 7 && $month <= 9){
			$sdate = date('Y-7-1', strtotime($sdate));
			} elseif($month >= 10 && $month <= 12){
			$sdate = date('Y-10-1', strtotime($sdate));
			}

			for($i=1; $i <= 5; $i++) {
			$monthCount = date('m', strtotime($sdate));
			$year = date('Y', strtotime($sdate));
			if( $monthCount >=1 && $monthCount <= 3){
			$quarters[$i]['name'] = 'Q3';
			$quarters[$i]['year'] = $year-1 .' - ' . $year;
			$quarters[$i]['sdate'] = $sdate;
			$quarters[$i]['edate'] = date('Y-m-t', strtotime("+2 months", strtotime($sdate)));
			} elseif($monthCount >= 4 && $monthCount <= 6){
			$quarters[$i]['name'] = 'Q4';
			$quarters[$i]['year'] = $year-1 .' - ' . $year;
			$quarters[$i]['sdate'] = $sdate;
			$quarters[$i]['edate'] = date('Y-m-t', strtotime("+2 months", strtotime($sdate)));
			} elseif($monthCount >= 7 && $monthCount <= 9){
			$quarters[$i]['name'] = 'Q1';
			$quarters[$i]['year'] = $year .' - ' . ($year+1);
			$quarters[$i]['sdate'] = $sdate;
			$quarters[$i]['edate'] = date('Y-m-t', strtotime("+2 months", strtotime($sdate)));
			} elseif($monthCount >= 10 && $monthCount <= 12){
			$quarters[$i]['name'] = 'Q2';
			$quarters[$i]['year'] = $year .' - ' . ($year+1);
			$quarters[$i]['sdate'] = $sdate;
			$quarters[$i]['edate'] = date('Y-m-t', strtotime("+2 months", strtotime($sdate)));
			}
			$sdate = date('Y-m-d', strtotime( "+3 months", strtotime($sdate)));
			}
			$i=0;
			foreach($quarters as $_GetPeroidKey => $_GetPeroidData)
					 { 
					 $_GerQuaterdd[$_GetPeroidData['sdate']."_".$_GetPeroidData['edate']."_".$i] = $_GetPeroidData['name']."(".$_GetPeroidData['year'].")";
					 
					 //$_GetPeroidData['sdate'];
					 //$_GetPeroidData['edate'];
					 $i++;
					} 
					//
			return $_GerQuaterdd;	
			
         
	}
    
	
	public function  Quarterlabelreportpdf($_Quaval) 
    { 
			$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
			$end_date = $_curdate;
			$sdate = date('Y-m-1', strtotime("-1 year"));
            $quarters = array();
			$month = date('m', strtotime($sdate));

			if( $month >=1 && $month <= 3){
			$sdate = date('Y-1-1', strtotime($sdate));
			} elseif($month >= 4 && $month <= 6){
			$sdate = date('Y-4-1', strtotime($sdate));
			} elseif($month >= 7 && $month <= 9){
			$sdate = date('Y-7-1', strtotime($sdate));
			} elseif($month >= 10 && $month <= 12){
			$sdate = date('Y-10-1', strtotime($sdate));
			}

			for($i=1; $i <= 5; $i++) {
			$monthCount = date('m', strtotime($sdate));
			$year = date('Y', strtotime($sdate));
			if( $monthCount >=1 && $monthCount <= 3){
			$quarters[$i]['name'] = 'Q3';
			$quarters[$i]['year'] = $year-1 .' - ' . $year;
			$quarters[$i]['sdate'] = $sdate;
			$quarters[$i]['edate'] = date('Y-m-t', strtotime("+2 months", strtotime($sdate)));
			} elseif($monthCount >= 4 && $monthCount <= 6){
			$quarters[$i]['name'] = 'Q4';
			$quarters[$i]['year'] = $year-1 .' - ' . $year;
			$quarters[$i]['sdate'] = $sdate;
			$quarters[$i]['edate'] = date('Y-m-t', strtotime("+2 months", strtotime($sdate)));
			} elseif($monthCount >= 7 && $monthCount <= 9){
			$quarters[$i]['name'] = 'Q1';
			$quarters[$i]['year'] = $year .' - ' . ($year+1);
			$quarters[$i]['sdate'] = $sdate;
			$quarters[$i]['edate'] = date('Y-m-t', strtotime("+2 months", strtotime($sdate)));
			} elseif($monthCount >= 10 && $monthCount <= 12){
			$quarters[$i]['name'] = 'Q2';
			$quarters[$i]['year'] = $year .' - ' . ($year+1);
			$quarters[$i]['sdate'] = $sdate;
			$quarters[$i]['edate'] = date('Y-m-t', strtotime("+2 months", strtotime($sdate)));
			}
			$sdate = date('Y-m-d', strtotime( "+3 months", strtotime($sdate)));
			}
			$i=0;
			
			foreach($quarters as $_GetPeroidKey => $_GetPeroidData)
					 { 
					 $_GerQuaterdd[$_GetPeroidData['sdate']."_".$_GetPeroidData['edate']."_".$i] = $_GetPeroidData['name']."(".$_GetPeroidData['year'].")";
					 
					 //$_GetPeroidData['sdate'];
					 //$_GetPeroidData['edate'];
					 $i++;
					} 
		return $_GerQuaterdd[$_Quaval];
    }
	public function creatYearsdd()
	{
         $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
		 $_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
         $_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
         $start_date  = $_Year."-".$_Month."-"."1";  //start date
		 $end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
	     $_MonthLoopCount = $this->datediff('yyyy',date("y-m-d",strtotime($start_date )),date("y-m-d",strtotime($end_date)));				 
         $_CurrentYear = date("Y"); // current year
         $_PreviousYears = date("Y")-1; //previous year 
		 $_Year =  array($_PreviousYears,$_CurrentYear);
		 foreach($_Year as $_Year1)
		 {
		  $_YearDd[$_Year1] = $_Year1;
		 }
		
		return  $_YearDd;
	}	
   
    public function checkReportPeriodQuarteresa($condition= null,$condition_group= null,$dateform,$dateto,$getquarters = null)
   {
    global $db, $app_list_strings;
	$_Yrow = array();
	$conditionY = " DATE(cases.date_entered) BETWEEN '" .$dateform . "' AND '" . $dateto . "' AND ";
	$query_query_Y = "SELECT count(cases.id),cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$conditionY. $condition . " cases.deleted=0 and cases.caseescalate_c > 0 AND cases.status != 'Resolved' group by QUARTER(cases.date_entered)".$condition_group." ORDER BY cases.date_entered DESC";
	$resultY = $db->query($query_query_Y);

    foreach($resultY as $resulty)
    {
	 $_Yrow[] = $resulty['count(cases.id)'];
    }
	if(isset($getquarters)):
	 return array_sum($_Yrow);
	else:
	 return array_sum($_Yrow);
	endif;
   }
   
	

    //end unresolved cases
    //1.2.1.3.6 Volume of Cases By Customer Service Associates
    public function action_volumecc() {
        
        global $db, $app_list_strings;
		global $sugar_config;
		$ReportName = 'volumecc';
        $this->view = 'volumecc';
        $this->view_object_map['getAllCaseCategory'] = $this->getAllCaseCategory();
        $this->view_object_map['getTimePeriod'] = $this->getTimePeriod();
		$this->view_object_map['site_url'] = $sugar_config['site_url'];
		$this->view_object_map['createMonthdd'] = $this->createMonthdd();
		$this->view_object_map['creatWeeklydd'] = $this->creatWeeklydd();
		
		//get branch store name
		$this->view_object_map['branch_store_name'] = $this->getAllBranchName();
		$this->view_object_map['getYearDd'] = $this->creatYearsdd();
		$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
		$end_date = $_curdate;
		$start_date = date('Y-m-1', strtotime("-1 year"));
		$this->view_object_map['creatQudd'] = $this->creatQuarterdd($start_date,$end_date);
		
        $volumecc = $queryCase = $_Yearquery= $_ColumnsDate=$volumeDate=$_DailyLoopC=$_DateEnteredArray
		=$volumecc_grid=$_NoOfQuarters=$_GetOneQuarters=array();
		$_WeeklyGlobal = $_QuaterlyGlobal = $_MonthGlobal = 0;
        $condition = $condition_group=$_StartMonth = $_EndMonth = $_StartW= $_EndW  =$_StartQ  =$_EndQ = '';
 
            if (isset($_REQUEST['query']) == 'true') {
            if ($_REQUEST['category_id'] || $_REQUEST['period'] || $_REQUEST['origin'] ||
                    $_REQUEST['from_date'] || $_REQUEST['to_date']) {
                
                if ($_REQUEST['category_id'] == "all") {
                    $condition .= "";
					$condition_group .= "";
				 }else
				 {
				     $condition .= "  cases_cstm.category_c = '" . $_REQUEST['category_id'] . "' AND ";
					$condition_group .= ",cases_cstm.category_c";
				 }
				 
				 
               /* if ($_REQUEST['category_id'] && empty($_REQUEST['origin'])) {
                    $condition .= "  cases_cstm.category_c = '" . $_REQUEST['category_id'] . "' AND ";
					$condition_group .= ",cases_cstm.category_c";
				 } */
                if ($_REQUEST['origin'] == "all")  {
                    $condition .= " ";
					$condition_group .= "";
                }else
				 {
				    $condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
					$condition_group .= ",cases_cstm.origin_c";
				 }
				 
				 if ($_POST['branch_store_name'] == "all"  || $_POST['branch_store_name'] == "" )  {
				$condition .= " ";
				}else
				{
				$condition .= "  cases.branch_store_name = '" . $_POST['branch_store_name'] . "'  AND ";
				}
				
				if ($_REQUEST['sub_category_id']  == "all") {
                    $condition .= " ";
					$condition_group .= "";
                }else
				 {
				    $condition .= "  cases_cstm.subcategory_c = '" . $_REQUEST['sub_category_id'] . "'  AND ";
					$condition_group .= ",cases_cstm.subcategory_c";
				 }
                
				if(!empty($_POST['periodmonthsdd'])):
				  $_StartMonth = $_POST['periodmonthsdd'];
				endif;
				
				if(!empty($_POST['periodmonthedd'])):
				  $_EndMonth = $_POST['periodmonthedd'];
				endif;
				
				if(!empty($_POST['periodweeksdd'])):
				  $_StartW = $_POST['periodweeksdd'];
				endif;
				
				if(!empty($_POST['periodweekedd'])):
				  $_EndW = $_POST['periodweekedd'];
				endif;
				
				if(!empty($_POST['periodquasdd'])):
				  $_StartQ = $_POST['periodquasdd'];
				endif;
				
				if(!empty($_POST['periodquaedd'])):
				  $_EndQ = $_POST['periodquaedd'];
				endif;
				
				
			    /*if (!empty($_REQUEST['origin']) && !empty($_REQUEST['category_id']) && !empty($_REQUEST['sub_category_id'])) {
				
					$condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND  cases_cstm.category_c = '" . $_REQUEST['category_id'] . "' AND cases_cstm.subcategory_c = '".$_REQUEST['sub_category_id']."' AND";
					$condition_group .= ",cases_cstm.origin_c,cases_cstm.category_c,cases_cstm.subcategory_c";
                 } */
            /*checking query starting*/
			$start_date = date("Y-m-d",strtotime($_REQUEST['from_date']));
			$end_date = date("Y-m-d",strtotime($_REQUEST['to_date']));

			
				
			$start_date = $_REQUEST['from_date']; //fromdate for post
			$this->view_object_map['getFromDate'] = $start_date;
			$end_date = $_REQUEST['to_date']; //todate for post
			$this->view_object_map['getToDate'] = $end_date;
			$_Periodpost = $_REQUEST['period']; //period for post
			$this->view_object_map['getPeriod'] = $_Periodpost;
			$_Oroginpost = $_REQUEST['origin']; //origin for post
			$this->view_object_map['getOrigin'] = $_Oroginpost;
			$_Categorypost = $_REQUEST['category_id']; //categoryid for post
			$this->view_object_map['getCategory'] = $_Categorypost;
			$_Subcatgorypost = $_REQUEST['sub_category_id']; //sucategoryid for post
			$this->view_object_map['getSubCategory'] = $_Subcatgorypost;
			$this->view_object_map['getStartmonth'] =  $_StartMonth; // selected month start
			$this->view_object_map['getEndmonth'] = $_EndMonth ; // selected month end
			$this->view_object_map['periodquasdd'] =  $_StartQ; // selected month start
			$this->view_object_map['periodquaedd'] = $_EndQ ; // selected month end
			$this->view_object_map['getStartweek'] =  $_StartW; // selected month start
			$this->view_object_map['getEndweek'] =  $_EndW; // selected month end
			$this->view_object_map['sub_category_id'] = $_POST['sub_category_id']; // selected subcat
			$_BranchStore = $_REQUEST['branch_store_name']; //branch_store_name for post
            $this->view_object_map['getBranchName'] = $_BranchStore;
			$this->view_object_map['getFromyear'] = $_POST['getYearsDd']; // selected from year
		    $this->view_object_map['getToyear'] = $_POST['getYeareDd']; // selected  to year
			if($_REQUEST['period'] == "daily"):
						
						$_DailyLoopCount = $this->datediff('d',date("y-m-d",strtotime($_REQUEST['from_date'])),date("y-m-d",strtotime($_REQUEST['to_date'])));				 

						for($i=0;$i<=$_DailyLoopCount;$i++)
						{
						$_DailyLoopC[] =  date ("Y-m-d", strtotime("+$i day", strtotime($start_date)));
						}
						
						if ($_REQUEST['from_date'] && $_REQUEST['to_date']) {
								$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";
						}
								
								
					    $query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where " . $condition . " cases.deleted=0  group by date(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
								
						$result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecc[] = $row;
					    $volumeDate[] = date("Y-m-d",strtotime($row['date_entered']));
						}
						else:
						$row['emptyrecord'] = "N/A";
                       // $volumecc[] = $row;
						endif;
						
					   
					
                elseif($_REQUEST['period'] == "weekly"):
				
					    /*current year cycle week calculation*/
						
						if(date("m") <= 06){
						$_CurrentYear = date("Y"); // current year
						$_NextYears =  date("Y")-1; //previous year 
						
						$start_date =  date($_NextYears.'-07-01'); //common from date
						$end_date =  date($_CurrentYear.'-06-30'); 
						$_WeekLoopCount = $this->datediff('ww',$start_date ,$end_date )." Week<br>";

						}
						else{
						$_CurrentYear =  date("Y"); // current year
						$_NextYears  =  date("Y") + 1;  // post year
						$start_date =  date($_CurrentYear.'-07-01'); //common from date
						$end_date =  date($_NextYears.'-06-30'); 
						$_WeekLoopCount = $this->datediff('ww',$start_date ,$end_date )." Week<br>";
						
						}
						//$_WeekLoopCount= $this->datediff('ww',date("y-m-d",strtotime($_REQUEST['from_date'])),date("y-m-d",strtotime($_REQUEST['to_date'])));				 

						for($i=0;$i<=$_WeekLoopCount;$i++)
						{
						$_DailyLoopC[] =  date ("Y-m-d", strtotime("+ $i week", strtotime($start_date)));
						}
						
						$_WeeklyGlobal = 1;
                        
						$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";
						
					    $query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
							. "cases_cstm.member_tier_c,"
							. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
							. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
							. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
							. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
							. " cases.date_entered , cases.assigned_user_id FROM cases "
							. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
							. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
							. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
							. " where " . $condition . " cases.deleted=0  group by week(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";

						$result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
						$volumecc[] = $row;
						}
						else:
						$row['emptyrecord'] = "N/A";
						// $volumecc[] = $row;
						endif;
				 
				elseif($_REQUEST['period'] == "monthly"):
				        $_MonthGlobal = 1;
						$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
						$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
						$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
						$start_date  = $_Year."-".$_Month."-"."1";  //start date
						$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
						$_MonthLoopCount = $this->datediff('m',date("y-m-d",strtotime($start_date )),date("y-m-d",strtotime($end_date)));				 
						/*month logic end */
						for($i=0;$i<=$_MonthLoopCount+1;$i++)
						{
						$_DailyLoopC[] =  date ("M-Y", strtotime("+ $i month", strtotime($start_date)));
						}
						$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";
					    $query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
							. "cases_cstm.member_tier_c,"
							. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
							. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
							. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
							. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
							. " cases.date_entered , cases.assigned_user_id FROM cases "
							. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
							. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
							. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
							. " where " . $condition . " cases.deleted=0  group by month(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
						$result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['date_entered'] = date("M-Y",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
						$volumecc[] = $row;
						}
						else:
						$row['emptyrecord'] = "N/A";
						// $volumecc[] = $row;
						endif;
				elseif($_REQUEST['period'] == "quarterly"):
				$_QuaterlyGlobal =1;
				/*quater logic start*/
				$_Start_Q = explode("_",$_StartQ);
				$_OpenQ = $_Start_Q[2];
				$_End_Q = explode("_",$_EndQ);
				$_EndQ = $_End_Q[2];
				/* end */
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
				$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
			    $start_date  = $_Year."-".$_Month."-"."1";  //start date
				$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
				$_CurrentYear = date("Y"); // current year
				$_PreviousYears = date("Y")-1; //previous year 
				
				
				$from = $_POST['getYearsDd'];
				$to = $_POST['getYeareDd'];
				
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				
				$this->view_object_map['creatQudd'] = $this->creatQuarterdd($start_date,$end_date);
				//echo "<pre>";
				//print_r($this->view_object_map['creatQudd'] );
                $_Startq = explode("_",$_StartQ); 
				$_Endq = explode("_",$_EndQ); 
				$_GetQuarters = $this->creatQuarterdd($start_date,$end_date);

				foreach($_GetQuarters as $_GetQuarters1Key=>$_GetQuarters1)
				{
				$_Startq = explode("_",$_GetQuarters1Key); 
				
				$_DailyLoopC[$_GetQuarters1Key] = $_GetQuarters1;
				$_GetPeroid[$_GetQuarters1Key."_".$_GetQuarters1] = $this->checkReportPeriodQuarter($condition,$condition_group,$_Startq[0],$_Startq[1],$ReportName);

                }				
				//$_GetQuarters = $this->getQuarters(date("m-d-Y",strtotime($start_date)),date("m-d-Y",strtotime($end_date )));
				/*if($_GetQuarters == 'no-quarters'):
				$_GetQuartersDate = date("Y-m-d",strtotime($start_date));
				$_GetQuartersEndDate = date("Y-m-d",strtotime($end_date));
				$_noQuarter = "no-quarters";
				$_GetOneQuarters[$_GetQuartersEndDate] = $this->checkReportPeriodQuarter($condition,$condition_group,$_GetQuartersDate,$_GetQuartersEndDate,$ReportName,$_noQuarter);
				
				else:
				foreach($_GetQuarters as $_GetQuarters1)
				{
	
				foreach($_GetQuarters1 as $_GetQuarters2)
				{
				 $_GetQuartersDate  = date("Y-m-d",strtotime(array_values((array)$_GetQuarters2)[0]));
				 $_DailyLoopC[] =  date("Y-m-d",strtotime(array_values((array)$_GetQuarters2)[0]));
				 //$_GetQuartersEndDate = date ("Y-m-d", strtotime("+ 3 month", strtotime(array_values((array)$_GetQuarters2)[0])));
				 $_GetQuartersEndDate = date('Y-m-d' ,strtotime("- 1 days", strtotime("+ 3 month", strtotime(array_values((array)$_GetQuarters2)[0])))); 
				 $_GetPeroid[date("Y-m-d",strtotime(array_values((array)$_GetQuarters2)[0]))] = $this->checkReportPeriodQuarter($condition,$condition_group,$_GetQuartersDate,$_GetQuartersEndDate,$ReportName);
				} 
				}
			    endif;
				
				*/
				
				
				
				
				
			    $query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where " . $condition . " cases.deleted=0  group by QUARTER(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
				
				        $result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['date_entered'] = date("Y",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecc[] = $row;
						}
						else:
						$row['emptyrecord'] = "N/A";
                       // $volumecc[] = $row;
						endif;
			    elseif($_REQUEST['period'] == "annual"):
				
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
				$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
			    $start_date  = $_Year."-".$_Month."-"."1";  //start date
				$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
				$_CurrentYear = date("Y"); // current year
				$_PreviousYears = date("Y")-1; //previous year 
				if ($_POST['getYearsDd'] != $_POST['getYeareDd']) {
					$_Year =  array($_PreviousYears,$_CurrentYear);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}else{
				    $_Year =  array($_POST['getYearsDd']);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}
				
				$from = $_POST['getYearsDd'];
				$to = $_POST['getYeareDd'];
				
				if ($_POST['getYearsDd'] != $_POST['getYeareDd']) {
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				} else {
				$start_date = date('Y-m-d', strtotime("$from-01-01"));
				$end_date = date('Y-m-d', strtotime("$from-12-31"));
				}
				
						
				 $condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d", strtotime($start_date)) . "' AND '" . date("y-m-d", strtotime($end_date)) . "' AND ";
							
					
					
				$query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where " . $condition . " cases.deleted=0  group by year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
				
				$result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['date_entered'] = date("Y",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecc[] = $row;
						}
						else:
						$row['emptyrecord'] = "N/A";
                       // $volumecc[] = $row;
						endif;
				else:
				if ($_REQUEST['category_id'] && empty($_REQUEST['origin'])) {
				$condition .= "  cases_cstm.category_c = '" . $_REQUEST['category_id'] . "' AND ";
				$condition_group .= ",cases_cstm.category_c";
				}
				if ($_REQUEST['origin'] && empty($_REQUEST['category_id'])) {
				$condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
				$condition_group .= ",cases_cstm.origin_c";
				}

				if (!empty($_REQUEST['origin']) && !empty($_REQUEST['category_id'])) {
				$condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND  cases_cstm.category_c = '" . $_REQUEST['category_id'] . "' AND";
				$condition_group .= ",cases_cstm.origin_c,cases_cstm.category_c";
				}

				/*checking query starting*/
				$start_date = date("Y-m-d",strtotime($_REQUEST['from_date']));
				$end_date = date("Y-m-d",strtotime($_REQUEST['to_date']));
				$_DailyLoopCount = $this->datediff('d',date("y-m-d",strtotime($_REQUEST['from_date'])),date("y-m-d",strtotime($_REQUEST['to_date'])));				 

			    for($i=0;$i<=$_DailyLoopCount;$i++)
				{
				  $_DailyLoopC[] =  date ("Y-m-d", strtotime("+$i day", strtotime($start_date)));
				}
						
				if ($_REQUEST['from_date'] && $_REQUEST['to_date']) {
				  $condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";
				}
								
								
				$query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where " . $condition . " cases.deleted=0  group by date(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
								
						$result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecc[] = $row;
					    $volumeDate[] = date("Y-m-d",strtotime($row['date_entered']));
						}
						else:
						$row['emptyrecord'] = "N/A";
                       // $volumecc[] = $row;
						endif;
				endif;
				if($_POST['period'] == 'monthly'){//for month start

			     $_MonthStartArray = array_keys($_DailyLoopC,$_StartMonth);
				 $_MonthEndArray =  array_keys($_DailyLoopC,$_EndMonth);
				 $_Totvalue = $_MonthEndArray[0]-$_MonthStartArray[0];
			     $_DailyLoopC = array_slice($_DailyLoopC,$_MonthStartArray[0],$_Totvalue+1);
				 //for month end
				}
				if($_WeeklyGlobal == 1)
				{
					if(count($volumecc)):
						 foreach($volumecc as $volumeccData)
						 {
							$_DateEntered1Array[$volumeccData['date_entered']] = $volumeccData['date_entered']."_".$volumeccData['category_c']."_".$volumeccData['origin_c']."_".$volumeccData['count(cases.id)'];
						 }
					endif;
				}
				else{
					if(count($volumecc)):
						 foreach($volumecc as $volumeccData)
						 {
							$_DateEnteredArray[] = $volumeccData['date_entered'];
							$_DateEntered1Array[$volumeccData['date_entered']] = array($volumeccData['date_entered'],$volumeccData['category_c'],$volumeccData['origin_c'],$volumeccData['count(cases.id)']);
						 }
					endif;
				}
//$_DailyLoopCData,$_DateEnteredArray))
				// echo "<br>";
				$_yearRecord = array();
				if(!empty($_DateEntered1Array)):
				 foreach($_DateEntered1Array as $_DateEntered1Array1)
				 {
				  $_yearRecord[]  = $_DateEntered1Array1[3];
				 }
				 endif;
				 
				$i = 1;
                if(count($_DailyLoopC) > 0):
				if($_QuaterlyGlobal==1):
				
				$temp2 = array();
				//for($p = $_StartQ; $p <= $_EndQ; $p++){
				//$temp2[] = $p;
				//}
				$_OpenQua = array();
				for($_OpenQ;$_OpenQ<=$_EndQ;$_OpenQ++){
				$_OpenQua[] = $_OpenQ;
				}
			   foreach($_GetPeroid as $_GetPeroidKey => $_GetPeroidData)
					 { 
					/* if($_POST['period'] == 'quarterly'):
					 if(!in_array($i,$temp2)){
					 $i++;
						continue;
						
					 }
					 endif;
					 */
					 				
					$_GetPeroidDisaply = $_GetPeroidKey;
					$_GetPeroidDisaply =  explode("_",$_GetPeroidDisaply);

					$_Qendate = date ("M y", strtotime("+ 3 month", strtotime($_GetPeroidKey)));
					$_GetPeroidSd =  date ("M y",strtotime($_GetPeroidKey));
					$_GetPeroided = $_Qendate;
					 if($_REQUEST['category_id'] == 'all'):
						$_Catname = 'All';
					 else:
						$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
					 endif;
					 

					$start_date = $_Startdate['start_date'];
					$end_date = $_Startdate['end_date'];

					if(in_array($_GetPeroidDisaply[2],$_OpenQua)):
					$_GetPeroidKey = explode("_",$_GetPeroidKey);
					if($_GetPeroidData== 0):
					 $volumecc_grid[] = "<tr>
					 <td>".$_GetPeroidKey[3]."</td>
							 <td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>
							 <td>".$_Catname."</td>
							 <td>0</td>";
					  $volumecc_grid[] = "</tr>";
					else:
					 $volumecc_grid[] = "<tr>
					 <td>".$_GetPeroidKey[3]."</td>
							 <td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>
							 <td>".$_Catname."</td>
							 <td class=counter onclick='checkclick(this.title)' id=Dailydata_".$_GetPeroidKey." title=daily_".$_GetPeroidKey[0]."_".$_GetPeroidKey[1].">".$_GetPeroidData."</td>";
					  $volumecc_grid[] = "</tr>";
					endif;
				    
				     $volumecc_grid[] ="<tr class=dailyresulthide id=dailyresult_".$_GetPeroidKey[0]."_".$_GetPeroidKey[1]." style=display:none>
						 <td colspan='4' class='parent-TD'>
						 </td></tr>";
				     $i++;
					 endif;
					 
					 }
                else:
						$temp2 = array();
						for($p = $_StartW ; $p <= $_EndW ; $p++){
						$temp2w[] = $p;
						}
				
				foreach($_DailyLoopC as $_DailyLoopCDataKey => $_DailyLoopCData)
					 { 
					 
					 if($_POST['period'] == 'weekly'):
					 if(!in_array($i,$temp2w)){
					 $i++;
						continue;
						
					 }
					  endif;
				 
				   if($_WeeklyGlobal == 1):
				   
				 
						/*weekly interval*/
						//	if($_StartW <= 45):
					    $_WeekStartdate = $_DailyLoopCData; //weekly date start
					    $_WeekEnddate =  date("Y-m-d", strtotime("+ 1 week", strtotime($_DailyLoopCData))); //weekly date ended
					    $_WeekEnddate =  date("Y-m-d", strtotime("-1 day", strtotime($_WeekEnddate)));
						$_WeekDateInterval = $this->returnBetweenDates($_WeekStartdate, $_WeekEnddate); 
					    $_GetPeroid = $this->checkReportPeriodreportcc($condition,$condition_group,$_WeekStartdate,$_WeekEnddate);
						
						$_WeekStartdate = date("d M Y",strtotime($_WeekStartdate));
						$_WeekEnddate = date("d M Y",strtotime($_WeekEnddate));
						
						if($_REQUEST['category_id'] == 'all'):
						$_Catname = 'All';
						else:
						$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
						endif;
						if($_GetPeroid==0):
							$volumecc_grid[] = "<tr><td><strong>Week ".$i."</strong> (".$_WeekStartdate." - ".$_WeekEnddate.")</td>
							 <td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>
							 <td>".$_Catname."</td>
							 <td>0</td>
							 </tr>";
						else:
							$volumecc_grid[] = "<tr><td>Week ".$i." (".$_WeekStartdate." - ".$_WeekEnddate.")</td>
						     <td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>
							 <td>".$_Catname."</td>
							 <td class=counter onclick='checkclick(this.title)' id=Dailydata_".$_DailyLoopCData." title=daily_".$_DailyLoopCData.">".$_GetPeroid."</td>
                             </tr>";
							  $volumecc_grid[] ="<tr class=dailyresulthide id=dailyresult_".$_DailyLoopCData." style=display:none>
						 <td colspan='4' class='parent-TD'>
						 </td></tr>";
                        endif;						
                      /*weekly interval*/
						
					elseif($_MonthGlobal ==1):
					
	                    if($_REQUEST['category_id'] == 'all'):
						$_Catname = 'All';
						else:
						$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
						endif;
						
						$volumecc_grid[] = "<tr>";
						if (in_array($_DailyLoopCData,$_DateEnteredArray))
						{
						//$key = array_search($_DailyLoopCData, $_DateEnteredArray);
						 $volumecc_grid[] = "<td>".$_DateEntered1Array[$_DailyLoopCData][0]."</td>";
						 $volumecc_grid[] = "<td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>";
						 $volumecc_grid[] = "<td>".$_Catname."</td>";
						 $volumecc_grid[] = "<td class=counter onclick='checkclick(this.title)' id=Dailydata_".$_DateEntered1Array[$_DailyLoopCData][0]." title=daily_".$_DateEntered1Array[$_DailyLoopCData][0].">".$_DateEntered1Array[$_DailyLoopCData][3]."</td>";
						}
						else
						{
						 $volumecc_grid[] =  "<td>".$_DailyLoopCData."</td>
						 <td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>
						 <td>".$_Catname."</td>
						 <td colspan=3>0"."</td>";
						}
						$volumecc_grid[] = "</tr>";
						$volumecc_grid[] ="<tr class=dailyresulthide id=dailyresult_".$_DailyLoopCData." style=display:none>
						 <td colspan='4' class='parent-TD'>
						 </td></tr>";
                    else:
						$volumecc_grid[] = "<tr>";
						if($_REQUEST['category_id'] == 'all'):
						$_Catname = 'All';
						else:
						$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
						endif;

                        if($_POST['period'] != 'daily'): 
							if (in_array($_DailyLoopCDataKey, $_DateEnteredArray)):
							$volumecc_grid[] = "<td>".$_DailyLoopCDataKey ."</td>";
                            $volumecc_grid[] = "<td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>";
							$volumecc_grid[] = "<td>".$_Catname."</td>";
							$volumecc_grid[] = "<td class=counter onclick='checkclick(this.title)' id=Dailydata_".$_DateEntered1Array[$_DailyLoopCData][0]." title=daily_".$_DailyLoopCDataKey.">".array_sum($_yearRecord)."</td>";

							else:
							$volumecc_grid[] = "<td>".$_DailyLoopCDataKey."</td>";
							$volumecc_grid[] = "<td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>";
							 $volumecc_grid[] = "<td>".$_Catname."</td>";
							$volumecc_grid[] = "<td>0</td>";
                            endif;

						else:
						    
						if (!in_array($_DailyLoopCData,$_DateEnteredArray))
						{
							$volumecc_grid[] =  "<td>".$_DailyLoopCData."</td><td>NA</td><td>NA</td><td>0</td>";
                        
						
						  // $volumecc_grid[] =  "<td>".$_DailyLoopCData."</td><td>".$this->getCaseOriginName($_REQUEST['origin'])."</td><td>".$_Catname."</td><td>0</td>";
                        }

						endif;						 
						 
						
						 $volumecc_grid[] = "</tr>";
					      
						 if (in_array($_DailyLoopCData,$_DateEnteredArray))
						 {
						 
						/*script for showing daily wise record*/
						 $_DailSSdate = $_DailyLoopCData; //start date
						 $_DailESdate =  date ("Y-m-d", strtotime("+1 day", strtotime($_DailyLoopCData))); //end date
						 
						$_DailyRowrecord =  $this->dailydataDailywise($_REQUEST['sub_category_id'] ,$_REQUEST['origin'],$_REQUEST['category_id'],$_DailSSdate, $_DailESdate,$_REQUEST['branch_store_name'] );
						/*script for showing daily wise record*/
                         foreach($_DailyRowrecord  as $_DailyRowrecord1):
       					 $volumecc_grid[] = "<tr style=padding:20px;>";
						 $volumecc_grid[] = "<td >".$_DailyRowrecord1['date_entered']."</td>";
						 $volumecc_grid[] = "<td >".$_DailyRowrecord1['origin_c']."</td>";
						 $volumecc_grid[] = "<td >".$_DailyRowrecord1['category_c']."</td>";
						 $volumecc_grid[] = "<td >1</td>";

						 $volumecc_grid[] = "</tr>";
						 endforeach;
						 }
						 $volumecc_grid[] ="<tr class=dailyresulthide id=dailyresult_".$_DailyLoopCData." style=display:none>
						 <td colspan='4' class='parent-TD'>
						 </td></tr>";
					endif;
					    //echo $_DailyLoopCData[$i]."checkarrayindex".$_DailyLoopCData[$i+1]."<br>"; 
						
					$i++;
				}

				endif;
				else:
                   
                endif;				 
				
				

		
				// echo "<br>";
				
                // $total1 = $result1->num_rows;
				/*checking query ending*/
           
            }
        }
        if (isset($total) > 0) {
            $this->view_object_map['total_cases'] = $total;
        } else {
            $this->view_object_map['total_cases'] = 0;
        }
        $this->view_object_map['volumeccgrid'] = $volumecc_grid;
    }
    
	
	function dailydataDailywise($_getSubcat,$_getOrigin,$_getCat,$_StartDate , $_EndDate ,$_getBranchstore)
    {
			global $db, $app_list_strings;
			$volumecc = array();
			$condition="";
			if ($_getCat == "all") {
			 $condition .= "";
			}else
			{
			 $condition .= "  cases_cstm.category_c = '" . $_getCat . "' AND ";
			}


			if ($_getOrigin == "all")  {
			$condition .= " ";
			}else
			{
			$condition .= "  cases_cstm.origin_c = '" . $_getOrigin . "'  AND ";
			}
			if ($_getBranchstore == "all"  || $_getBranchstore == "" )  {
				$condition .= " ";
				}else
				{
				$condition .= "  cases.branch_store_name = '" . $_getBranchstore . "'  AND ";
				}
			

			if ($_getSubcat  == "all") {
			$condition .= " ";
			}else
			{
			$condition .= "  cases_cstm.subcategory_c = '" . $_getSubcat . "'  AND ";
			}

		   $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .$_StartDate. "' AND '" .  $_StartDate . "' AND";
		   $queryDaily_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id FROM cases "
                        . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$condition . $conditiondAILY . " cases.deleted=0 ORDER BY cases.date_entered ASC";

			$result = $db->query($queryDaily_case);
			$total = $result->num_rows;
			if($total > 0):
			while ($row = $db->fetchByAssoc($result)) {
			$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$volumecc[] = $row;
            }
			else:
			$row['emptyrecord'] = "N/A";
			// $volumecc[] = $row;
			endif;
			
			return $volumecc;
			
			
    }

   
   function dailydataDailywiseEsca($_getSubcat,$_getOrigin,$_getbranchstore,$_getCat,$_StartDate , $_EndDate,$_Status,$Membertier)
    {
			global $db, $app_list_strings;
			$volumecc = array();
			$condition="";
			if ($_getCat == "all") {
			 $condition .= "";
			}else
			{
			 $condition .= "  cases_cstm.category_c = '" . $_getCat . "' AND ";
			}


			if ($_getOrigin == "all")  {
			$condition .= " ";
			}else
			{
			$condition .= "  cases_cstm.origin_c = '" . $_getOrigin . "'  AND ";
			}
            
			if ($_getbranchstore == "all" || $_getbranchstore == "")  {
			$condition .= " ";
			}else
			{
			$condition .= "  cases.branch_store_name = '" . $_getbranchstore . "'  AND ";
			}
			

			if ($_getSubcat  == "all") {
			$condition .= " ";
			}else
			{
			$condition .= "  cases_cstm.subcategory_c = '" . $_getSubcat . "'  AND ";
			}
            
			
			if ($Membertier == "all") {
			$condition .= "";
			}else
			{
			$condition .= "  cases_cstm.member_tier_c = '" . $Membertier . "' AND ";
			}

			if ($_Status  == "all") {
			$condition .= " ";
			}else
			{
			$condition .= "  cases.status = '" . $_Status . "'  AND ";
			}
				 
		   $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .$_StartDate. "' AND '" .  $_StartDate . "' AND";
		   
           $queryDaily_case = "SELECT cases.id,cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases 
			LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c 
			LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id
			LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id 
			AND jt0.deleted=0 AND jt0.deleted=0"
			. " where " . $condition .$conditiondAILY ." cases.deleted=0 and cases.caseescalate_c > 0 AND cases.status NOT IN('Resolved','Closed') ORDER BY cases.date_entered DESC";;
			$result = $db->query($queryDaily_case);
			$total = $result->num_rows;
			if($total > 0):
			while ($row = $db->fetchByAssoc($result)) {
			$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$volumecc[] = $row;
            }
			else:
			$row['emptyrecord'] = "N/A";
			// $volumecc[] = $row;
			endif;
			
		
			return $volumecc;
			
    }
	
    
    public function checkReportPeriodQuarter($condition,$condition_group,$dateform,$dateto, $reportName)
   {
    global $db, $app_list_strings;
	$_Yrow = array();
	if($reportName == "membertier"):
		$conditionY = " DATE(cases.date_entered) BETWEEN '" .$dateform . "' AND '" . $dateto . "' AND ";
		$query_query_Y = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where ". $condition . $conditionY . " cases.deleted=0  group by QUARTER(cases.date_entered),year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
		
		$resultY = $db->query($query_query_Y);
		foreach($resultY as $resulty)
		{
		 $_Yrow[] = $resulty['count(cases.id)'];
		}
		
		if(isset($getQuarters)):
		 return array_sum($_Yrow) ;
		else:
			return array_sum($_Yrow) ;
		endif;
	
	elseif($reportName == "unresolvedcases"):
	    $conditionY = " DATE(cases.date_entered) BETWEEN '" .$dateform . "' AND '" . $dateto . "' AND ";
		$query_query_Y = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where ". $condition . $conditionY . " cases.status NOT IN('Resolved','Closed') AND cases.deleted=0  group by QUARTER(cases.date_entered),year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
		$resultY = $db->query($query_query_Y);
		foreach($resultY as $resulty)
		{
		 $_Yrow[] = $resulty['count(cases.id)'];
		}
		if(isset($getQuarters)):
		 return array_sum($_Yrow) ;
		else:
			return array_sum($_Yrow) ;
		endif;
	
	elseif($reportName == "volumecc"):
	    $conditionY = " DATE(cases.date_entered) BETWEEN '" .$dateform . "' AND '" . $dateto . "' AND ";
		$query_query_Y = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where ". $condition . $conditionY . " cases.deleted=0  group by QUARTER(cases.date_entered),year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
		$resultY = $db->query($query_query_Y);
		foreach($resultY as $resulty)
		{
		 $_Yrow[] = $resulty['count(cases.id)'];
		}
		if(isset($getQuarters)):
		 return array_sum($_Yrow) ;
		else:
			return array_sum($_Yrow) ;
		endif;
	elseif($reportName == "volumecsr"):
	
	    $conditionY = " DATE(cases.date_entered) BETWEEN '" .$dateform . "' AND '" . $dateto . "' AND ";
		$query_query_Y = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where ". $condition . $conditionY . " cases.deleted=0  group by QUARTER(cases.date_entered),year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
		$resultY = $db->query($query_query_Y);
		foreach($resultY as $resulty)
		{
		 $_Yrow[] = $resulty['count(cases.id)'];
		}
		
		if(isset($getQuarters)):
		 return array_sum($_Yrow) ;
		else:
			return array_sum($_Yrow) ;
		endif;
	
	endif;
   }
	
	
    public function getQuarters($start, $end) {

        $StartDate = DateTime::createFromFormat('m-d-Y', $start);
        $EndDate   = DateTime::createFromFormat('m-d-Y', $end);

        $quarters  = new DatePeriod($StartDate, new DateInterval('P3M'), $EndDate);

        $p = 0;
        $r = [];
        foreach($quarters as $quarter) {
            if (!$p) {
                $q = [$quarter];
                $p++;
            } else {
                $q[] = $quarter;
                $p = 0;
                $r[] = $q;
            }
        }
        if(count($r) > 0):
             return $r;
        else:
             return 'no-quarters';
            endif;

}
    public function action_getdailydata() {
	  global $db, $app_list_strings;
	  $condition = "";
	   if($_POST['getperiod'] == 'daily'):
	       $_POST['daily'];
			if ($_POST['getcategory'] && empty($_POST['origin'])) {
			$condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
			}
			if ($_POST['origin'] && empty($_POST['getcategory'])) {
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
			}

			if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
			}
           $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .$_POST['daily'] . "' AND '" . $_POST['daily'] . "' AND";
		   $queryDaily_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id FROM cases "
                        . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$condition . $conditiondAILY . " cases.deleted=0 ORDER BY cases.date_entered DESC";

		
			$result = $db->query($queryDaily_case);
			$total = $result->num_rows;
			if($total > 0):
			while ($row = $db->fetchByAssoc($result)) {
			$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$volumecsa[] = $row;
            }
			else:
			$row['emptyrecord'] = "N/A";
			// $volumecsa[] = $row;
			endif;
			echo "<td colspan='4' class='parent-TD'><table>
			<tr><td></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong><td><strong>Priority</strong></td></tr>";
			foreach($volumecsa as $volumecsa1)
			{
			echo "<tr>";
			echo "<td>".$volumecsa1['date_entered']."</td>";
			echo "<td>".$volumecsa1['origin_c']."</td>";
			echo "<td>".$volumecsa1['category_c']."</td>";
			echo "<td>".$volumecsa1['priority']."</td>";
			echo "</tr>";	
			}
			echo "</table></td>";
			
	   elseif($_POST['getperiod']== 'monthly'):
	   
	        $_Dailypost = explode("-",$_POST['daily']);	
			$month =   $_Dailypost[0];
			$year = $_Dailypost[1];
		    $_Days = cal_days_in_month(CAL_GREGORIAN, $month, $year)-1;
		    $_fromdate = $year."-".$month."-".'01';
		    $_EndDate = date("Y-m-d",strtotime("+ ".$_Days." days",strtotime($_fromdate)));
		   if ($_POST['getcategory'] && empty($_POST['origin'])) {
			$condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
			}
			if ($_POST['origin'] && empty($_POST['getcategory'])) {
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
			}

			if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
			}
		   $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_fromdate)). "' AND '" . $_EndDate . "' AND date(cases.date_entered) <= '".date("y-m-d",strtotime($_POST['enddate']))."' AND date(cases.date_entered) >= '".date("y-m-d",strtotime($_POST['fromdate']))."' AND";
		    $queryDaily_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id FROM cases "
                        . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$condition . $conditiondAILY . " cases.deleted=0 ORDER BY cases.date_entered ASC";
 		    $result = $db->query($queryDaily_case);
			$total = $result->num_rows;
			if($total > 0):
			while ($row = $db->fetchByAssoc($result)) {
			$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$volumecsa[] = $row;
            }
			else:
			$row['emptyrecord'] = "N/A";
			// $volumecsa[] = $row;
			endif;
			echo "<td colspan='4' class='parent-TD'><table>
			<tr><td></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong><td><strong>Priority</strong></td></tr>";
			foreach($volumecsa as $volumecsa1)
			{
			echo "<tr>";
			echo "<td>".$volumecsa1['date_entered']."</td>";
			echo "<td>".$volumecsa1['origin_c']."</td>";
			echo "<td>".$volumecsa1['category_c']."</td>";
			echo "<td>".$volumecsa1['priority']."</td>";
			echo "</tr>";	
			}
			echo "</table></td>";
	  elseif($_POST['getperiod']== 'annual'):
        if ($_POST['getcategory'] && empty($_POST['origin'])) {
		$condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
		}
		if ($_POST['origin'] && empty($_POST['getcategory'])) {
		$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
		}

		if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
		$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
		}
	   $conditiondAILY = " year(cases.date_entered) = '" . $_POST['daily'] . "' AND date(cases.date_entered) <= '".date("y-m-d",strtotime($_POST['enddate']))."' AND date(cases.date_entered) >= '".date("y-m-d",strtotime($_POST['fromdate']))."' AND";
       $queryQuarterly_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id FROM cases "
                        . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$conditiondAILY . $condition. " cases.deleted=0 ORDER BY cases.date_entered ASC";
            $result = $db->query($queryQuarterly_case);
			$total = $result->num_rows;
			if($total > 0):
			while ($row = $db->fetchByAssoc($result)) {
			$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$volumecsa[] = $row;
            }
			else:
			$row['emptyrecord'] = "N/A";
			// $volumecsa[] = $row;
			endif;
			echo "<td colspan='4' class='parent-TD'><table>
			<tr><td></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong><td><strong>Priority</strong></td></tr>";
			foreach($volumecsa as $volumecsa1)
			{
			echo "<tr>";
			echo "<td>".$volumecsa1['date_entered']."</td>";
			echo "<td>".$volumecsa1['origin_c']."</td>";
			echo "<td>".$volumecsa1['category_c']."</td>";
			echo "<td>".$volumecsa1['priority']."</td>";
			echo "</tr>";	
			}
			echo "</table></td>";
       elseif($_POST['getperiod']== 'weekly'): 
        if ($_POST['getcategory'] && empty($_POST['origin'])) {
			$condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
			}
		if ($_POST['origin'] && empty($_POST['getcategory'])) {
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
			}

		if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
			}
	   $_EndDate = date ("Y-m-d", strtotime("+ 1 week", strtotime($_POST['daily'])));
	   $conditionW = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_POST['daily'])) . "' AND '" .  $_EndDate . "' AND ";
       $query_query_W = "SELECT cases.id,cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
							. "cases_cstm.member_tier_c,"
							. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
							. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
							. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
							. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
							. " cases.date_entered , cases.assigned_user_id FROM cases "
							. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
							. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
							. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
							. " where ". $condition . $conditionW . " cases.deleted=0 ORDER BY cases.date_entered ASC";
		$result = $db->query($query_query_W);
			$total = $result->num_rows;
			if($total > 0):
			while ($row = $db->fetchByAssoc($result)) {
			$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$volumecsa[] = $row;
            }
			else:
			$row['emptyrecord'] = "N/A";
			// $volumecsa[] = $row;
			endif;
			echo "<td colspan='4' class='parent-TD'><table>
			<tr><td></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong><td><strong>Priority</strong></td></tr>";
			foreach($volumecsa as $volumecsa1)
			{
			echo "<tr>";
			echo "<td>".$volumecsa1['date_entered']."</td>";
			echo "<td>".$volumecsa1['origin_c']."</td>";
			echo "<td>".$volumecsa1['category_c']."</td>";
			echo "<td>".$volumecsa1['priority']."</td>";
			echo "</tr>";	
			}
			echo "</table></td>";
       elseif($_POST['getperiod']== 'quarterly'):
		if ($_POST['getcategory'] && empty($_POST['origin'])) {
			$condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
			}
		if ($_POST['origin'] && empty($_POST['getcategory'])) {
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
			}

		if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
			}
	   $_EndDate = date ("Y-m-d", strtotime("+ 3 month", strtotime($_POST['daily'])));
            if($_CheckQuarters == 'no-quarters'):
	   	 $conditionY = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_POST['fromdate'])) . "' AND '" .  date("y-m-d",strtotime($_POST['enddate'])) . "' AND ";
            else:
                      $conditionY = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_POST['daily'])) . "' AND '" .  $_EndDate . "' AND ";
            endif; 
       
	  // $conditionY = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_POST['daily'])) . "' AND '" .  $_EndDate . "' AND ";
       $query_query_Y = "SELECT cases.id,cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
							. "cases_cstm.member_tier_c,"
							. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
							. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
							. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
							. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
							. " cases.date_entered , cases.assigned_user_id FROM cases "
							. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
							. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
							. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
							. " where ". $condition . $conditionY . " cases.deleted=0 ORDER BY cases.date_entered ASC";
		 $result = $db->query($query_query_Y);
			$total = $result->num_rows;
			if($total > 0):
			while ($row = $db->fetchByAssoc($result)) {
			$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$volumecsa[] = $row;
            }
			else:
			$row['emptyrecord'] = "N/A";
			// $volumecsa[] = $row;
			endif;
			echo "<td colspan='4' class='parent-TD'><table>
			<tr><td></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong><td><strong>Priority</strong></td></tr>";
			foreach($volumecsa as $volumecsa1)
			{
			echo "<tr>";
			echo "<td>".$volumecsa1['date_entered']."</td>";
			echo "<td>".$volumecsa1['origin_c']."</td>";
			echo "<td>".$volumecsa1['category_c']."</td>";
			echo "<td>".$volumecsa1['priority']."</td>";
			echo "</tr>";	
			}
			echo "</table></td>";
       else:
            echo $_POST['daily'];
			if ($_POST['getcategory'] && empty($_POST['origin'])) {
			$condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
			}
			if ($_POST['origin'] && empty($_POST['getcategory'])) {
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
			}

			if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
			}

			
		   $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .$_POST['daily'] . "' AND '" . $_POST['daily'] . "' AND";
		   $queryDaily_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id FROM cases "
                        . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$condition . $conditiondAILY . " cases.deleted=0 ORDER BY cases.date_entered DESC";

		
			$result = $db->query($queryDaily_case);
			$total = $result->num_rows;
			if($total > 0):
			while ($row = $db->fetchByAssoc($result)) {
			$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$volumecsa[] = $row;
            }
			else:
			$row['emptyrecord'] = "N/A";
			// $volumecsa[] = $row;
			endif;
			echo "<td colspan='4' class='parent-TD'><table>
			<tr><td></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong><td><strong>Priority</strong></td></tr>";
			foreach($volumecsa as $volumecsa1)
			{
			echo "<tr>";
			echo "<td>".$volumecsa1['date_entered']."</td>";
			echo "<td>".$volumecsa1['origin_c']."</td>";
			echo "<td>".$volumecsa1['category_c']."</td>";
			echo "<td>".$volumecsa1['priority']."</td>";
			echo "</tr>";	
			}
			echo "</table></td>";	   
	   endif;
	   exit;
    }
    
	
	/****volumecsa start***/
	 function dailydataDailywisecsa($_getSubcat,$_getOrigin,$_getCat,$_StartDate , $_EndDate , $_AssignName)
    {
			global $db, $app_list_strings;
			$volumecsa = array();
			$condition="";
			if ($_getCat == "all") {
			 $condition .= "";
			}else
			{
			 $condition .= "  cases_cstm.category_c = '" . $_getCat . "' AND ";
			}


			if ($_getOrigin == "all")  {
			$condition .= " ";
			}else
			{
			$condition .= "  cases_cstm.origin_c = '" . $_getOrigin . "'  AND ";
			}


			if ($_getSubcat  == "all") {
			$condition .= " ";
			}else
			{
			$condition .= "  cases_cstm.subcategory_c = '" . $_getSubcat . "'  AND ";
			}

		   $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .$_StartDate. "' AND '" .  $_StartDate . "' AND";
		   $queryDaily_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
                        . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id FROM cases "
                        . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$condition . $conditiondAILY . " cases.deleted=0 ORDER BY cases.date_entered ASC";

			$result = $db->query($queryDaily_case);
			$total = $result->num_rows;
			if($total > 0):
			while ($row = $db->fetchByAssoc($result)) {
			$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$volumecsa[] = $row;
            }
			else:
			$row['emptyrecord'] = "N/A";
			// $volumecsa[] = $row;
			endif;
			
			return $volumecsa;
			
			
    }

   public function checkReportPeriodQuarterCSA($condition,$condition_group,$dateform,$dateto)
   {
    global $db, $app_list_strings;
	$_Yrow = array();
    $conditionY = " DATE(cases.date_entered) BETWEEN '" .$dateform . "' AND '" . $dateto . "' AND ";
     $query_query_Y = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
							. "cases_cstm.member_tier_c,"
							. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
							. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
							. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
							. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
							. " cases.date_entered , cases.assigned_user_id FROM cases "
							. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
							. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
							. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
							. " where ". $condition . $conditionY . " cases.deleted=0  group by QUARTER(cases.date_entered),year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
    $resultY = $db->query($query_query_Y);
    foreach($resultY as $resulty)
    {
	 $_Yrow[] = $resulty['count(cases.id)'];
    }
    if(isset($getQuarters)):
     return array_sum($_Yrow) ;
    else:
        return array_sum($_Yrow) ;
    endif;
   }
      
   public function action_getdailydatacsa() {
	
	
        global $db, $app_list_strings;
        $condition = "";
		if ($_POST['branch_store_name'] == "all" || $_POST['branch_store_name'] == "")  {
			$condition .= " ";
			$condition_group .= "";
			}else
			{
			$condition .= "  cases.branch_store_name = '" . $_POST['branch_store_name'] . "'  AND ";
			}
			
        if ($_POST['getperiod'] == 'daily'):
            //$_POST['daily'];
			if ($_POST['getcategory'] == "all") {
			 $condition .= "";
			 $condition_group .= "";
			}else
			{
			 $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
			}


			if ($_POST['origin'] == "all")  {
			$condition .= " ";
			$condition_group .= "";
			}else
			{
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
			}
			
			if ($_POST['branch_store_name'] == "all"  || $_POST['branch_store_name'] == "" )  {
			$condition .= " ";
			}else
			{
			$condition .= "  cases.branch_store_name = '" . $_POST['branch_store_name'] . "'  AND ";
			}
			

			if ($_POST['subcat']  == "all") {
			$condition .= " ";
			$condition_group .= "";
			}else
			{
			$condition .= "  cases_cstm.subcategory_c = '" . $_POST['subcat'] . "'  AND ";
			}
			
			if ($_POST['getstatus']  == "all") {
			$condition .= " ";
			}else
			{
			$condition .= "  cases.status = '" . $_POST['getstatus'] . "'  AND ";
			}
			
           $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .$_POST['daily'] . "' AND '" . $_POST['daily'] . "' AND";
			
            $queryDaily_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                    . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                    . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                    . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                    . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
                    . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                    . " cases.date_entered , cases.assigned_user_id FROM cases "
                    . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                    . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                    . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                    . " where " . $condition . $conditiondAILY . " cases.deleted=0 ORDER BY cases.date_entered DESC";


            $result = $db->query($queryDaily_case);
            $total = $result->num_rows;
            if ($total > 0):
                while ($row = $db->fetchByAssoc($result)) {
                    $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                    $volumecsa[] = $row;
                }
            else:
                $row['emptyrecord'] = "N/A";
            // $volumecsa[] = $row;
            endif;
            echo "<td colspan='6' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
                <tr><td><strong>Date</strong></td><td><strong>Case Id</strong></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong><td><strong>Case Priority</strong></td><td><strong>Customer Service Associate Name</strong></td></tr>";

            foreach ($volumecsa as $volumecsa1) {
                echo "<tr>";
				 echo "<td>" .$volumecsa1['date_entered'] . "</td>";
                echo "<td>" . $volumecsa1['case_number'] . "</td>";
                echo "<td>" . $volumecsa1['origin_c'] . "</td>";
                echo "<td>" . $volumecsa1['category_c'] . "</td>";
                echo "<td>" . $volumecsa1['priority'] . "</td>";
                echo "<td>" . $volumecsa1['assigned_to_name'] . "</td>";
                echo "</tr>";
            }
            echo "</table></td>";
        elseif ($_POST['getperiod'] == 'monthly'):
			
			
			  $_Dailypost = explode("-",$_POST['daily']);	
			$month =   $_Dailypost[0];
			$year = $_Dailypost[1];
		    $_Days = cal_days_in_month(CAL_GREGORIAN, $month, $year)-1;
		    $_fromdate = $year."-".$month."-".'01';
		    $_EndDate = date("Y-m-d",strtotime("+ ".$_Days." days",strtotime($_fromdate)));
			
			
			
           
		    
			if ($_POST['getcategory'] == "all") {
			 $condition .= "";
			 $condition_group .= "";
			}else
			{
			 $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
			}

			if ($_POST['origin'] == "all")  {
			$condition .= " ";
			$condition_group .= "";
			}else
			{
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
			}
			
			
			if ($_POST['branch_store_name'] == "all" || $_POST['branch_store_name'] == "" )  {
			$condition .= " ";
			}else
			{
			$condition .= "  cases.branch_store_name = '" . $_POST['branch_store_name'] . "'  AND ";
			}
			
			
			

			if ($_POST['subcat']  == "all") {
			$condition .= " ";
			$condition_group .= "";
			}else
			{
			$condition .= "  cases_cstm.subcategory_c = '" . $_POST['subcat'] . "'  AND ";
			}
			
			if ($_POST['getstatus'] == "all") {
			 $condition .= "";
			}else
			{
			 $condition .= "  cases.status = '" . $_POST['getstatus'] . "' AND ";
			}
			
           
			
			// $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_fromdate)). "' AND ' ".date("y-m-d",strtotime($_EndDate))."' AND";
			 
			  $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_fromdate)). "' AND '" . $_EndDate . "' AND date(cases.date_entered) <= '".$_EndDate."' AND date(cases.date_entered) >= '".date("y-m-d",strtotime($_fromdate))."' AND";
			
             $queryDaily_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                    . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                    . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                    . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                    . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
                    . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                    . " cases.date_entered , cases.assigned_user_id FROM cases "
                    . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                    . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                    . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                    . " where " . $condition . $conditiondAILY . " cases.deleted=0 ORDER BY cases.date_entered ASC";
            $result = $db->query($queryDaily_case);
            $total = $result->num_rows;
            if ($total > 0):
                while ($row = $db->fetchByAssoc($result)) {
                    $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                    $volumecsa[] = $row;
                }
            else:
                $row['emptyrecord'] = "N/A";
            // $volumecsa[] = $row;
            endif;
            echo "<td colspan='6' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
            <tr><td><strong>Date</strong></td><td><strong>Case Id</strong></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong><td><strong>Case Priority</strong></td><td><strong>Customer Service Associate Name</strong></td></tr>";
            //<td><strong>Priority</strong></td>
            foreach ($volumecsa as $volumecsa1) {
                echo "<tr>";
                echo "<td>" . $volumecsa1['date_entered'] . "</td>";
				echo "<td>" . $volumecsa1['case_number'] . "</td>";
                echo "<td>" . $volumecsa1['origin_c'] . "</td>";
                echo "<td>" . $volumecsa1['category_c'] . "</td>";
                echo "<td>" . $volumecsa1['priority'] . "</td>";
                echo "<td>" . $volumecsa1['assigned_to_name'] . "</td>";
                echo "</tr>";
            }
            echo "</table></td>";
        elseif ($_POST['getperiod'] == 'annual'):
           
			if ($_REQUEST['getcategory'] == "all") {
                    $condition .= "";
				 }else
				 {
				     $condition .= "  cases_cstm.category_c = '" . $_REQUEST['getcategory'] . "' AND ";
				 }
				 
				if ($_REQUEST['origin'] == "all")  {
                    $condition .= "";
                }else{
				    $condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
				 }
				 
				if ($_POST['branch_store_name'] == "all" || $_POST['branch_store_name'] == "" )  { 
				$condition .= " ";
				}else
				{
				$condition .= "  cases.branch_store_name = '" . $_POST['branch_store_name'] . "'  AND ";
				}

				 
				if ($_REQUEST['subcat']  == "all") {
                    $condition .= " ";
                }else
				 {
				    $condition .= "  cases_cstm.subcategory_c = '" . $_REQUEST['subcat'] . "'  AND ";
				 }
				
				
				if ($_REQUEST['getstatus']  == "all") {
                    $condition .= " ";
                }else
				 {
				    $condition .= "  cases.status = '" . $_POST['getstatus'] . "'  AND ";
				 }
				 
				
		 
				 if(date("m") <= 06){
					$_CurrentYear = date("Y"); // current year
					$_NextYears =  date("Y")-1; //previous year 
					
					$_fromdate =  date($_NextYears.'-07-01'); //common from date
					$_EndDate =  date($_CurrentYear.'-06-30'); 

					}
					else{
					$_CurrentYear =  date("Y"); // current year
					$_NextYears  =  date("Y") + 1;  // post year
					$_fromdate =  date($_CurrentYear.'-07-01'); //common from date
					$_EndDate =  date($_NextYears.'-06-30'); 
					
				}
			
						
			 //  $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_fromdate)). "' AND ' ".date("y-m-d",strtotime($_EndDate))."' AND";
			   
			    $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_fromdate)). "' AND '" . $_EndDate . "' AND date(cases.date_entered) <= '".$_EndDate."' AND date(cases.date_entered) >= '".date("y-m-d",strtotime($_fromdate))."' AND";
			
			
               $queryQuarterly_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                    . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                    . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                    . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                    . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
                    . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                    . " cases.date_entered , cases.assigned_user_id FROM cases "
                    . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                    . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                    . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                    . " where " . $condition .$conditiondAILY .  " cases.deleted=0 ORDER BY cases.date_entered ASC";
            $result = $db->query($queryQuarterly_case);
            $total = $result->num_rows;
            if ($total > 0):
                while ($row = $db->fetchByAssoc($result)) {
                    $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                    $volumecsa[] = $row;
                }
            else:
                $row['emptyrecord'] = "N/A";
            // $volumecsa[] = $row;
            endif;
			
            echo "<td colspan='6' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
            <tr><td><strong>Date</strong></td><td><strong>Case Id</strong></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong><td><strong>Case Priority</strong></td><td><strong>Customer Service Associate Name</strong></td></tr>";
            // <td><strong>Priority</strong></td>
            foreach ($volumecsa as $volumecsa1) {
                echo "<tr>";
                echo "<td>" . $volumecsa1['date_entered'] . "</td>";
				echo "<td>" . $volumecsa1['case_number'] . "</td>";
                echo "<td>" . $volumecsa1['origin_c'] . "</td>";
                echo "<td>" . $volumecsa1['category_c'] . "</td>";
                echo "<td>" . $volumecsa1['priority'] . "</td>";
                echo "<td>" . $volumecsa1['assigned_to_name'] . "</td>";

                echo "</tr>";
            }
            echo "</table></td>";
        elseif ($_POST['getperiod'] == 'weekly'):
             if ($_REQUEST['getcategory'] == "all") {
                    $condition .= "";
				 }else
				 {
				     $condition .= "  cases_cstm.category_c = '" . $_REQUEST['getcategory'] . "' AND ";
				 }
				 
				if ($_REQUEST['origin'] == "all")  {
                    $condition .= "";
                }else{
				    $condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
				 }
				 
				 
				if ($_POST['branch_store_name'] == "all" || $_POST['branch_store_name'] == ""  )  {
				$condition .= " ";
				}else
				{
				$condition .= "  cases.branch_store_name = '" . $_POST['branch_store_name'] . "'  AND ";
				}
			
				if ($_REQUEST['subcat']  == "all") {
                    $condition .= " ";
                }else
				 {
				    $condition .= "  cases_cstm.subcategory_c = '" . $_REQUEST['subcat'] . "'  AND ";
				 }
				
				if ($_REQUEST['getstatus']  == "all") {
                    $condition .= " ";
					$condition_group .= "";
                }else
				 {
					$condition .= " ";
				  $condition .= "  cases.status = '" . $_POST['getstatus'] . "'  AND ";
				 }
				 
				 
            $_EndDate = date ("Y-m-d", strtotime("+ 1 week", strtotime($_POST['daily'])));
	   $_EndDate = date ("Y-m-d", strtotime("- 1 day", strtotime($_EndDate)));
	   $conditionW = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_POST['daily'])) . "' AND '" .  $_EndDate . "' AND ";
	   
	   
            $query_query_W = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                    . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                    . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                    . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                    . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
                    . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                    . " cases.date_entered , cases.assigned_user_id FROM cases "
                    . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                    . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                    . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                    . " where " . $condition . $conditionW . " cases_cstm.member_tier_c IN ('Base','base','Silver','silver','Gold','gold') AND cases.deleted=0 ORDER BY cases.date_entered ASC";
            $result = $db->query($query_query_W);
            $total = $result->num_rows;
            if ($total > 0):
                while ($row = $db->fetchByAssoc($result)) {
                    $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                    $volumecsa[] = $row;
                }
            else:
                $row['emptyrecord'] = "N/A";
            // $volumecsa[] = $row;
            endif;
            echo "<td colspan='6' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
            <tr><td><strong>Date</strong></td><td><strong>Case Id</strong></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong><td><strong>Case Priority</strong></td><td><strong>Customer Service Associate Name</strong></td></tr>";
            //<td><strong>Priority</strong></td>
            foreach ($volumecsa as $volumecsa1) {
                echo "<tr>";
                echo "<td>" . $volumecsa1['date_entered'] . "</td>";
				echo "<td>" . $volumecsa1['case_number'] . "</td>";
                echo "<td>" . $volumecsa1['origin_c'] . "</td>";
                echo "<td>" . $volumecsa1['category_c'] . "</td>";
                echo "<td>" . $volumecsa1['priority'] . "</td>";
                echo "<td>" . $volumecsa1['assigned_to_name'] . "</td>";
                echo "</tr>";
            }
            echo "</table></td>";
        elseif ($_POST['getperiod'] == 'quarterly'):
				if ($_REQUEST['getcategory'] == "all") {
                    $condition .= "";
				 }else
				 {
				     $condition .= "  cases_cstm.category_c = '" . $_REQUEST['getcategory'] . "' AND ";
				 }
				 
				if ($_REQUEST['origin'] == "all")  {
                    $condition .= "";
                }else{
				    $condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
				 }
				 
				 
				if ($_POST['branch_store_name'] == "all" || $_POST['branch_store_name'] == "" )  {
				$condition .= " ";
				}else
				{
				$condition .= "  cases.branch_store_name = '" . $_POST['branch_store_name'] . "'  AND ";
				}
			
				 
				if ($_REQUEST['subcat']  == "all") {
                    $condition .= " ";
                }else
				 {
				    $condition .= "  cases_cstm.subcategory_c = '" . $_REQUEST['subcat'] . "'  AND ";
				 }
				if ($_REQUEST['getstatus']  == "all") {
                    $condition .= " ";
                }else
				 {
					$condition .= " ";
				  $condition .= "  cases.status = '" . $_POST['getstatus'] . "'  AND ";
				 }
				 
		    $_StartDate = $_EndDate = "";
			if(isset($_POST['daily'])):
		    $_DailyExplode =   explode("_",$_POST['daily']);
			$_StartDate =  $_DailyExplode[0];
			$_EndDate = $_DailyExplode[1];
		    endif;
			
     
          
			$conditionY = " DATE(cases.date_entered) BETWEEN '" .$_StartDate . "' AND '" .  $_EndDate . "' AND ";
            $query_query_Y = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                    . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                    . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                    . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                    . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
                    . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                    . " cases.date_entered , cases.assigned_user_id FROM cases "
                    . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                    . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                    . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                    . " where " . $condition . $conditionY . "  cases.deleted=0 ORDER BY cases.date_entered ASC";
            $result = $db->query($query_query_Y);
            $total = $result->num_rows;
            if ($total > 0):
                while ($row = $db->fetchByAssoc($result)) {
                    $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                    $volumecsa[] = $row;
                }
            else:
                $row['emptyrecord'] = "N/A";
            endif;
            echo "<td colspan='6' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
           <tr><td><strong>Date</strong></td><td><strong>Case Id</strong></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong><td><strong>Case Priority</strong></td><td><strong>Customer Service Associate Name</strong></td></tr>";
            //<td><strong>Priority</strong></td>
            foreach ($volumecsa as $volumecsa1) {
                echo "<tr>";
                echo "<td>" . $volumecsa1['date_entered'] . "</td>";
				echo "<td>" . $volumecsa1['case_number'] . "</td>";
                echo "<td>" . $volumecsa1['origin_c'] . "</td>";
                echo "<td>" . $volumecsa1['category_c'] . "</td>";
                echo "<td>" . $volumecsa1['priority'] . "</td>";
                echo "<td>" . $volumecsa1['assigned_to_name'] . "</td>";
                echo "</tr>";
            }
            echo "</table></td>";
        else:
            // echo $_POST['daily'];
            if ($_POST['getcategory'] && empty($_POST['origin'])) {
                $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
            }
            if ($_POST['origin'] && empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
            }

            if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
            }
			
			
			if ($_POST['branch_store_name'] == "all" || $_POST['branch_store_name'] == "" )  {
			$condition .= " ";
			}else
			{
			$condition .= "  cases.branch_store_name = '" . $_POST['branch_store_name'] . "'  AND ";
			}
			
            if ($_POST['getstatus']) {
                $condition .= "  cases.status = '" . $_POST['getstatus'] . "'  AND ";
            }
            if ($_POST['getpriority']) {
                $condition .= "  cases.priority = '" . $_POST['getpriority'] . "'  AND ";
            }
             $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .$_POST['daily'] . "' AND '" . $_POST['daily'] . "' AND";
            $queryDaily_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                    . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                    . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                    . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                    . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
                    . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                    . " cases.date_entered , cases.assigned_user_id FROM cases "
                    . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                    . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                    . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                    . " where " . $condition . $conditiondAILY . " cases_cstm.member_tier_c IN ('Base','base','Silver','silver','Gold','gold') AND cases.deleted=0 ORDER BY cases.date_entered DESC";


            $result = $db->query($queryDaily_case);
            $total = $result->num_rows;
            if ($total > 0):
                while ($row = $db->fetchByAssoc($result)) {
                    $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                    $volumecsa[] = $row;
                }
            else:
                $row['emptyrecord'] = "N/A";
            // $volumecsa[] = $row;
            endif;
            echo "<td colspan='6' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
            <tr><td><strong>Date</strong></td><td><strong>Case Id</strong></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong><td><strong>Case Priority</strong></td><td><strong>Customer Service Associate Name</strong></td></tr>";
            //<td><strong>Priority</strong></td>
            foreach ($volumecsa as $volumecsa1) {
                echo "<tr>";
                echo "<td>" . $volumecsa1['date_entered'] . "</td>";
				echo "<td>" . $volumecsa1['case_number'] . "</td>";
                echo "<td>" . $volumecsa1['origin_c'] . "</td>";
                echo "<td>" . $volumecsa1['category_c'] . "</td>";
                echo "<td>" . $volumecsa1['priority'] . "</td>";
                echo "<td>" . $volumecsa1['assigned_to_name'] . "</td>";
                echo "</tr>";
            }
            echo "</table></td>";
        endif;
        exit;
    }
	public function action_volumecsa() {
        global $db, $app_list_strings;
        global $sugar_config;
		$ReportName = 'volumecsa';
        $this->view = 'volumecsa';
        $this->view_object_map['getAllCaseCategory'] = $this->getAllCaseCategory();
        $this->view_object_map['getTimePeriod'] = $this->getTimePeriod();
        $this->view_object_map['site_url'] = $sugar_config['site_url'];
		$this->view_object_map['createMonthdd'] = $this->createMonthdd();
		$this->view_object_map['creatWeeklydd'] = $this->creatWeeklydd();
		$this->view_object_map['getYearDd'] = $this->creatYearsdd();
		//get branch store name
		$this->view_object_map['branch_store_name'] = $this->getAllBranchName();
		$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
		$end_date = $_curdate;
		$start_date = date('Y-m-1', strtotime("-1 year"));
		$this->view_object_map['creatQudd'] = $this->creatQuarterdd($start_date,$end_date);
        $volumecsa = $queryCase = $_Yearquery = $_ColumnsDate = $volumeDate = $_DailyLoopC = $_DateEnteredArray = $volumecsa_grid = $_NoOfQuarters =$_GetOneQuarters= array();
        $_WeeklyGlobal = $_QuaterlyGlobal = $_MonthGlobal = 0;
        $condition = $condition_group = $_StartMonth = $_EndMonth = $_StartW= $_EndW  =$_StartQ  =$_EndQ = $_BranchStore = '';

        if (isset($_REQUEST['query']) == 'true') {
            if ($_REQUEST['category_id'] || $_REQUEST['period'] || $_REQUEST['origin'] || $_REQUEST['branch_store_name'] || $_REQUEST['priority'] ||
                    $_REQUEST['status'] || $_REQUEST['from_date'] || $_REQUEST['to_date']) {
				
				 if ($_REQUEST['category_id'] == "all") {
                    $condition .= "";
					$condition_group .= "";
				 }else
				 {
				     $condition .= "  cases_cstm.category_c = '" . $_REQUEST['category_id'] . "' AND ";
					$condition_group .= ",cases_cstm.category_c";
				 }
				 
				 if ($_REQUEST['origin'] == "all")  {
                    $condition .= " ";
					$condition_group .= "";
                }else
				 {
				    $condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
					$condition_group .= ",cases_cstm.origin_c";
				 }
				 
				if ($_REQUEST['branch_store_name'] == "all" || $_REQUEST['branch_store_name'] == "")  {
                    $condition .= " ";
					$condition_group .= "";
                }else
				 {
				    $condition .= "  cases.branch_store_name = '" . $_REQUEST['branch_store_name'] . "'  AND ";
					$condition_group .= ",cases.branch_store_name";
				 }
				 
				 
				 
				if ($_REQUEST['sub_category_id']  == "all") {
                    $condition .= " ";
					$condition_group .= "";
                }else
				 {
				    $condition .= "  cases_cstm.subcategory_c = '" . $_REQUEST['sub_category_id'] . "'  AND ";
					$condition_group .= ",cases_cstm.subcategory_c";
				 }
				
				if ($_REQUEST['status']  == "all") {
                    $condition .= " ";
					$condition_group .= "";
                }else
				 {
				   $condition .= "  cases.status = '" . $_REQUEST['status'] . "'  AND ";
                    $condition_group .= ",cases.status";
				 }
				
				 
                if(!empty($_POST['periodmonthsdd'])):
				  $_StartMonth = $_POST['periodmonthsdd'];
				endif;
				
				if(!empty($_POST['periodmonthedd'])):
				  $_EndMonth = $_POST['periodmonthedd'];
				endif;
				
				if(!empty($_POST['periodweeksdd'])):
				  $_StartW = $_POST['periodweeksdd'];
				endif;
				
				if(!empty($_POST['periodweekedd'])):
				  $_EndW = $_POST['periodweekedd'];
				endif;
				
				if(!empty($_POST['periodquasdd'])):
				  $_StartQ = $_POST['periodquasdd'];
				endif;
				
				if(!empty($_POST['periodquaedd'])):
				  $_EndQ = $_POST['periodquaedd'];
				endif;
				
				

                /* checking query starting */
                $start_date = date("Y-m-d", strtotime($_REQUEST['from_date']));
                $end_date = date("Y-m-d", strtotime($_REQUEST['to_date']));

                $start_date = $_REQUEST['from_date']; //fromdate for post
                $this->view_object_map['getFromDate'] = $start_date;
                $end_date = $_REQUEST['to_date']; //todate for post
                $this->view_object_map['getToDate'] = $end_date;
                $_Periodpost = $_REQUEST['period']; //period for post
                $this->view_object_map['getPeriod'] = $_Periodpost;
                $_Oroginpost = $_REQUEST['origin']; //origin for post
                $this->view_object_map['getOrigin'] = $_Oroginpost;
                $_Categorypost = $_REQUEST['category_id']; //categoryid for post
                $this->view_object_map['getCategory'] = $_Categorypost;
                $_Statuspost = $_REQUEST['status']; //status for post
                $this->view_object_map['getStatus'] = $_Statuspost;
                $_Prioritypost = $_REQUEST['priority']; //priority for post
                $this->view_object_map['getPriority'] = $_Prioritypost;
				
				$_Subcatgorypost = $_REQUEST['sub_category_id']; //sucategoryid for post
				$this->view_object_map['getSubCategory'] = $_Subcatgorypost;
				$this->view_object_map['getStartmonth'] =  $_StartMonth; // selected month start
				$this->view_object_map['getEndmonth'] = $_EndMonth ; // selected month end
				$this->view_object_map['periodquasdd'] =  $_StartQ; // selected month start
				$this->view_object_map['periodquaedd'] = $_EndQ ; // selected month end
				$this->view_object_map['getStartweek'] =  $_StartW; // selected month start
				$this->view_object_map['getEndweek'] =  $_EndW; // selected month end
				$this->view_object_map['sub_category_id'] = $_POST['sub_category_id']; // selected subcat
				
				$_BranchStore = $_REQUEST['branch_store_name']; //branch_store_name for post
                $this->view_object_map['getBranchName'] = $_BranchStore;
				$this->view_object_map['getFromyear'] = $_POST['getYearsDd']; // selected from year
				$this->view_object_map['getToyear'] = $_POST['getYeareDd']; // selected  to year
				
				
				//daily query
                if ($_REQUEST['period'] == "daily"):

                    $_DailyLoopCount = $this->datediff('d', date("y-m-d", strtotime($_REQUEST['from_date'])), date("y-m-d", strtotime($_REQUEST['to_date'])));

                    for ($i = 0; $i <= $_DailyLoopCount; $i++) {
                        $_DailyLoopC[] = date("Y-m-d", strtotime("+$i day", strtotime($start_date)));
                    }

                    if ($_REQUEST['from_date'] && $_REQUEST['to_date']) {
                        $condition .= "  DATE(cases.date_entered) BETWEEN '" . date("y-m-d", strtotime($start_date)) . "' AND '" . date("y-m-d", strtotime($end_date)) . "' AND ";
                    }
                    $query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
                            . "cases_cstm.member_tier_c,cases.status,cases.branch_store_name,"
                            . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
                            . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                            . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
                            . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                            . " cases.date_entered , cases.assigned_user_id FROM cases "
                            . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                            . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                            . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                            . " where " . $condition . "  cases.deleted=0  group by date(cases.date_entered)" . $condition_group . " ORDER BY cases.date_entered ASC";

                    $result = $db->query($query_query);
                    $total = $result->num_rows;
                    if ($total > 0):
                        while ($row = $db->fetchByAssoc($result)) {


                            $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                            $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                            $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                            $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                            $volumecsa[] = $row;
                            $volumeDate[] = date("Y-m-d", strtotime($row['date_entered']));
                        }
                    else:
                        $row['emptyrecord'] = "N/A";
                    // $volumecsa[] = $row;
                    endif;

				//	echo "<pre>";print_r($volumecsa);
				//weekly query
                elseif ($_REQUEST['period'] == "weekly"):
				
					if(date("m") <= 06){
						$_CurrentYear = date("Y"); // current year
						$_NextYears =  date("Y")-1; //previous year 
						
						$start_date =  date($_NextYears.'-07-01'); //common from date
						$end_date =  date($_CurrentYear.'-06-30'); 
						$_WeekLoopCount = $this->datediff('ww',$start_date ,$end_date )." Week<br>";

						}
						else{
						$_CurrentYear =  date("Y"); // current year
						$_NextYears  =  date("Y") + 1;  // post year
						$start_date =  date($_CurrentYear.'-07-01'); //common from date
						$end_date =  date($_NextYears.'-06-30'); 
						$_WeekLoopCount = $this->datediff('ww',$start_date ,$end_date )." Week<br>";
						
						}
				
                   // $_WeekLoopCount = $this->datediff('ww', date("y-m-d", strtotime($_REQUEST['from_date'])), date("y-m-d", strtotime($_REQUEST['to_date'])));

                    for ($i = 0; $i <= $_WeekLoopCount; $i++) {
                        $_DailyLoopC[] = date("Y-m-d", strtotime("+ $i week", strtotime($start_date)));
                    }

                    $_WeeklyGlobal = 1;
                    					
					$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";
						
						
                    $query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
                            . "cases_cstm.member_tier_c,cases.status,cases.branch_store_name,"
                            . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
                            . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                            . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
                            . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                            . " cases.date_entered , cases.assigned_user_id FROM cases "
                            . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                            . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                            . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                            . " where " . $condition . "  cases.deleted=0  group by week(cases.date_entered)" . $condition_group . " ORDER BY cases.date_entered ASC";

                    $result = $db->query($query_query);
                    $total = $result->num_rows;
                    if ($total > 0):
                        while ($row = $db->fetchByAssoc($result)) {
                            $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                            $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                            $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                            $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                            $volumecsa[] = $row;
                        }
                    else:
                        $row['emptyrecord'] = "N/A";
                    // $volumecsa[] = $row;
                    endif;
				//monthly query
                elseif ($_REQUEST['period'] == "monthly"):
                    					
					    $_MonthGlobal = 1;
				        $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
						$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
						$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
						$start_date  = $_Year."-".$_Month."-"."1";  //start date
						$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
						$_MonthLoopCount = $this->datediff('m',date("y-m-d",strtotime($start_date )),date("y-m-d",strtotime($end_date)));				 
						/*month logic end */
						for($i=0;$i<=$_MonthLoopCount+1;$i++)
						{
						$_DailyLoopC[] =  date ("M-Y", strtotime("+ $i month", strtotime($start_date)));
						}
						$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";
					   
                    $query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
                            . "cases_cstm.member_tier_c,cases.status,cases.branch_store_name,"
                            . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
                            . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                            . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
                            . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                            . " cases.date_entered , cases.assigned_user_id FROM cases "
                            . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                            . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                            . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                            . " where " . $condition . " cases.deleted=0  group by month(cases.date_entered)" . $condition_group . " ORDER BY cases.date_entered ASC";

                    $result = $db->query($query_query);
                    $total = $result->num_rows;
                    if ($total > 0):
                        while ($row = $db->fetchByAssoc($result)) {
                            $row['date_entered'] = date("m-Y", strtotime($row['date_entered']));
                            $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                            $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                            $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                            $volumecsa[] = $row;
                        }
                    else:
                        $row['emptyrecord'] = "N/A";
                    // $volumecsa[] = $row;
                    endif;
					
				//quarterly query
                elseif ($_REQUEST['period'] == "quarterly"):
				$_QuaterlyGlobal = 1;
				/*quater logic start*/
				$_Start_Q = explode("_",$_StartQ);
				$_OpenQ = $_Start_Q[2];
				$_End_Q = explode("_",$_EndQ);
				$_EndQ = $_End_Q[2];
				/* end */
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				
			
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				
				$this->view_object_map['creatQudd'] = $this->creatQuarterdd($start_date,$end_date);
				//echo "<pre>";
				//print_r($this->view_object_map['creatQudd'] );
                $_Startq = explode("_",$_StartQ); 
				$_Endq = explode("_",$_EndQ); 
				$_GetQuarters = $this->creatQuarterdd($start_date,$end_date);

				foreach($_GetQuarters as $_GetQuarters1Key=>$_GetQuarters1)
				{
				$_Startq = explode("_",$_GetQuarters1Key); 
				
				$_DailyLoopC[$_GetQuarters1Key] = $_GetQuarters1;
				$_GetPeroid[$_GetQuarters1Key."_".$_GetQuarters1] = $this->checkReportPeriodQuarterCSA($condition,$condition_group,$_Startq[0],$_Startq[1]);

                }
					
                
                    $query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
                            . "cases_cstm.member_tier_c,cases.status,cases.branch_store_name,"
                            . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
                            . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                            . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
                            . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                            . " cases.date_entered , cases.assigned_user_id FROM cases "
                            . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                            . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                            . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                            . " where " . $condition . " cases.deleted=0  group by QUARTER(cases.date_entered)" . $condition_group . " ORDER BY cases.date_entered ASC";

                    $result = $db->query($query_query);
                    $total = $result->num_rows;
                    if ($total > 0):
                        while ($row = $db->fetchByAssoc($result)) {
                            $row['date_entered'] = date("Y", strtotime($row['date_entered']));
                            $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                            $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                            $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                            $volumecsa[] = $row;
                        }
                    else:
                        $row['emptyrecord'] = "N/A";

                    endif;
					
				//annual query
                elseif ($_REQUEST['period'] == "annual"):
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
				$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
			    $start_date  = $_Year."-".$_Month."-"."1";  //start date
				$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
				$_CurrentYear = date("Y"); // current year
				$_PreviousYears = date("Y")-1; //previous year 
				if ($_POST['getYearsDd'] != $_POST['getYeareDd']) {
					$_Year =  array($_PreviousYears,$_CurrentYear);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}else{
				    $_Year =  array($_POST['getYearsDd']);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}
				
				$from = $_POST['getYearsDd'];
				$to = $_POST['getYeareDd'];
				
				if ($_POST['getYearsDd'] != $_POST['getYeareDd']) {
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				} else {
				$start_date = date('Y-m-d', strtotime("$from-01-01"));
				$end_date = date('Y-m-d', strtotime("$from-12-31"));
				}
					
					
                   
					$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";

                $query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,cases.status,"
                            . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority,cases.branch_store_name, "
                            . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                            . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
                            . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod, cases.assigned_user_id FROM cases "
                            . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                            . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                            . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                           . " where " . $condition . " cases.deleted=0  group by year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
					
                    $result = $db->query($query_query);
                    $total = $result->num_rows;
                    if ($total > 0):
                        while ($row = $db->fetchByAssoc($result)) {
                            $row['date_entered'] = date("Y", strtotime($row['date_entered']));
                            $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                            $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                            $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                            $volumecsa[] = $row;
                        }
                    else:
                        $row['emptyrecord'] = "N/A";
                    // $volumecsa[] = $row;
                    endif;
					
                else:
                    if ($_REQUEST['category_id'] && empty($_REQUEST['origin'])) {
                        $condition .= "  cases_cstm.category_c = '" . $_REQUEST['category_id'] . "' AND ";
                        $condition_group .= ",cases_cstm.category_c";
                    }
                    if ($_REQUEST['origin'] && empty($_REQUEST['category_id'])) {
                        $condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
                        $condition_group .= ",cases_cstm.origin_c";
                    }

                    if (!empty($_REQUEST['origin']) && !empty($_REQUEST['category_id'])) {
                        $condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND  cases_cstm.category_c = '" . $_REQUEST['category_id'] . "' AND";
                        $condition_group .= ",cases_cstm.origin_c,cases_cstm.category_c";
                    }
                    if (!empty($_REQUEST['status'])) {
                        $condition .= "  cases.status = '" . $_REQUEST['status'] . "'  AND ";
                        $condition_group .= ",cases.status";
                    }
                    if (!empty($_REQUEST['priority'])) {
                        $condition .= "  cases.priority = '" . $_REQUEST['priority'] . "'  AND ";
                        $condition_group .= ",cases.priority";
                    }
					if (!empty($_REQUEST['branch_store_name'])) {
                        $condition .= "  cases.branch_store_name = '" . $_REQUEST['branch_store_name'] . "'  AND ";
                        $condition_group .= ",cases.branch_store_name";
                    }
                    /* checking query starting */
                    $start_date = date("Y-m-d", strtotime($_REQUEST['from_date']));
                    $end_date = date("Y-m-d", strtotime($_REQUEST['to_date']));
                    $_DailyLoopCount = $this->datediff('d', date("y-m-d", strtotime($_REQUEST['from_date'])), date("y-m-d", strtotime($_REQUEST['to_date'])));

                    for ($i = 0; $i <= $_DailyLoopCount; $i++) {
                        $_DailyLoopC[] = date("Y-m-d", strtotime("+$i day", strtotime($start_date)));
                    }

                    if ($_REQUEST['from_date'] && $_REQUEST['to_date']) {
                        $condition .= "  DATE(cases.date_entered) BETWEEN '" . date("y-m-d", strtotime($start_date)) . "' AND '" . date("y-m-d", strtotime($end_date)) . "' AND ";
                    }


                    $query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
                            . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority,cases.branch_store_name, "
                            . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                            . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
                            . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                            . " cases.date_entered , cases.assigned_user_id FROM cases "
                            . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                            . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                            . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                            . " where " . $condition . "  cases.deleted=0  group by date(cases.date_entered)" . $condition_group . " ORDER BY cases.date_entered ASC";

                    $result = $db->query($query_query);
                    $total = $result->num_rows;
                    if ($total > 0):
                        while ($row = $db->fetchByAssoc($result)) {
                            $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                            $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                            $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                            $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                            $volumecsa[] = $row;
                            $volumeDate[] = date("Y-m-d", strtotime($row['date_entered']));
                        }
                    else:
                        $row['emptyrecord'] = "N/A";
                    // $volumecsa[] = $row;
                    endif;
                endif;

                if($_POST['period'] == 'monthly'){//for month start
					 $_MonthStartArray = array_keys($_DailyLoopC,$_StartMonth);
					 $_MonthEndArray =  array_keys($_DailyLoopC,$_EndMonth);
					 $_Totvalue = $_MonthEndArray[0]-$_MonthStartArray[0];
					 $_DailyLoopC = array_slice($_DailyLoopC,$_MonthStartArray[0],$_Totvalue+1);
					 //for month end
				}
			
				$volumecsaYearcount = "";
                if ($_WeeklyGlobal == 1) {
                    if (count($volumecsa)):
                        foreach ($volumecsa as $volumecsaData) {
                            $_DateEntered1Array[$volumecsaData['date_entered']] = $volumecsaData['date_entered'] . "_" . $volumecsaData['category_c'] . "_" . $volumecsaData['origin_c'] . "_" . $volumecsaData['count(cases.id)']."_".$volumecsaData['assigned_to_name'];
                        }
                    endif;
                } else {
                    if (count($volumecsa)):
                        foreach ($volumecsa as $volumecsaData) {
                            $_DateEnteredArray[] = $volumecsaData['date_entered'];
                            $_DateEntered1Array[$volumecsaData['date_entered']] = array($volumecsaData['date_entered'], $volumecsaData['category_c'], $volumecsaData['origin_c'], $volumecsaData['count(cases.id)'],$volumecsaData['assigned_to_name']);
							$volumecsaYearcount = $volumecsaData['count(cases.id)'];
                        }
                    endif;
                }
				
				
				$_yearRecord = array();
				if(!empty($_DateEntered1Array)):
				 foreach($_DateEntered1Array as $_DateEntered1Array1)
				 {
				  $_yearRecord[]  = $_DateEntered1Array1[3];
				 }
				 endif;
				 $i = 1;


                if (count($_DailyLoopC) > 0):
                    if ($_QuaterlyGlobal == 1):
					$_OpenQua = array();
					for($_OpenQ;$_OpenQ<=$_EndQ;$_OpenQ++){
					  $_OpenQua[] = $_OpenQ;
						}
						$temp2 = array();
						//for($p = $_StartQ; $p <= $_EndQ; $p++){
						//$temp2[] = $p;
						//}
				
                        foreach ($_GetPeroid as $_GetPeroidKey => $_GetPeroidData) {
						
							//if($_POST['period'] == 'quarterly'):
								 //if(!in_array($i,$temp2)){
								// $i++;
									//continue;
									
								 //}
								// endif;
								$_GetPeroidDisaply = $_GetPeroidKey;
					            $_GetPeroidDisaply =  explode("_",$_GetPeroidDisaply);
								$_Qendate = date ("M y", strtotime("+ 3 month", strtotime($_GetPeroidKey)));
								$_GetPeroidSd =  date ("M y",strtotime($_GetPeroidKey));
								$_GetPeroided = $_Qendate;
								 if($_REQUEST['category_id'] == 'all'):
									$_Catname = 'All';
								 else:
									$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
								 endif;
								 

								if(date("m") <= 06){
									$_NextYears = date("Y"); // current year
									$_CurrentYear =  date("Y")-1; //previous year 
								}
								else{
									$_CurrentYear =  date("Y"); // current year
									$_NextYears  =  date("Y") + 1;  // post year
								}
								$_Startdate = $this->getDateRange( $i, $_CurrentYear."-".$_NextYears);
								$start_date = $_Startdate['start_date'];
								$end_date = $_Startdate['end_date'];
								
					   if(in_array($_GetPeroidDisaply[2],$_OpenQua)):
							$_GetPeroidKey = explode("_",$_GetPeroidKey);
                            if ($_GetPeroidData == 0):
								$volumecsa_grid[] =  "<tr><td>".$_GetPeroidKey[3]."</td>
								 <td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>
								 <td>".$_Catname."</td>
								 <td>NA</td>
								 <td>NA</td>
								 <td>0</td>
								 </tr>";
								
                            else:
							 $volumecsa_grid[] = "<tr><td>".$_GetPeroidKey[3]."</td>
							 <td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>
							 <td>".$_Catname."</td>
							 <td>NA</td>
							 <td>NA</td>
							 <td class=counter onclick='checkclick(this.title)' id=Dailydata_".$_GetPeroidKey." title=daily_".$_GetPeroidKey[0]."_".$_GetPeroidKey[1].">".$_GetPeroidData."</td>
							 </tr>";								
                            endif;
							
                            $volumecsa_grid[] = "</tr>";
                            $volumecsa_grid[] = "<tr class=dailyresulthide id=dailyresult_".$_GetPeroidKey[0]."_".$_GetPeroidKey[1]." style=display:none>
						 <td colspan='6' class='parent-TD'>
						 </td></tr>";
						 endif;
						  $i++;
                        }
                    else:
						
						$temp2 = array();
						for($p = $_StartW ; $p <= $_EndW ; $p++){
						$temp2w[] = $p;
						}
                        foreach ($_DailyLoopC as $_DailyLoopCDataKey => $_DailyLoopCData) {
						
							if($_POST['period'] == 'weekly'):
							 if(!in_array($i,$temp2w)){
							 $i++;
								continue;
								
							 }
							 endif;
					  
                            if ($_WeeklyGlobal == 1):
                                /* weekly interval */
								$_WeekStartdate = $_DailyLoopCData; //weekly date start
								$_WeekEnddate =  date("Y-m-d", strtotime("+ 1 week", strtotime($_DailyLoopCData))); //weekly date ended
								$_WeekEnddate =  date("Y-m-d", strtotime("-1 day", strtotime($_WeekEnddate)));
								$_WeekDateInterval = $this->returnBetweenDates($_WeekStartdate, $_WeekEnddate); 
								$_GetPeroid = $this->checkReportPeriodreportcc($condition,$condition_group,$_WeekStartdate,$_WeekEnddate);

								$_WeekStartdate = date("d M Y",strtotime($_WeekStartdate));
								$_WeekEnddate = date("d M Y",strtotime($_WeekEnddate));

								if($_REQUEST['category_id'] == 'all'):
								$_Catname = 'All';
								else:
								$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
								endif;
                                if ($_GetPeroid == 0):
								
									$volumecsa_grid[] = "<tr><td><strong>Week ".$i."</strong> (".$_WeekStartdate." - ".$_WeekEnddate.")</td>
								 <td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>
								 <td>".$_Catname."</td>
								 <td>NA</td>
								 <td>NA</td>
								 <td>0</td>
								 </tr>";
                                    
                                else:
									$volumecsa_grid[] = "<tr><td>Week ".$i." (".$_WeekStartdate." - ".$_WeekEnddate.")</td>
											 <td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>
											 <td>".$_Catname."</td> 
											 <td>NA</td>
											<td>NA</td>
											 <td class=counter onclick='checkclick(this.title)' id=Dailydata_".$_DailyLoopCData." title=daily_".$_DailyLoopCData.">".$_GetPeroid."</td>
									</tr>";
								  $volumecsa_grid[] ="<tr class=dailyresulthide id=dailyresult_".$_DailyLoopCData." style=display:none>
										 <td colspan='6' class='parent-TD'>
										 </td></tr>";
                                    
                                endif;
                            /* weekly interval */

                            elseif ($_MonthGlobal == 1):
								
						
								if($_REQUEST['category_id'] == 'all'):
								$_Catname = 'All';
								else:
								$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
								endif;
								$_DailyLoopCDisplay =  date("M-Y",strtotime($_DailyLoopCData));
								$_DailyLoopCData =  date("m-Y",strtotime($_DailyLoopCData));
								
                                $volumecsa_grid[] = "<tr>";
								if (in_array($_DailyLoopCData,$_DateEnteredArray))
								{
								//need to check why not in the loop once he is back @ashok for monthly
								//$key = array_search($_DailyLoopCData, $_DateEnteredArray);
								 $volumecsa_grid[] = "<td>".$_DailyLoopCDisplay."</td>";
								 $volumecsa_grid[] = "<td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>";
								 $volumecsa_grid[] = "<td>".$_Catname."</td>";
								 $volumecsa_grid[] = "<td>NA</td>";
								 $volumecsa_grid[] = "<td>NA</td>";
								 $volumecsa_grid[] = "<td class=counter onclick='checkclick(this.title)' id=Dailydata_".$_DateEntered1Array[$_DailyLoopCData][0]." title=daily_".$_DateEntered1Array[$_DailyLoopCData][0].">".$_DateEntered1Array[$_DailyLoopCData][3]."</td>";
								}
								else
								{
								 $volumecsa_grid[] =  "<td>".$_DailyLoopCDisplay."</td>
								 <td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>
								 <td>".$_Catname."</td>
								 <td>NA</td>
								 <td>NA</td>
								 <td colspan=6>0"."</td>";
								}
								
                                $volumecsa_grid[] = "</tr>";
                                $volumecsa_grid[] = "<tr class=dailyresulthide id=dailyresult_" . $_DailyLoopCData . " style=display:none>
						 <td colspan='6' class='parent-TD'>
						 </td></tr>";
                            else:
                                $volumecsa_grid[] = "<tr>";
								if($_REQUEST['category_id'] == 'all'):
								$_Catname = 'All';
								else:
								$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
								endif;
								
								if($_POST['period'] != 'daily'): 
									if (in_array($_DailyLoopCDataKey, $_DateEnteredArray)):

									$volumecsa_grid[] = "<td>".$_DailyLoopCDataKey ."</td>";
									$volumecsa_grid[] = "<td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>";
									$volumecsa_grid[] = "<td>".$_Catname."</td>";
									$volumecsa_grid[] = "<td>NA</td>";
									$volumecsa_grid[] = "<td>NA</td>";
									$volumecsa_grid[] = "<td class=counter onclick='checkclick(this.title)' id=Dailydata_".$_DateEntered1Array[$_DailyLoopCData][0]." title=daily_".$_DailyLoopCDataKey.">".$volumecsaYearcount."</td>";

									else:
									$volumecsa_grid[] = "<td>".$_DailyLoopCDataKey."</td>";
									$volumecsa_grid[] = "<td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>";
									$volumecsa_grid[] = "<td>".$_Catname."</td>";
									$volumecsa_grid[] = "<td>NA</td>";
									$volumecsa_grid[] = "<td>NA</td>";
									$volumecsa_grid[] = "<td>0</td>";
									endif;
					
								else:
											
									  if (!in_array($_DailyLoopCData, $_DateEnteredArray)) {
									  //Modified by Ashok on 10-08-2017 to show default NA in case of daily
									 // $volumecsa_grid[] =  "<td>".$_DailyLoopCData."</td><td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>
									 //<td>".$_Catname."</td><td>NA</td><td>NA</td><td>0</td>";
									 
									  $volumecsa_grid[] =  "<td>NA</td><td>NA</td>
									 <td>NA</td><td>NA</td><td>NA</td><td>0</td>";
									 }

								endif;		
								
								 $volumecsa_grid[] = "</tr>";
                                if (in_array($_DailyLoopCData, $_DateEnteredArray)) {
								
								
									/*script for showing daily wise record*/
									 $_DailSSdate = $_DailyLoopCData; //start date
									 $_DailESdate =  date ("Y-m-d", strtotime("+1 day", strtotime($_DailyLoopCData))); //end date
									 $_DailyRowrecord =  $this->dailydataDailywisecsa($_REQUEST['sub_category_id'] ,$_REQUEST['origin'],$_REQUEST['category_id'],$_DailSSdate, $_DailESdate ,$_REQUEST['assigned_to_name']);
                                   
									foreach($_DailyRowrecord  as $_DailyRowrecord1):
										 $volumecsa_grid[] = "<tr style=padding:20px;>";
										 $volumecsa_grid[] = "<td style=background:#e5f7fe !important;>".$_DailyRowrecord1['date_entered']."</td>";
										 $volumecsa_grid[] = "<td style=background:#e5f7fe !important;>".$_DailyRowrecord1['origin_c']."</td>";
										 $volumecsa_grid[] = "<td style=background:#e5f7fe !important;>".$_DailyRowrecord1['category_c']."</td>";
										 $volumecsa_grid[] = "<td style=background:#e5f7fe !important;>".$_DailyRowrecord1['priority']."</td>";
										 $volumecsa_grid[] = "<td style=background:#e5f7fe !important;>".$_DailyRowrecord1['assigned_to_name']."</td>";
										 $volumecsa_grid[] = "<td style=background:#e5f7fe !important;>1</td>";
										 $volumecsa_grid[] = "</tr>";
									 endforeach;
									 }
									  $volumecsa_grid[] = "<tr class=dailyresulthide id=dailyresult_" . $_DailyLoopCData . " style=display:none>
						 <td colspan='6' class='parent-TD'>
						 </td></tr>";
						 
                               endif;
							$i++;
                            
                        }

                    endif;
                else:
                    if ($_QuaterlyGlobal == 1):
                        foreach ($_GetOneQuarters as $_GetPeroidKey => $_GetPeroidVal):
                            if ($_GetPeroidVal == 0):
                                $volumecsa_grid[] = "<tr><td>" . $_GetPeroidKey . "</td>
                                                <td colspan='8'>We can't find records for this period</td>
                                                </tr>";
                            else:
                                $volumecsa_grid[] = "<tr><td>" . $_GetPeroidKey . "</td>
                                                <td>" . "" . "</td>
                                                <td>" . "" . "</td>
                                                <td>" . "" . "</td><td>" . "" . "</td>
                                                <td onclick='checkclick(this.title)' id=Dailydata_" . $_GetPeroidKey . " title=daily_" . $_GetPeroidKey . ">" . $_GetPeroidVal . "</td>
                                                </tr>";
                            endif;
                            $volumecsa_grid[] = "</tr>";
                            $volumecsa_grid[] = "<tr class=dailyresulthide id=dailyresult_" . $_GetPeroidKey . " style=display:none>
                                                <td colspan='8' class='parent-TD'>
                                                </td></tr>";
                        endforeach;
                    endif;
                endif;

                /* checking query ending */
            }
        }
        if (isset($total) > 0) {
            $this->view_object_map['total_cases'] = $total;
        } else {
            $this->view_object_map['total_cases'] = 0;
        }
        $this->view_object_map['volumecsagrid'] = $volumecsa_grid;
    }

    public function getExportContentCSA($_QueryFD,$_QueryTD,$_QueryPer,$_QueryORI,$_QueryReportBranchStore,$_QueryCat,$_QuerySubCat,$_QuerySta,$_QueryReportType,$_Mstart,
	 $_Start,$_Wstart ,$_Wend,$_Qastart,$_QaEnd,$_Qfromyear,$_Qtoyear) { 
        global $db, $app_list_strings, $sugar_config;
		$this->view = 'volumecsa';
        $volumecsa = $queryCase = $_Yearquery = $_ColumnsDate = $volumeDate = $_DailyLoopC = $_DateEnteredArray = $volumecsa_grid = $_NoOfQuarters = $_GetOneQuarters = $volumecsa_grid1 = array();
        $_WeeklyGlobal = $_QuaterlyGlobal = $_MonthGlobal = $_DailyGlobal = $_YearlyGlobal = 0;
         $condition = $condition_group=$_StartMonth=$_EndMonth= $_StartW= $_EndW=$_StartQ=$_EndQ='';
		
		if ($_QueryFD || $_QueryPer || $_QueryORI || $_QueryORI || $_QueryReportBranchStore || $_QueryCat || $_QuerySubCat || $_QuerySta ) {

		
		if ($_Qfromyear && $_Qtoyear) {
		    $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
			$from = $_Qfromyear;
			$to = $_Qtoyear;		
			if ($_Qfromyear != $_Qtoyear) {
			$end_date = $_curdate;
			$start_date = date('Y-m-1', strtotime("-1 year"));
			} else {
			$start_date = date('Y-m-d', strtotime("$from-01-01"));
			$end_date = date('Y-m-d', strtotime("$from-12-31"));
			}
			$condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($start_date)) . "' AND '" . date("Y-m-d", strtotime($end_date)) . "' AND ";
			}else
		{
			if ($_QueryPer == "daily"):
			if ($_QueryFD && $_QueryTD) {
			$condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($_QueryFD)) . "' AND '" . date("Y-m-d", strtotime($_QueryTD)) . "' AND ";
			}
			endif;
		}
		
		
			if ($_QueryReportBranchStore == "all" || $_QueryReportBranchStore == "") {
				$condition .= "";
				$condition_group .= "";
				}else
				{
				$condition .= "  cases.branch_store_name = '" . $_QueryReportBranchStore . "' AND ";
				$condition_group .= ",cases.branch_store_name";
				}
				
				
            if ($_QueryCat == "all") {
				$condition .= "";
				$condition_group .= "";
				}else
				{
				$condition .= "  cases_cstm.category_c = '" . $_QueryCat . "' AND ";
				$condition_group .= ",cases_cstm.category_c";
				}

				if ($_QueryORI == "all")  {
				$condition .= " ";
				$condition_group .= "";
				}else
				{
				$condition .= "  cases_cstm.origin_c = '" . $_QueryORI . "'  AND ";
				$condition_group .= ",cases_cstm.origin_c";
				}

				if ($_QuerySubCat  == "all") {
				$condition .= " ";
				$condition_group .= "";
				}else
				{
				$condition .= "  cases_cstm.subcategory_c = '" . $_QuerySubCat . "'  AND ";
				$condition_group .= ",cases_cstm.subcategory_c";
				}
				
				if ($_QuerySta  == "all") {
				$condition .= " ";
				$condition_group .= "";
				}else
				{
				$condition .= "  cases.status = '" . $_QuerySta . "'  AND ";
				$condition_group .= ",cases.status";
				}	   
				
				if(!empty($_Mstart)):
				   $_StartMonth = $_Mstart;
				endif;
				
				if(!empty($_Start)):
				   $_EndMonth = $_Start;
				endif;
				
				if(!empty($_Wstart)):
				  $_StartW = $_Wstart;
				endif;
				
				if(!empty($_Wend)):
				  $_EndW = $_Wend;
				endif;
				
				if(!empty($_Qastart)):
				  $_StartQ = $_Qastart;
				  $_StartQ = explode("_",$_Qastart);
				  $_StartQ = $_StartQ[0];
				endif;
				
				if(!empty($_QaEnd)):
				  $_EndQ = $_QaEnd;
				  $_EndQ = explode("_",$_EndQ);
				  $_EndQ = $_EndQ[1];
				endif;
				


           

            /* checking query starting */
            $start_date = date("Y-m-d", strtotime($_QueryFD));
            $end_date = date("Y-m-d", strtotime($_QueryTD));

            if ($_QueryPer == "daily"):
                $_DailyGlobal = 1;
                $_DailyLoopCount = $this->datediff('d', $start_date, $end_date);

                for ($i = 0; $i <= $_DailyLoopCount; $i++) {
                    $_DailyLoopC[] = date("Y-m-d", strtotime("+$i day", strtotime($start_date)));
                }

                if ($start_date && $end_date) {
                    $condition .= "  DATE(cases.date_entered) BETWEEN '" . date("y-m-d", strtotime($start_date)) . "' AND '" . date("y-m-d", strtotime($end_date)) . "' AND ";
                }


                $query_query = "SELECT cases.id,cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . "cases_cstm.member_tier_c,cases.status,cases.branch_store_name,"
                        . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
                        . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
                        . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id FROM cases "
                        . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition . " cases.deleted=0 ORDER BY cases.date_entered ASC";
				
                $result = $db->query($query_query);
                $total = $result->num_rows;
                if ($total > 0):
                    while ($row = $db->fetchByAssoc($result)) {
                        $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                        $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                        $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                        $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecsa[] = $row;
                        $volumeDate[] = date("Y-m-d", strtotime($row['date_entered']));
                    }
                else:
                    $row['emptyrecord'] = "N/A";
                endif;
            elseif ($_QueryPer == "weekly"):
                
            elseif ($_QueryPer == "monthly"):
			    $_MonthGlobal = 1;
				$_StartMonth =  date('Y-m-d',strtotime($_StartMonth));
				$_EndMonth = date('Y-m-d',strtotime($_EndMonth ));
				$a_date = $_EndMonth; 
				$date = new DateTime($a_date);
				$date->modify('last day of this month');
				$_EndMonth = $date->format('Y-m-d');
						
                $_MonthLoopCount = $this->datediff('m',date("y-m-d",strtotime($_StartMonth)),date("y-m-d",strtotime($_EndMonth)));				 
				for($i=0;$i<=$_MonthLoopCount+1;$i++)
				{
				$_DailyLoopC[] =  date ("m-Y", strtotime("+ $i month", strtotime($start_date)));
				}
				$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_StartMonth)) . "' AND '" . date("y-m-d",strtotime($_EndMonth)) . "' AND ";
                $query_query = "SELECT cases.id,cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . "cases_cstm.member_tier_c,cases.status,cases.branch_store_name,"
                        . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
                        . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
                        . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id FROM cases "
                        . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition . " cases.deleted=0 ORDER BY cases.date_entered ASC";
                $result = $db->query($query_query);
                $total = $result->num_rows;
                if ($total > 0):
                    while ($row = $db->fetchByAssoc($result)) {
                        $row['date_entered'] = date("d-m-Y", strtotime($row['date_entered']));
                        $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                        $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                        $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecsa[] = $row;
                    }
                else:
                    $row['emptyrecord'] = "N/A";
                endif;
				
				
            elseif ($_QueryPer == "quarterly"):
				$_QuaterlyGlobal =1;
				
				 $condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_StartQ)) . "' AND '" . date("y-m-d",strtotime($_EndQ)) . "' AND ";
				 
               $query_query = "SELECT cases.id,cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . "cases_cstm.member_tier_c,cases.status,cases.branch_store_name,"
                        . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
                        . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
                        . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id FROM cases "
                        . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition . "  cases.deleted=0 ORDER BY cases.date_entered ASC";
                $result = $db->query($query_query);
                $total = $result->num_rows;
                if ($total > 0):
                    while ($row = $db->fetchByAssoc($result)) {
                        $row['date_entered'] = date("Y", strtotime($row['date_entered']));
                        $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                        $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                        $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecsa[] = $row;
                    }
                else:
                    $row['emptyrecord'] = "N/A";

                endif;
            elseif ($_QueryPer == "annual"):
                 $_YearlyGlobal = 1;
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
				$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
			    $start_date  = $_Year."-".$_Month."-"."1";  //start date
				$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
				$_CurrentYear = date("Y"); // current year
				$_PreviousYears = date("Y")-1; //previous year 
				if ($_POST['getYearsDd'] != $_POST['getYeareDd']) {
					$_Year =  array($_PreviousYears,$_CurrentYear);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}else{
				    $_Year =  array($_POST['getYearsDd']);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}
				
				$from = $_POST['getYearsDd'];
				$to = $_POST['getYeareDd'];
				
				if ($_POST['getYearsDd'] != $_POST['getYeareDd']) {
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				} else {
				$start_date = date('Y-m-d', strtotime("$from-01-01"));
				$end_date = date('Y-m-d', strtotime("$from-12-31"));
				}
					
					
                   
				//$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . //date("y-m-d",strtotime($end_date)) . "' AND ";
			   
                $query_query = "SELECT cases.id,cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . "cases_cstm.member_tier_c,cases.status,cases.branch_store_name,"
                        . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
                        . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
                        . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id FROM cases "
                        . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition . "  cases.deleted=0 ORDER BY cases.date_entered ASC";
                $result = $db->query($query_query);
                $total = $result->num_rows;
                if ($total > 0):
                    while ($row = $db->fetchByAssoc($result)) {
                        $row['date_entered'] = date("Y", strtotime($row['date_entered']));
                        $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                        $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                        $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecsa[] = $row;
                    }
                else:
                    $row['emptyrecord'] = "N/A";
                endif;
            else:
                if ($_QueryCat && empty($_QueryORI)) {
                    $condition .= "  cases_cstm.category_c = '" . $_QueryCat . "' AND ";
                    $condition_group .= ",cases_cstm.category_c";
                }
                if ($_QueryORI && empty($_QueryCat)) {
                    $condition .= "  cases_cstm.origin_c = '" . $_QueryORI . "'  AND ";
                    $condition_group .= ",cases_cstm.origin_c";
                }

                if (!empty($_QueryORI) && !empty($_QueryCat)) {
                    $condition .= "  cases_cstm.origin_c = '" . $_QueryORI . "'  AND  cases_cstm.category_c = '" . $_QueryCat . "' AND";
                    $condition_group .= ",cases_cstm.origin_c,cases_cstm.category_c";
                }
                if (!empty($_QueryMem)) {
                    $condition .= " cases_cstm.member_tier_c = '" . $_QueryMem . "' AND ";
                    $condition_group .= ",cases_cstm.member_tier_c";
                }
                if (!empty($_QuerySta)) {
                    $condition .= "  cases.status = '" . $_QuerySta . "'  AND ";
                    $condition_group .= ",cases.status";
                }
				
				 if (!empty($_QueryReportBranchStore)) {
                    $condition .= "  cases.branch_store_name = '" . $_QueryReportBranchStore . "'  AND ";
                    $condition_group .= ",cases.branch_store_name";
                }
				
				
                /* checking query starting */
                $start_date = date("Y-m-d", strtotime($_QueryFD));
                $end_date = date("Y-m-d", strtotime($_QueryTD));
                $_DailyLoopCount = $this->datediff('d', date("y-m-d", strtotime($_QueryFD)), date("y-m-d", strtotime($_QueryTD)));

                for ($i = 0; $i <= $_DailyLoopCount; $i++) {
                    $_DailyLoopC[] = date("Y-m-d", strtotime("+$i day", strtotime($start_date)));
                }

                if ($_QueryFD && $_QueryTD) {
                    $condition .= "  DATE(cases.date_entered) BETWEEN '" . date("y-m-d", strtotime($start_date)) . "' AND '" . date("y-m-d", strtotime($end_date)) . "' AND ";
                }


                $query_query = "SELECT cases.id,cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . "cases_cstm.member_tier_c,cases.status,cases.branch_store_name,"
                        . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
                        . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
                        . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id FROM cases "
                        . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition . " cases_cstm.member_tier_c IN ('Base','base','Silver','silver','Gold','gold') AND cases.deleted=0  group by date(cases.date_entered)" . $condition_group . " ORDER BY cases.date_entered ASC";

                $result = $db->query($query_query);
                $total = $result->num_rows;
                if ($total > 0):
                    while ($row = $db->fetchByAssoc($result)) {
                        $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                        $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                        $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                        $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecsa[] = $row;
                        $volumeDate[] = date("Y-m-d", strtotime($row['date_entered']));
                    }
                else:
                    $row['emptyrecord'] = "N/A";

                endif;
            endif;
			 if($_QueryPer == 'weekly'){//for month start
				$temp2 = array();
					for($p = $_StartW ; $p <= $_EndW ; $p++){
						$temp2w[] = $p;
					}
				}

            if ($_DailyGlobal == 1 || $_YearlyGlobal == 1 || $_MonthGlobal == 1 || $_WeeklyGlobal == 1 || $_QuaterlyGlobal == 1):
				$i = 0;

					foreach ($volumecsa as $volumecsa1):
					 if($_QueryPer == 'weekly'):
					 if(!in_array($i,$temp2w)){
					 $i++;
						continue;
						
					 }
					endif;
                      
                    $volumecsa_grid1["date_entered"] = $volumecsa1['date_entered'];
					$volumecsa_grid1["case_number"] = $volumecsa1['case_number'];
                    $volumecsa_grid1["origin_c"] = $volumecsa1['origin_c'];
                    $volumecsa_grid1["category_c"] = $volumecsa1['category_c'];
                    $volumecsa_grid1["priority"] = $volumecsa1['priority'];
                    $volumecsa_grid1["assigned_to_name"] = $volumecsa1['assigned_to_name'];
					$volumecsa_grid1["branch_store_name"] = $volumecsa1['branch_store_name'];
                    $volumecsa_grid[] = $volumecsa_grid1;

                endforeach;
            endif;
           
        }

        return $volumecsa_grid;

        if (isset($total) > 0) {
            $this->view_object_map['total_cases'] = $total;
        } else {
            $this->view_object_map['total_cases'] = 0;
        }
    }
	 public function getExportContentsummeryreportCSA($_QueryFD,$_QueryTD,$_QueryPer,$_QueryORI,$_QueryReportBranchStore,$_QueryCat,$_QuerySubCat,$_QuerySta,$_QueryReportType,$_Mstart,$_Mend,$_Wstart,$_Wend, $_Qstart,$_Qend,$_Qfromyear,$_Qtoyear)
	 {
	 
	    global $db, $app_list_strings;
		global $sugar_config;
		$ReportName = 'volumecsa';
        $this->view = 'volumecsa';
        $this->view_object_map['getAllCaseCategory'] = $this->getAllCaseCategory();
        $this->view_object_map['getTimePeriod'] = $this->getTimePeriod();
		$this->view_object_map['site_url'] = $sugar_config['site_url'];
        $volumecsa = $queryCase = $_Yearquery= $_ColumnsDate=$volumeDate=$_DailyLoopC=$_DateEnteredArray
		=$volumecsa_grid=$_NoOfQuarters=$_GetOneQuarters=array();
		$_WeeklyGlobal = $_QuaterlyGlobal = $_MonthGlobal = 0;
        $condition = $condition_group='';
			
		if ($_Qfromyear && $_Qtoyear) {
		    $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
			$from = $_Qfromyear;
			$to = $_Qtoyear;		
			if ($_Qfromyear != $_Qtoyear) {
			$end_date = $_curdate;
			$start_date = date('Y-m-1', strtotime("-1 year"));
			} else {
			$start_date = date('Y-m-d', strtotime("$from-01-01"));
			$end_date = date('Y-m-d', strtotime("$from-12-31"));
			}
			$condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($start_date)) . "' AND '" . date("Y-m-d", strtotime($end_date)) . "' AND ";
			}
			else
		{
		if($_QueryPer == "monthly"):
			if ($_QueryFD && $_QueryTD) {
			$condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($_QueryFD)) . "' AND '" . date("Y-m-d", strtotime($_QueryTD)) . "' AND ";
			}
		endif;	
		}
		 if ($_QueryReportBranchStore == "all" || $_QueryReportBranchStore == "") {
			$condition .= "";
			$condition_group .= "";
		 }else
		 {
			 $condition .= "  cases.branch_store_name = '" . $_QueryReportBranchStore . "' AND ";
			$condition_group .= ",cases.branch_store_name";
		 }	   
		
		 if ($_QueryCat == "all") {
			$condition .= "";
			$condition_group .= "";
		 }else
		 {
			 $condition .= "  cases_cstm.category_c = '" . $_QueryCat . "' AND ";
			$condition_group .= ",cases_cstm.category_c";
		 }
		if ($_QueryORI == "all")  {
			$condition .= " ";
			$condition_group .= "";
		}else
		 {
			$condition .= "  cases_cstm.origin_c = '" . $_QueryORI . "'  AND ";
			$condition_group .= ",cases_cstm.origin_c";
		 }
		if ($_QuerySubCat  == "all") {
			$condition .= " ";
			$condition_group .= "";
		}else
		 {
			$condition .= "  cases_cstm.subcategory_c = '" . $_QuerySubCat. "'  AND ";
			$condition_group .= ",cases_cstm.subcategory_c";
		 }
		 
		 if ($_QuerySta  == "all") {
			$condition .= " ";
			$condition_group .= "";
		}else
		 {
			$condition .= "  cases.status = '" . $_QuerySta. "'  AND ";
			$condition_group .= ",cases.status";
		 }
		 
		 if(!empty($_Mstart)):
				  $_StartMonth = $_Mstart;
				endif;
				
				if(!empty($_Mend)):
				   $_EndMonth = $_Mend;
				endif;
				
				if(!empty($_Wstart)):
				  $_StartW = $_Wstart;
				endif;
				
				if(!empty($_Wend)):
				  $_EndW = $_Wend;
				endif;
				
				if(!empty($_Qstart)):
				  $_StartQ = $_Qstart;
				endif;
				
				if(!empty($_Qend)):
				  $_EndQ = $_Qend;
				endif;
		 
		 if($_QueryPer == "daily"):
		 
		  $_DailyLoopCount = $this->datediff('d',date("y-m-d",strtotime($_QueryFD)),date("y-m-d",strtotime($_QueryTD)));				 

						for($i=0;$i<=$_DailyLoopCount;$i++)
						{
						$_DailyLoopC[] =  date ("Y-m-d", strtotime("+$i day", strtotime($_QueryFD)));
						}
						
				     $condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_QueryFD)) . "' AND '" . date("y-m-d",strtotime($_QueryTD)) . "' AND ";
						
								
								
					  $query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where " . $condition . " cases.deleted=0  group by date(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
							
						$result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
                        $row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecsa[] = $row;
					    $volumeDate[] = date("Y-m-d",strtotime($row['date_entered']));
						}
						else:
						$row['emptyrecord'] = "N/A";
                       // $volumecsa[] = $row;
						endif;
		  
		 
		 
		 elseif($_QueryPer == "weekly"):
		      if(date("m") <= 06){
						$_CurrentYear = date("Y"); // current year
						$_NextYears =  date("Y")-1; //previous year 
						
						$start_date =  date($_NextYears.'-07-01'); //common from date
						$end_date =  date($_CurrentYear.'-06-30'); 
						$_WeekLoopCount = $this->datediff('ww',$start_date ,$end_date )." Week<br>";

						}
						else{
						$_CurrentYear =  date("Y"); // current year
						$_NextYears  =  date("Y") + 1;  // post year
						$start_date =  date($_CurrentYear.'-07-01'); //common from date
						$end_date =  date($_NextYears.'-06-30'); 
						$_WeekLoopCount = $this->datediff('ww',$start_date ,$end_date )." Week<br>";
						
				}
				for($i=0;$i<=$_WeekLoopCount;$i++)
						{
						$_DailyLoopC[] =  date ("Y-m-d", strtotime("+ $i week", strtotime($start_date)));
						}
						$_WeeklyGlobal = 1;
                        
						$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";
						
					    $query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
							. "cases_cstm.member_tier_c,"
							. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
							. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
							. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
							. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
							. " cases.date_entered , cases.assigned_user_id FROM cases "
							. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
							. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
							. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
							. " where " . $condition . " cases.deleted=0  group by week(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";

						$result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
						$volumecsa[] = $row;
						}
						else:
						$row['emptyrecord'] = "N/A";
						// $volumecsa[] = $row;
						endif;
		 elseif($_QueryPer == "monthly"):
				$_MonthGlobal = 1;
			    $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
				$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
				$start_date  = $_Year."-".$_Month."-"."1";  //start date
				$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
				$_MonthLoopCount = $this->datediff('m',date("y-m-d",strtotime($start_date )),date("y-m-d",strtotime($end_date)));				 
				/*month logic end */
				for($i=0;$i<=$_MonthLoopCount+1;$i++)
				{
				$_DailyLoopC[] =  date ("M-Y", strtotime("+ $i month", strtotime($start_date)));
				}
				
				$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";
				
			    $query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
							. "cases_cstm.member_tier_c,"
							. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
							. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
							. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
							. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
							. " cases.date_entered , cases.assigned_user_id FROM cases "
							. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
							. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
							. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
							. " where " . $condition . " cases.deleted=0  group by month(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
						$result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['date_entered'] = date("M-Y",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
						$volumecsa[] = $row;
						}
						else:
						$row['emptyrecord'] = "N/A";
						// $volumecsa[] = $row;
						endif;
		 elseif($_QueryPer == "quarterly"):
				$_QuaterlyGlobal =1;
				/*quater logic start*/
				$_Start_Q = explode("_",$_StartQ);
				$_OpenQ = $_Start_Q[2];
				$_End_Q = explode("_",$_EndQ);
				$_EndQ = $_End_Q[2];
				/* end */
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				
				$this->view_object_map['creatQudd'] = $this->creatQuarterdd($start_date,$end_date);
				//echo "<pre>";
				//print_r($this->view_object_map['creatQudd'] );
                
				$_GetQuarters = $this->creatQuarterdd($start_date,$end_date);

				foreach($_GetQuarters as $_GetQuarters1Key=>$_GetQuarters1)
				{
				$_Startq = explode("_",$_GetQuarters1Key); 
				
				$_DailyLoopC[$_GetQuarters1Key] = $_GetQuarters1;
				$_GetPeroid[$_GetQuarters1Key."_".$_GetQuarters1]= $this->checkReportPeriodQuarterCSA($condition,$condition_group,$_Startq[0],$_Startq[1]);

                }		
	
				
			     $query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where " . $condition . " cases.deleted=0  group by QUARTER(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
				
				        $result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['date_entered'] = date("Y",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecsa[] = $row;
						}
						else:
						$row['emptyrecord'] = "N/A";
                       // $volumecsa[] = $row;
						endif;
		 elseif($_QueryPer == "annual"):
				  $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
				$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
			    $start_date  = $_Year."-".$_Month."-"."1";  //start date
				$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
				$_CurrentYear = date("Y"); // current year
				$_PreviousYears = date("Y")-1; //previous year 
				if ($_Qfromyear!= $_Qtoyear) {
					$_Year =  array($_PreviousYears,$_CurrentYear);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}else{
				    $_Year =  array($_Qfromyear);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}

				
                //$_YearlyLoopCount = $this->datediff('yyyy',date("y-m-d",strtotime($_REQUEST['from_date'])),date("y-m-d",strtotime($_REQUEST['to_date'])));
                
				$from = $_Qfromyear;
				$to = $_Qtoyear;
				
				if ($_Qfromyear != $_Qtoyear) {
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				} else {
				$start_date = date('Y-m-d', strtotime("$from-01-01"));
				$end_date = date('Y-m-d', strtotime("$from-12-31"));
				}
						
				//$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";
							
					
					
				 $query_query = "SELECT count(cases.id),cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) assigned_to_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where " . $condition . " cases.deleted=0  group by year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
				$result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['date_entered'] = date("Y",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecsa[] = $row;
						}
						else:
						$row['emptyrecord'] = "N/A";
                       // $volumecsa[] = $row;
						endif;
		 
		 
		 endif;

		$_DateEntered1ArrayTotalfor = "";
	    if($_WeeklyGlobal == 1)
		{
					if(count($volumecsa)):
						 foreach($volumecsa as $volumecsaData)
						 {
							$_DateEntered1Array[$volumecsaData['date_entered']] = $volumecsaData['date_entered']."_".$volumecsaData['category_c']."_".$volumecsaData['origin_c']."_".$volumecsaData['count(cases.id)'];
						 }
					endif;
				}
		else{
					if(count($volumecsa)):
						 foreach($volumecsa as $volumecsaData)
						 {
							$_DateEnteredArray[] = $volumecsaData['date_entered'];
							$_DateEntered1Array[$volumecsaData['date_entered']] = array($volumecsaData['date_entered'],$volumecsaData['category_c'],$volumecsaData['origin_c'],$volumecsaData['count(cases.id)']);
							$_DateEntered1MytCount[$volumecsaData['date_entered']] = $volumecsaData['count(cases.id)'];
							$_DateEntered1ArrayTotalfor  = $volumecsaData['count(cases.id)'];
						 }
					endif;
		}
		if($_QueryPer == 'monthly'){//for month start

			     $_MonthStartArray = array_keys($_DailyLoopC,$_StartMonth);
				 $_MonthEndArray =  array_keys($_DailyLoopC,$_EndMonth);
				 $_Totvalue = $_MonthEndArray[0]-$_MonthStartArray[0];
			     $_DailyLoopC = array_slice($_DailyLoopC,$_MonthStartArray[0],$_Totvalue+1);
				 //for month end
				}
		
		 if(!empty($_DateEntered1Array)):
				 foreach($_DateEntered1Array as $_DateEntered1Array1)
				 {
				  $_yearRecord[]  = $_DateEntered1Array1[3];
				 }
		 endif;
				 
				 
		 $i = 1;
                if(count($_DailyLoopC) > 0):
				if($_QuaterlyGlobal==1):
				$_OpenQua = array();
            for($_OpenQ;$_OpenQ<=$_EndQ;$_OpenQ++){
			  $_OpenQua[] = $_OpenQ;
				}
				$temp2 = array();
				//for($p = $_StartQ; $p <= $_EndQ; $p++){
				//$temp2[] = $p;
				//}
				foreach($_GetPeroid as $_GetPeroidKey => $_GetPeroidData)
					 { 
					 //if($_QueryPer == 'quarterly'):
					 //if(!in_array($i,$temp2)){
					 //$i++;
					//	continue;
						
					// }
					// endif;
					 
					 $_GetPeroidDisaply = $_GetPeroidKey;
					 $_GetPeroidDisaply =  explode("_",$_GetPeroidDisaply);
					 $_Qendate = date ("Y-m-d", strtotime("+ 3 month", strtotime($_GetPeroidKey)));
					 $_GetPeroidSd = date("M y",strtotime($_GetPeroidKey));
					 $_GetPeroided = date("M y",strtotime($_Qendate));
					 if($_REQUEST['category_id'] == 'all'):
						$_Catname = 'All';
					 else:
						$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
					 endif;
					  if(in_array($_GetPeroidDisaply[2],$_OpenQua)):
					   $_GetPeroidKey = explode("_",$_GetPeroidKey);
					        if($_GetPeroidData==0):
							$volumecsa_grid[] = array($_GetPeroidKey[3], 0);
							else:
							$volumecsa_grid[] = array($_GetPeroidKey[3],$_GetPeroidData);
							endif;
					  endif;		
				     $i++;}
                else:
                   $temp2 = array();
						for($p = $_StartW ; $p <= $_EndW ; $p++){
						$temp2w[] = $p;
						}
						foreach($_DailyLoopC as $_DailyLoopCDataKey => $_DailyLoopCData)
					 { 
					 
					 if($_QueryPer == 'weekly'):
					 if(!in_array($i,$temp2w)){
					 $i++;
						continue;
						
					 }
					  endif;
				   if($_WeeklyGlobal == 1):
						/*weekly interval*/
						
					    $_WeekStartdate = $_DailyLoopCData; //weekly date start
					    $_WeekEnddate =  date("Y-m-d", strtotime("+ 1 week", strtotime($_DailyLoopCData))); //weekly date ended
					    $_WeekEnddate =  date("Y-m-d", strtotime("-1 day", strtotime($_WeekEnddate)));
						$_WeekDateInterval = $this->returnBetweenDates($_WeekStartdate, $_WeekEnddate); 
					    $_GetPeroid = $this->checkReportPeriodreportcc($condition,$condition_group,$_WeekStartdate,$_WeekEnddate);
						
						$_WeekStartdate = date("d M Y",strtotime($_WeekStartdate));
						$_WeekEnddate = date("d M Y",strtotime($_WeekEnddate));
						
						if($_REQUEST['category_id'] == 'all'):
						$_Catname = 'All';
						else:
						$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
						endif;
						if($_GetPeroid==0):
							$volumecsa_grid[] = array("week ".$i." (".$_WeekStartdate." - ".$_WeekEnddate.")",0);
							
						else:
							$volumecsa_grid[] = array("week ".$i." (".$_WeekStartdate." - ".$_WeekEnddate.")",$_GetPeroid);
							
						
                        endif;						
                      /*weekly interval*/
						
					elseif($_MonthGlobal ==1):

					if($_REQUEST['category_id'] == 'all'):
						$_Catname = 'All';
						else:
						$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
						endif;
						
						if (in_array($_DailyLoopCData,$_DateEnteredArray))
						{
						//$key = array_search($_DailyLoopCData, $_DateEnteredArray);
						 $volumecsa_grid[] = array($_DailyLoopCData,$_DateEntered1Array[$_DailyLoopCData][3]);
						}
						else
						{
						 $volumecsa_grid[] = array($_DailyLoopCData,0);  
						}
					
					
                    else:	
					
						if($_REQUEST['category_id'] == 'all'):
						$_Catname = 'All';
						else:
						$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
						endif;

						if (in_array($_DailyLoopCData,$_DateEnteredArray))
						{
						
						  $volumecsa_grid[] =  array($_DailyLoopCData,$_DateEntered1ArrayTotalfor);
						}else
						{
						  $volumecsa_grid[] =  array($_DailyLoopCData,0);
						}
						
						
						
						/*if (in_array($_DailyLoopCData,$_DateEnteredArray))
						{
						//$key = array_search($_DailyLoopCData, $_DateEnteredArray);
					 	 if($_QueryPer != 'daily'):
						 	if(array_sum($_yearRecord) > 0):
							if($i==1):
							$volumecsa_grid[] = array($_NextYears.' - '.$_CurrentYear,array_sum( $_yearRecord));
							endif;
                            else:
							$volumecsa_grid[] = array($_DailyLoopCData.' - '.$_CurrentYear,0);
                            endif;
							
						  else:
						  $volumecsa_grid[] = array($_DateEntered1Array[$_DailyLoopCData][0],$_DateEntered1Array[$_DailyLoopCData][3]);

						 endif;
						}
						
						else
						{
                          $volumecsa_grid[] =  array($_DailyLoopCData,0);
						}
						 */
					endif;
					    //echo $_DailyLoopCData[$i]."checkarrayindex".$_DailyLoopCData[$i+1]."<br>"; 
						
					$i++;	}

				endif;
				else:
                   if($_QuaterlyGlobal==1):
				   foreach($_GetOneQuarters as $_GetPeroidKey=>$_GetPeroidVal):
                      if($_GetPeroidVal==0):
						$volumecsa_grid[] = "<tr><td>".$_GetPeroidKey."</td>
						<td colspan=3>We can't find records for this period</td>
						</tr>";
					   else:
						$volumecsa_grid[] = "<tr><td>".$_GetPeroidKey."</td>
						<td>".""."</td>
						<td>".""."</td>
						<td onclick='checkclick(this.title)' id=Dailydata_".$_GetPeroidKey." title=daily_".$_GetPeroidKey.">".$_GetPeroidVal."</td>
						</tr>";
					   endif;
						$volumecsa_grid[] = "</tr>";
						$volumecsa_grid[] ="<tr class=dailyresulthide id=dailyresult_".$_GetPeroidKey." style=display:none>
						<td colspan='4' class='parent-TD'>
						</td></tr>";
					endforeach;	
				   endif;
                endif;
				//echo '<pre>';
				//print_r($volumecsa_grid);
				 //$volumecsa_grid = array_intersect_key($temp2, $volumecsa_grid);
				return $volumecsa_grid;

		 }
    
	 public function action_exportvolumecsa() {
	 
        global $db, $app_list_strings;
		$condition =$_QueryFD =$_QueryTD =$_QueryPer= $_QueryORI = $_QueryCat =$_QueryReportType= $_QuerySubCat =$_QuerySta =$start_date=$end_date= $_QueryReportMonthStart=$_QueryReportMonthEnd=$_QueryReportBranchStore="";
		  			
	  if(isset($_REQUEST['queryfromdate']))
          {
		   $_QueryFD =  $_REQUEST['queryfromdate'];
          }
		  
          if(isset($_REQUEST['querytodate']))
          {
		  $_QueryTD =  $_REQUEST['querytodate'];
          }

          if(isset($_REQUEST['queryPeriod']))
          {
		  $_QueryPer =  $_REQUEST['queryPeriod'];
          }

          if(isset($_REQUEST['queryorigin']))
          {
		  $_QueryORI=  $_REQUEST['queryorigin'];
          }

          if(isset($_REQUEST['querycategory']))
          {
		  $_QueryCat =  $_REQUEST['querycategory'];
          }
		   if(isset($_REQUEST['querysubcategory']))
          {
		  $_QuerySubCat =  $_REQUEST['querysubcategory'];
          }
		  
          if(isset($_REQUEST['querystatus']))
          {
		  $_QuerySta =  $_REQUEST['querystatus'];
          }
          
          if(isset($_POST['report_type']))
          {
		  $_QueryReportType =  $_POST['report_type'];
          }
          
		  if(isset($_POST['querySmonth']))
		 {
		   $_QueryReportMonthStart =  $_POST['querySmonth'];
		 }

		 if(isset($_POST['queryEmonth']))
		 {
		  $_QueryReportMonthEnd =  $_POST['queryEmonth'];
		} 		  
		   
		  if(isset($_POST['querysWeek']))
		 {
		  $_Wstart =  $_POST['querysWeek'];
		} 
		 if(isset($_POST['queryeWeek']))
		 {
		  $_Wend =  $_POST['queryeWeek'];
		} 
		   if(isset($_POST['queryeQs']))
		 {
		  $_Qstart =  $_POST['queryeQs'];
		} 
		 if(isset($_POST['queryeQe']))
		 {
		  $_Qend =  $_POST['queryeQe'];
		} 

		
		 if(isset($_POST['queryBranchStore']))
		 {
		  $_QueryReportBranchStore =  $_POST['queryBranchStore'];
		} 	
		
		if(isset($_POST['getFromyear']))
		 {
		  $_Qfromyear =  $_POST['getFromyear'];
		} 
		if(isset($_POST['getToyear']))
		 {
		  $_Qtoyear =  $_POST['getToyear'];
		} 
		if( $_QueryReportType == "detailsreport"){ // summery report 
	    
		  $_dataColumns = $this->getExportContentCSA($_QueryFD,$_QueryTD,$_QueryPer,$_QueryORI,$_QueryReportBranchStore,$_QueryCat,$_QuerySubCat,$_QuerySta,$_QueryReportType,$_QueryReportMonthStart,$_QueryReportMonthEnd,$_Wstart,$_Wend, $_Qstart,$_Qend,$_Qfromyear,$_Qtoyear);  //calling function to get export data
		 //calling function to get export data
            if ($_POST['file_type'] == 'csv') { //Export CSV
                //CSV File name and Header
                $filename = "volumecsa_" . date('Y-m-d:H:i:s') . ".csv";
                 $fp = fopen('php://output', 'w');
                 $header = array('Case Id','Date', 'Case Origin', 'Case Category', 'Case Priority' , 'Customer Service Associate');
                 header('Content-type: application/csv');
                 header('Content-Disposition: attachment; filename=' . $filename);
                 fputcsv($fp, $header);
				$condition ="";
				$export_list_case = array();
				foreach($_dataColumns as $_dataColumns1Val):
				$row['case_number'] = $_dataColumns1Val['case_number'];
				$row['date_entered'] = $_dataColumns1Val['date_entered'];
				$row['origin_c'] = $_dataColumns1Val['origin_c'];
				$row['category_c'] = $_dataColumns1Val['category_c'];
				$row['priority'] = $_dataColumns1Val['priority'];
                $row['assigned_to_name'] = $_dataColumns1Val['assigned_to_name'];
				$export_list_case[] = $row;
			    fputcsv($fp, $row); //Genrate CSV
				endforeach;
				fclose($fp);
                exit;
            } elseif ($_POST['file_type'] == 'xls') { //Export XLS
                $list = array();
                $list['tableheading'] = array('Case Id','Date', 'Case Origin', 'Case Category', 'Case Priority' , 'Customer Service Associate');
                $fichier = "volumecsa_" . date('Y-m-d:H:i:s') . ".xls";
                header("Content-Type: text/csv;charset=utf-8");
                header("Content-Disposition: attachment;filename=\"$fichier\"");
                header("Pragma: no-cache");
                header("Expires: 0");
                $fp = fopen('php://output', 'w');
                fputcsv($fp, $list['tableheading']);
                //Fetch data
                foreach($_dataColumns as $_dataColumns1Val):
				$row['case_number'] = $_dataColumns1Val['case_number'];
				$row['date_entered'] = $_dataColumns1Val['date_entered'];
				$row['origin_c'] = $_dataColumns1Val['origin_c'];
				$row['category_c'] = $_dataColumns1Val['category_c'];
				$row['priority'] = $_dataColumns1Val['priority'];
                $row['assigned_to_name'] = $_dataColumns1Val['assigned_to_name'];
				$data['list'] = $row;
				//$export_list_case[] = $row;
			    fputcsv($fp, $data['list']); //Genrate CSV
				endforeach;
				fclose($fp);
                exit();
            }elseif($_POST['file_type'] == 'pdf')
			{
               require_once 'include/dompdf/dompdf_config.inc.php';
			   global $current_user;
			   $name = $current_user->first_name . '&nbsp;' . $current_user->last_name;
			   $current_date = date('d/m/Y  h:i A');
			   $dompdf = new Dompdf();
			  			  
			  if($_QueryPer  == 'daily'):
			   $start_date =$_QueryFD;
			   $end_date =$_QueryTD;
			  elseif($_QueryPer  == 'monthly'):
			   $start_date =$_QueryReportMonthStart;
			   $end_date =$_QueryReportMonthEnd;
			  elseif($_QueryPer  == 'quarterly'):
			   $start_date = "Quarter ".$this->Quarterlabelreportpdf($_Qstart);
			   $end_date = "Quarter ".$this->Quarterlabelreportpdf($_Qend);
			  elseif($_QueryPer  == 'weekly'):
			   $start_date =  $_Wstart;
			   $end_date =  $_Wend;
				
			  else:
			      if(date("m") <= 06){
						$_CurrentYear = date("Y"); // current year
						$_NextYears =  date("Y")-1; //previous year 
						
						$start_date =  date($_NextYears.'-07-01'); //common from date
						$end_date =  date($_CurrentYear.'-06-30'); 

						}
						else{
						$_CurrentYear =  date("Y"); // current year
						$_NextYears  =  date("Y") + 1;  // post year
						$start_date =  date($_CurrentYear.'-07-01'); //common from date
						$end_date =  date($_NextYears.'-06-30'); 
						}
				endif;		
				
			   $_CaseOriginPdf = $_CaseOriginCat = "";
			   if($_QueryORI == 'all'):
			    $_CaseOriginPdf = 'All';
			   else:
			    $_CaseOriginPdf = $this->getCaseOriginName($_QueryORI);
			   endif;
			   
			    $_CaseBranchStorePdf = "";
			   if($_QueryReportBranchStore == 'all'):
			    $_CaseBranchStorePdf = 'All';
			   else:
			    $_CaseBranchStorePdf = $_QueryReportBranchStore;
			   endif;
			   
			   
			   if($_QueryCat == 'all'):
			    $_CaseOriginCat = 'All';
			   else:
			    $_CaseOriginCat = $this->getCaseCategoryName($_QueryCat);
			   endif;
			   
			   if($_QuerySubCat == 'all'):
			    $_CaseOriginSubCat = 'All';
			   else:
			    $_CaseOriginSubCat = $this->getCaseSubCategoryName($_QuerySubCat);
			   endif;
			   
			   if($_QuerySta == 'all'):
			    $_CaseStatus = 'All';
			   else:
			    $_CaseStatus = $_QuerySta;
			   endif;
			   $header = '<html>
            <body>
                <div style="width:100%;color:#fff;background:#17479d;padding:5px 0px;margin:0px;text-align:center;">
                    <img src="custom/include/images/logo.png" style="padding: 7px;position: absolute;left: 10px;"><h2>Volume of Cases By Customer Service Associates  </h2>
                </div>
				<br />
				<table style="width:450px; margin:0 auto; text-align:left;">
				    <tr>
						<td style="width="20%"><b>From  - </b></td>
						<td style="width="10%">'.$start_date.'</td>
						<td style="width="20%"><b>To  - </b></td>
						<td style="width="10%">'.$end_date.'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Period  - </b></td>
						<td style="width="50%">'.ucfirst($_QueryPer).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Origin  - </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginPdf).'</td>
					</tr>
					';
					 if($_QueryReportBranchStore == 'all'):
						 $header .= '<tr>
						<td style="width="50%"><b>Branch Store - </b></td>
						<td style="width="50%">All</td>
					</tr>';
						elseif($_QueryReportBranchStore == ''):
							 $header .= ''; 
					   else:
						 $header .= '<tr>
						<td style="width="50%"><b>Branch Store  - </b></td>
						<td style="width="50%">'.ucfirst($_QueryReportBranchStore).'</td>
					</tr>'; 
					   endif;
				 $header .= '
					<tr>
						<td style="width="50%"><b>Case Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginCat).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Sub-Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginSubCat).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Status  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseStatus).'</td>
					</tr>
				</table>';
				
			    $content .= '<table border="1" cellspacing="0" cellpadding="5" width="100%">  
                    <thead>
                        <tr>
                            <th nowrap>Case Id</th>
                            <th nowrap>Date</th>
                            <th nowrap>Case Origin</th> 
                            <th nowrap>Case Category</th>  
							<th nowrap>Case Priority</th> 
							<th nowrap>Customer Service Associate</th> 
                        </tr>
                </thead>';
				
				foreach($_dataColumns as $_dataColumns1Val):
				    $content .= '<tbody>
                        <tr>
                          <td>' . $_dataColumns1Val["case_number"] . '</td>
                          <td>' . $_dataColumns1Val["date_entered"] . '</td>
                          <td>' . $_dataColumns1Val["origin_c"] . '</td>
                          <td>' . $_dataColumns1Val["category_c"] . '</td>
                          <td>' . $_dataColumns1Val["priority"] . '</td>
						  <td>' . $_dataColumns1Val["assigned_to_name"] . '</td>
                     </tr>
                    <tbody>';
				
				endforeach;
				$content .= '</table>';
				$footer = '<table style="width:100%;color:#ccc;background:#17479d;padding:5px 0px;margin:0px;">
								<tr>
							<td width="30%"><span style="float:left!important;margin-left:10px;">Printed by: ' . $name . '&nbsp;' . $current_date . '</span></td>
							<td style="text-align:center;width:30%;">www.nakumatt.net</td>
							<td  width="30%">&nbsp;</td>
								</tr>
							</table>
							<h4 style="color:red;">The content is confidential and not meant to be shared in any form with any external persons / entities.</h4>
							</body>
							</html>';
				$html = $header . $content . $footer;
				$dompdf->load_html($html);
				// (Optional) Setup the paper size and orientation
				$dompdf->set_paper('A4', 'landscape');
				// Render the HTML as PDF
				$dompdf->render();
				// Output the generated PDF to Browser
				$filename = "Volume of Cases By Customer Service Associates " . date('Y-m-d:H:i:s') . ".pdf";
				$dompdf->stream($filename);			
			   //pdf report
			
		   }
		}elseif( $_QueryReportType == "summeryreport" ){  // details report
			   $_dataColumns = $this->getExportContentsummeryreportCSA($_QueryFD,$_QueryTD,$_QueryPer,$_QueryORI,$_QueryReportBranchStore,$_QueryCat,$_QuerySubCat,$_QuerySta,$_QueryReportType,$_QueryReportMonthStart,$_QueryReportMonthEnd,$_Wstart,$_Wend, $_Qstart,$_Qend,$_Qfromyear,$_Qtoyear);  //calling function to get export data
			   $_Period = "";
			 if ($_POST['file_type'] == 'csv') { //Export CSV
                //CSV File name and Header
                $filename = "volumecsa_summery_report_" . date('Y-m-d:H:i:s') . ".csv";
                $fp = fopen('php://output', 'w');
				
				if($_QueryPer == 'daily'):
				 $_Period = "Daily";
				elseif($_QueryPer =='weekly'):
				 $_Period = "Weekly";
				elseif($_QueryPer == 'monthly'):
				 $_Period = "Monthly";
				elseif($_QueryPer == 'quarterly'):
				 $_Period = "Quarterly";
				elseif($_QueryPer == 'annual'):
				 $_Period = "Annual";
				endif;
                $header = array($_Period,'Count');
                header('Content-type: application/csv');
                header('Content-Disposition: attachment; filename=' . $filename);
                fputcsv($fp, $header);
				$condition ="";
				$export_list_case = array();
				foreach($_dataColumns as $_dataColumns1Key => $_dataColumns1Val):
				$row['period'] =  $_dataColumns1Val[0];
				$row['count'] = $_dataColumns1Val[1];
				$export_list_case[] = $row;
			    fputcsv($fp, $row); //Genrate CSV
				endforeach;
				fclose($fp);
                exit;
            } elseif ($_POST['file_type'] == 'xls') { //Export XLS
                $list = array();
				if($_QueryPer == 'daily'):
				 $_Period = "Daily";
				elseif($_QueryPer =='weekly'):
				 $_Period = "Weekly";
				elseif($_QueryPer == 'monthly'):
				 $_Period = "Monthly";
				elseif($_QueryPer == 'quarterly'):
				 $_Period = "Quarterly";
				elseif($_QueryPer == 'annual'):
				 $_Period = "Annual";
				endif;
				
                $list['tableheading'] = array($_Period,'Count');
                $fichier = "volumecsa_" . date('Y-m-d:H:i:s') . ".xls";
                header("Content-Type: text/csv;charset=utf-8");
                header("Content-Disposition: attachment;filename=\"$fichier\"");
                header("Pragma: no-cache");
                header("Expires: 0");
                $fp = fopen('php://output', 'w');
                fputcsv($fp, $list['tableheading']);
                //Fetch data
                foreach($_dataColumns as $_dataColumns1Val):
				$row['week'] =  $_dataColumns1Val[0];
				$row['count'] = $_dataColumns1Val[1];
				$data['list'] = $row;
				//$export_list_case[] = $row;
			    fputcsv($fp, $data['list']); //Genrate CSV
				endforeach;
				fclose($fp);
                exit();
            }elseif($_POST['file_type'] == 'pdf')
			{
			require_once 'include/dompdf/dompdf_config.inc.php';
			   global $current_user;
			   
			  if($_QueryPer  == 'daily'):
			   $_Period = "Daily";
			   $start_date =$_QueryFD;
			   $end_date =$_QueryTD;
			  elseif($_QueryPer  == 'monthly'):
			   $_Period = "Monthly";
			   $start_date =$_QueryReportMonthStart;
			   $end_date =$_QueryReportMonthEnd;
			  elseif($_QueryPer  == 'quarterly'):
			   $_Period = "Quarter";
			   $start_date = "Quarter ".$this->Quarterlabelreportpdf($_Qstart);
			   $end_date = "Quarter ".$this->Quarterlabelreportpdf($_Qend);
			  elseif($_QueryPer  == 'weekly'):
			   $_Period = "Weekly";
			   $start_date =  $_Wstart;
			   $end_date =  $_Wend;
			  elseif($_QueryPer == 'annual'):
				  $_Period = "Annual";
			      if(date("m") <= 06){
						$_CurrentYear = date("Y"); // current year
						$_NextYears =  date("Y")-1; //previous year 
						
						$start_date =  date($_NextYears.'-07-01'); //common from date
						$end_date =  date($_CurrentYear.'-06-30'); 

						}
						else{
						$_CurrentYear =  date("Y"); // current year
						$_NextYears  =  date("Y") + 1;  // post year
						$start_date =  date($_CurrentYear.'-07-01'); //common from date
						$end_date =  date($_NextYears.'-06-30'); 
						}
				endif;	
				
			   $name = $current_user->first_name . '&nbsp;' . $current_user->last_name;
			   $current_date = date('d/m/Y  h:i A');
			   $dompdf = new Dompdf();
			//   echo '<pre>';
			 //  print_r($_dataColumns);
			 //  die;
			    $_CaseOriginPdf = $_CaseOriginCat = "";
			   if($_QueryORI == 'all'):
			    $_CaseOriginPdf = 'All';
			   else:
			    $_CaseOriginPdf = $this->getCaseOriginName($_QueryORI);
			   endif;
			   
			   if($_QueryCat == 'all'):
			    $_CaseOriginCat = 'All';
			   else:
			    $_CaseOriginCat = $this->getCaseCategoryName($_QueryCat);
			   endif;
			   
			   if($_QuerySubCat == 'all'):
			    $_CaseOriginSubCat = 'All';
			   else:
			    $_CaseOriginSubCat = $this->getCaseSubCategoryName($_QuerySubCat);
			   endif;
			   
			    if($_QuerySta == 'all'):
			    $_CaseSta = 'All'; 
			   else:
			    $_CaseSta = $_QuerySta;
			   endif;
			   
			   
				$_CaseBranchStorePdf = "";
				if($_QueryReportBranchStore == 'all'):
				$_CaseBranchStorePdf = 'All';
				else:
				$_CaseBranchStorePdf = $_QueryReportBranchStore;
				endif;
				
				
			   
			   $header = '<html>
            <body>
                <div style="width:100%;color:#fff;background:#17479d;padding:5px 0px;margin:0px;text-align:center;">
                    <img src="custom/include/images/logo.png" style="padding: 7px;position: absolute;left: 10px;"><h3>Volume of Cases By Customer Service Associates </h3>
                </div>
				<br />
				<table style="width:450px; margin:0 auto; text-align:left;">
				    <tr>
						<td style="width="20%"><b>From  - </b></td>
						<td style="width="10%">'.$start_date.'</td>
						<td style="width="20%"><b>To  - </b></td>
						<td style="width="10%">'.$end_date.'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Period  - </b></td>
						<td style="width="50%">'.ucfirst($_QueryPer).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Origin  - </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginPdf ).'</td>
					</tr>
					
					';
					 if($_QueryReportBranchStore == 'all'):
						 $header .= '<tr>
						<td style="width="50%"><b>Branch Store - </b></td>
						<td style="width="50%">All</td>
					</tr>';
						elseif($_QueryReportBranchStore == ''):
							 $header .= ''; 
					   else:
						 $header .= '<tr>
						<td style="width="50%"><b>Branch Store  - </b></td>
						<td style="width="50%">'.ucfirst($_QueryReportBranchStore).'</td>
					</tr>'; 
					   endif;
					   
					  $header .= '  
					<tr>
						<td style="width="50%"><b>Case Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginCat).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Sub Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginSubCat).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Status -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseSta).'</td>
					</tr>
				</table>';
			    $content .= '<table border="1" cellspacing="0" cellpadding="5" width="100%">  
                    <thead>
                        <tr>
                            <th nowrap>'.$_Period.'</th>
                            <th nowrap>Count</th>
                        </tr>
                </thead>';
				
				foreach($_dataColumns as $_dataColumns1Val):
				    $content .= '<tbody>
                        <tr>
                          <td>' .$_dataColumns1Val[0]. '</td>
                          <td>' .$_dataColumns1Val[1]. '</td>
                     </tr>
                    <tbody>';
				
				endforeach;
				$content .= '</table>';
				$footer = '<table style="width:100%;color:#ccc;background:#17479d;padding:5px 0px;margin:0px;">
								<tr>
							<td width="30%"><span style="float:left!important;margin-left:10px;">Printed by: ' . $name . '&nbsp;' . $current_date . '</span></td>
							<td style="text-align:center;width:30%;">www.nakumatt.net</td>
							<td  width="30%">&nbsp;</td>
								</tr>
							</table>
							<h4 style="color:red;">The content is confidential and not meant to be shared in any form with any external persons / entities.</h4>
							</body>
							</html>';
				$html = $header . $content . $footer;
				$dompdf->load_html($html);
				// (Optional) Setup the paper size and orientation
				$dompdf->set_paper('A4', 'landscape');
				// Render the HTML as PDF
				$dompdf->render();
				// Output the generated PDF to Browser
				$filename = "Volume of Cases By Customer Service Associates " . date('Y-m-d:H:i:s') . ".pdf";
				$dompdf->stream($filename);			
			   //pdf report
			 //pdf report
			
		   } 
	   }  
    }
  
	
	/****volumecsa end***/
    public function action_volumecsr() {
        global $db, $app_list_strings;
        global $sugar_config;
        $this->view = 'volumecsr';
		$ReportName = "volumecsr";
        $this->view_object_map['getAllCaseCategory'] = $this->getAllCaseCategory();
        $this->view_object_map['getTimePeriod'] = $this->getTimePeriod();
		$this->view_object_map['getCasepriority'] = $this->getCasepriority();
        $this->view_object_map['site_url'] = $sugar_config['site_url'];
		//get branch store name
		$this->view_object_map['branch_store_name'] = $this->getAllBranchName();
		
        $volumecsr = $queryCase = $_Yearquery= $_ColumnsDate=$volumeDate=$_DailyLoopC=$_DateEnteredArray
        =$volumecsr_grid=$_NoOfQuarters=array();
        $_WeeklyGlobal = $_QuaterlyGlobal = $_MonthGlobal = 0;
        $condition = $condition_group=$_BranchStore = '';
 
        if (isset($_REQUEST['query']) == 'true') {
            if ($_REQUEST['category_id'] || $_REQUEST['period'] || $_REQUEST['origin'] || $_REQUEST['branch_store_name'] || $_REQUEST['member_tier_c'] || $_REQUEST['priority'] ||
                    $_REQUEST['status'] || $_REQUEST['from_date'] || $_REQUEST['to_date']) {

					if ($_REQUEST['category_id'] == "all") {
					$condition .= "";
					$condition_group .= "";
					}else
					{
					$condition .= "  cases_cstm.category_c = '" . $_REQUEST['category_id'] . "' AND ";
					$condition_group .= ",cases_cstm.category_c";
					}


					if ($_REQUEST['origin'] == "all")  {
					$condition .= " ";
					$condition_group .= "";
					}else
					{
					$condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
					$condition_group .= ",cases_cstm.origin_c";
					}
					
					if ($_REQUEST['branch_store_name'] == "all" || $_REQUEST['branch_store_name'] == "")  {
                    $condition .= " ";
					$condition_group .= "";
					}else
					 {
						$condition .= "  cases.branch_store_name = '" . $_REQUEST['branch_store_name'] . "'  AND ";
						$condition_group .= ",cases.branch_store_name";
					 }
				 
					if ($_REQUEST['sub_category_id']  == "all") {
					$condition .= " ";
					$condition_group .= "";
					}else
					{
					$condition .= "  cases_cstm.subcategory_c = '" . $_REQUEST['sub_category_id'] . "'  AND ";
					$condition_group .= ",cases_cstm.subcategory_c";
					}


					if ($_REQUEST['member_tier_c'] == "all") {
					$condition .= "";
					$condition_group .= "";
					}else
					{
					$condition .= "  cases_cstm.member_tier_c = '" . $_REQUEST['member_tier_c'] . "' AND ";
					$condition_group .= ",cases_cstm.member_tier_c";
					}

					if ($_REQUEST['status']  == "all") {
					$condition .= " ";
					$condition_group .= "";
					}else
					{
					$condition .= "  cases.status = '" . $_REQUEST['status'] . "'  AND ";
					$condition_group .= ",cases.status";
					}
					
					if ($_REQUEST['priority']  == "all") {
					$condition .= " ";
					$condition_group .= "";
					}else
					{
					$condition .= "  cases.priority = '" . $_REQUEST['priority'] . "'  AND ";
					$condition_group .= ",cases.priority";
					}
					
                    
					$_Status =  $_REQUEST['status'];
				    $_Membertier = $_REQUEST['member_tier_c'];
				
                    /*checking query starting*/
                    $start_date = date("Y-m-d",strtotime($_REQUEST['from_date']));
                    $end_date = date("Y-m-d",strtotime($_REQUEST['to_date']));



                    $start_date = $_REQUEST['from_date']; //fromdate for post
                    $this->view_object_map['getFromDate'] = $start_date;
                    $end_date = $_REQUEST['to_date']; //todate for post
                    $this->view_object_map['getToDate'] = $end_date;
                    $_Periodpost = $_REQUEST['period']; //period for post
                    $this->view_object_map['getPeriod'] = $_Periodpost;
                    $_Oroginpost = $_REQUEST['origin']; //origin for post
                    $this->view_object_map['getOrigin'] = $_Oroginpost;
                    $_Categorypost = $_REQUEST['category_id']; //categoryid for post
                    $this->view_object_map['getCategory'] = $_Categorypost;
                    $_MemberTierpost = $_REQUEST['member_tier_c']; //categoryid for post
                    $this->view_object_map['getMemberTier'] = $_MemberTierpost;
                    
                    $_Statuspost = $_REQUEST['status']; //status for post
                    $this->view_object_map['getStatus'] = $_Statuspost;
                    $_Prioritypost = $_REQUEST['priority']; //priority for post
                    $this->view_object_map['getPriority'] = $_Prioritypost;
                    $this->view_object_map['sub_category_id'] = $_REQUEST['sub_category_id'];
					
					$_BranchStore = $_REQUEST['branch_store_name']; //branch_store_name for post
					$this->view_object_map['getBranchName'] = $_BranchStore;
				
                    if($_REQUEST['period'] == "daily"):
						
						$_DailyLoopCount = $this->datediff('d',date("y-m-d",strtotime($_REQUEST['from_date'])),date("y-m-d",strtotime($_REQUEST['to_date'])));				 

						for($i=0;$i<=$_DailyLoopCount;$i++)
						{
						$_DailyLoopC[] =  date ("Y-m-d", strtotime("+$i day", strtotime($start_date)));
						}
						
						if ($_REQUEST['from_date'] && $_REQUEST['to_date']) {
								$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";
						}
								
								
					    $query_query = "SELECT cases.id,cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where " . $condition . " cases.deleted=0  group by date(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";
						
						$result = $db->query($query_query);
						$total = $result->num_rows;
						if($total > 0):
						while ($row = $db->fetchByAssoc($result)) {
						$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                        $volumecsr[] = $row;
					    $volumeDate[] = date("Y-m-d",strtotime($row['date_entered']));
						}
						else:
						$row['emptyrecord'] = "N/A";
						endif;
		            endif;
			
			
				if(count($volumecsr)):
						 foreach($volumecsr as $volumecsrData)
						 {
							$_DateEnteredArray[] = $volumecsrData['date_entered'];
							$_DateEntered1Array[$volumecsrData['date_entered']] = array($volumecsrData['date_entered'],$volumecsrData['category_c'],$volumecsrData['origin_c'],$volumecsrData['count(cases.id)']);
						 }
				endif;
				
				$i = 0;
                if(count($_DailyLoopC) > 0):
				
                     foreach($_DailyLoopC as $_DailyLoopCDataKey => $_DailyLoopCData)
					 { 
						if($_REQUEST['category_id'] == 'all'):
						$_Catname = 'All';
						else:
						$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
						endif;
								
					    $volumecsr_grid[] = "<tr>";
						if (in_array($_DailyLoopCData,$_DateEnteredArray))
						{
						//$key = array_search($_DailyLoopCData, $_DateEnteredArray);
						 //$volumecsr_grid[] = "<td>".$_DateEntered1Array[$_DailyLoopCData][0]."</td>";
						 //$volumecsr_grid[] = "<td>".""."</td>";
						 //$volumecsr_grid[] = "<td>".""."</td>";
						 //$volumecsr_grid[] = "<td>".""."</td>";
						 //$volumecsr_grid[] = "<td>".""."</td>";
						 //$volumecsr_grid[] = "<td onclick='checkclick(this.title)' id=Dailydata_".$_DateEntered1Array[$_DailyLoopCData][0]." title=daily_".$_DateEntered1Array[$_DailyLoopCData][0].">".$_DateEntered1Array[$_DailyLoopCData][3]."</td>";
						}
						else
						{
						 $_StatusVal = "";
						 if($_POST['status'] == 'all'):
						 $_StatusVal = 'NA';
						 else:
						 $_StatusVal = ucfirst($_POST['status']);
						 endif;
						 $volumecsr_grid[] =  "<td>".$_DailyLoopCData."</td>
						        <td>NA</td> <td>NA</td> <td>NA</td> <td>NA</td> <td>NA</td>";
								
								/*
								<td>".$this->getCaseOriginName($_POST['origin'])."</td>
								<td>".$_Catname."</td>
								<td>".ucfirst($this->getCasePriorityvalue($_POST['priority']))."</td>
								<td>".$_StatusVal."*/
						}
						 $volumecsr_grid[] = "</tr>";
						 
						 $volumecsr_grid[] ="<tr class=dailyresulthide id=dailyresult_".$_DailyLoopCData." style=display:none>
						 <td colspan='4' class='parent-TD'>
						 </td></tr>";
						 
						 if (in_array($_DailyLoopCData,$_DateEnteredArray))
						 {
						 /*script for showing daily wise record*/
								$_DailSSdate = $_DailyLoopCData; //start date
								$_DailESdate =  date ("Y-m-d", strtotime("+1 day", strtotime($_DailyLoopCData))); //end date
								$_DailyRowrecord =  $this->dailydataDailywiseCaseStatus($_REQUEST['sub_category_id'] ,$_REQUEST['origin'],$_REQUEST['branch_store_name'],$_REQUEST['category_id'],$_DailSSdate, $_DailESdate,$_Status,$_Membertier, $_REQUEST['priority']);
								/*script for showing daily wise record*/
								
								foreach($_DailyRowrecord  as $_DailyRowrecord1):
								$volumecsr_grid[] = "<tr style=padding:20px;>";
								$volumecsr_grid[] = "<td >".$_DailyRowrecord1['date_entered']."</td>";
								$volumecsr_grid[] = "<td >".$_DailyRowrecord1['case_number']."</td>";
								$volumecsr_grid[] = "<td >".$this->getCaseOriginName($_POST['origin'])."</td>";
								$volumecsr_grid[] = "<td >".$_DailyRowrecord1['category_c']."</td>";
								$volumecsr_grid[] = "<td >".$_DailyRowrecord1['priority']."</td>";
								$volumecsr_grid[] = "<td >".ucfirst($_DailyRowrecord1['status'])."</td>";
                                $volumecsr_grid[] = "</tr>";
								endforeach;
						 }
						 
						
						}
                 endif;				 
						

			   // echo '<pre>';
			//	print_r($volumecsr_grid);
			// echo "<br>";
				
                // $total1 = $result1->num_rows;
				/*checking query ending*/
           
            }
        }
        if (isset($total) > 0) {
            $this->view_object_map['total_cases'] = $total;
        } else {
            $this->view_object_map['total_cases'] = 0;
        }
        $this->view_object_map['volumecsrgrid'] = $volumecsr_grid;
    }
	
	public function dailydataDailywiseCaseStatus($_getSubcat,$_getOrigin,$_QueryReportBranchStore,$_getCat,$_StartDate , $_EndDate,$_Status,$Membertier,$Priority)
	{
	
	global $db, $app_list_strings;
			$casestatus_report = array();
			$condition="";
			if ($_getCat == "all") {
			 $condition .= "";
			}else
			{
			 $condition .= "  cases_cstm.category_c = '" . $_getCat . "' AND ";
			}


			if ($_getOrigin == "all")  {
			$condition .= " ";
			}else
			{
			$condition .= "  cases_cstm.origin_c = '" . $_getOrigin . "'  AND ";
			}
			
			if ($_QueryReportBranchStore == "all" || $_QueryReportBranchStore == "")  {
			$condition .= " ";
			}else
			{
			$condition .= "  cases.branch_store_name = '" . $_QueryReportBranchStore . "'  AND ";
			}
			
			
			
			   

			if ($_getSubcat  == "all") {
			$condition .= " ";
			}else
			{
			$condition .= "  cases_cstm.subcategory_c = '" . $_getSubcat . "'  AND ";
			}
            
			if ($Membertier == "all") {
			$condition .= "";
			}else
			{
			$condition .= "  cases_cstm.member_tier_c = '" . $Membertier . "' AND ";
			}

			if ($_Status  == "all") {
			$condition .= " ";
			}else
			{
			$condition .= "  cases.status = '" . $_Status . "'  AND ";
			}
			
			$conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .$_StartDate. "' AND '" .  $_StartDate . "' AND";
		   			
		    $query_query = "SELECT cases.id,cases.date_entered,cases_cstm.category_c,cases.status,cases_cstm.member_tier_c,"
								. "cases_cstm.member_tier_c,"
								. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
								. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
								. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
								. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
								. " cases.date_entered , cases.assigned_user_id FROM cases "
								. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
								. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
								. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
								. " where " . $condition .$conditiondAILY . " cases.deleted=0  ORDER BY cases.date_entered ASC";
						
				
			  
			$result = $db->query($query_query);
			$total = $result->num_rows;
			if($total > 0):
			while ($row = $db->fetchByAssoc($result)) {
			$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$casestatus_report[] = $row;
            }
			else:
			$row['emptyrecord'] = "N/A";
			// $volumecc[] = $row;
			endif;
			
		
			return $casestatus_report;
	}
	public function getCasePriorityvalue($_priority)
	{
		 $_Reurnval = "";
		 switch($_priority)
		{
		 case "P1":
		 $_Reurnval =  "High";
		 break;
		 
		 case "P2":
		  $_Reurnval = "Medium"; 
		 break;
		 
		 case "P3":
		  $_Reurnval = "Low";
		 break;
		 
		 case "all":
		  $_Reurnval = "All";
		 break;
		}
		return $_Reurnval;
	}
	
    public function action_getdailydatacsr(){
        global $db, $app_list_strings;
        $condition = "";
        if($_POST['getperiod'] == 'daily'):
                //$_POST['daily'];
                if ($_POST['getcategory'] && empty($_POST['origin'])) {
                $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
                }
                if ($_POST['origin'] && empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
                }

                if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
                }
				
				if ($_POST['branch_store_name'] == "all"  || $_POST['branch_store_name'] == "" )  {
				$condition .= " ";
				}else
				{
				$condition .= "  cases.branch_store_name = '" . $_POST['branch_store_name'] . "'  AND ";
				}
			
                if ($_POST['getmembertier']) {
                    $condition .= " cases_cstm.member_tier_c = '" . $_POST['getmembertier'] . "' AND ";
                }
                if ($_POST['getstatus']) { 
                    $condition .= "  cases.status = '" . $_POST['getstatus'] . "'  AND ";
                   
                }
                if ($_POST['getpriority']) { 
                    $condition .= "  cases.priority = '" . $_POST['getpriority'] . "'  AND ";
                  
                }
		
		$conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .$_POST['daily'] . "' AND '" . $_POST['daily'] . "' AND";
		$queryDaily_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id FROM cases "
                        . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$condition . $conditiondAILY . " cases.deleted=0 ORDER BY cases.date_entered DESC";

		
                $result = $db->query($queryDaily_case);
                $total = $result->num_rows;
                if($total > 0):
                    while ($row = $db->fetchByAssoc($result)) {
                            $row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
                            $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                            $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                            $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                            $volumecsr[] = $row;
                    }
                else:
                    $row['emptyrecord'] = "N/A";
                // $volumecsa[] = $row;
                endif;
                echo "<td colspan='6' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
                <tr><td></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong><td><strong>Case Priority</strong></td><td><strong>Case Status</strong></td></tr>";
                //<td><strong>Priority</strong></td>
                foreach($volumecsr as $volumecsr1)
                {
                    echo "<tr>";
                    echo "<td>".$volumecsr1['date_entered']."</td>";
                    echo "<td>".$volumecsr1['origin_c']."</td>";
                    echo "<td>".$volumecsr1['category_c']."</td>";
                    echo "<td>".$volumecsr1['priority']."</td>";
                    echo "<td>".$volumecsr1['status']."</td>";
                    echo "</tr>";	
                }
		echo "</table></td>";
			
	elseif($_POST['getperiod']== 'monthly'):
	   
	        $_Dailypost = explode("-",$_POST['daily']);	
                    $month =   $_Dailypost[0];
                    $year = $_Dailypost[1];
		    $_Days = cal_days_in_month(CAL_GREGORIAN, $month, $year)-1;
		    $_fromdate = $year."-".$month."-".'01';
		    $_EndDate = date("Y-m-d",strtotime("+ ".$_Days." days",strtotime($_fromdate)));
		if ($_POST['getcategory'] && empty($_POST['origin'])) {
                    $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
                }
		if ($_POST['origin'] && empty($_POST['getcategory'])) {
                    $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
		}
                if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
                    $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
                }
                if ($_POST['getmembertier']) {
                    $condition .= " cases_cstm.member_tier_c = '" . $_POST['getmembertier'] . "' AND ";
                }
               if ($_POST['getstatus']) { 
                    $condition .= "  cases.status = '" . $_POST['getstatus'] . "'  AND ";
                   
                }
                if ($_POST['getpriority']) { 
                    $condition .= "  cases.priority = '" . $_POST['getpriority'] . "'  AND ";
                  
                }
                $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_fromdate)). "' AND '" . $_EndDate . "' AND date(cases.date_entered) <= '".date("y-m-d",strtotime($_POST['enddate']))."' AND date(cases.date_entered) >= '".date("y-m-d",strtotime($_POST['fromdate']))."' AND";
		$queryDaily_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id FROM cases "
                        . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$condition . $conditiondAILY . " cases.deleted=0 ORDER BY cases.date_entered ASC";
                $result = $db->query($queryDaily_case);
                $total = $result->num_rows;
                if($total > 0):
                while ($row = $db->fetchByAssoc($result)) {
                    $row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                    $volumecsr[] = $row;
            }
            else:
                $row['emptyrecord'] = "N/A";
                // $volumecsa[] = $row;
            endif;
            echo "<td colspan='6' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
            <tr><td></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong><td><strong>Case Priority</strong></td><td><strong>Case Status</strong></td></tr>";
            //<td><strong>Priority</strong></td>
            foreach($volumecsr as $volumecsr1)
            {
                echo "<tr>";
                echo "<td>".$volumecsr1['date_entered']."</td>";
                echo "<td>".$volumecsr1['origin_c']."</td>";
                echo "<td>".$volumecsr1['category_c']."</td>";
                 echo "<td>".$volumecsr1['priority']."</td>";
                    echo "<td>".$volumecsr1['status']."</td>";
                echo "</tr>";	
            }
            echo "</table></td>";
	elseif($_POST['getperiod']== 'annual'):
            if ($_POST['getcategory'] && empty($_POST['origin'])) {
                $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
            }
            if ($_POST['origin'] && empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
            }

            if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
            }
            if ($_POST['getmembertier']) {
                    $condition .= " cases_cstm.member_tier_c = '" . $_POST['getmembertier'] . "' AND ";
                }
            if ($_POST['getstatus']) { 
                    $condition .= "  cases.status = '" . $_POST['getstatus'] . "'  AND ";
                   
            }
            if ($_POST['getpriority']) { 
                $condition .= "  cases.priority = '" . $_POST['getpriority'] . "'  AND ";

            }
            $conditiondAILY = " year(cases.date_entered) = '" . $_POST['daily'] . "' AND date(cases.date_entered) <= '".date("y-m-d",strtotime($_POST['enddate']))."' AND date(cases.date_entered) >= '".date("y-m-d",strtotime($_POST['fromdate']))."' AND";
            $queryQuarterly_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id FROM cases "
                        . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$conditiondAILY . $condition. " cases.deleted=0 ORDER BY cases.date_entered ASC";
            $result = $db->query($queryQuarterly_case);
            $total = $result->num_rows;
            if($total > 0):
            while ($row = $db->fetchByAssoc($result)) {
                $row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
                $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                $volumecsr[] = $row;
            }
            else:
                $row['emptyrecord'] = "N/A";
            // $volumecsa[] = $row;
            endif;
            echo "<td colspan='6' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
            <tr><td></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong><td><strong>Case Priority</strong></td><td><strong>Case Status</strong></td></tr>";
           // <td><strong>Priority</strong></td>
            foreach($volumecsr as $volumecsr1)
            {
                echo "<tr>";
                echo "<td>".$volumecsr1['date_entered']."</td>";
                echo "<td>".$volumecsr1['origin_c']."</td>";
                echo "<td>".$volumecsr1['category_c']."</td>";
                echo "<td>".$volumecsr1['priority']."</td>";
                echo "<td>".$volumecsr1['status']."</td>";

                echo "</tr>";	
            }
            echo "</table></td>";
        elseif($_POST['getperiod']== 'weekly'): 
            if ($_POST['getcategory'] && empty($_POST['origin'])) {
                $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
            }
            if ($_POST['origin'] && empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
            }

            if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
            }
            if ($_POST['getmembertier']) {
                    $condition .= " cases_cstm.member_tier_c = '" . $_POST['getmembertier'] . "' AND ";
                }
            if ($_POST['getstatus']) { 
                    $condition .= "  cases.status = '" . $_POST['getstatus'] . "'  AND ";
                   
            }
            if ($_POST['getpriority']) { 
                $condition .= "  cases.priority = '" . $_POST['getpriority'] . "'  AND ";

            }
            $_EndDate = date ("Y-m-d", strtotime("+ 1 week", strtotime($_POST['daily'])));
            
            $_Weekdate =   date("Y-m-d", strtotime("-1 day", strtotime($_EndDate)));
            $conditionW = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_POST['daily'])) . "' AND '" .  $_Weekdate . "' AND ";
            $query_query_W = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id FROM cases "
                        . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where ". $condition . $conditionW . " cases.deleted=0 ORDER BY cases.date_entered ASC";
            $result = $db->query($query_query_W);
            $total = $result->num_rows;
            if($total > 0):
            while ($row = $db->fetchByAssoc($result)) {
                $row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
                $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                $volumecsr[] = $row;
            }
            else:
                $row['emptyrecord'] = "N/A";
                // $volumecsa[] = $row;
            endif;
            echo "<td colspan='6' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
            <tr><td></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong><td><strong>Case Priority</strong></td><td><strong>Case Status</strong></td></tr>";
            //<td><strong>Priority</strong></td>
            foreach($volumecsr as $volumecsr1)
            {
                echo "<tr>";
                echo "<td>".$volumecsr1['date_entered']."</td>";
                echo "<td>".$volumecsr1['origin_c']."</td>";
                echo "<td>".$volumecsr1['category_c']."</td>";
                 echo "<td>".$volumecsr1['priority']."</td>";
                    echo "<td>".$volumecsr1['status']."</td>";
                echo "</tr>";	
            }
            echo "</table></td>";
        elseif($_POST['getperiod']== 'quarterly'):
            if ($_POST['getcategory'] && empty($_POST['origin'])) {
                $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
            }
            if ($_POST['origin'] && empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
            }

            if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
                $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
            }
            if ($_POST['getmembertier']) {
                    $condition .= " cases_cstm.member_tier_c = '" . $_POST['getmembertier'] . "' AND ";
                }
            if ($_POST['getstatus']) { 
                $condition .= "  cases.status = '" . $_POST['getstatus'] . "'  AND ";

            }
            if ($_POST['getpriority']) { 
                $condition .= "  cases.priority = '" . $_POST['getpriority'] . "'  AND ";

            }
             $_CheckQuarters = $this->getQuarters(date("m-d-Y",strtotime($_POST['fromdate'])) ,date("m-d-Y",strtotime($_POST['enddate']))); 
            $_EndDate = date ("Y-m-d", strtotime("+ 3 month", strtotime($_POST['daily'])));
             if($_CheckQuarters == 'no-quarters'):
	   	 $conditionY = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_POST['fromdate'])) . "' AND '" .  date("y-m-d",strtotime($_POST['enddate'])) . "' AND ";
            else:
                      $conditionY = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_POST['daily'])) . "' AND '" .  $_EndDate . "' AND ";
            endif; 
            //$conditionY = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_POST['daily'])) . "' AND '" .  $_EndDate . "' AND ";
            $query_query_Y = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id FROM cases "
                        . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                            . " where ". $condition . $conditionY . " cases.deleted=0 ORDER BY cases.date_entered ASC";
            $result = $db->query($query_query_Y);
            $total = $result->num_rows;
            if($total > 0):
            while ($row = $db->fetchByAssoc($result)) {
                $row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
                $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                $volumecsr[] = $row;
            }
           else:
               $row['emptyrecord'] = "N/A";
           endif;
           echo "<td colspan='6' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
           <tr><td></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong><td><strong>Case Priority</strong></td><td><strong>Case Status</strong></td></tr>";
           //<td><strong>Priority</strong></td>
           foreach($volumecsr as $volumecsr1)
           {
               echo "<tr>";
               echo "<td>".$volumecsr1['date_entered']."</td>";
               echo "<td>".$volumecsr1['origin_c']."</td>";
               echo "<td>".$volumecsr1['category_c']."</td>";
               echo "<td>".$volumecsr1['priority']."</td>";
               echo "<td>".$volumecsr1['status']."</td>";
               echo "</tr>";	
           }
           echo "</table></td>";
       else:
           // echo $_POST['daily'];
            if ($_POST['getcategory'] && empty($_POST['origin'])) {
            $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
            }
            if ($_POST['origin'] && empty($_POST['getcategory'])) {
            $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
            }

            if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
            $condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
            }

            if ($_POST['getmembertier']) {
                    $condition .= " cases_cstm.member_tier_c = '" . $_POST['getmembertier'] . "' AND ";
                }
            if ($_POST['getstatus']) { 
                $condition .= "  cases.status = '" . $_POST['getstatus'] . "'  AND ";

            }
            if ($_POST['getpriority']) { 
                $condition .= "  cases.priority = '" . $_POST['getpriority'] . "'  AND ";

            }
            $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .$_POST['daily'] . "' AND '" . $_POST['daily'] . "' AND";
            $queryDaily_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                 . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                 . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                 . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                 . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                 . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                 . " cases.date_entered , cases.assigned_user_id FROM cases "
                 . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                 . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                 . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                 . " where " .$condition . $conditiondAILY . " cases.deleted=0 ORDER BY cases.date_entered DESC";


            $result = $db->query($queryDaily_case);
            $total = $result->num_rows;
            if($total > 0):
            while ($row = $db->fetchByAssoc($result)) {
                    $row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
                    $volumecsr[] = $row;
            }
            else:
                $row['emptyrecord'] = "N/A";
                // $volumecsa[] = $row;
            endif;
            echo "<td colspan='6' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
            <tr><td></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong><td><strong>Case Priority</strong></td><td><strong>Case Status</strong></td></tr>";
            //<td><strong>Priority</strong></td>
            foreach($volumecsr as $volumecsr1)
            {
                echo "<tr>";
                echo "<td>".$volumecsr1['date_entered']."</td>";
                echo "<td>".$volumecsr1['origin_c']."</td>";
                echo "<td>".$volumecsr1['category_c']."</td>";
                echo "<td>".$volumecsr1['priority']."</td>";
                echo "<td>".$volumecsr1['status']."</td>";
                echo "</tr>";	
            }
            echo "</table></td>";	   
        endif;
        exit;
    }
    public function returnBetweenDates( $startDate, $endDate ){
			$startStamp = strtotime(  $startDate );
			$endStamp   = strtotime(  $endDate );

			if( $endStamp > $startStamp ){
				while( $endStamp >= $startStamp ){

					$dateArr[] = date( 'Y-m-d', $startStamp );

					$startStamp = strtotime( ' +1 day ', $startStamp );

				}
				return $dateArr;    
			}else{
				return $startDate;
			}

    }
    //EOC of volume of cases by category
     public function action_getdailydatacc() {
	  global $db, $app_list_strings;
	  $condition = "";
	  if ($_POST['branch_store_name'] == "all" || $_POST['branch_store_name'] == "")  {
			$condition .= " ";
			$condition_group .= "";
			}else
			{
			$condition .= "  cases.branch_store_name = '" . $_POST['branch_store_name'] . "'  AND ";
			}
			
		
	   if($_POST['getperiod'] == 'daily'):
	       $_POST['daily'];
			/*if ($_POST['getcategory'] && empty($_POST['origin'])) {
			$condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
			}
			if ($_POST['origin'] && empty($_POST['getcategory'])) {
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
			}

			if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
			}*/
            
			if ($_POST['getcategory'] == "all") {
			 $condition .= "";
			 $condition_group .= "";
			}else
			{
			 $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
			}


			if ($_POST['origin'] == "all")  {
			$condition .= " ";
			$condition_group .= "";
			}else
			{
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
			}
            
			
			

			if ($_POST['subcat']  == "all") {
			$condition .= " ";
			$condition_group .= "";
			}else
			{
			$condition .= "  cases_cstm.subcategory_c = '" . $_POST['subcat'] . "'  AND ";
			}

			
			
		   $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .$_POST['daily'] . "' AND '" . $_POST['daily'] . "' AND";
		   $queryDaily_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id FROM cases "
                        . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$condition . $conditiondAILY . " cases.deleted=0 ORDER BY cases.date_entered DESC";

		
			$result = $db->query($queryDaily_case);
			$total = $result->num_rows;
			if($total > 0):
			while ($row = $db->fetchByAssoc($result)) {
			$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$volumecc[] = $row;
            }
			else:
			$row['emptyrecord'] = "N/A";
			// $volumecc[] = $row;
			endif;
			echo "<td colspan='4' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
			<tr><td><strong>Case ID</strong></td><td><strong>Date</strong></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong></tr>";
			foreach($volumecc as $volumecc1)
			{
			echo "<tr>";
			echo "<td>".$volumecc1['case_number']."</td>";
			echo "<td>".$volumecc1['date_entered']."</td>";
			echo "<td>".$volumecc1['origin_c']."</td>";
			echo "<td>".$volumecc1['category_c']."</td>";
			echo "</tr>";	
			}
			echo "</table></td>";
			
	   elseif($_POST['getperiod']== 'monthly'):
	        $_POST['daily'] =  date("m-Y",strtotime($_POST['daily']));
	        $_Dailypost = explode("-",$_POST['daily']);	
			$month =   $_Dailypost[0];
			$year = $_Dailypost[1];
		    $_Days = cal_days_in_month(CAL_GREGORIAN, $month, $year)-1;
		    $_fromdate = $year."-".$month."-".'01';
			$_fromdate= date('Y-m-d',strtotime($_fromdate));
		    $_EndDate = date("Y-m-d",strtotime("+ ".$_Days." days",strtotime($_fromdate)));
		    /*if ($_POST['getcategory'] && empty($_POST['origin'])) {
			$condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
			}
			if ($_POST['origin'] && empty($_POST['getcategory'])) {
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
			}

			if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
			}
			*/
			if ($_POST['getcategory'] == "all") {
			 $condition .= "";
			 $condition_group .= "";
			}else
			{
			 $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
			}

			if ($_POST['origin'] == "all")  {
			$condition .= " ";
			$condition_group .= "";
			}else
			{
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
			}

			if ($_POST['subcat']  == "all") {
			$condition .= " ";
			$condition_group .= "";
			}else
			{
			$condition .= "  cases_cstm.subcategory_c = '" . $_POST['subcat'] . "'  AND ";
			}
		   $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_fromdate)). "' AND ' ".date("y-m-d",strtotime($_EndDate))."' AND";
           $queryDaily_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id FROM cases "
                        . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$condition . $conditiondAILY . " cases.deleted=0 ORDER BY cases.date_entered ASC";
 		    $result = $db->query($queryDaily_case);
			$total = $result->num_rows;
			if($total > 0):
			while ($row = $db->fetchByAssoc($result)) {
			$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$volumecc[] = $row;
            }
			else:
			$row['emptyrecord'] = "N/A";
			// $volumecc[] = $row;
			endif;
			echo "<td colspan='4' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
			<tr><td><strong>Case ID</strong></td><td><strong>Date</strong></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong></tr>";
			foreach($volumecc as $volumecc1)
			{
			echo "<tr>";
			echo "<td>".$volumecc1['case_number']."</td>";
			echo "<td>".$volumecc1['date_entered']."</td>";
			echo "<td>".$volumecc1['origin_c']."</td>";
			echo "<td>".$volumecc1['category_c']."</td>";
			echo "</tr>";	
			}
			echo "</table></td>";
	  elseif($_POST['getperiod']== 'annual'):
       /* if ($_POST['getcategory'] && empty($_POST['origin'])) {
		$condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
		}
		if ($_POST['origin'] && empty($_POST['getcategory'])) {
		$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
		}

		if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
		$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
		}*/
		if ($_POST['getcategory'] == "all") {
			 $condition .= "";
			 $condition_group .= "";
			}else
			{
			 $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
			}

			if ($_POST['origin'] == "all")  {
			$condition .= " ";
			$condition_group .= "";
			}else
			{
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
			}

			if ($_POST['subcat']  == "all") {
			$condition .= " ";
			$condition_group .= "";
			}else
			{
			$condition .= "  cases_cstm.subcategory_c = '" . $_POST['subcat'] . "'  AND ";
			}
		 
		 if(date("m") <= 06){
						$_CurrentYear = date("Y"); // current year
						$_NextYears =  date("Y")-1; //previous year 
						
						$_fromdate =  date($_NextYears.'-07-01'); //common from date
						$_EndDate =  date($_CurrentYear.'-06-30'); 

						}
						else{
						$_CurrentYear =  date("Y"); // current year
						$_NextYears  =  date("Y") + 1;  // post year
						$_fromdate =  date($_CurrentYear.'-07-01'); //common from date
						$_EndDate =  date($_NextYears.'-06-30'); 
						
		  }
						
						
	    $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_fromdate)). "' AND ' ".date("y-m-d",strtotime($_EndDate))."' AND";
        $queryQuarterly_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id FROM cases "
                        . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$conditiondAILY . $condition. " cases.deleted=0 ORDER BY cases.date_entered ASC";
            $result = $db->query($queryQuarterly_case);
			$total = $result->num_rows;
			if($total > 0):
			while ($row = $db->fetchByAssoc($result)) {
			$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$volumecc[] = $row;
            }
			else:
			$row['emptyrecord'] = "N/A";
			// $volumecc[] = $row;
			endif;
			echo "<td colspan='4' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
			<tr><td><strong>Case ID</strong></td><td><strong>Date</strong></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong></tr>";
			foreach($volumecc as $volumecc1)
			{
			echo "<tr>";
			echo "<td>".$volumecc1['case_number']."</td>";
			echo "<td>".$volumecc1['date_entered']."</td>";
			echo "<td>".$volumecc1['origin_c']."</td>";
			echo "<td>".$volumecc1['category_c']."</td>";
			echo "</tr>";	
			}
			echo "</table></td>";
       elseif($_POST['getperiod']== 'weekly'): 
	       
       elseif($_POST['getperiod']== 'quarterly'):
	 
			if ($_POST['getcategory'] == "all") {
			 $condition .= "";
			 $condition_group .= "";
			}else
			{
			 $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
			}

			if ($_POST['origin'] == "all")  {
			$condition .= " ";
			$condition_group .= "";
			}else
			{
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
			}

			if ($_POST['subcat']  == "all") {
			$condition .= " ";
			$condition_group .= "";
			}else
			{
			$condition .= "  cases_cstm.subcategory_c = '" . $_POST['subcat'] . "'  AND ";
			}
			
			$_StartDate = $_EndDate = "";
			if(isset($_POST['daily'])):
		    $_DailyExplode =   explode("_",$_POST['daily']);
			$_StartDate =  $_DailyExplode[0];
			$_EndDate = $_DailyExplode[1];
		    endif;
		
		/*checking quarters*/	
	   $conditionY = " DATE(cases.date_entered) BETWEEN '" .$_StartDate . "' AND '" .  $_EndDate . "' AND ";
	   $query_query_Y = "SELECT cases.id,cases.date_entered,cases_cstm.category_c,cases_cstm.member_tier_c,"
							. "cases_cstm.member_tier_c,"
							. "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number,cases.priority, "
							. "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
							. "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
							. "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
							. " cases.date_entered , cases.assigned_user_id FROM cases "
							. "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
							. "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
							. "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
							. " where ". $condition . $conditionY . " cases.deleted=0 ORDER BY cases.date_entered ASC";
		 
		 $result = $db->query($query_query_Y);
			$total = $result->num_rows;
			if($total > 0):
			while ($row = $db->fetchByAssoc($result)) {
			$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$volumecc[] = $row;
            }
			else:
			$row['emptyrecord'] = "N/A";
			// $volumecc[] = $row;
			endif;
			echo "<td colspan='4' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
			<tr><td><strong>Case ID</strong></td><td><strong>Date</strong></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></strong></tr>";
			foreach($volumecc as $volumecc1)
			{
			echo "<tr>";
			echo "<td>".$volumecc1['case_number']."</td>";
			echo "<td>".$volumecc1['date_entered']."</td>";
			echo "<td>".$volumecc1['origin_c']."</td>";
			echo "<td>".$volumecc1['category_c']."</td>";
			echo "</tr>";	
			}
			echo "</table></td>";
       else:
            echo $_POST['daily'];
			if ($_POST['getcategory'] && empty($_POST['origin'])) {
			$condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
			}
			if ($_POST['origin'] && empty($_POST['getcategory'])) {
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
			}

			if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
			$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
			}

			
		   $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .$_POST['daily'] . "' AND '" . $_POST['daily'] . "' AND";
		   $queryDaily_case = "SELECT cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . "cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . "cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . "naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . "LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . "jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id FROM cases "
                        . "LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . "LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . "LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$condition . $conditiondAILY . " cases.deleted=0 ORDER BY cases.date_entered DESC";

		
			$result = $db->query($queryDaily_case);
			$total = $result->num_rows;
			if($total > 0):
			while ($row = $db->fetchByAssoc($result)) {
			$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$volumecc[] = $row;
            }
			else:
			$row['emptyrecord'] = "N/A";
			// $volumecc[] = $row;
			endif;
			echo "<td colspan='4' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
			<tr><td><strong>Case ID</strong></td><td><strong>Date</strong></td><td><strong>Case Origin</strong></td><td><strong>Case Category</td></tr>";
			foreach($volumecc as $volumecc1)
			{
			echo "<tr>";
			echo "<td>".$volumecc1['case_number']."</td>";
			echo "<td>".$volumecc1['date_entered']."</td>";
			echo "<td>".$volumecc1['origin_c']."</td>";
			echo "<td>".$volumecc1['category_c']."</td>";
			echo "</tr>";	
			}
			echo "</table></td>";	   
	   endif;
	   exit;
    }

    
	public	function action_getdailydatacsmt() {
	global $db, $app_list_strings;
	$condition = "";
	if ($_POST['branch_store_name'] == "all" || $_POST['branch_store_name'] == "")  {
			$condition .= " ";
			$condition_group .= "";
			}else
			{
			$condition .= "  cases.branch_store_name = '" . $_POST['branch_store_name'] . "'  AND ";
			}
	
	if($_POST['getperiod'] == 'monthly'):
	        $_Dailypost = explode("-",$_POST['daily']);	
			$month =   $_Dailypost[0];
			$year = $_Dailypost[1];
		    $_Days = cal_days_in_month(CAL_GREGORIAN, date("m",strtotime($month )), $year)-1;
		    $_fromdate = $year."-".$month."-".'01';
			
			$_fromdate= date('Y-m-d',strtotime($_fromdate));
		    $_EndDate = date("Y-m-d",strtotime("+ ".$_Days." days",strtotime($_fromdate)));
						
			if ($_REQUEST['getcategory'] == "all") {
			$condition .= "";
			$condition_group .= "";
			}else
			{
			$condition .= "  cases_cstm.category_c = '" . $_REQUEST['getcategory'] . "' AND ";
			}

			if ($_REQUEST['membertier'] == "all") {
			$condition .= "";
			}else
			{
			$condition .= "  cases_cstm.member_tier_c = '" . $_REQUEST['membertier'] . "' AND ";
			}


			if ($_REQUEST['origin'] == "all")  {
			$condition .= " ";
			}else
			{
			$condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
			}
			if ($_REQUEST['subcat']  == "all") {
			$condition .= " ";
			}else
			{
			$condition .= "  cases_cstm.subcategory_c = '" . $_REQUEST['subcat'] . "'  AND ";
			}

			if ($_REQUEST['getstatus']  == "all") {
			$condition .= " ";
			}else
			{
			$condition .= "  cases.status = '" . $_REQUEST['getstatus'] . "'  AND ";
			}

		   $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .$_fromdate . "' AND '" . $_EndDate . "' AND";
		/*echo    $queryDaily_case = "SELECT cases.id,cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, 
				                      LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,
									  cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT 
									  JOIN users jt0 ON cases.created_by=jt0.id AND jt0.deleted=0 AND jt0.deleted=0
									  LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id"
                                      . " where " . $condition . $conditiondAILY . " cases.deleted=0  ORDER BY cases.date_entered DESC";
      */
	     	 
	       $queryDaily_case = "SELECT cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, 
				                      LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,
									  cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT 
									  JOIN users jt0 ON cases.assigned_user_id=jt0.id   LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id AND jt0.deleted=0 AND jt0.deleted=0"
                                      . " where " . $condition . $conditiondAILY . " cases.deleted=0 ORDER BY cases.date_entered DESC";

		   $result = $db->query($queryDaily_case);
			$total = $result->num_rows;
			if($total > 0):
			while ($row = $db->fetchByAssoc($result)) {
			$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$volumecc[] = $row;
            }
			else:
			$row['emptyrecord'] = "N/A";
			// $volumecc[] = $row;
			endif;
		   //echo "<pre>";
		   //print_r($volumecc );
		   
			echo "<td colspan='6' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
			<tr>
			<td><strong>Case ID</strong></td>
			<td><strong>Date</strong></td>
			<td><strong>Member Tier</strong></td>
            <td><strong>Case Origin</strong></td>
			<td><strong>Case Category</strong></td>
			<td><strong>Case Status</strong></td>
			<td><strong>Case Priority</strong></td>
			</tr>";
			foreach($volumecc as $volumecc1)
			{
			echo "<tr>";
			echo "<td>".$volumecc1['case_number']."</td>";
			echo "<td>".$volumecc1['date_entered']."</td>";
			echo "<td>".$volumecc1['member_tier_c']."</td>";
			echo "<td>".$volumecc1['origin_c']."</td>";
			echo "<td>".$volumecc1['category_c']."</td>";
			echo "<td>".$volumecc1['status']."</td>";
			echo "<td>".$volumecc1['priority']."</td>";
			echo "</tr>";	
			}
			echo "</table></td>";
	  elseif($_POST['getperiod'] == 'annual'):
	   

			if ($_REQUEST['getcategory'] == "all") {
			$condition .= "";
			$condition_group .= "";
			}else
			{
			$condition .= "  cases_cstm.category_c = '" . $_REQUEST['getcategory'] . "' AND ";
			}

			if ($_REQUEST['membertier'] == "all") {
			$condition .= "";
			}else
			{
			$condition .= "  cases_cstm.member_tier_c = '" . $_REQUEST['membertier'] . "' AND ";
			}


			if ($_REQUEST['origin'] == "all")  {
			$condition .= " ";
			}else
			{
			$condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
			}
			if ($_REQUEST['subcat']  == "all") {
			$condition .= " ";
			}else
			{
			$condition .= "  cases_cstm.subcategory_c = '" . $_REQUEST['subcat'] . "'  AND ";
			}

			if ($_REQUEST['getstatus']  == "all") {
			$condition .= " ";
			}else
			{
			$condition .= "  cases.status = '" . $_REQUEST['getstatus'] . "'  AND ";
			}
			
		
		$_fromdate = $_POST['daily'].'01'.'01';
		$_EndDate =  $_POST['daily'].'12'.'31';
	    $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_fromdate)). "' AND ' ".date("y-m-d",strtotime($_EndDate))."' AND";
        $queryDaily_case = "SELECT cases.id,cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, 
				                      LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,
									  cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT 
									  JOIN users jt0 ON cases.assigned_user_id=jt0.id  LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id  AND jt0.deleted=0 AND jt0.deleted=0"
                                      . " where " . $condition . $conditiondAILY . " cases.deleted=0  ORDER BY cases.date_entered DESC";
        $result = $db->query($queryDaily_case);
	    $total = $result->num_rows;
	    if($total > 0):
		 while ($row = $db->fetchByAssoc($result)) {
			$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$volumecc[] = $row;
         }
		else:
			$row['emptyrecord'] = "N/A";
		endif;
			echo "<td colspan='6' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
			<tr>
			<td><strong>Case ID</strong></td>
			<td><strong>Date</strong></td>
			<td><strong>Member Tier</strong></td>
            <td><strong>Case Origin</strong></td>
			<td><strong>Case Category</strong></td>
			<td><strong>Case Status</strong></td>
			<td><strong>Case Priority</strong></td>
			</tr>";
			foreach($volumecc as $volumecc1)
			{
			echo "<tr>";
			echo "<td>".$volumecc1['case_number']."</td>";
			echo "<td>".$volumecc1['date_entered']."</td>";
			echo "<td>".$volumecc1['member_tier_c']."</td>";
			echo "<td>".$volumecc1['origin_c']."</td>";
			echo "<td>".$volumecc1['category_c']."</td>";
			echo "<td>".$volumecc1['status']."</td>";
			echo "<td>".$volumecc1['priority']."</td>";
			echo "</tr>";	
			}
			echo "</table></td>";
    elseif($_POST['getperiod'] == 'quarterly'):
	  if ($_REQUEST['getcategory'] == "all") {
			$condition .= "";
			$condition_group .= "";
			}else
			{
			$condition .= "  cases_cstm.category_c = '" . $_REQUEST['getcategory'] . "' AND ";
			}

			if ($_REQUEST['membertier'] == "all") {
			$condition .= "";
			}else
			{
			$condition .= "  cases_cstm.member_tier_c = '" . $_REQUEST['membertier'] . "' AND ";
			}


			if ($_REQUEST['origin'] == "all")  {
			$condition .= " ";
			}else
			{
			$condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
			}
			if ($_REQUEST['subcat']  == "all") {
			$condition .= " ";
			}else
			{
			$condition .= "  cases_cstm.subcategory_c = '" . $_REQUEST['subcat'] . "'  AND ";
			}

			if ($_REQUEST['getstatus']  == "all") {
			$condition .= " ";
			}else
			{
			$condition .= "  cases.status = '" . $_REQUEST['getstatus'] . "'  AND ";
			}	
		
		/*checking quarters*/	
	   
	  $_StartDate = $_EndDate = "";
			if(isset($_POST['daily'])):
		    $_DailyExplode =   explode("_",$_POST['daily']);
			$_StartDate =  $_DailyExplode[0];
			$_EndDate = $_DailyExplode[1];
	  endif;
			
     
	   
	 $conditionY = " DATE(cases.date_entered) BETWEEN '" .$_StartDate . "' AND '" .  $_EndDate . "' AND ";

       $queryDaily_case = "SELECT cases.id,cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, 
				                      LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,
									  cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT 
									  JOIN users jt0 ON cases.assigned_user_id=jt0.id LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id  AND jt0.deleted=0 AND jt0.deleted=0"
                                      . " where " . $condition . $conditionY . " cases.deleted=0  ORDER BY cases.date_entered DESC";
        $result = $db->query($queryDaily_case);
	    $total = $result->num_rows;
	    if($total > 0):
		 while ($row = $db->fetchByAssoc($result)) {
			$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$volumecc[] = $row;
         }
		else:
			$row['emptyrecord'] = "N/A";
		endif;
			echo "<td colspan='6' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
			<tr>
			<td><strong>Case ID</strong></td>
			<td><strong>Date</strong></td>
			<td><strong>Member Tier</strong></td>
            <td><strong>Case Origin</strong></td>
			<td><strong>Case Category</strong></td>
			<td><strong>Case Status</strong></td>
			<td><strong>Case Priority</strong></td>
			</tr>";
			foreach($volumecc as $volumecc1)
			{
			echo "<tr>";
			echo "<td>".$volumecc1['case_number']."</td>";
			echo "<td>".$volumecc1['date_entered']."</td>";
			echo "<td>".$volumecc1['member_tier_c']."</td>";
			echo "<td>".$volumecc1['origin_c']."</td>";
			echo "<td>".$volumecc1['category_c']."</td>";
			echo "<td>".$volumecc1['status']."</td>";
			echo "<td>".$volumecc1['priority']."</td>";
			echo "</tr>";	
			}
			echo "</table></td>";
	else:
     if ($_POST['getcategory'] && empty($_POST['origin'])) {
		$condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
		}
		if ($_POST['origin'] && empty($_POST['getcategory'])) {
		$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
		}

		if (!empty($_POST['origin']) && !empty($_POST['getcategory'])) {
		$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND";
		}
		
		if (!empty($_POST['membertier'])) {
            $condition .= " cases_cstm.member_tier_c = '" . $_POST['membertier'] . "' AND ";
        }
		if (!empty($_POST['getstatus'])) {
            $condition .= "  cases.status = '" . $_POST['getstatus'] . "' AND ";
        }	
		
		/*checking quarters*/	
	   $_CheckQuarters = $this->getQuarters(date("m-d-Y",strtotime($_POST['fromdate'])) ,date("m-d-Y",strtotime($_POST['enddate'])));
			
	   $_EndDate = date ("Y-m-d", strtotime("+ 3 month", strtotime($_POST['daily'])));
       if($_CheckQuarters == 'no-quarters'):
	   	 $conditionY = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_POST['fromdate'])) . "' AND '" .  date("y-m-d",strtotime($_POST['enddate'])) . "' AND ";
       else:
	   	 $conditionY = " DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_POST['daily'])) . "' AND '" .  $_EndDate . "' AND ";
       endif;
	   
	   
       $queryDaily_case = "SELECT cases.id,cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, 
				                      LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,
									  cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT 
									  JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                                      . " where " . $condition . $conditionY . " cases.deleted=0  ORDER BY cases.date_entered DESC";
        $result = $db->query($queryDaily_case);
	    $total = $result->num_rows;
	    if($total > 0):
		 while ($row = $db->fetchByAssoc($result)) {
			$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$volumecc[] = $row;
         }
		else:
			$row['emptyrecord'] = "N/A";
		endif;
			echo "<td colspan='6' class='parent-TD'><table>
			<tr>
			<td><strong>Case ID</strong></td>
			<td><strong>Date</strong></td>
			<td><strong>Member Tier</strong></td>
            <td><strong>Case Origin</strong></td>
			<td><strong>Case Category</strong></td>
			<td><strong>Case Status</strong></td>
			<td><strong>Case Priority</strong></td>
			</tr>";
			foreach($volumecc as $volumecc1)
			{
			echo "<tr>";
			echo "<td>".$volumecc1['case_number']."</td>";
			echo "<td>".$volumecc1['date_entered']."</td>";
			echo "<td>".$volumecc1['member_tier_c']."</td>";
			echo "<td>".$volumecc1['origin_c']."</td>";
			echo "<td>".$volumecc1['category_c']."</td>";
			echo "<td>".$volumecc1['status']."</td>";
			echo "<td>".$volumecc1['priority']."</td>";
			echo "</tr>";	
			}
			echo "</table></td>";	
	endif;
	exit();
	
	}
	
 public function getExportContentServiceEsc($_QueryFD,$_QueryTD,$_QueryPer,$_QueryORI,$_QueryCat,$_QueryMemTier,$_QueryStatus)
	{
	  global $db, $app_list_strings,$sugar_config;
	  $volumecc = $queryCase = $_Yearquery= $_ColumnsDate=$volumeDate=$_DailyLoopC=$_DateEnteredArray
	   =$volumecc_grid=$_NoOfQuarters=$_GetOneQuarters=array();
		$_WeeklyGlobal = $_QuaterlyGlobal = $_MonthGlobal = 0;
        $condition = $condition_group='';
		if (!empty($_QueryMemTier)) {
                    $condition .= " cases_cstm.member_tier_c = '" . $_QueryMemTier . "' AND ";
        }
        if (!empty($_QueryCat)) {
                    $condition .= "  cases_cstm.category_c = '" . $_QueryCat . "' AND ";
        }
        if (!empty($_QueryORI)) {
                    $condition .= "  cases_cstm.origin_c = '" . $_QueryORI. "'  AND ";
        }
        if (!empty($_QueryStatus)) {
                    $condition .= "cases.status = '" . $_QueryStatus . "' AND ";
        }
                //if (!empty($_REQUEST['from_date']) && !empty($_REQUEST['to_date'])) {
                  //  $condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($_REQUEST['from_date'])) . "' AND '" . date("Y-m-d", strtotime($_REQUEST['to_date'])) . "' AND ";
                //}
                
				/*checking query starting*/
		$start_date = date("Y-m-d",strtotime($_QueryFD));
	    $end_date = date("Y-m-d",strtotime($_QueryTD));
										
        $default_query_case = "SELECT cases.id,cases.name,cases_cstm.category_c,cases_cstm.member_tier_c,cases_cstm.origin_c,cases.case_number,cases.priority,cases.status, LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name, 'Users' created_by_name_mod,cases.date_entered,cases.assigned_user_id,cases_cstm.loyalty_id_c,cases_cstm.mobile_number_c FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition . " cases.deleted=0 and cases.caseescalate_c > 0 AND cases.status != 'Resolved' ORDER BY cases.date_entered DESC";
		$result = $db->query($default_query_case);
		$total = $result->num_rows;
	
	
		if($total > 0):
		while ($row = $db->fetchByAssoc($result)) {
		$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
		$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
		$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
		$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
		$volumecmt[] = $row;
		}
		else:
		$row['emptyrecord'] = "N/A";
		// $volumecc[] = $row;
		endif;

		if(count($volumecmt)> 0):
			foreach($volumecmt as $volumecmt1):
					
						$volumecc_grid1["case_id"] = $volumecmt1['case_number'];
						$volumecc_grid1["date_entered"] = $volumecmt1['date_entered'];
						$volumecc_grid1["member_tier"] = $volumecmt1['member_tier_c'];
						$volumecc_grid1["origin_c"] = $volumecmt1['origin_c'];
						$volumecc_grid1["category_c"] = $volumecmt1['category_c'];
						$volumecc_grid1["status"] = $volumecmt1['status'];
						$volumecc_grid1["priority"] = $volumecmt1['priority'];
						$volumecc_grid[] = $volumecc_grid1;
					
			endforeach;
			endif;
		return $volumecc_grid;
	  
	}
	
	
    ////////////////get branch names from nakumatt_store Magento////////////////////
    
	
	
 public function checkReportPeriodQuartervolsupplier($condition,$condition_group= null,$dateform,$dateto,$ReportName,$_Selectedsuppsku)
   {
   global $db, $app_list_strings;
    $_Yrow = array();
	if($_Selectedsuppsku == 'sku'):
	 $conditionY = " DATE(cases.date_entered) BETWEEN '" .$dateform . "' AND '" . $dateto . "' AND ";
           $default_query_case = " SELECT count(cases.prod_sku) as myt, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition . " cases.deleted=0 ) as mytotalfor,   cases.prod_sku,cases.prod_supplier_name,cases.prod_sku, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $conditionY.$condition . " cases.deleted=0  GROUP BY QUARTER(cases.date_entered),year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered DESC";
	else:
	 $conditionY = " DATE(cases.date_entered) BETWEEN '" .$dateform . "' AND '" . $dateto . "' AND ";
           $default_query_case = " SELECT count(cases.prod_supplier_id) as myt, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition . " cases.deleted=0 ) as mytotalfor,   cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $conditionY.$condition . " cases.deleted=0  GROUP BY QUARTER(cases.date_entered),year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered DESC";
	endif;
		//echo "<br><br><br><br><br>";			
	        $resultY = $db->query($default_query_case);
		
			$total = $resultY->num_rows;
			if($total > 0):
			while ($row = $db->fetchByAssoc($resultY)) {
			$row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';

			$total_cases = $row['mytotalfor'];
			$num_amount = $row['myt'];
			$count1 = $num_amount / $total_cases;
			$count2 = $count1 * 100;
			$count = number_format($count2, 0);
			$row['mypercentage'] = $count;
			$_row = $row['myt'];
			$volumesupplier[] = $row;
			}
			else:
			$row['emptyrecord'] = "N/A";
			// $volumesupplier[] = $row;
			endif;
          
			return $volumesupplier;		
						
   }
   
    public function checkReportPeriodsupplierweek($condition,$condition_group,$dateform,$dateto,$skuorsupplierOption)
	{
		global $db, $app_list_strings;
		$_Wrow = array();
		$conditionW = " DATE(cases.date_entered) BETWEEN '" .$dateform . "' AND '" . $dateto . "' AND ";
		
		if($skuorsupplierOption == 'sku'):
	 	$query_query_w  = " SELECT count(cases.id) as myt, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " .$condition. $conditionW . " cases.deleted=0 ) as mytotalfor,   cases.prod_sku,cases.prod_supplier_name,cases.prod_sku, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$condition.$conditionW. " cases.deleted=0  GROUP BY week(cases.date_entered),cases.prod_supplier_id ORDER BY cases.date_entered DESC";
		else:
		$query_query_w  = " SELECT count(cases.id) as myt, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " .$condition. $conditionW . " cases.deleted=0 ) as mytotalfor,   cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$condition.$conditionW. " cases.deleted=0  GROUP BY week(cases.date_entered),cases.prod_supplier_id ORDER BY cases.date_entered DESC";
		endif;
				
		$result = $db->query($query_query_w);
	    
		$total = $result->num_rows;
		if($total > 0):
		 while ($row = $db->fetchByAssoc($result)) {
			$row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			
			$total_cases = $row['mytotalfor'];
			$num_amount = $row['myt'];
			$count1 = $num_amount / $total_cases;
			$count2 = $count1 * 100;
			$count = number_format($count2, 0);
			$row['mypercentage'] = $count;
			//$_row = $row['myt'];
            $volumesupplier[] = $row;
		}
		else:
		 $row['emptyrecord'] = "N/A";
		endif;
		
	   
        return $volumesupplier;		
			}
    
	
	public function action_getdailydatavolumesupplier()
	{
	
    //echo "<pre>";
    //print_r($_POST);
	global $db, $app_list_strings;
	$condition = $conditionY=$conditiondAILY="";
	/* code for single volume supplier record */
	$volumecc = array();
	if($_POST['getperiod'] == "annual"):
	$_DailySupplier = explode("_",$_POST['daily']);
	$_DailySupplier[2] = $_DailySupplier[1] ;
	elseif($_POST['getperiod'] == "quarterly"):
	$_DailySupplier = explode("_",$_POST['daily']);
	$_DailySupplier[2] = $_DailySupplier[2] ;
	else:
	$_DailySupplier = explode("-",$_POST['daily']);
	endif;
	
    	if ($_POST['getcategory'] == "all") {
		$condition .= "";
		}else
		{
		 $condition .= "  cases_cstm.category_c = '" . $_POST['getcategory'] . "' AND ";
		}

		if ($_POST['getstatus'] == "all") {
		$condition .= "";
		}else
		{
		 $condition .= "  cases.status= '" . $_POST['status'] . "' AND ";
		}

		if ($_POST['origin'] == "all")  {
		$condition .= " ";
		}else
		{
		$condition .= "  cases_cstm.origin_c = '" . $_POST['origin'] . "'  AND ";
		}
		
		if ($_POST['branch_store_name'] == "all"  || $_POST['branch_store_name'] == "" )  {
		$condition .= " ";
		}else
		{
		$condition .= "  cases.branch_store_name = '" . $_POST['branch_store_name'] . "'  AND ";
		}
		
				
		if ($_POST['getSubcat'] == "all") {
		$condition .= " ";
		}else
		{
		$condition .= "  cases_cstm.subcategory_c = '" . $_POST['getSubcat'] . "'  AND ";
		}
		

		if($_POST['getSupplierandsku'] == 'supplier' ):
		$mul_supid='';
		if ($_POST['supplierid']) {
		$mul_supid = $_POST['supplierid'];
		if($mul_supid  ==  'all')
		{
		$condition .= " ";
		}else{
		$condition .= "  cases.prod_supplier_id IN (" .$_DailySupplier[2] . ") AND ";
		}
		}
		endif;

		if($_POST['getSupplierandsku'] == 'sku'):
		$mul_skuid  ='';
		if ($_POST['getSupplierSKU']) {
		$mul_skuid =  $_POST['getSupplierSKU'];
		if($mul_skuid  == "all")
		{
		$condition .= " ";
		}else{
		$condition .= "  cases.prod_sku  IN ( " . $_DailySupplier[2] . ") AND ";
		}
		}
		endif;
		
		/*if(date("m") <= 06){
		$_CurrentYear = date("Y"); // current year
		$_NextYears = date("Y")-1; //previous year 

		$start_date = date($_NextYears.'-07-01'); //common from date
		$end_date = date($_CurrentYear.'-06-30');

		}else{
		$_CurrentYear = date("Y"); // current year
		$_NextYears = date("Y") + 1;  // post year
		$start_date = date($_CurrentYear.'-07-01'); //common from date
		$end_date = date($_NextYears.'-06-30');
        }
         */    
				
     if($_POST['getperiod'] == 'weekly'):
	 $_EndDate =  date("y-m-d",strtotime("+ 1 week",strtotime($_POST['daily'])));
	 $_EndDate =  date("y-m-d",strtotime("- 1 day",strtotime($_EndDate)));
	 $conditiondAILY = "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_POST['daily'])) . "' AND '" . date("y-m-d",strtotime($_EndDate)) . "' AND date(cases.date_entered) <= '".date("Y-m-d",strtotime($_EndDate))."' AND date(cases.date_entered) >= '".date("Y-m-d",strtotime($_POST['daily']))."' AND ";
    elseif($_POST['getperiod'] == 'annual'):
	    $_Dailypost = explode("_",$_POST['daily']);	
	    $year =   $_Dailypost[0];
	    $_fromdate = $year."-".'01'."-".'01';
		$end_date =  $year."-".'12'."-".'31';
	  $conditiondAILY = " year(cases.date_entered) BETWEEN '" .$start_date. "' AND '" . $end_date."' AND date(cases.date_entered) <= '".$end_date."' AND date(cases.date_entered) >= '".$start_date."' AND";
    elseif($_POST['getperiod'] == 'quarterly'):
        
		 $_StartDate = $_EndDate = "";
	    $_StartDate =  $_DailySupplier[0];
		$_EndDate = $_DailySupplier[1];
		 $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .$_StartDate . "' AND '" .  $_EndDate . "' AND ";
	elseif($_POST['getperiod'] == 'monthly'):
		$_Dailypost = explode("-",$_POST['daily']);	
		$month =   $_Dailypost[0];
		$year = $_Dailypost[1];	
		$_Days = cal_days_in_month(CAL_GREGORIAN, $month, $year)-1;
	    $_fromdate = $year."-".$month."-".'01';
	    $_EndDate = date("Y-m-d",strtotime("+ ".$_Days." days",strtotime($_fromdate)));
		$conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .$_fromdate. "' AND '" . $_EndDate . "' AND date(cases.date_entered) <= '".$_EndDate."' AND date(cases.date_entered) >= '".$_fromDate."' AND";
	endif;
	
	if(!empty($_POST['getSupplierSKU'])):
	 $query_query = "SELECT cases.prod_sku as myt,(SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.created_by=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition . " cases.deleted=0 ) as mytotalfor,cases.prod_sku,cases.prod_supplier_name,cases.prod_sku,cases.quality_description, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.created_by=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition. $conditiondAILY." cases.deleted=0 ORDER BY cases.date_entered DESC";
						
	elseif(!empty($_POST['supplierid'])): 
        $query_query = "SELECT cases.prod_supplier_id as myt,(SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.created_by=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition . " cases.deleted=0 ) as mytotalfor,cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku,cases.quality_description, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.created_by=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition. $conditiondAILY." cases.deleted=0 ORDER BY cases.date_entered DESC";
	endif;		
	$result = $db->query($query_query);
	$total = $result->num_rows;
	if($total > 0):
	while ($row = $db->fetchByAssoc($result)) {
	$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
	$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
	$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
	$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
	$volumecc[] = $row;
	$volumeDate[] = date("Y-m-d",strtotime($row['date_entered']));
	}
	else:
	$row['emptyrecord'] = "N/A";
	// $volumecc[] = $row;
	endif;
   if(!empty($_POST['getSupplierSKU'])):
       echo "<td colspan='6' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
		<tr>
		<td><strong>Date</strong></td>
		<td><strong>Case Id</strong></td>
		<td><strong>Sku</strong></td>
		<td><strong>Sku Description</strong></td>
		<td><strong>Case Category</strong></td>
		<td><strong>Case Priority</strong></td>
		</tr>";
		foreach($volumecc as $volumecc1)
		{
		echo "<tr>";
		echo "<td>".$volumecc1['date_entered']."</td>";
		echo "<td>".$volumecc1['case_number']."</td>";
		echo "<td>".$volumecc1['prod_sku']."</td>";
		echo "<td>".$volumecc1['quality_description']."</td>";
		echo "<td>".$volumecc1['category_c']."</td>";
		echo "<td>".$volumecc1['priority']."</td>";
		echo "</tr>";	
		}
		echo "</table></td>";
   elseif(!empty($_POST['supplierid'])): 
       echo "<td colspan='6' class='parent-TD'><div class='close-iocn' title='Close'>&#10006;</div><table>
		<tr>
		<td><strong>Date</strong></td>
		<td><strong>Case Id</strong></td>
		<td><strong>Supplier ID</strong></td>
		<td><strong>Supplier Description</strong></td>
		<td><strong>Case Category</strong></td>
		<td><strong>Case Priority</strong></td>
		</tr>";
		foreach($volumecc as $volumecc1)
		{
		echo "<tr>";
		echo "<td>".$volumecc1['date_entered']."</td>";
		echo "<td>".$volumecc1['case_number']."</td>";
		echo "<td>".$volumecc1['prod_supplier_id']."</td>";
		echo "<td>".$volumecc1['prod_supplier_name']."</td>";
		echo "<td>".$volumecc1['category_c']."</td>";
		echo "<td>".$volumecc1['priority']."</td>";
		echo "</tr>";	
		}
		echo "</table></td>";
   endif;
   
	die;
	
	}
	
 /**
     * This method is Get All supplier details name, id , phone, fax, department from table 'naku_Suppliers'
     *
     */
    public function getAllSupplierDetails() {
        $bean = BeanFactory::getBean('naku_Suppliers');
        $supplierFullList = $bean->get_full_list('', 'naku_suppliers.deleted =0');
        $getAllSupplier = array();
        if (count($supplierFullList) > 0) {
            foreach ($supplierFullList as $supValue) {
                $data['id'] = $supValue->id;
                $data['name'] = $supValue->name;
                $data['supplier_id'] = $supValue->supplier_id;
                $data['supplier_department'] = $supValue->supplier_department;
                $data['prod_sku'] = $supValue->prod_sku;
                $data['supplier_po_box'] = $supValue->supplier_po_box;
                $data['supplier_email'] = $supValue->supplier_email;
                $data['supplier_fax_no'] = $supValue->supplier_fax_no;
                
                $getAllSupplier[] = $data;
            }
            return $getAllSupplier;
        }
    }
    
     /**
     * This method is Get All supplier details name, id , phone, fax, department from table 'naku_Suppliers'
     *
     */
    public function getAllSupplierDetailsReports() {
         global $db;
         $query = "SELECT supplier_id,name FROM naku_suppliers WHERE deleted =0 limit 10";
        $result = $db->query($query);
         $getAllSupplier = array();
         while($data = $db->fetchByAssoc($result)){
              $data['supplier_id'] = $data['supplier_id'];
              $data['name'] = $data['name'] ;
              $getAllSupplier[] =$data;
            // echo "<pre>";print_r($data['total']);
         }
			$this->view_object_map['getAllSupplier'] = $getAllSupplier;//supplier popup @Ashok Dated: 25-04-2017 
            return $getAllSupplier;
    }
     public function getAllSupplierDepartment() {
        $bean = BeanFactory::getBean('naku_Suppliers');
        $supplierFullList = $bean->get_full_list('', 'naku_suppliers.deleted =0 AND naku_suppliers.supplier_department !=""');
        $getAllSupplierDepatment = array();
        if (count($supplierFullList) > 0) {
            foreach ($supplierFullList as $supValue) {
                $data['id'] = $supValue->id;
                $data['supplier_id'] = $supValue->supplier_id;
                $data['supplier_department'] = $supValue->supplier_department;
                $getAllSupplierDepatment[] = $data;
            }
            return $getAllSupplierDepatment;
        }
    }
    
    
/*****************Branch selector*******************/

function getAllBranchName(){
global $db;
$branchName = array();$xdata='';
$sql = "SELECT distinct(branch_store_name) FROM `cases` where deleted=0 AND branch_store_name <> ''";
$result =$db->query($sql);
$num = $result->num_rows;

if(0==$num) {
echo "No record";
exit;
}
while($row = $db->fetchByAssoc($result)) {
$branchName[] =$row['branch_store_name'];


}

return $branchName;
}
 
 /*************************************/
  function displayBySupplierYear($Supid,$checkSupplyName,$condition,$condition_group,$conditionMonth,$distype,$AllSup,$_ForexportSummery = null)
{
$volumesupplier = array();
 global $db, $app_list_strings, $sugar_config;
 

 if($distype == "supplier"):
 
  if($_ForexportSummery ==1):
   $AllSup = $AllSup;
 else:
  $AllSup = implode(",",$AllSup);
 endif;
 
 
  $default_query_case = " SELECT count(cases.id) as myt,cases.date_entered, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition . "  cases.prod_supplier_id IN (".$AllSup.") AND cases.deleted=0 ) as mytotalfor, 				
				cases.prod_sku,cases.prod_supplier_name, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition .$conditionMonth. " cases.prod_supplier_id IN (".$Supid.") AND cases.deleted=0  GROUP BY year(cases.date_entered) ".$condition_group ." ORDER BY cases.date_entered DESC";
	elseif($distype == "sku"):
  $AllSup = implode(",",$AllSup);
 $default_query_case = " SELECT count(cases.id) as myt,cases.date_entered, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition ." cases.prod_sku IN (".$AllSup.") AND cases.deleted=0 ) as mytotalfor,
				cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition .$conditionMonth. " cases.prod_sku IN (".$Supid.") AND  cases.deleted=0  GROUP BY year(cases.date_entered) ".$condition_group ." ORDER BY cases.date_entered DESC";
    endif;
//echo $default_query_case."<br><br>";	
	$result = $db->query($default_query_case);
	if($result->num_rows > 0){
		$total = $result->num_rows;
	}else{
		$total = 0;
	}
	if($total > 0):
		while ($row = $db->fetchByAssoc($result)) {
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$total_cases = $row['mytotalfor'];
			$num_amount = $row['myt'];
			$count1 = $num_amount / $total_cases;
			$count2 = $count1 * 100;
			$count = round($count2,2);
			$row['mypercentage'] = $count;

			$volumesupplier = $row;
			$volumesupplierDate[] = date("Y-m-d",strtotime($row['date_entered']));
		}
		else:
			$row['emptyrecord'] = "N/A";
		   // $volumecc[] = $row;
		endif;
		return $volumesupplier;	
}


/*************************************/
  function displayBySupplierYearReport($Supid,$checkSupplyName,$condition,$condition_group,$conditionMonth,$distype,$AllSup,$_ForexportSummery = null)
{
$volumesupplier = array();
 global $db, $app_list_strings, $sugar_config;
 

 if($distype == "supplier"):
 
  if($_ForexportSummery ==1):
   $AllSup = $AllSup;
 else:
  $AllSup = implode(",",$AllSup);
 endif;
 
 
  $default_query_case = " SELECT count(cases.id) as myt,cases.date_entered, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition . "  cases.prod_supplier_id IN (".$AllSup.") AND cases.deleted=0 ) as mytotalfor, 				
				cases.prod_sku,cases.prod_supplier_name, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition .$conditionMonth. " cases.prod_supplier_id IN (".$Supid.") AND cases.deleted=0  GROUP BY year(cases.date_entered) ".$condition_group ." ORDER BY cases.date_entered DESC";
	elseif($distype == "sku"):
    $AllSup = $AllSup;
 $default_query_case = " SELECT count(cases.id) as myt,cases.date_entered, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition ." cases.prod_sku IN (".$AllSup.") AND cases.deleted=0 ) as mytotalfor,
				cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition .$conditionMonth. " cases.prod_sku IN (".$Supid.") AND  cases.deleted=0  GROUP BY year(cases.date_entered) ".$condition_group ." ORDER BY cases.date_entered DESC";
    endif;
//echo $default_query_case."<br><br>";	
	$result = $db->query($default_query_case);
	if($result->num_rows > 0){
		$total = $result->num_rows;
	}else{
		$total = 0;
	}
	if($total > 0):
		while ($row = $db->fetchByAssoc($result)) {
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$total_cases = $row['mytotalfor'];
			$num_amount = $row['myt'];
			$count1 = $num_amount / $total_cases;
			$count2 = $count1 * 100;
			$count = round($count2,2);
			$row['mypercentage'] = $count;

			$volumesupplier = $row;
			$volumesupplierDate[] = date("Y-m-d",strtotime($row['date_entered']));
		}
		else:
			$row['emptyrecord'] = "N/A";
		   // $volumecc[] = $row;
		endif;
		return $volumesupplier;	
}


 function displayBySupplier($Supid,$checkSupplyName,$condition,$condition_group,$conditionMonth,$distype,$AllSup,$_ForexportSummery = null,$_MonthFrom = null,$_MonthTo = null)
{
$volumesupplier = array();
 global $db, $app_list_strings, $sugar_config;
 $condition_MyTotcount = "";
 $condition_MyTotcount = "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_MonthFrom)) . "' AND '" . date("y-m-d",strtotime($_MonthTo)) . "' AND ";
 
 if($distype == "supplier"):
 if($_ForexportSummery ==1):
 $AllSup = $AllSup;
 else:
 $AllSup = implode(",",$AllSup);
 endif;

 if(isset($_MonthFrom) && isset($_MonthTo)):

 $default_query_case = " SELECT count(cases.prod_supplier_id) as myt,(SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition.$condition_MyTotcount." cases.prod_supplier_id IN (".$AllSup.") AND  cases.deleted=0 ) as myNewtotalfor, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition. $conditionMonth." cases.prod_supplier_id IN (".$AllSup.") AND  cases.deleted=0 ) as mytotalfor,   cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$condition . $conditionMonth."  cases.prod_supplier_id IN (".$Supid.") AND  cases.deleted=0  GROUP BY month(cases.date_entered)".$condition_group." ORDER BY cases.date_entered DESC";
  
 else:
     $default_query_case = " SELECT count(cases.prod_supplier_id) as myt, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition. $conditionMonth." cases.prod_supplier_id IN (".$AllSup.") AND  cases.deleted=0 ) as mytotalfor,   cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$condition . $conditionMonth."  cases.prod_supplier_id IN (".$Supid.") AND  cases.deleted=0  GROUP BY month(cases.date_entered)".$condition_group." ORDER BY cases.date_entered DESC";
	 endif;
	elseif($distype == "sku"):
if($_ForexportSummery ==1):
 $AllSup = implode(",",$AllSup);
 else:
 $AllSup = implode(",",$AllSup);
 endif;
  if(isset($_MonthFrom) && isset($_MonthTo)):
  $default_query_case = " SELECT count(cases.prod_sku) as myt,cases.date_entered, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition .$condition_MyTotcount. " cases.prod_sku IN (".$AllSup.") AND cases.deleted=0 ) as myNewtotalfor,(SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition .$conditionMonth. " cases.prod_sku IN (".$AllSup.") AND cases.deleted=0 ) as mytotalfor,
				cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition .$conditionMonth. " cases.prod_sku IN (".$Supid.") AND  cases.deleted=0  GROUP BY month(cases.date_entered) ".$condition_group ." ORDER BY cases.date_entered DESC";
  else:
	$default_query_case = " SELECT count(cases.prod_sku) as myt,cases.date_entered, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition .$conditionMonth. " cases.prod_sku IN (".$AllSup.") AND cases.deleted=0 ) as mytotalfor,
				cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition .$conditionMonth. " cases.prod_sku IN (".$Supid.") AND  cases.deleted=0  GROUP BY month(cases.date_entered) ".$condition_group ." ORDER BY cases.date_entered DESC";
    endif;
	endif;
//echo $default_query_case."<br><br>";	
	$result = $db->query($default_query_case);
	if($result->num_rows > 0){
		$total = $result->num_rows;
	}else{
		$total = 0;
	}
	if($total > 0):
		while ($row = $db->fetchByAssoc($result)) {
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$total_cases = $row['myNewtotalfor'];
			$num_amount = $row['myt'];
			$count1 = $num_amount / $total_cases;
			$count2 = $count1 * 100;
			$count = round($count2,2);
			$row['mypercentage'] = $count;
            
			$volumesupplier = $row;
			$volumesupplierDate[] = date("Y-m-d",strtotime($row['date_entered']));
		}
		else:
			$row['emptyrecord'] = "N/A";
		   // $volumecc[] = $row;
		endif;
		
		return $volumesupplier;	
}


function displayBySupplierMonthexport($Supid,$checkSupplyName,$condition,$condition_group,$conditionMonth,$distype,$AllSup,$_ForexportSummery = null,$_MonthFrom = null,$_MonthTo = null)
{
$volumesupplier = array();
 global $db, $app_list_strings, $sugar_config;
 $condition_MyTotcount = "";
 $condition_MyTotcount = "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($_MonthFrom)) . "' AND '" . date("y-m-d",strtotime($_MonthTo)) . "' AND ";
 
  if($distype == "supplier"):
 if($_ForexportSummery ==1):
 $AllSup = $AllSup;
 else:
 $AllSup = implode(",",$AllSup);
 endif;

 if(isset($_MonthFrom) && isset($_MonthTo)):

 $default_query_case = " SELECT count(cases.prod_supplier_id) as myt,(SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition.$condition_MyTotcount." cases.prod_supplier_id IN (".$AllSup.") AND  cases.deleted=0 ) as myNewtotalfor, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition. $conditionMonth." cases.prod_supplier_id IN (".$AllSup.") AND  cases.deleted=0 ) as mytotalfor,   cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$condition . $conditionMonth."  cases.prod_supplier_id IN (".$Supid.") AND  cases.deleted=0  GROUP BY month(cases.date_entered)".$condition_group." ORDER BY cases.date_entered DESC";
  
 else:
     $default_query_case = " SELECT count(cases.prod_supplier_id) as myt,(SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition. $condition_MyTotcount." cases.prod_supplier_id IN (".$AllSup.") AND  cases.deleted=0 ) as myNewtotalfor, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition. $conditionMonth." cases.prod_supplier_id IN (".$AllSup.") AND  cases.deleted=0 ) as mytotalfor,   cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$condition . $conditionMonth."  cases.prod_supplier_id IN (".$Supid.") AND  cases.deleted=0  GROUP BY month(cases.date_entered)".$condition_group." ORDER BY cases.date_entered DESC";
	 endif;
	elseif($distype == "sku"):
if($_ForexportSummery ==1):
 $AllSup = implode(",",$AllSup);
 else:
 $AllSup = implode(",",$AllSup);
 endif;
 
 if(isset($_MonthFrom) && isset($_MonthTo)):
  $default_query_case = " SELECT count(cases.prod_sku) as myt,cases.date_entered, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition .$condition_MyTotcount. " cases.prod_sku IN (".$AllSup.") AND cases.deleted=0 ) as myNewtotalfor,(SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition .$conditionMonth. " cases.prod_sku IN (".$AllSup.") AND cases.deleted=0 ) as mytotalfor,
				cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition .$conditionMonth. " cases.prod_sku IN (".$Supid.") AND  cases.deleted=0  GROUP BY month(cases.date_entered) ".$condition_group ." ORDER BY cases.date_entered DESC";
  else:
	$default_query_case = " SELECT count(cases.prod_sku) as myt,cases.date_entered,(SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition .$condition_MyTotcount. " cases.prod_sku IN (".$AllSup.") AND cases.deleted=0 ) as myNewtotalfor, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition .$conditionMonth. " cases.prod_sku IN (".$AllSup.") AND cases.deleted=0 ) as mytotalfor,
				cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition .$conditionMonth. " cases.prod_sku IN (".$Supid.") AND  cases.deleted=0  GROUP BY month(cases.date_entered) ".$condition_group ." ORDER BY cases.date_entered DESC";
    endif;
	endif;
	
	$result = $db->query($default_query_case);
	if($result->num_rows > 0){
		$total = $result->num_rows;
	}else{
		$total = 0;
	}
	if($total > 0):
		while ($row = $db->fetchByAssoc($result)) {
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
			$total_cases = $row['myNewtotalfor'];
			$num_amount = $row['myt'];
			$count1 = $num_amount / $total_cases;
			$count2 = $count1 * 100;
			$count = round($count2,2);
			$row['mypercentage'] = $count;
            
			$volumesupplier = $row;
			$volumesupplierDate[] = date("Y-m-d",strtotime($row['date_entered']));
		}
		else:
			$row['emptyrecord'] = "N/A";
		   // $volumecc[] = $row;
		endif;
		
		return $volumesupplier;	
}

/*
* for Quarter grid
*/
function displayBySupplierQuarter($Supid,$checkSupplyName,$condition,$condition_group,$conditionMonth,$distype,$_SUPSKU,$first_day_SelectedQat_from,$last_day_SelectedQat_To)
{
$volumesupplier = array();
 global $db, $app_list_strings, $sugar_config;

 $conditionQ = "  DATE(cases.date_entered) BETWEEN '" . $first_day_SelectedQat_from . "' AND '" . $last_day_SelectedQat_To . "' AND ";
 if($distype == 'sku'):
  //$AllSup = implode(",",$_SUPSKU);
  $AllSup = implode(",",$_SUPSKU);
  $default_query_case = " SELECT count(cases.prod_sku) as myt, (SELECT COUNT(cases.prod_sku) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition . $conditionQ." cases.prod_sku IN (".$AllSup.") AND  cases.deleted=0 ) as mytotalnewfor,(SELECT COUNT(cases.prod_sku) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition ." cases.prod_sku IN (".$AllSup.") AND  cases.deleted=0 ) as mytotalfor,   cases.prod_sku,cases.prod_supplier_name,cases.prod_sku, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition.$conditionMonth . " cases.prod_sku IN (".$Supid.") AND cases.deleted=0  GROUP BY QUARTER(cases.date_entered),year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered DESC";
	else:
		//if($_ForexportSummery ==1):
		//$AllSup = $_SUPSKU;
		//else:
		//$AllSup = implode(",",$_SUPSKU);
		//endif;
		$AllSup = implode(",",$_SUPSKU);
         $default_query_case = " SELECT count(cases.prod_supplier_id) as myt,(SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition.$conditionQ. " cases.prod_supplier_id IN (".$AllSup.") AND  cases.deleted=0 ) as mytotalnewfor, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition. " cases.prod_supplier_id IN (".$AllSup.") AND  cases.deleted=0 ) as mytotalfor,   cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$condition . $conditionMonth."  cases.prod_supplier_id IN (".$Supid.") AND  cases.deleted=0  GROUP BY QUARTER(cases.date_entered),year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered DESC";
	
	endif;
	        	//echo  $default_query_case ."<br><br><br><br><br>";			
			$resultY = $db->query($default_query_case);
		
			$total = $resultY->num_rows;
			if($total > 0):
			while ($row = $db->fetchByAssoc($resultY)) {
			$row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';

			$total_cases = $row['mytotalnewfor'];
			$num_amount = $row['myt'];
			$count1 = $num_amount / $total_cases;
			$count2 = $count1 * 100;
			$count = round($count2,2);
			$row['mypercentage'] = $count;
			$_row = $row['myt'];
			$volumesupplier = $row;
			}
			else:
			$row['emptyrecord'] = "N/A";
			// $volumesupplier[] = $row;
			endif;
			
			return $volumesupplier;
}

/*
* for Quarter export report
*/
function displayBySupplierQuarterExport($Supid,$checkSupplyName,$condition,$condition_group,$conditionMonth,$distype,$_SUPSKU,$first_day_SelectedQat_from,$last_day_SelectedQat_To)
{
$volumesupplier = array();
 global $db, $app_list_strings, $sugar_config;
 $conditionQ = "  DATE(cases.date_entered) BETWEEN '" . $first_day_SelectedQat_from . "' AND '" . $last_day_SelectedQat_To . "' AND ";
 if($distype == 'sku'):
  $AllSup = implode(",",$_SUPSKU);
   $default_query_case = " SELECT count(cases.prod_sku) as myt, (SELECT COUNT(cases.prod_sku) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition . $conditionQ." cases.prod_sku IN (".$AllSup.") AND  cases.deleted=0 ) as mytotalnewfor,(SELECT COUNT(cases.prod_sku) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition ." cases.prod_sku IN (".$AllSup.") AND  cases.deleted=0 ) as mytotalfor,   cases.prod_sku,cases.prod_supplier_name,cases.prod_sku, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition.$conditionMonth . " cases.prod_sku IN (".$Supid.") AND cases.deleted=0  GROUP BY QUARTER(cases.date_entered),year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered DESC";
	else:
		$AllSup = $_SUPSKU;
		$default_query_case = " SELECT count(cases.prod_supplier_id) as myt,(SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition.$conditionQ. " cases.prod_supplier_id IN (".$AllSup.") AND  cases.deleted=0 ) as mytotalnewfor, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition. " cases.prod_supplier_id IN (".$AllSup.") AND  cases.deleted=0 ) as mytotalfor,   cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " .$condition . $conditionMonth."  cases.prod_supplier_id IN (".$Supid.") AND  cases.deleted=0  GROUP BY QUARTER(cases.date_entered),year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered DESC";
		
	endif;
	//echo  $default_query_case ."<br><br><br><br><br>";			
	
	        $resultY = $db->query($default_query_case);
		
			$total = $resultY->num_rows;
			if($total > 0):
			while ($row = $db->fetchByAssoc($resultY)) {
			$row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
			$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
			$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
			$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';

			$total_cases = $row['mytotalnewfor'];
			$num_amount = $row['myt'];
			$count1 = $num_amount / $total_cases;
			$count2 = $count1 * 100;
			$count = round($count2,2);
			$row['mypercentage'] = $count;
			$_row = $row['myt'];
			$volumesupplier = $row;
			}
			else:
			$row['emptyrecord'] = "N/A";
			// $volumesupplier[] = $row;
			endif;
			return $volumesupplier;
}


     //1.2.1.3.7 Volume of Cases By Suppliers or Products for Quality Complaints
    public function action_volumesupplier(){
        global $db, $app_list_strings, $sugar_config;
        $ReportName = 'volumesupplier';
        $this->view = 'volumesupplier';
		
		//$this->view_object_map['getAllSupplierName'] = $this->getAllSupplierName();
		$this->view_object_map['getAllSupplierFromCases'] = $this->getAllSupplierFromCases();
		$this->view_object_map['getAllSKUFromCases'] = $this->getAllSKUFromCases();
		
        $this->view_object_map['getTimePeriod'] = $this->getTimePeriod();
        $this->view_object_map['createMonthdd'] = $this->createMonthdd();
        $this->view_object_map['creatWeeklydd'] = $this->creatWeeklydd();
        $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
		$this->view_object_map['getYearDd'] = $this->creatYearsdd();

        $this->view_object_map['getAllCaseCategory'] = $this->getAllCaseCategory();
        $this->view_object_map['getAllSupplierDetails'] = $this->getAllSupplierDetailsReports();
        $this->view_object_map['getAllSupplierDepartment'] = $this->getAllSupplierDepartment();
        $this->view_object_map['site_url'] = $sugar_config['site_url'];
        $this->view_object_map['branch_store_name'] = $this->getAllBranchName();
		$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
		$end_date = $_curdate;
		$start_date = date('Y-m-1', strtotime("-1 year"));
		$this->view_object_map['creatQudd'] = $this->creatQuarterdd($start_date,$end_date);
		$volumesupplier = $queryCase = $_Yearquery = $_ColumnsDate = $volumeDate = $_DailyLoopC = $_DateEnteredArray = $volumesupplier_grid = $_NoOfQuarters = $_GetOneQuarters = $_DateEntered1Array = $_percentageRecord = $_yearRecord =  array();
        $_WeeklyGlobal = $_QuaterlyGlobal = $_MonthGlobal = $_Dailyglobal = 0;
		
		$_DisplayrecordMsg = 0;
		$condition = $condition_group=$_StartMonth = $_EndMonth = $_StartW= $_EndW  =$_StartQ  =$_EndQ = $_QuaMyt='';

        $groupby = '';
        if (isset($_REQUEST['query']) == 'true') { 
            if ($_REQUEST['category_id'] || $_REQUEST['origin'] || $_REQUEST['status'] ||
            $_REQUEST['from_date'] || $_REQUEST['to_date'] || $_REQUEST['supplier_id'] || $_REQUEST['supplier_dept_id'] ) {

                if ($_REQUEST['category_id'] == "all") {
                    $condition .= "";
					$condition_group .= "";
				 }else
				 {
				     $condition .= "  cases_cstm.category_c = '" . $_REQUEST['category_id'] . "' AND ";
					$condition_group .= ",cases_cstm.category_c";
				 }
				 
				 if ($_REQUEST['status'] == "all") {
                    $condition .= "";
					$condition_group .= "";
				 }else
				 {
				     $condition .= "  cases.status= '" . $_REQUEST['status'] . "' AND ";
					$condition_group .= ",cases.status";
				 }
				
                 if ($_REQUEST['origin'] == "all")  {
                    $condition .= " ";
					$condition_group .= "";
                 }else
				 {
				    $condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
					$condition_group .= ",cases_cstm.origin_c";
				 }
				 
				 if ($_POST['branch_store_name'] == "all"  || $_POST['branch_store_name'] == "" )  {
				$condition .= " ";
				}else
				{
				$condition .= "  cases.branch_store_name = '" . $_POST['branch_store_name'] . "'  AND ";
				}
			
				 if ($_REQUEST['sub_category_id']  == "all") {
                    $condition .= " ";
					$condition_group .= "";
                 }else
				 {
				    $condition .= "  cases_cstm.subcategory_c = '" . $_REQUEST['sub_category_id'] . "'  AND ";
					$condition_group .= ",cases_cstm.subcategory_c";
				  }
				 
				 
                if(!empty($_POST['periodmonthsdd'])):
                $_StartMonth = $_POST['periodmonthsdd'];
                endif;

                if(!empty($_POST['periodmonthedd'])):
                $_EndMonth = $_POST['periodmonthedd'];
                endif;

                if(!empty($_POST['periodweeksdd'])):
                $_StartW = $_POST['periodweeksdd'];
                endif;

                if(!empty($_POST['periodweekedd'])):
                $_EndW = $_POST['periodweekedd'];
                endif;

                if(!empty($_POST['periodquasdd'])):
                $_StartQ = $_POST['periodquasdd'];
                endif;

                if(!empty($_POST['periodquaedd'])):
                $_EndQ = $_POST['periodquaedd'];
                endif;

				if($_POST['period']=="daily"): 
                if ($_REQUEST['from_date'] && $_REQUEST['to_date']) {
                $condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($_REQUEST['from_date'])) . "' AND '" . date("Y-m-d", strtotime($_REQUEST['to_date'])) . "' AND ";
		        }
				endif;
				
				
				if($_POST['suppliersku_id'] == 'supplier' ):
				$mul_supid='';
                if ($_REQUEST['supplier_id']) {
				$mul_supid =  implode(",",$_REQUEST['supplier_id']);
				if($mul_supid  ==  'all')
				{
				$condition .= " ";
				$condition_group .= "";		 
			    }else{
                //$condition .= "  cases.prod_supplier_id IN (" .$mul_supid . ") AND ";
               // $condition_group .= ",cases.prod_supplier_id";
				}
                }
				endif;
				
				if($_POST['suppliersku_id'] == 'sku'):
				$mul_skuid  ='';
                if ($_REQUEST['suppliersku']) {
				$mul_skuid =  implode(",",$_REQUEST['suppliersku']);
				if($mul_skuid  == "all")
				{
				$condition .= " ";
				$condition_group .= "";		 
			    }else{
                //$condition .= "  cases.prod_sku  IN ( " . $mul_skuid . ") AND ";
                //$condition_group .= ",cases.prod_sku";
				}
                }
                endif;
				
                if ($_REQUEST['supplier_dept_id']) {
                $condition .= "  naku_suppliers.supplier_department = '" . trim($_REQUEST['supplier_dept_id']) . "' AND ";
                $condition_group .='';
                }
                /* checking query starting */

                $start_date = date("Y-m-d", strtotime($_REQUEST['from_date']));
                $end_date = date("Y-m-d", strtotime($_REQUEST['to_date']));

                $start_date = $_REQUEST['from_date']; //fromdate for post
                $this->view_object_map['getFromDate'] = $start_date;
                $end_date = $_REQUEST['to_date']; //todate for post
                $this->view_object_map['getToDate'] = $end_date;
                $_Periodpost = $_REQUEST['period']; //period for post
                $this->view_object_map['getPeriod'] = $_Periodpost;
                $_Originpost = $_REQUEST['origin']; //origin for post
                $this->view_object_map['getOrigin'] = $_Originpost;
                $_Categorypost = $_REQUEST['category_id']; //categoryid for post
                $this->view_object_map['getCategory'] = $_Categorypost;

                $this->view_object_map['getSupplierid'] = $mul_supid;//$_POST['supplier_id'];
                $this->view_object_map['getSupplierDeptid'] = $_POST['supplier_dept_id'];
                $this->view_object_map['getStatus'] = $_POST['status'];
                $this->view_object_map['getSupplierandsku'] = $_POST['suppliersku_id'];
                $this->view_object_map['getSupplierSKU'] = $mul_skuid;//$_POST['suppliersku'];
                $this->view_object_map['sub_category_id'] = $_POST['sub_category_id'];//$_POST['suppliersku'];


                //new cases
                $_Subcatgorypost = $_REQUEST['sub_category_id']; //sucategoryid for post
                $this->view_object_map['getSubCategory'] = $_Subcatgorypost;
                $this->view_object_map['getStartmonth'] = $_StartMonth; // selected month start
                $this->view_object_map['getEndmonth'] = $_EndMonth; // selected month end
                $this->view_object_map['periodquasdd'] = $_StartQ; // selected month start
                $this->view_object_map['periodquaedd'] = $_EndQ; // selected month end
                $this->view_object_map['getStartweek'] = $_StartW; // selected month start
                $this->view_object_map['getEndweek'] = $_EndW; // selected month end
				$_BranchStore = $_REQUEST['branch_store_name']; //branch_store_name for post
                $this->view_object_map['getBranchName'] = $_BranchStore;
				
				$this->view_object_map['getFromyear'] = $_POST['getYearsDd']; // selected from year
				$this->view_object_map['getToyear'] = $_POST['getYeareDd']; // selected  to year
				
				

                if($_POST['period'] == 'daily'):
                    
                   // $_Dailyglobal = 1;
                    $_DailyLoopCount = $this->datediff('d', date("y-m-d", strtotime($_REQUEST['from_date'])), date("y-m-d", strtotime($_REQUEST['to_date'])));

                    for($i = 0; $i<=$_DailyLoopCount;$i++)
                    {
                    $_DailyLoopC[] = date ("Y-m-d", strtotime("+$i day", strtotime($start_date)));
                    }

                    if ($_REQUEST['from_date'] && $_REQUEST['to_date']) {
                    $condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d", strtotime($start_date)) . "' AND '" . date("y-m-d", strtotime($end_date)) . "' AND ";
                    }
                    if(isset($_REQUEST['suppliersku'])):

                        $default_query_case = " SELECT count(cases.id) as myt,(SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c  "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition . " cases.deleted=0 ) as mytotalfor,  cases.prod_sku,cases.prod_supplier_name,cases.prod_sku, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,
						cases_cstm.loyalty_id_c, cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition . " cases.deleted=0  GROUP BY date(cases.date_entered) ".$condition_group ." ORDER BY cases.date_entered DESC";

                    else:

                        $default_query_case = " SELECT count(cases.id) as myt,
                          (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition . " cases.deleted=0 ) as mytotalfor,   
                             cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition . " cases.deleted=0  GROUP BY date(cases.date_entered) ".$condition_group ." ORDER BY cases.date_entered DESC";
                    endif;
                $result = $db->query($default_query_case);
                if($result->num_rows > 0){
                    $total = $result->num_rows;
                }else{
                    $total = 0;
                }
				if($total > 0):
					while ($row = $db->fetchByAssoc($result)) {
						$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
						$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
						$row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
						$total_cases = $row['mytotalfor'];
						$num_amount = $row['myt'];
						$count1 = $num_amount / $total_cases;
						$count2 = $count1 * 100;
						$count = number_format($count2, 0);
						$row['mypercentage'] = $count;

						$volumesupplier[] = $row;
						$volumesupplierDate[] = date("Y-m-d",strtotime($row['date_entered']));
					}
					else:
						$row['emptyrecord'] = "N/A";
                       // $volumecc[] = $row;
					endif;
                
            elseif($_REQUEST['period'] == 'weekly'):
    
                if(date("m") <= 06){
                $_CurrentYear = date("Y"); // current year
                $_NextYears = date("Y")-1; //previous year 

                $start_date = date($_NextYears.'-07-01'); //common from date
                $end_date = date($_CurrentYear.'-06-30');
                $_WeekLoopCount = $this->datediff('ww', $start_date, $end_date )." Week<br>";

                }else{
                $_CurrentYear = date("Y"); // current year
                $_NextYears = date("Y") + 1;  // post year
                $start_date = date($_CurrentYear.'-07-01'); //common from date
                $end_date = date($_NextYears.'-06-30');
                $_WeekLoopCount = $this->datediff('ww', $start_date, $end_date )." Week<br>";

                }

                for($i = 0;$i<=$_WeekLoopCount;$i++)
                {
                $_DailyLoopC[] = date ("Y-m-d", strtotime("+ $i week", strtotime($start_date)));
                }

                $_WeeklyGlobal = 1;

                $condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d", strtotime($start_date)) . "' AND '" . date("y-m-d", strtotime($end_date)) . "' AND ";

				 if(isset($_REQUEST['suppliersku'])):

                        $default_query_case = " SELECT count(cases.id) as myt,(SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c  "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition . " cases.deleted=0 ) as mytotalfor,   
                                                                                        cases.prod_sku,cases.prod_supplier_name, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition . " cases.deleted=0  GROUP BY week(cases.date_entered) ".$condition_group ." ORDER BY cases.date_entered DESC";

                    else:

                        $default_query_case = " SELECT count(cases.id) as myt,
                         (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition . " cases.deleted=0 ) as mytotalfor,   
                             cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition . " cases.deleted=0  GROUP BY week(cases.date_entered) ".$condition_group ." ORDER BY cases.date_entered DESC";
                    endif;
					
                $result = $db->query($default_query_case);
                $total = $result->num_rows;
                if($total > 0):
                    while ($row = $db->fetchByAssoc($result)) {
                        $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                        $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                        $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                        $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
						
						$total_cases = $row['mytotalfor'];
						$num_amount = $row['myt'];
						$count1 = $num_amount / $total_cases;
						$count2 = $count1 * 100;
						$count = number_format($count2, 0);
						$row['mypercentage'] = $count;
					
					
                        $volumesupplier[] = $row;
                    }
				else:
					$row['emptyrecord'] = "N/A";
					// $volumesupplier[] = $row;
				endif;
            elseif($_REQUEST['period'] == "monthly"):
                
                $_MonthGlobal = 1;
                
               		if($_POST['suppliersku_id'] == 'supplier' ):
				$mul_supid='';
                if ($_REQUEST['supplier_id']) {
				$mul_supid =  implode(",",$_REQUEST['supplier_id']);
				if($mul_supid  ==  'all')
				{
				$condition .= " ";
				$condition_group .= "";		 
			    }else{
                $condition .= "  cases.prod_supplier_id IN (" .$mul_supid . ") AND ";
                $condition_group .= ",cases.prod_supplier_id";
				}
                }
				endif;
				
				if($_POST['suppliersku_id'] == 'sku'):
				$mul_skuid  ='';
                if ($_REQUEST['suppliersku']) {
				$mul_skuid =  implode(",",$_REQUEST['suppliersku']);
				if($mul_skuid  == "all")
				{
				$condition .= " ";
				$condition_group .= "";		 
			    }else{
                $condition .= "  cases.prod_sku  IN ( " . $mul_skuid . ") AND ";
                $condition_group .= ",cases.prod_sku";
				}
                }
                endif;
				

			       $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
					$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
					$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
					$start_date  = $_Year."-".$_Month."-"."1";  //start date
					$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
					$_MonthLoopCount = $this->datediff('m',date("y-m-d",strtotime($start_date )),date("y-m-d",strtotime($end_date)));				 
					/*month logic end */
					for($i=0;$i<=$_MonthLoopCount+1;$i++)
					{
					$_DailyLoopC[] =  date ("M-Y", strtotime("+ $i month", strtotime($start_date)));
					}
					
					/*
					* month script
					*/
					$_VolumeSupplier_Start_D = $_VolumeSupplier_End_D =$conditionMonth = "";
					$_VolumeSupplier_Start_D = $_POST['periodmonthsdd'];
					$_VolumeSupplier_End_D =$_POST['periodmonthedd'];
				    $first_day_this_month = date('Y-m-01',strtotime($_VolumeSupplier_Start_D));
				    $last_day_this_month  = date('Y-m-t',strtotime($_VolumeSupplier_End_D));
					
					if(isset($first_day_this_month) && isset($last_day_this_month)):
					$conditionMonth .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($first_day_this_month)) . "' AND '" . date("y-m-d",strtotime($last_day_this_month)) . "' AND ";
					endif;
					
				    $condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";
					
                if(isset($_REQUEST['suppliersku_id'])): 
                 $default_query_case = " SELECT count(cases.id) as myt,cases.date_entered, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition . $conditionMonth." cases.deleted=0 ) as mytotalfor, 				
				cases.prod_sku,cases.prod_supplier_name, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition .$conditionMonth. " cases.deleted=0  GROUP BY month(cases.date_entered) ".$condition_group ." ORDER BY cases.date_entered DESC";

                else:
                 $default_query_case = " SELECT count(cases.id) as myt,cases.date_entered, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition .$conditionMonth. " cases.deleted=0 ) as mytotalfor,
				cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition .$conditionMonth. " cases.deleted=0  GROUP BY month(cases.date_entered) ".$condition_group ." ORDER BY cases.date_entered DESC";
                endif;
				
                $result = $db->query($default_query_case);
                $total = $result->num_rows;
                if($total > 0):
                    while ($row = $db->fetchByAssoc($result)) {
                    $row['date_entered'] = date("m-Y", strtotime($row['date_entered']));
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';

                    $num_amount = $row['myt'];
                    if($row['mytotalfor'] != 0){
                        $total_cases = $row['mytotalfor'];
                        $count1 = $num_amount / $total_cases;
                        $count2 = $count1 * 100;
                        $count = number_format($count2, 0);
                        $row['mypercentage'] = $count;
                    }
                    $volumesupplier[] = $row;

                    }
                else:
                    $row['emptyrecord'] = "N/A";
                    // $volumesupplier[] = $row;
                endif;
            elseif($_REQUEST['period'] == "quarterly"):
                $_QuaterlyGlobal = 1;
				/*quater logic start*/
				$_Start_Q = explode("_",$_StartQ);
				$_OpenQ = $_Start_Q[2];
				$_End_Q = explode("_",$_EndQ);
				$_EndQ = $_End_Q[2];
				/* end */
                
					
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				
			
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				
				$this->view_object_map['creatQudd'] = $this->creatQuarterdd($start_date,$end_date);
				//echo "<pre>";
				//print_r($this->view_object_map['creatQudd'] );
                $_Startq = explode("_",$_StartQ); 
				$_Endq = explode("_",$_EndQ); 
				$_GetQuarters = $this->creatQuarterdd($start_date,$end_date);
				foreach($_GetQuarters as $_GetQuarters1Key=>$_GetQuarters1)
				{
				$_Startq = explode("_",$_GetQuarters1Key); 
				
				$_DailyLoopC[$_GetQuarters1Key] = $_GetQuarters1;
				$_GetPeroid[$_GetQuarters1Key."_".$_GetQuarters1] = $this->checkReportPeriodQuartervolsupplier($condition,$condition_group,$_Startq[0],$_Startq[1],$ReportName, $_POST['suppliersku_id']);
				$_DateEntered1ArrayMyt[$volumesupplierDataQ['date_entered']]+= $volumesupplierDataQ['myt'];  //myt total array
				 $_DateEntered1ArrayMyPer[$volumesupplierDataQ['date_entered']]+= $volumesupplierDataQ['mypercentage'];  //myt percentange array

                }
					
					
				
				 if(isset($_REQUEST['suppliersku'])):
                $default_query_case = " SELECT count(cases.id) as myt,cases.date_entered, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition . " cases.deleted=0 ) as mytotalfor,   cases.prod_sku,cases.prod_supplier_name,cases.prod_sku, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition . " cases.deleted=0  group by QUARTER(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";

                else:
                $default_query_case = " SELECT count(cases.id) as myt,cases.date_entered, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition . " cases.deleted=0 ) as mytotalfor,   cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition . " cases.deleted=0  group by QUARTER(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";

                
                endif;
				
                $result = $db->query($default_query_case);
                $total = $result->num_rows;
                if($total > 0):
                    while ($row = $db->fetchByAssoc($result)) {
                        $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                        $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                        $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                        $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
						
						$total_cases = $row['mytotalfor'];
						$num_amount = $row['myt'];
						$count1 = $num_amount / $total_cases;
						$count2 = $count1 * 100;
						$count = number_format($count2, 0);
						$row['mypercentage'] = $count;
					
                        $volumesupplier[] = $row;
                    }
                else:
                    $row['emptyrecord'] = "N/A";
                    // $volumesupplier[] = $row;
                endif;

            elseif($_REQUEST['period'] == "annual"):
                $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
				$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
			    $start_date  = $_Year."-".$_Month."-"."1";  //start date
				$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
				$_CurrentYear = date("Y"); // current year
				$_PreviousYears = date("Y")-1; //previous year 
				if ($_POST['getYearsDd'] != $_POST['getYeareDd']) {
					$_Year =  array($_PreviousYears,$_CurrentYear);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}else{
				    $_Year =  array($_POST['getYearsDd']);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}
				
		
				$from = $_POST['getYearsDd'];
				$to = $_POST['getYeareDd'];
				
				if ($_POST['getYearsDd'] != $_POST['getYeareDd']) {
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				} else {
				$start_date = date('Y-m-d', strtotime("$from-01-01"));
				$end_date = date('Y-m-d', strtotime("$from-12-31"));
				}
			
			   //die;
			
                $condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d", strtotime($start_date)) . "' AND '" . date("y-m-d", strtotime($end_date)) . "' AND ";
				
				 if(isset($_REQUEST['suppliersku'])):
                $default_query_case = " SELECT count(cases.id) as myt,cases.date_entered, (SELECT COUNT(cases.id) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition . " cases.deleted=0 ) as mytotalfor,   cases.prod_sku,cases.prod_supplier_name,cases.prod_sku, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition . " cases.deleted=0  group by year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";

                else:
                $default_query_case = " SELECT count(cases.id) as myt,cases.date_entered, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition . " cases.deleted=0 ) as mytotalfor,   cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition . " cases.deleted=0  group by year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";

                
                endif;
				
             
                $result = $db->query($default_query_case);
                $total = $result->num_rows;
                if($total > 0):
                    while ($row = $db->fetchByAssoc($result)) {
                        $row['date_entered'] = date("Y", strtotime($row['date_entered']));
                        $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                        $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                        $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';

                        $total_cases = $row['mytotalfor'];
                        $num_amount = $row['myt'];
                        $count1 = $num_amount / $total_cases;
                        $count2 = $count1 * 100;
                        $count = number_format($count2, 0);
                        $row['mypercentage'] = $count;

                        $volumesupplier[] = $row;
                    }
                else:
                    $row['emptyrecord'] = "N/A";
                endif;

            else:
			
				if ($_REQUEST['category_id']) {
                $condition .= "  cases_cstm.category_c = '" . $_REQUEST['category_id'] . "' AND ";
                $condition_group .= ",cases_cstm.category_c";
                }
                if ($_REQUEST['origin']) {
                $condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
                $condition_group .= ",cases_cstm.origin_c";
                }
                if ($_REQUEST['status']) {
                $condition .= "  cases.status = '" . $_REQUEST['status'] . "' AND ";
                $condition_group .= ",cases.status";
                }
                if ($_REQUEST['sub_category_id']) {
                $condition .= "  cases_cstm.subcategory_c = '" . $_REQUEST['sub_category_id'] . "'  AND ";
                $condition_group .= ",cases_cstm.subcategory_c";
                }
				
                /*checking query starting*/
                $start_date = date("Y-m-d",strtotime($_REQUEST['from_date']));
                $end_date = date("Y-m-d",strtotime($_REQUEST['to_date']));
                $_DailyLoopCount = $this->datediff('d',date("y-m-d",strtotime($_REQUEST['from_date'])),date("y-m-d",strtotime($_REQUEST['to_date'])));				 

                for($i=0;$i<=$_DailyLoopCount;$i++)
                {
                  $_DailyLoopC[] =  date ("Y-m-d", strtotime("+$i day", strtotime($start_date)));
                }

                if ($_REQUEST['from_date'] && $_REQUEST['to_date']) {
                  $condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";
                }
				
				if(isset($_REQUEST['suppliersku'])):
                $default_query_case = " SELECT count(cases.id) as myt,cases.date_entered, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition . " cases.deleted=0 ) as mytotalfor,   cases.prod_sku,cases.prod_supplier_name,cases.prod_sku, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition . " cases.deleted=0  GROUP BY date(cases.date_entered) ".$condition_group." ORDER BY cases.date_entered DESC";

                else:
                $default_query_case = " SELECT count(cases.id) as myt,cases.date_entered, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition . " cases.deleted=0 ) as mytotalfor,   cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition . " cases.deleted=0  GROUP BY date(cases.date_entered) ".$condition_group." ORDER BY cases.date_entered DESC";

                
                endif;
				
			             
                $result = $db->query($default_query_case);
                $total = $result->num_rows;
                if($total > 0):
                    while ($row = $db->fetchByAssoc($result)) {
                        $row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
                        $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                        $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                        $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
						
						$total_cases = $row['mytotalfor'];
                        $num_amount = $row['myt'];
                        $count1 = $num_amount / $total_cases;
                        $count2 = $count1 * 100;
                        $count = number_format($count2, 0);
                        $row['mypercentage'] = $count;
						
                        $volumesupplier[] = $row;
                        $volumesupplierData[] = date("Y-m-d",strtotime($row['date_entered']));
                    }
					else:
						$row['emptyrecord'] = "N/A";

					endif;
					 
            endif;
			
			
			   
             if($_POST['period'] == 'monthly'){//for month start
					 $_MonthStartArray = array_keys($_DailyLoopC,$_StartMonth);
					 $_MonthEndArray =  array_keys($_DailyLoopC,$_EndMonth);
					 $_Totvalue = $_MonthEndArray[0]-$_MonthStartArray[0];
					 $_DailyLoopC = array_slice($_DailyLoopC,$_MonthStartArray[0],$_Totvalue+1);
					 //for month end
				}
			
		
		 $_DateEntered1ArrayMyt = $_DateEntered1ArrayMyPer= array();
            if($_WeeklyGlobal == 1)
            {
                if(count($volumesupplier)):
                    foreach($volumesupplier as $volumesupplierData)
                    {
                    $_DateEntered1Array[$volumesupplierData['date_entered']] = $volumesupplierData['date_entered']."_".$volumesupplierData['category_c']."_".$volumesupplierData['origin_c']."_".$volumesupplierData['mytotalfor']."_".$volumesupplierData['mypercentage'];
                    $_DateEntered1ArrayMytWeek = $volumesupplierData['myt'];
					$_DateEntered1ArrayMyTotWeek = $volumesupplierData['mytotalfor'];
					$_DateEntered1ArrayPerWeek = $volumesupplierData['mypercentage'];
					}
                endif;
            }else{
			
                if(count($volumesupplier)):
				
						//echo array_sum($_MYT);
                    foreach($volumesupplier as $volumesupplierData)
                        {
				        if($_POST['period'] == 'daily'):
						 $_DateEnteredArray[] = date('Y-m-d',strtotime($volumesupplierData['date_entered']));
						else:
						 $_DateEnteredArray[] = $volumesupplierData['date_entered'];
						endif;
                        $_DateEntered1Array[$volumesupplierData['date_entered']] = array($volumesupplierData['date_entered'], $volumesupplierData['category_c'], $volumesupplierData['origin_c'], $volumesupplierData['myt'], $volumesupplierData['mypercentage']);
						$_DateEntered1ArrayMyt[$volumesupplierData['date_entered']]+= $volumesupplierData['myt'];  //myt total array
						$_DateEntered1ArrayMyPer[$volumesupplierData['date_entered']]+= $volumesupplierData['mypercentage'];  //myt percentange array
						$_DateEntered1ArrayTotalfor = $volumesupplierData['mytotalfor'];
						}
                endif;
            }
			
					
				  
				
					
					// echo "<br>";
            if(!empty($_DateEntered1Array)):
                foreach($_DateEntered1Array as $_DateEntered1Array1)
                {
                 $_yearRecord[]  = $_DateEntered1Array1[3];
				 $_percentageRecord[]  += $_DateEntered1Array1[4];
                }
            endif;
            //$i = 0;
            $i = 1;
             if(count($_DailyLoopC) > 0):
                if($_QuaterlyGlobal==1):
				$_OpenQua = array();
				for($_OpenQ;$_OpenQ<=$_EndQ;$_OpenQ++){
				$_OpenQua[] = $_OpenQ;
				}
				$temp2 = array();
                
                foreach($_GetPeroid as $_GetPeroidKey => $_GetPeroidData)
                {
                  
					$_GetPeroidDisaply = $_GetPeroidKey;
					$_GetPeroidDisaply =  explode("_",$_GetPeroidDisaply);
				   $_QuaMyt = $_QuaMytPer = "";
				   if(count($_DateEntered1ArrayMyt) > 0):  
					$_QuaMyt =  array_sum($_DateEntered1ArrayMyt);
					$_QuaMytPer =  array_sum($_DateEntered1ArrayMyPer);
				   endif; 
					 
                    $_Qendate = date ("M y", strtotime("+ 2 month", strtotime($_GetPeroidKey)));
                    $_GetPeroidSd = date ("M y", strtotime($_GetPeroidKey));
                    $_GetPeroided = $_Qendate;
                    if($_REQUEST['category_id'] == 'all'):
                        $_Catname = 'All';
                    else:
                        $_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
                    endif;
					
					if($_REQUEST['suppliersku_id'] == 'supplier'){
					     if(isset($_REQUEST['supplier_id'])):
					        $_Supname = $this->getAllSupplierName(implode(",",$_REQUEST['supplier_id']));
						    $_SupName = array();
							foreach( $_Supname as  $_SupnameData)
							  {
							    $_SupName[] =  $_SupnameData['name'];
							  }
							 $_Supname =     implode(",",$_SupName);
							 if($_Supname != '')
							   {	
								$_Supname = $_Supname;
						       }
						       else{
								$_Supname = 'All'; 
						       }
						 endif;	   
						}elseif($_REQUEST['suppliersku_id'] == 'sku'){
						 if(isset($_REQUEST['suppliersku'])):
							$_Supname =  implode(",",$_REQUEST['suppliersku']);
							if($_Supname  !=  'all')
							 {
								$_Supname = $_Supname;
							 }else{
								$_Supname = 'All'; 
							 }
						  endif;	 
						}
					if(date("m") <= 06){
						$_NextYears = date("Y"); // current year
						$_CurrentYear =  date("Y")-1; //previous year 
					}
					else{
						$_CurrentYear =  date("Y"); // current year
						$_NextYears  =  date("Y") + 1;  // post year
					}
					
					$_Startdate = $this->getDateRange( $i, $_CurrentYear."-".$_NextYears);
					$start_date = $_Startdate['start_date'];
					$end_date = $_Startdate['end_date'];
					/***percentage cal****/
					$count_C  = "";
					$total_cases_c = $_DateEntered1ArrayTotalfor;
					if($total_cases_c > 0):
					$num_amount_c = $_QuaMyt;
					$count1_c = $num_amount_c / $total_cases_c;
					$count2_c = $count1_c * 100;
					$count_C = number_format($count2_c, 0);
                    endif;
					 if(in_array($_GetPeroidDisaply[2],$_OpenQua)):
					 
					 $_GetPeroidKey = explode("_",$_GetPeroidKey);
					if($_GetPeroidData==0):

													
                    else:
					     $first_day_this_Quarter = date('Y-m-01',strtotime($_GetPeroidKey[0]));
						 $last_day_this_Quarter  = date('Y-m-t',strtotime($_GetPeroidKey[1]));
						 
						 $conditionQ ='';
						 if($_REQUEST['suppliersku_id'] == 'supplier'):
						 $_SupnameTotal = $this->getAllSupplierName(implode(",",$_REQUEST['supplier_id']));
						 else:
						 $_SupnameTotal = $_REQUEST['suppliersku'];
						 endif;
						 
						 /***quarter code*******/
						 $_FirstDateQuarter = explode("_",$_POST['periodquasdd']);
						 
						 $first_day_SelectedQat_from = $_FirstDateQuarter[0];
						 $_LastDateQuarter = explode("_",$_POST['periodquaedd']);
				         $last_day_SelectedQat_To = $_LastDateQuarter[1];
						 foreach($_SupnameTotal as $check1):
						   
						   $conditionQ .= "  DATE(cases.date_entered) BETWEEN '" . $first_day_this_Quarter . "' AND '" . $last_day_this_Quarter . "' AND ";
						   $_DisplayGrid ="";
						    $supplier = $_REQUEST['suppliersku_id'];
							
							
						   if($_REQUEST['suppliersku_id'] == 'supplier'){
						        $check1 =  $check1['supplier_id'];
						   		$_DisplayGrid = $this->displayBySupplierQuarter($check1,$checkSupplyName,$condition,$condition_group,$conditionQ,$supplier, $_REQUEST['supplier_id'],$first_day_SelectedQat_from,$last_day_SelectedQat_To );
								
								if($_DisplayGrid['prod_supplier_name'] != ""):
                                $_DisplayrecordMsg = 1;
								$volumesupplier_grid[] = "<tr>";	 
								$volumesupplier_grid[] = "<td>".$_GetPeroidKey[3]."</td>";
								$volumesupplier_grid[] = "<td>".$_DisplayGrid['prod_supplier_name']."</td>";
								$volumesupplier_grid[] = "<td>Product</td>";
								$volumesupplier_grid[] = "<td>".$_DisplayGrid['origin_c']."</td>";
								$volumesupplier_grid[] = "<td class=counter onclick='checkclick(this.title)' id=Dailydata_".$_DateEntered1Array[$_DailyLoopCData][0]." title=daily_".$_GetPeroidKey[0]."_".$_GetPeroidKey[1]."_".$check1.">".$_DisplayGrid['myt']."</td>";
								$volumesupplier_grid[] = "<td>".$_DisplayGrid['mypercentage']." %</td>";
								$volumesupplier_grid[] = "</tr>";
								$volumesupplier_grid[] = "<tr class=dailyresulthide id=dailyresult_".$_GetPeroidKey[0]."_".$_GetPeroidKey[1]."_".$check1." style=display:none>
                                                <td colspan='6' class='parent-TD'>
                                                </td></tr>";
							   endif;
							}else if($_REQUEST['suppliersku_id'] == 'sku'){
							    $check1 =  $check1;
								$sku = $_REQUEST['suppliersku_id'];
								$_DisplayGrid = $this->displayBySupplierQuarter($check1,$checkSupplyName,$condition,$condition_group,$conditionQ,$sku,$_SupnameTotal,$first_day_SelectedQat_from,$last_day_SelectedQat_To);
								if($_DisplayGrid['prod_sku'] != ""):
								$_DisplayrecordMsg = 1;
								$volumesupplier_grid[] = "<tr>";	 
								$volumesupplier_grid[] = "<td>".$_GetPeroidKey[3]."</td>";
								$volumesupplier_grid[] = "<td>".$_DisplayGrid['prod_sku']."</td>";
								$volumesupplier_grid[] = "<td>Product</td>";
								$volumesupplier_grid[] = "<td>".$_DisplayGrid['origin_c']."</td>";
								$volumesupplier_grid[] = "<td class=counter onclick='checkclick(this.title)' id=Dailydata_".$_DateEntered1Array[$_DailyLoopCData][0]." title=daily_".$_GetPeroidKey[0]."_".$_GetPeroidKey[1]."_".$check1.">".$_DisplayGrid['myt']."</td>";
								$volumesupplier_grid[] = "<td>".$_DisplayGrid['mypercentage']." %</td>";
								$volumesupplier_grid[] = "</tr>";
								$volumesupplier_grid[] = "<tr class=dailyresulthide id=dailyresult_".$_GetPeroidKey[0]."_".$_GetPeroidKey[1]."_".$check1." style=display:none>
                                                <td colspan='6' class='parent-TD'>
                                                </td></tr>";
								endif;
							}							
						 endforeach;
						 
					
                       /* $volumesupplier_grid[] = "<tr><td>".$_GetPeroidKey[3]."</td>
                                                     <td>".str_replace(","," <br />",$_Supname)."</td>
                                                    <td>".$_Catname."</td> 
													<td>All</td>
													<td class=counter onclick='checkclick(this.title)' id=Dailydata_".$_GetPeroidKey." title=daily_".$_GetPeroidKey[0]."_".$_GetPeroidKey[1].">".$_QuaMyt."</td>
													<td>".$count_C." %</td>
                                                    </tr>";*/
                    endif;
                        $volumesupplier_grid[] = "</tr>";
                        $volumesupplier_grid[] = "<tr class=dailyresulthide id=dailyresult_".$_GetPeroidKey[0]."_".$_GetPeroidKey[1]." style=display:none>
                                                    <td colspan='6' class='parent-TD'>
                                                    </td></tr>";
                    endif;
					$i++;
					
                }
            else:

                $temp2 = array();
                for($p = $_StartW; $p <= $_EndW;$p++){
                    $temp2w[] = $p;
                }
				//print_r($_DailyLoopC);
                foreach($_DailyLoopC as $_DailyLoopCDataKey => $_DailyLoopCData)
                {
					//weekly
					if($_POST['period'] == 'weekly'):
						if(!in_array($i, $temp2w)){
							$i++;
							continue;
						}
					endif;

					if($_WeeklyGlobal == 1):

						/* weekly interval */
						$_WeekStartdate = $_DailyLoopCData; //weekly date start
						$_WeekEnddate = date("Y-m-d", strtotime("+ 1 week", strtotime($_DailyLoopCData))); //weekly date ended
						$_WeekEnddate = date("Y-m-d", strtotime("-1 day", strtotime($_WeekEnddate)));
						$_WeekDateInterval = $this->returnBetweenDates($_WeekStartdate, $_WeekEnddate);

						
						$_GetPeroid = $this->checkReportPeriodsupplierweek($condition, $condition_group, $_WeekStartdate, $_WeekEnddate, $_POST['suppliersku_id']);
						$_WeekStartdate = date("d M Y", strtotime($_WeekStartdate));
						$_WeekEnddate = date("d M Y", strtotime($_WeekEnddate));
              	if($_REQUEST['category_id'] == ''):
							$_Catname = 'All';
						else:
							$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
						endif;
						
						if($_REQUEST['supplier_id'] != ''){
						   $_Supname = $this->getAllSupplierName(implode(",",$_REQUEST['supplier_id']));
						   $_SupName = array();
						   foreach( $_Supname as  $_SupnameData)
						   {
						      $_SupName[] =  $_SupnameData['name'];
						   }
                             $_Supname =     implode(",",$_SupName);
						   
						}elseif($_REQUEST['suppliersku'] != ''){
							$_Supname =  implode(",",$_REQUEST['suppliersku']);
						}else{
							 $_Supname = 'All'; 
						}
						$_MytSum = array();
						
						$_TotWeek = array();
						$_PerWeek = "";
						if(is_array($_GetPeroid))
						{
						  foreach($_GetPeroid as  $_GetPeroidData)
						   {
                             $_MytSum[] =  $_GetPeroidData['myt'];
							 //$_TotWeek[] +=  $_GetPeroidData['mytotalfor'];
							// $_TotWeek[$_GetPeroidData['date_entered']]+= $_GetPeroidData['mypercentage'];  //myt percentange array

							 $_PerWeek[]   =  $_GetPeroidData['mypercentage'];
						   }
						   	
						}
           			if($_GetPeroid==0):
							$volumesupplier_grid[] = "<tr><td><strong>Week ".$i."</strong> (".$_WeekStartdate." - ".$_WeekEnddate.")</td>
														<td>".str_replace(","," <br />",$_Supname)."</td>
														<td>".$_Catname."</td>
														<td>All</td>
														<td>0</td>
														<td>0</td>
														</tr>";
						else:
							$volumesupplier_grid[] = "<tr><td>Week ".$i." (".$_WeekStartdate." - ".$_WeekEnddate.")</td>
														   <td>".str_replace(","," <br />",$_Supname)."</td>
														   <td>".$_Catname."</td>
															<td>All</td>
															<td class=counter onclick='checkclick(this.title)' id=Dailydata_".$_DailyLoopCData." title=daily_".$_DailyLoopCData.">".array_sum($_MytSum)."</td>
															<td>".array_sum($_PerWeek)."</td>
													</tr>";
							$volumesupplier_grid[] = "<tr class=dailyresulthide id=dailyresult_".$_DailyLoopCData." style=display:none>
														 <td colspan='6' class='parent-TD'>
														 </td></tr>";
						endif;
						
					/* weekly interval */
                //monthy interval 
                elseif($_MonthGlobal ==1):

                    if($_REQUEST['category_id'] == 'all'):
                        $_Catname = 'All';
                    else:
                        $_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
                    endif;
					
					if($_REQUEST['suppliersku_id'] == 'supplier'){
					     if(isset($_REQUEST['supplier_id'])):
					        $_Supname = $this->getAllSupplierName(implode(",",$_REQUEST['supplier_id']));
						    $_SupName = array();
							foreach( $_Supname as  $_SupnameData)
							  {
							    $_SupName[] =  $_SupnameData['name'];
							  }
							 $_Supname =     implode(",",$_SupName);
							 if($_Supname != '')
							   {	
								$_Supname = $_Supname;
						       }
						       else{
								$_Supname = 'All'; 
						       }
						 endif;	   
						}elseif($_REQUEST['suppliersku_id'] == 'sku'){
						 if(isset($_REQUEST['suppliersku'])):
							$_Supname =  implode(",",$_REQUEST['suppliersku']);
							if($_Supname  !=  'all')
							 {
								$_Supname = $_Supname;
							 }else{
								$_Supname = 'All'; 
							 }
						  endif;	 
						}
					$_DailyLoopCDataMonth = $_DailyLoopCData;	
		            $_DailyLoopCData =  date("m-Y",strtotime($_DailyLoopCData));
                    $volumesupplier_grid[] = "<tr>"; 
				
				
					if (in_array($_DailyLoopCData, $_DateEnteredArray))
                    { 
					  /*code for getting myt collection for month start*/
					  $_MonthMyt = $_DateEntered1ArrayMyt[$_DateEntered1Array[$_DailyLoopCData][0]];
					  $_MonthPercentage = $_DateEntered1ArrayMyPer[$_DateEntered1Array[$_DailyLoopCData][0]];
					
					  /*code for getting myt collection for month end*/
					  //$key = array_search($_DailyLoopCData, $_DateEnteredArray);
                       // $volumesupplier_grid[] = "<td>". date("M-Y",strtotime($_DailyLoopCDataMonth))."</td>";
						//$volumesupplier_grid[] = "<td>".str_replace(","," <br />",$_Supname)."</td>";
                       // $volumesupplier_grid[] = "<td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>";
                       // $volumesupplier_grid[] = "<td>".$_Catname."</td>";
						// $volumesupplier_grid[] = "<td>All</td>";
                       // $volumesupplier_grid[] = "<td class=counter onclick='checkclick(this.title)' id=Dailydata_".$_DateEntered1Array[$_DailyLoopCData][0]." title=daily_".$_DateEntered1Array[$_DailyLoopCData][0].">".$_MonthMyt."</td>";
						// $volumesupplier_grid[] = "<td>".$_MonthPercentage." %</td>";
						//echo date("m",strtotime($_DailyLoopCDataMonth));
						
						$first_day_this_month = date('Y-m-01',strtotime($_DailyLoopCDataMonth));
						$last_day_this_month  = date('Y-m-t',strtotime($_DailyLoopCDataMonth));
						 
						 $conditionMonth ='';
						 if($_REQUEST['suppliersku_id'] == 'supplier'):
						 $_SupnameTotal = $this->getAllSupplierName(implode(",",$_REQUEST['supplier_id']));
						 else:
						 $_SupnameTotal = $_REQUEST['suppliersku'];
						 endif;
						$first_day_SelectedMonth_from = date('Y-m-01',strtotime($_POST['periodmonthsdd']));
				        $last_day_SelectedMonth_To = date('Y-m-t',strtotime($_POST['periodmonthedd']));
						 foreach($_SupnameTotal as $check1):
						   $conditionMonth .= "  DATE(cases.date_entered) BETWEEN '" . $first_day_this_month . "' AND '" . $last_day_this_month . "' AND ";
						   $_DisplayGrid =$_ForexportSummery="";
						    $supplier = $_REQUEST['suppliersku_id'];
						   if($_REQUEST['suppliersku_id'] == 'supplier'){
						        $check1 =  $check1['supplier_id'];
						   		$_DisplayGrid = $this->displayBySupplier($check1,$checkSupplyName,$condition,$condition_group,$conditionMonth,$supplier,$_REQUEST['supplier_id'],$_ForexportSummery,$first_day_SelectedMonth_from,$last_day_SelectedMonth_To);
								if($_DisplayGrid['prod_supplier_name'] != ""):
								$_DisplayrecordMsg = 1;
								$volumesupplier_grid[] = "<tr>";	 
								$volumesupplier_grid[] = "<td>".date("M-Y",strtotime($_DailyLoopCDataMonth))."</td>";
								$volumesupplier_grid[] = "<td>".$_DisplayGrid['prod_supplier_name']."</td>";
								$volumesupplier_grid[] = "<td>Product</td>";
								$volumesupplier_grid[] = "<td>".$_DisplayGrid['origin_c']."</td>";
								$volumesupplier_grid[] = "<td class=counter onclick='checkclick(this.title)' id=Dailydata_".$_DateEntered1Array[$_DailyLoopCData][0]." title=daily_".$_DateEntered1Array[$_DailyLoopCData][0]."-".$check1.">".$_DisplayGrid['myt']."</td>";
								$volumesupplier_grid[] = "<td>".$_DisplayGrid['mypercentage']." %</td>";
								$volumesupplier_grid[] = "</tr>";
								$volumesupplier_grid[] = "<tr class=dailyresulthide id=dailyresult_".$_DailyLoopCData."-".$check1." style=display:none>
                                                <td colspan='6' class='parent-TD'>
                                                </td></tr>";
							endif;
							}else if($_REQUEST['suppliersku_id'] == 'sku'){
							    $check1 =  $check1;
								$sku = $_REQUEST['suppliersku_id'];
								$_DisplayGrid = $this->displayBySupplier($check1,$checkSupplyName,$condition,$condition_group,$conditionMonth,$sku, $_SupnameTotal,$_ForexportSummery,$first_day_SelectedMonth_from,$last_day_SelectedMonth_To);
								if($_DisplayGrid['prod_sku'] != ""):
								$_DisplayrecordMsg = 1;
								$volumesupplier_grid[] = "<tr>";	 
								$volumesupplier_grid[] = "<td>".date("M-Y",strtotime($_DailyLoopCDataMonth))."</td>";
								$volumesupplier_grid[] = "<td>".$_DisplayGrid['prod_sku']."</td>";
								$volumesupplier_grid[] = "<td>Product</td>";
								$volumesupplier_grid[] = "<td>".$_DisplayGrid['origin_c']."</td>";
								$volumesupplier_grid[] = "<td class=counter onclick='checkclick(this.title)' id=Dailydata_".$_DateEntered1Array[$_DailyLoopCData][0]." title=daily_".$_DateEntered1Array[$_DailyLoopCData][0]."-".$check1.">".$_DisplayGrid['myt']."</td>";
								$volumesupplier_grid[] = "<td>".$_DisplayGrid['mypercentage']." %</td>";
								$volumesupplier_grid[] = "</tr>";
								$volumesupplier_grid[] = "<tr class=dailyresulthide id=dailyresult_".$_DailyLoopCData."-".$check1." style=display:none>
                                                <td colspan='6' class='parent-TD'>
                                                </td></tr>";
								endif;
							}							
						 endforeach;
                    }else{
                    //$volumesupplier_grid[] = "<td>".date("M-Y",strtotime($_DailyLoopCDataMonth))."</td><td>".str_replace(","," <br />",$_Supname)."</td> <td>".$_Catname."</td>
																	// <td>All</td>
																	// <td>0</td>
									                                // <td>0</td>";
                    }
                    $volumesupplier_grid[] = "</tr>";
					
                 

                else:
			
                    $volumesupplier_grid[] = "<tr>";
                    if($_REQUEST['category_id'] == 'all'):
                        $_Catname = 'All';
                    else:
                         $_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
                    endif;
					
										
					if($_REQUEST['suppliersku_id'] == 'supplier'){
					     if(isset($_REQUEST['supplier_id'])):
					        $_Supname = $this->getAllSupplierName(implode(",",$_REQUEST['supplier_id']));
						    $_SupName = array();
							foreach( $_Supname as  $_SupnameData)
							  {
							    $_SupName[] =  $_SupnameData['name'];
							  }
							 $_Supname =     implode(",",$_SupName);
							 if($_Supname != '')
							   {	
								$_Supname = $_Supname;
						       }
						       else{
								$_Supname = 'All'; 
						       }
						 endif;	   
						}elseif($_REQUEST['suppliersku_id'] == 'sku'){
						 if(isset($_REQUEST['suppliersku'])):
							$_Supname =  implode(",",$_REQUEST['suppliersku']);
							if($_Supname  !=  'all')
							 {
								$_Supname = $_Supname;
							 }else{
								$_Supname = 'All'; 
							 }
						  endif;	 
						}
						
				    /***percentage cal****/
					if(count($_DateEnteredArray) > 0):
					$_QuaMyt =  array_sum($_DateEntered1ArrayMyt);
					
					$total_cases_c = $_DateEntered1ArrayTotalfor;
					$num_amount_c = $_QuaMyt;
					$count1_c = $num_amount_c / $total_cases_c;
					$count2_c = $count1_c * 100;
					$count_C = number_format($count2_c, 0);

					endif;
					if($_POST['period'] != 'daily'): 
					  // echo $_DailyLoopCDataKey."<br>";
							if (in_array($_DailyLoopCDataKey, $_DateEnteredArray)):
							//year code start
								if ($_POST['getYearsDd'] != $_POST['getYeareDd']) {
								$end_date = $_curdate;
								$start_date = date('Y-m-1', strtotime("-1 year"));
								} else {
								$start_date = date('Y-m-d', strtotime("$from-01-01"));
								$end_date = date('Y-m-d', strtotime("$from-12-31"));
								}
								$first_day_this_month = $start_date;
								$last_day_this_month  = $end_date;

								$conditionMonth ='';
								if($_REQUEST['suppliersku_id'] == 'supplier'): 
								$_SupnameTotal = $this->getAllSupplierName(implode(",",$_REQUEST['supplier_id']));
								else:
								$_SupnameTotal = $_REQUEST['suppliersku'];
								endif;
							
								 foreach($_SupnameTotal as $check1):
								   $conditionYear .= "  DATE(cases.date_entered) BETWEEN '" . $first_day_this_month . "' AND '" . $last_day_this_month . "' AND ";
								   $_DisplayGrid ="";
									$supplier = $_REQUEST['suppliersku_id'];
								   if($_REQUEST['suppliersku_id'] == 'supplier'){
										$check1 =  $check1['supplier_id'];
										$_DisplayGrid = $this->displayBySupplierYear($check1,$checkSupplyName,$condition,$condition_group,$conditionYear,$supplier,$_REQUEST['supplier_id']);
										if($_DisplayGrid['prod_supplier_name'] != ""):
										$_DisplayrecordMsg = 1;
										$volumesupplier_grid[] = "<tr>";	 
										$volumesupplier_grid[] = "<td>".$_DailyLoopCDataKey ."</td>";
										$volumesupplier_grid[] = "<td>".$_DisplayGrid['prod_supplier_name']."</td>";
										$volumesupplier_grid[] = "<td>".$_Catname."</td>";
										$volumesupplier_grid[] = "<td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>";
										$volumesupplier_grid[] = "<td class=counter onclick='checkclick(this.title)' id=Dailydata_".$_DateEntered1Array[$_DailyLoopCData][0]." title=daily_".$_DailyLoopCDataKey."_".$check1.">".$_DisplayGrid['myt']."</td>";
										$volumesupplier_grid[] = "<td>".$_DisplayGrid['mypercentage']." %</td>";

										$volumesupplier_grid[] = "</tr>";
										$volumesupplier_grid[] = "<tr class=dailyresulthide id=dailyresult_".$_DailyLoopCData."_".$check1." style=display:none>
														<td colspan='6' class='parent-TD'>
														</td></tr>";
														
														//2017_1598
														
									   endif;
									}else if($_REQUEST['suppliersku_id'] == 'sku'){
										$check1 =  $check1;
										$sku = $_REQUEST['suppliersku_id'];
										$_DisplayGrid = $this->displayBySupplierYear($check1,$checkSupplyName,$condition,$condition_group,$conditionYear,$sku,$_SupnameTotal);
										if($_DisplayGrid['prod_sku'] != ""):
										$_DisplayrecordMsg = 1;
										$volumesupplier_grid[] = "<tr>";	 
										$volumesupplier_grid[] = "<td>".$_DailyLoopCDataKey ."</td>";
										$volumesupplier_grid[] = "<td>".$_DisplayGrid['prod_sku']."</td>";
										$volumesupplier_grid[] = "<td>".$_Catname."</td>";
										$volumesupplier_grid[] = "<td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>";
										$volumesupplier_grid[] = "<td class=counter onclick='checkclick(this.title)' id=Dailydata_".$_DateEntered1Array[$_DailyLoopCData][0]." title=daily_".$_DailyLoopCDataKey."_".$check1.">".$_DisplayGrid['myt']."</td>";
										$volumesupplier_grid[] = "<td>".$_DisplayGrid['mypercentage']." %</td>";

										$volumesupplier_grid[] = "</tr>";
										$volumesupplier_grid[] = "<tr class=dailyresulthide id=dailyresult_".$_DailyLoopCData."_".$check1." style=display:none>
														<td colspan='6' class='parent-TD'>
														</td></tr>";
										endif;
									}							
								 endforeach;
						 
                            endif;

                        else:
						    
						if (!in_array($_DailyLoopCData,$_DateEnteredArray))
						{
						   //$volumesupplier_grid[] = "<td>".$_DailyLoopCData."</td>";
							//$volumesupplier_grid[] = "<td>".str_replace(","," <br />",$_Supname)."</td>";
                            //$volumesupplier_grid[] = "<td>".$_Catname."</td>";
							//$volumesupplier_grid[] = "<td>".$this->getCaseOriginName($_REQUEST['origin'])."</td>";
							//$volumesupplier_grid[] = "<td>0</td>";
                           // $volumesupplier_grid[] = "<td>0</td>";
                        }else{
						//$volumesupplier_grid[] = "<td colspan=6>No Record Found</td>";
						}

						endif;	
					//yearly
                  
                    $volumesupplier_grid[] = "</tr>";
                    if($_POST['period'] == 'daily'): 
                    if (in_array($_DailyLoopCData, $_DateEnteredArray))
                    {
                       
					   /* script for showing daily wise record */
                        $_DailSSdate = $_DailyLoopCData; //start date
                        $_DailESdate = date ("Y-m-d", strtotime("+1 day", strtotime($_DailyLoopCData))); //end date

                        $_DailyRowrecord = $this->dailydataDailywiseSupplier($_REQUEST['sub_category_id'], $_REQUEST['origin'], $_REQUEST['category_id'], $_DailSSdate, $_DailESdate ,$mul_supid , $mul_skuid , $_REQUEST['status'],$_REQUEST['branch_store_name']);
                        /* script for showing daily wise record */
                      
 					  foreach($_DailyRowrecord as $_DailyRowrecord1):
					   if($_DailyRowrecord1['prod_supplier_name']):
					        $_DisplayrecordMsg =1;
                            $volumesupplier_grid[] = "<tr style=padding:20px;>";
                            $volumesupplier_grid[] = "<td >".$_DailyRowrecord1['date_entered']."</td>";
							$volumesupplier_grid[] = "<td >".$_DailyRowrecord1['prod_supplier_name']."</td>";
							$volumesupplier_grid[] = "<td >".$_DailyRowrecord1['category_c']."</td>";
							$volumesupplier_grid[] = "<td >".$_DailyRowrecord1['origin_c']."</td>";
							$volumesupplier_grid[] = "<td >NA</td>";    
							$volumesupplier_grid[] = "<td >NA</td>";                       
                            $volumesupplier_grid[] = "</tr>";
						endif;	
                      endforeach;
					}
					endif;
					
                    $volumesupplier_grid[] = "<tr class=dailyresulthide id=dailyresult_".$_DailyLoopCData." style=display:none>
                                                <td colspan='6' class='parent-TD'>
                                                </td></tr>";
                endif;
                //echo $_DailyLoopCData[$i]."checkarrayindex".$_DailyLoopCData[$i+1]."<br>"; 

                $i++;

            }
            endif;
            else:
                if($_QuaterlyGlobal==1):
                    foreach($_GetOneQuarters as $_GetPeroidKey => $_GetPeroidVal):
                        if($_GetPeroidVal==0):
                            $volumesupplier_grid[] = "<tr><td>".$_GetPeroidKey."</td>
                                                        <td colspan=6>We can't find records for this period</td>
                                                        </tr>";
                        else:
                            $volumesupplier_grid[] = "<tr><td>".$_GetPeroidKey."</td>
                                                        <td>".""."</td>
                                                        <td>".""."</td> <td>".""."</td> 
                                                        <td onclick='checkclick(this.title)' id=Dailydata_".$_GetPeroidKey." title=daily_".$_GetPeroidKey.">".$_GetPeroidVal."</td><td>".""."</td>
                                                        </tr>";
                        endif;
                        $volumesupplier_grid[] = "</tr>";
                        $volumesupplier_grid[] = "<tr class=dailyresulthide id=dailyresult_".$_GetPeroidKey." style=display:none>
                                                                                <td colspan='6' class='parent-TD'>
                                                            </td></tr>";
                    endforeach;
                endif;
          

		   endif;
		  // else:
         ////echo "111"; 
       //endif;
        }
    }
    if (isset($total) > 0) {
        $this->view_object_map['total_cases'] = $total;
    } else {
        $this->view_object_map['total_cases'] = 0;
    }
    
	
	if($_DisplayrecordMsg == 0):
	 $volumesupplier_grid[] = "<tr><td class=empty-text colspan=11>We can't find records for this period.</td></tr>";
	endif;
	
	$this->view_object_map['volumesupplierrecord'] = $_DisplayrecordMsg;
	$this->view_object_map['volumesupplier'] = $volumesupplier_grid;
    
}		


function dailydataDailywiseSupplier($_getSubcat,$_getOrigin,$_getCat,$_StartDate , $_EndDate,$sup,$sku , $_getStatus ,$_getBranchstore)
    {
			   global $db, $app_list_strings;
			   $volumesupplier = array();
			   $condition="";
				if(isset($sup)):
                if ($sup == 'all') { 
                $condition .= "";
                }else{
				$condition .= "  cases.prod_supplier_id IN (" .$sup . ") AND ";
				}
                endif;
				
				if(isset($sku)):
				if ($sku == 'all') {
                 $condition .= "";
                }else{
				 $condition .= "  cases.prod_sku  IN ( " . $sku . ") AND ";
				}
                endif;
				
				
				if ($_getCat == "all") {
				$condition .= "";
				}else
				{
				$condition .= "  cases_cstm.category_c = '" . $_getCat . "' AND ";
				}


				if ($_getOrigin == "all")  {
				$condition .= " ";
				}else
				{
				$condition .= "  cases_cstm.origin_c = '" . $_getOrigin . "'  AND ";
				}


				if ($_getSubcat  == "all") {
				$condition .= " ";
				}else
				{
				$condition .= "  cases_cstm.subcategory_c = '" . $_getSubcat . "'  AND ";
				}
			
			    if ($_getStatus  == "all") {
				$condition .= " ";
				}else
				{
				$condition .= "  cases.status = '" . $_getStatus . "'  AND ";
				}
			     
				if ($_getBranchstore == "all"  || $_getBranchstore == "" )  {
				$condition .= " ";
				}else
				{
				$condition .= "  cases.branch_store_name = '" . $_getBranchstore . "'  AND ";
				}
			
			
				 
				 
				 
				 
               $conditiondAILY = " DATE(cases.date_entered) BETWEEN '" .$_StartDate. "' AND '" .  $_StartDate . "' AND";
     
     
                if(isset($sku)):

                        $default_query_case = " SELECT cases.prod_sku as myt, cases.prod_sku,cases.prod_supplier_name,cases.prod_sku, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,
      cases_cstm.loyalty_id_c, cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition .$conditiondAILY. " cases.deleted=0  ORDER BY cases.date_entered DESC";

                    else:

                        $default_query_case = " SELECT cases.prod_supplier_id as myt,
                             cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition .$conditiondAILY. " cases.deleted=0  ORDER BY cases.date_entered DESC";
                    endif;
              // echo $default_query_case;echo "<br />";
                $result = $db->query($default_query_case);
                if($result->num_rows > 0){
                    $total = $result->num_rows;
                }else{
                    $total = 0;
                }
    if($total > 0):
     while ($row = $db->fetchByAssoc($result)) {
      $row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
      $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
      $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
      $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
      $volumesupplier[] = $row;
     }
     else:
      $row['emptyrecord'] = "N/A";
      // $volumecc[] = $row;
     endif;
  
   return $volumesupplier;
    }

 public function getExportContentVolumesupplier($_QueryFD,$_QueryTD,$_QueryPer,$_QueryORI,$_QuerySubCat,$_QueryReportType,$_QueryReportMonthStart,$_QueryReportMonthEnd,$_Wstart,$_Wend, $_Qstart,$_Qend,$_QueryCat,$_QuerySid,$_QueryStatus,$_QuerySuppdeptid,$_QuerySuppsku,$_Query_Sku,$_Qbranchname,$_Qfromyear,$_Qtoyear)
	{
	 global $db, $app_list_strings,$sugar_config;
	  $volumesupplier = $queryCase = $_Yearquery= $_ColumnsDate=$volumeDate=$_DailyLoopC=$_DateEnteredArray
		=$volumesupplier_grid=$_NoOfQuarters=$_GetOneQuarters=$_DateEntered1Array=array();
		$_WeeklyGlobal = $_QuaterlyGlobal = $_MonthGlobal = $_Dailyglobal = 0;
        $condition = $condition_group='';
        $volumesupplier = array();
        $condition = '';
        $groupby='';
		
		if($_QueryPer == "yearly"):
			if ($_Qfromyear && $_Qtoyear):
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$from = $_Qfromyear;
				$to = $_Qtoyear;		
				if ($_Qfromyear != $_Qtoyear) {
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				} else {
				$start_date = date('Y-m-d', strtotime("$from-01-01"));
				$end_date = date('Y-m-d', strtotime("$from-12-31"));
				}
				$condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($start_date)) . "' AND '" . date("Y-m-d", strtotime($end_date)) . "' AND ";
			endif;
			
		elseif($_QueryPer == "monthly"):
		
			$first_day_SelectedMonth_from = date('Y-m-01',strtotime($_QueryReportMonthStart));
			$last_day_SelectedMonth_To = date('Y-m-t',strtotime($_QueryReportMonthEnd));
			$condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($first_day_SelectedMonth_from)) . "' AND '" . date("Y-m-d", strtotime($last_day_SelectedMonth_To)) . "' AND ";
		
		elseif($_QueryPer == "daily"):
		
          if ($_QueryFD && $_QueryTD) {
			$condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($_QueryFD)) . "' AND '" . date("Y-m-d", strtotime($_QueryTD)) . "' AND ";
			}

			
	    endif;
		
		if ($_QueryCat == "all") {
		$condition .= "";
		}else
		{
		 $condition .= "  cases_cstm.category_c = '" . $_QueryCat . "' AND ";
		}

		if ($_QueryStatus == "all") {
		$condition .= "";
		}else
		{
		 $condition .= "  cases.status= '" . $_QueryStatus . "' AND ";
		}
		if ($_QueryORI == "all")  {
		$condition .= " ";
		}else
		{
		$condition .= "  cases_cstm.origin_c = '" . $_QueryORI . "'  AND ";
		}
		
		if ($_QuerySubCat == "all") {
		$condition .= " ";
		}else
		{
		$condition .= "  cases_cstm.subcategory_c = '" . $_QuerySubCat . "'  AND ";
		}
		
		if ($_Qbranchname == "all"  || $_Qbranchname == "" )  {
		$condition .= " ";
		}else
		{
		$condition .= "  cases.branch_store_name = '" . $_Qbranchname . "'  AND ";
		}

		if( $_QuerySuppsku == 'supplier' ):
		$mul_supid='';
		if ($_QuerySid) {
		if($_QuerySid  == "all")
		{
		$condition .= " ";
		}else{
		$condition .= "  cases.prod_supplier_id IN (" .$_QuerySid . ") AND ";
		}
		}
		endif;

		if( $_QuerySuppsku == 'sku'):
		$mul_skuid  ='';
		if ($_Query_Sku) {
		$mul_skuid =  $_Query_Sku;
		if($mul_skuid  == "all")
		{
		$condition .= " ";
		}else{
		$condition .= "  cases.prod_sku  IN ( " . $mul_skuid . ") AND ";
		}
		}
		endif;
         /*checking query starting*/
		$start_date = date("Y-m-d",strtotime($_QueryFD));
	    $end_date = date("Y-m-d",strtotime($_QueryTD));
		/***quarter code*******/
		
		$conditionQ = "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime( $_Qstart)) . "' AND '" . date("Y-m-d", strtotime($_Qend)) . "' AND ";
      if($_QuerySuppsku == 'supplier'):		
        $default_query_case = "SELECT cases.prod_supplier_id as myt,
                        (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition . $conditionQ." cases.deleted=0 ) as mytotalfor,   
						cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku,cases.quality_description,"
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition . $conditionQ." cases.deleted=0  ORDER BY cases.date_entered DESC";
		else:				
		$default_query_case = "SELECT cases.prod_sku as myt,
                        (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition .$conditionQ. " cases.deleted=0 ) as mytotalfor,   
						cases.prod_sku,cases.prod_supplier_name,cases.quality_description,"
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition .$conditionQ. " cases.deleted=0  ORDER BY cases.date_entered DESC";
		endif;	
		//echo $default_query_case;die;
		$result = $db->query($default_query_case);
		$total = $result->num_rows;
	    $volumesupplier_grid = array();
	
		if($total > 0):
			while ($row = $db->fetchByAssoc($result)) {
				$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
				$row['date_entered'] = date("Y-m-d",strtotime($row['date_entered']));
				$row['category_c'] = $this->getCaseCategoryName($row['category_c']);
				$row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
				$volumesupplier[] = $row;
			}
		else:
		$row['emptyrecord'] = "N/A";
		// $volumesupplier[] = $row;
		endif;
		if(count($volumesupplier)> 0):
		if($_QuerySuppsku == 'supplier'):	
			foreach($volumesupplier as $volumesupplier1):
						$volumesupplier_grid1["case_number"] = $volumesupplier1['case_number'];
						$volumesupplier_grid1["date_entered"] = $volumesupplier1['date_entered'];
						$volumesupplier_grid1["prod_supplier_id"] = $volumesupplier1['prod_supplier_id'];
						$volumesupplier_grid1["prod_supplier_name"] = $volumesupplier1['prod_supplier_name'];
						$volumesupplier_grid1["category_c"] = $volumesupplier1['category_c'];
						$volumesupplier_grid1["priority"] = $volumesupplier1['priority'];
						$volumesupplier_grid1["origin_c"] = $volumesupplier1['origin_c'];
						$volumesupplier_grid[] = $volumesupplier_grid1;
					
			endforeach;
		else:	
	
		  foreach($volumesupplier as $volumesupplier1):
						$volumesupplier_grid1["case_number"] = $volumesupplier1['case_number'];
						$volumesupplier_grid1["date_entered"] = $volumesupplier1['date_entered'];
						$volumesupplier_grid1["prod_sku"] = $volumesupplier1['prod_sku'];
						$volumesupplier_grid1["category_c"] = $volumesupplier1['category_c'];
						$volumesupplier_grid1["priority"] = $volumesupplier1['priority'];
						$volumesupplier_grid1["origin_c"] = $volumesupplier1['origin_c'];
						$volumesupplier_grid1["quality_description"] = $volumesupplier1['quality_description'];
						$volumesupplier_grid[] = $volumesupplier_grid1;
					
			endforeach;
		endif;	
			else:
			
			if($_QuerySuppsku == 'supplier'):	
		
						$volumesupplier_grid1["case_number"] = "";
						$volumesupplier_grid1["date_entered"] = "";
						$volumesupplier_grid1["prod_supplier_id"] = "";
						$volumesupplier_grid1["prod_supplier_name"] = "";
						$volumesupplier_grid1["category_c"] = "";
						$volumesupplier_grid1["priority"] = "";
						$volumesupplier_grid1["origin_c"] = "";
						$volumesupplier_grid[] = $volumesupplier_grid1;
					
		else:	
						$volumesupplier_grid1["case_number"] = "";
						$volumesupplier_grid1["date_entered"] = "";
						$volumesupplier_grid1["prod_sku"] = "";
						$volumesupplier_grid1["category_c"] = "";
						$volumesupplier_grid1["priority"] = "";
						$volumesupplier_grid1["origin_c"] = "";
						$volumesupplier_grid1["quality_description"] = "";
						$volumesupplier_grid[] = $volumesupplier_grid1;
					
		endif;	
			endif;
			
		return $volumesupplier_grid;

				
	}
	//new export action for volumesupplier
    public function action_exportvolumesupplier() {
        global $db, $app_list_strings;
		
		$condition =$_QueryFD =$_QueryTD =$_QueryPer=$_QueryORI= $_QueryCat= $_QuerySid =$_QueryStatus=$_QuerySuppdeptid=$_QuerySuppSku=$_Query_Sku=$_QueryReportType= $_QuerySubCat =$start_date=$end_date= $_QueryReportMonthStart=$_QueryReportMonthEnd=
        $_Qbranchstore = "";
		
			
		
	    if(isset($_POST['fromdate']))
          {
		   $_QueryFD =  $_POST['fromdate'];
          }
		  
          if(isset($_POST['enddate']))
          {
		  $_QueryTD =  $_POST['enddate'];
          }

          if(isset($_POST['getperiod']))
          {
		  $_QueryPer =  $_POST['getperiod'];
          }

          if(isset($_POST['origin']))
          {
		  $_QueryORI=  $_POST['origin'];
          }
		  
          if(isset($_POST['getcategory']))
          {
		   
			/*$catid =$_POST['getcategory'];
			$sql = "SELECT name FROM `naku_casecategory` WHERE deleted=0 AND id = '$catid'";
			$result = $GLOBALS['db']->query($sql);
			$row = $db->fetchByAssoc($result); 	
			*/
			$_QueryCat = $_POST['getcategory'];
		  
          }
          
		  if(isset($_POST['getsupplierid']))
          {
		  $_QuerySid =  $_POST['getsupplierid'];
          }
		  
		  if(isset($_POST['status']))
          {
		  $_QueryStatus =  $_POST['status'];
          }
		  if(isset($_POST['getsupplierdeptid']))
          {
		  $_QuerySuppdeptid =  $_POST['getsupplierdeptid'];
          }
		  if(isset($_POST['getSupplierandsku']))
          {
		  $_QuerySuppSku =  $_POST['getSupplierandsku'];
          }
		  if(isset($_POST['getSupplierSKU']))
          {
		  $_Query_Sku =  $_POST['getSupplierSKU'];
          }
		  
		  ////new 
		  
		  if(isset($_REQUEST['queryfromdate']))
          {
		   $_QueryFD =  $_REQUEST['queryfromdate'];
          }
		  
          if(isset($_REQUEST['querytodate']))
          {
		  $_QueryTD =  $_REQUEST['querytodate'];
          }

          if(isset($_REQUEST['queryPeriod']))
          {
		  $_QueryPer =  $_REQUEST['queryPeriod'];
          }

          if(isset($_REQUEST['queryorigin']))
          {
		  $_QueryORI=  $_REQUEST['queryorigin'];
          }

          if(isset($_REQUEST['querycategory']))
          {
		  $_QueryCat =  $_REQUEST['querycategory'];
          }
		  
		  if(isset($_REQUEST['querysubcategory']))
          {
		  $_QuerySubCat =  $_REQUEST['querysubcategory'];
          }
          
		  if(isset($_POST['report_type']))
          {
		  $_QueryReportType =  $_POST['report_type'];
          }
          
		  if(isset($_POST['querySmonth']))
		 {
		   $_QueryReportMonthStart =  $_POST['querySmonth'];
		 }

		 if(isset($_POST['queryEmonth']))
		 {
		  $_QueryReportMonthEnd =  $_POST['queryEmonth'];
		} 		  
		   
		  if(isset($_POST['querysWeek']))
		 {
		  $_Wstart =  $_POST['querysWeek'];
		} 
		 if(isset($_POST['queryeWeek']))
		 {
		  $_Wend =  $_POST['queryeWeek'];
		} 
		   if(isset($_POST['queryeQs']))
		 {
		  $_Qstart =  $_POST['queryeQs'];
		} 
		 if(isset($_POST['queryeQe']))
		 {
		  $_Qend =  $_POST['queryeQe'];
		} 
		if(isset($_POST['queryBranchStore']))
		 {
		  $_Qbranchname =  $_POST['queryBranchStore'];
		} 
		if(isset($_POST['getFromyear']))
		 {
		  $_Qfromyear =  $_POST['getFromyear'];
		} 
		if(isset($_POST['getToyear']))
		 {
		  $_Qtoyear =  $_POST['getToyear'];
		} 
		
		 if(isset($_POST['queryeQs']))
		 {
		  $_Qstart =  $_POST['queryeQs'];
		  $_Qstart_dis = explode("_",  $_Qstart);
		  $_Qstart = $_Qstart_dis[0];
		  $_Wstart = $_Qstart_dis[2]; // this is temprory using for quaarter cal
		} 
		 if(isset($_POST['queryeQe']))
		 {
		   $_Qend =  $_POST['queryeQe']."<br>";
		  $_Qend_dis = explode("_",  $_Qend);
		  $_Qend = $_Qend_dis[1];
		  $_Wend = $_Qend_dis[2];// this is temprory using for quaarter cal
		} 
		
		
		  //eoc
		  if( $_QueryReportType == "detailsreport"){ // summery report
		  $_dataColumns = $this->getExportContentVolumesupplier($_QueryFD,$_QueryTD,$_QueryPer,$_QueryORI,$_QuerySubCat,$_QueryReportType,$_QueryReportMonthStart,$_QueryReportMonthEnd,$_Wstart,$_Wend, $_Qstart,$_Qend,$_QueryCat,$_QuerySid,$_QueryStatus,$_QuerySuppdeptid,$_QuerySuppSku,$_Query_Sku,$_Qbranchname,$_Qfromyear,$_Qtoyear);
		 // echo "<pre>"; print_r($_dataColumns); die;
		  if ($_POST['file_type'] == 'csv') { //Export CSV
                //CSV File name and Header
                $filename = "volumesupplier" . date('Y-m-d:H:i:s') . ".csv";
                $fp = fopen('php://output', 'w');
				if($_QuerySuppSku == 'supplier'):
                $header = array('Case Number','Date','Supplier ID', 'Supplier Description','Case Category', 'Case Priority','Origin');
                else:
				 $header = array('Case Number','Date','SKU','Sku Description','Case Category', 'Case Priority','Origin');

				endif;
				header('Content-type: application/csv');
                header('Content-Disposition: attachment; filename=' . $filename);
                fputcsv($fp, $header);
                $export_list_case = array();
                $default_query_case = "";
				if($_QuerySuppSku == 'supplier'):
					foreach($_dataColumns as $_dataColumns1Val):
						$row['case_number'] = $_dataColumns1Val['case_number'];
						$row['date_entered'] = $_dataColumns1Val['date_entered'];
						$row["prod_supplier_id"] = $_dataColumns1Val['prod_supplier_id'];
						$row["prod_supplier_name"] = $_dataColumns1Val['prod_supplier_name'];
						$row["category_c"] = $_dataColumns1Val['category_c'];
						$row["priority"] = $_dataColumns1Val['priority'];
						$row["origin_c"] = $_dataColumns1Val['origin_c'];
					$export_list_case[] = $row;
					fputcsv($fp, $row); //Genrate CSV
					endforeach;
				else:
					foreach($_dataColumns as $_dataColumns1Val):
						$row['case_number'] = $_dataColumns1Val['case_number'];
						$row['date_entered'] = $_dataColumns1Val['date_entered'];
						$row["prod_sku"] = $_dataColumns1Val['prod_sku'];
						$row["quality_description"] = $_dataColumns1Val['quality_description'];
						$row["category_c"] = $_dataColumns1Val['category_c'];
						$row["priority"] = $_dataColumns1Val['priority'];
						$row["origin_c"] = $_dataColumns1Val['origin_c'];
					$export_list_case[] = $row;
					fputcsv($fp, $row); //Genrate CSV
					endforeach;
				endif;
                fclose($fp);
                exit;
            } elseif ($_POST['file_type'] == 'xls') { //Export XLS
                $list = array();
               if($_QuerySuppSku == 'supplier'):
				 $list['tableheading'] =array('Case Number','Date','Supplier ID', 'Supplier Description','Case Category', 'Case Priority','Origin');
				else:
				 $list['tableheading'] =array('Case Number','Date','SKU','Sku Description','Case Category', 'Case Priority','Origin');
				endif;
				
                $fichier = "volumesupplier" . date('Y-m-d:H:i:s') . ".xls";
                header("Content-Type: text/csv;charset=utf-8");
                header("Content-Disposition: attachment;filename=\"$fichier\"");
                header("Pragma: no-cache");
                header("Expires: 0");
                $fp = fopen('php://output', 'w');
                fputcsv($fp, $list['tableheading']);
                //Fetch data
				$default_query_case = "";
				if($_QuerySuppSku == 'supplier'):
				   foreach($_dataColumns as $_dataColumns1Val):
				    $row['case_number'] = $_dataColumns1Val['case_number'];
					$row['date_entered'] = $_dataColumns1Val['date_entered'];
					$row["prod_supplier_id"] = $_dataColumns1Val['prod_supplier_id'];
					$row["prod_supplier_name"] = $_dataColumns1Val['prod_supplier_name'];
					$row["category_c"] = $_dataColumns1Val['category_c'];
					$row["priority"] = $_dataColumns1Val['priority'];
					$row["origin_c"] = $_dataColumns1Val['origin_c'];
					$data['list'] = $row;
					fputcsv($fp, $data['list']); //Genrate CSV
				endforeach;
				else:
				   foreach($_dataColumns as $_dataColumns1Val):
				    $row['case_number'] = $_dataColumns1Val['case_number'];
					$row['date_entered'] = $_dataColumns1Val['date_entered'];
					$row["prod_sku"] = $_dataColumns1Val['prod_sku'];
					$row["quality_description"] = $_dataColumns1Val['quality_description'];
					$row["category_c"] = $_dataColumns1Val['category_c'];
					$row["priority"] = $_dataColumns1Val['priority'];
					$row["origin_c"] = $_dataColumns1Val['origin_c'];
				   $data['list'] = $row;
					fputcsv($fp, $data['list']); //Genrate CSV
				endforeach;
				endif;
				
			   fclose($fp);
                exit();
            }elseif($_POST['file_type'] == 'pdf'){
               require_once 'include/dompdf/dompdf_config.inc.php';
			   global $current_user;
			   $name = $current_user->first_name . '&nbsp;' . $current_user->last_name;
			   $current_date = date('d/m/Y  h:i A');
			   $dompdf = new Dompdf();
			   //echo '<pre>';
			   //print_r($_dataColumns);
			  // die;
			  
			  if($_QueryPer  == 'daily'):
			   $_Period = "Daily";
			   $start_date =$_QueryFD;
			   $end_date =$_QueryTD;
			  elseif($_QueryPer  == 'monthly'):
			   $_Period = "Monthly";
			   $start_date =$_QueryReportMonthStart;
			   $end_date =$_QueryReportMonthEnd;
			  elseif($_QueryPer  == 'quarterly'):
			   $_Period = "Quarter";
			   $start_date = "Quarter ".$this->Quarterlabelreportpdf($_POST['queryeQs']);
			   $end_date = "Quarter ".$this->Quarterlabelreportpdf($_POST['queryeQe']);
			  elseif($_QueryPer  == 'weekly'):
			   $_Period = "Weekly";
			   $start_date =  $_Wstart;
			   $end_date =  $_Wend;
				
			  else:
			    $_Period = "Annual";
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$from = $_Qfromyear;
				$to = $_Qtoyear;

				if ($_Qfromyear != $_Qtoyear) {
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				} else {
				$start_date = date('Y-m-d', strtotime("$from-01-01"));
				$end_date = date('Y-m-d', strtotime("$from-12-31"));
				}
				
				endif;	
				
				if($_QueryORI == 'all'):
			    $_CaseOriginPdf = 'All';
			   else:
			    $_CaseOriginPdf = $this->getCaseOriginName($_QueryORI);
			   endif;

				if($_QueryCat == 'all'):
			    $_CaseOriginCat = 'All';
			   else:
			    $_CaseOriginCat = $this->getCaseCategoryName($_QueryCat);
			   endif;
			   
			   if($_QuerySubCat == 'all'):
			    $_CaseOriginSubCat = 'All';
			   else:
			    $_CaseOriginSubCat = $this->getCaseSubCategoryName($_QuerySubCat);
			   endif;
					$header = '<html>
            <body>
                <div style="width:100%;color:#fff;background:#17479d;padding:5px 0px;margin:0px;text-align:center;">
                    <img src="custom/include/images/logo.png" style="padding: 7px;position: absolute;left: 10px;"><h2>Volume of Cases By Suppliers or Products </h2>
                </div>
				<br />
				<table style="width:450px; margin:0 auto; text-align:left;">
				    <tr>
						<td style="width="20%"><b>From  - </b></td>
						<td style="width="10%">'.$start_date.'</td>
						<td style="width="20%"><b>To  - </b></td>
						<td style="width="10%">'.$end_date.'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Period  - </b></td>
						<td style="width="50%">'.ucfirst($_QueryPer).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Origin  - </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginPdf).'</td>
					</tr>';
					
				if($_Qbranchname == 'all'):
				$header .= '<tr>
						<td style="width="50%"><b>Branch Store - </b></td>
						<td style="width="50%">All</td>
					</tr>';
					elseif($_Qbranchname == ''):
				$header .= ''; 
					   else:
						 $header .= '<tr>
						<td style="width="50%"><b>Branch Store  - </b></td>
						<td style="width="50%">'.ucfirst($_Qbranchname).'</td>
					</tr>'; 
					   endif;
				$header .=	'<tr>
						<td style="width="50%"><b>Case Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginCat).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Sub Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginSubCat).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Status  -  </b></td>
						<td style="width="50%">'.ucfirst($_QueryStatus).'</td>
					</tr>
					
				</table>';
								 
				if($_QuerySuppSku == 'supplier'){
						$content .= '<table border="1" cellspacing="0" cellpadding="5" width="100%">  
							<thead>
							<tr>
									<th nowrap>Case Id</th>
									<th nowrap>Date</th>
									<th nowrap>Supplier ID</th>
									<th nowrap>Supplier Description</th>
									<th nowrap>Case Origin</th> 
									<th nowrap>Case Category</th>  
								</tr>
						</thead>';
						foreach($_dataColumns as $_dataColumns1Val):
							$content .= '<tbody>
								<tr>
								  <td>' . $_dataColumns1Val["case_number"] . '</td>
								  <td>' . $_dataColumns1Val["date_entered"] . '</td>
								  <td>' . $_dataColumns1Val["prod_supplier_id"] . '</td>
								  <td>' . $_dataColumns1Val["prod_supplier_name"] . '</td>
								  <td>' . $_dataColumns1Val["origin_c"] . '</td>
								  <td>' . $_dataColumns1Val["category_c"] . '</td>
							 </tr>
							<tbody>';
						
						endforeach;
						
						$content .= '</table>';
				}else{
					$content .= '<table border="1" cellspacing="0" cellpadding="5" width="100%">  
							<thead>
							<tr>
									<th nowrap>Case Id</th>
									<th nowrap>Date</th>
									<th nowrap>SKU</th>
									<th nowrap>SKU Description</th>
									<th nowrap>Case Origin</th> 
									<th nowrap>Case Category</th>  
								</tr>
						</thead>';
						foreach($_dataColumns as $_dataColumns1Val):
							$content .= '<tbody>
								<tr>
								  <td>' . $_dataColumns1Val["case_number"] . '</td>
								  <td>' . $_dataColumns1Val["date_entered"] . '</td>
								  <td>' . $_dataColumns1Val["prod_sku"] . '</td>
								  <td>' . $_dataColumns1Val["quality_description"] . '</td>
								  <td>' . $_dataColumns1Val["origin_c"] . '</td>
								  <td>' . $_dataColumns1Val["category_c"] . '</td>
							 </tr>
							<tbody>';
						
						endforeach;
						
						$content .= '</table>';
				}
				
				
				$footer = '<table style="width:100%;color:#ccc;background:#17479d;padding:5px 0px;margin:0px;">
								<tr>
							<td width="30%"><span style="float:left!important;margin-left:10px;">Printed by: ' . $name . '&nbsp;' . $current_date . '</span></td>
							<td style="text-align:center;width:30%;">www.nakumatt.net</td>
							<td  width="30%">&nbsp;</td>
								</tr>
							</table>
							<h4 style="color:red;">The content is confidential and not meant to be shared in any form with any external persons / entities.</h4>
							</body>
							</html>';
				$html = $header . $content . $footer;
				$dompdf->load_html($html);
				// (Optional) Setup the paper size and orientation
				$dompdf->set_paper('A4', 'landscape');
				// Render the HTML as PDF
				$dompdf->render();
				// Output the generated PDF to Browser
				$filename = "Volume of Cases By Suppliers " . date('Y-m-d:H:i:s') . ".pdf";
				$dompdf->stream($filename);			
			   //pdf report
			    }  
		}elseif( $_QueryReportType == "summeryreport" ){  
		 $_MYT = array();
		   $_dataColumns = $this->getExportContentsummeryreportSupplier($_QueryFD,$_QueryTD,$_QueryPer,$_QueryORI,$_QueryCat,$_QuerySubCat,$_QueryReportType,$_QueryReportMonthStart,$_QueryReportMonthEnd,$_Wstart,$_Wend, $_Qstart,$_Qend,$_QueryStatus,$_QuerySid,$_QuerySuppSku,$_Query_Sku,$_Qbranchname,$_Qfromyear,$_Qtoyear);  //calling function to get export data
		  //echo "<pre>"; print_r($_REQUEST);exit;
		//echo "<pre>";
	//	print_r($_dataColumns); 
	// die;
		
		   $_Period = "";
			if ($_POST['file_type'] == 'csv') { //Export CSV
                //CSV File name and Header
                $filename = "volumesupplier_summery_report" . date('Y-m-d:H:i:s') . ".csv";
                $fp = fopen('php://output', 'w');
				
				if($_QueryPer == 'daily'):
				 $_Period = "Daily";
				elseif($_QueryPer =='weekly'):
				 $_Period = "Weekly";
				elseif($_QueryPer == 'monthly'):
				 $_Period = "Monthly";
				elseif($_QueryPer == 'quarterly'):
				 $_Period = "Quarterly";
				elseif($_QueryPer == 'annual'):
				 $_Period = "Annual";
				endif;
                $header = array($_Period,'Count');
                header('Content-type: application/csv');
                header('Content-Disposition: attachment; filename=' . $filename);
                fputcsv($fp, $header);
				$condition ="";
				$export_list_case = array();
				foreach($_dataColumns as $_dataColumns1Key => $_dataColumns1Val):
				$row['period'] =  $_dataColumns1Val[0];
				
				
				if($_QueryPer == 'quarterly'):
							 if(is_array($_dataColumns1Val[1])):
									foreach($_dataColumns1Val[1] as $_dataColumns1Val1 => $_dataColumns1ValData1):
										$_MYT[] =   $_dataColumns1ValData1['myt'];
									endforeach;
							 endif;
				$row['count'] = array_sum($_MYT);
				else:
				$row['count'] = $_dataColumns1Val[1];
				endif;
				
				$export_list_case[] = $row;
			    fputcsv($fp, $row); //Genrate CSV
				endforeach;
				fclose($fp);
                exit;
            } elseif ($_POST['file_type'] == 'xls') { //Export XLS
                $list = array();
				if($_QueryPer == 'daily'):
				 $_Period = "Daily";
				elseif($_QueryPer =='weekly'):
				 $_Period = "Weekly";
				elseif($_QueryPer == 'monthly'):
				 $_Period = "Monthly";
				elseif($_QueryPer == 'quarterly'):
				 $_Period = "Quarterly";
				elseif($_QueryPer == 'annual'):
				 $_Period = "Annual";
				endif;
				
                $list['tableheading'] = array($_Period,'Count');
                $fichier = "CS" . date('Y-m-d:H:i:s') . ".xls";
                header("Content-Type: text/csv;charset=utf-8");
                header("Content-Disposition: attachment;filename=\"$fichier\"");
                header("Pragma: no-cache");
                header("Expires: 0");
                $fp = fopen('php://output', 'w');
                fputcsv($fp, $list['tableheading']);
                //Fetch data
				
                foreach($_dataColumns as $_dataColumns1Val):
				$row['week'] =  $_dataColumns1Val[0];
				if($_QueryPer == 'quarterly'):
							 if(is_array($_dataColumns1Val[1])):
									foreach($_dataColumns1Val[1] as $_dataColumns1Val1 => $_dataColumns1ValData1):
										$_MYT[] =   $_dataColumns1ValData1['myt'];
									endforeach;
							 endif;
				$row['count'] = array_sum($_MYT);
				else:
				$row['count'] = $_dataColumns1Val[1];
				endif;
				$data['list'] = $row;
				//$export_list_case[] = $row;
			    fputcsv($fp, $data['list']); //Genrate CSV
				endforeach;
				fclose($fp);
                exit();
            }elseif($_POST['file_type'] == 'pdf'){
				require_once 'include/dompdf/dompdf_config.inc.php';
			   global $current_user;
			   
			  if($_QueryPer  == 'daily'):
			   $_Period = "Daily";
			   $start_date =$_QueryFD;
			   $end_date =$_QueryTD;
			  elseif($_QueryPer  == 'monthly'):
			   $_Period = "Monthly";
			   $start_date =$_QueryReportMonthStart;
			   $end_date =$_QueryReportMonthEnd;
			  elseif($_QueryPer  == 'quarterly'):
			   $_Period = "Quarter";
			   $start_date = "Quarter ".$this->Quarterlabelreportpdf($_POST['queryeQs']);
			   $end_date = "Quarter ".$this->Quarterlabelreportpdf($_POST['queryeQe']);
			  elseif($_QueryPer  == 'weekly'):
			   $_Period = "Weekly";
			   $start_date =  $_Wstart;
			   $end_date =  $_Wend;
				
			  else:
			  $_Period = "Annual";
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$from = $_Qfromyear;
				$to = $_Qtoyear;

				if ($_Qfromyear != $_Qtoyear) {
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				} else {
				$start_date = date('Y-m-d', strtotime("$from-01-01"));
				$end_date = date('Y-m-d', strtotime("$from-12-31"));
				}
						
						
				endif;	
				
			   $name = $current_user->first_name . '&nbsp;' . $current_user->last_name;
			   $current_date = date('d/m/Y  h:i A');
			   $dompdf = new Dompdf();
			 
			

			
				
				if($_QueryORI == 'all'):
			    $_CaseOriginPdf = 'All';
			   else:
			    $_CaseOriginPdf = $this->getCaseOriginName($_QueryORI);
			   endif;

				if($_QueryCat == 'all'):
			    $_CaseOriginCat = 'All';
			   else:
			    $_CaseOriginCat = $this->getCaseCategoryName($_QueryCat);
			   endif;
			   
			   if($_QuerySubCat == 'all'):
			    $_CaseOriginSubCat = 'All';
			   else:
			    $_CaseOriginSubCat = $this->getCaseSubCategoryName($_QuerySubCat);
			   endif;
			   
			 $header = '<html>
				<body>
                <div style="width:100%;color:#fff;background:#17479d;padding:5px 0px;margin:0px;text-align:center;">
                    <img src="custom/include/images/logo.png" style="padding: 7px;position: absolute;left: 10px;"><h2>Volume of Cases By Suppliers or Products </h2>
                </div>
				<br />
				<table style="width:450px; margin:0 auto; text-align:left;">
				    <tr>
						<td style="width="20%"><b>From  - </b></td>
						<td style="width="10%">'.$start_date.'</td>
						<td style="width="20%"><b>To  - </b></td>
						<td style="width="10%">'.$end_date.'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Period  - </b></td>
						<td style="width="50%">'.ucfirst($_QueryPer).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Origin  - </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginPdf).'</td>
					</tr>';
				if($_Qbranchname == 'all'):
				$header .= '<tr>
						<td style="width="50%"><b>Branch Store - </b></td>
						<td style="width="50%">All</td>
					</tr>';
					elseif($_Qbranchname == ''):
				$header .= ''; 
					   else:
						 $header .= '<tr>
						<td style="width="50%"><b>Branch Store  - </b></td>
						<td style="width="50%">'.ucfirst($_Qbranchname).'</td>
					</tr>'; 
					   endif;
				 $header .= '<tr>
						<td style="width="50%"><b>Case Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginCat).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Sub Category  -  </b></td>
						<td style="width="50%">'.ucfirst($_CaseOriginSubCat).'</td>
					</tr>
					<tr>
						<td style="width="50%"><b>Case Status  -  </b></td>
						<td style="width="50%">'.ucfirst($_QueryStatus).'</td>
					</tr>
					
				</table>';
			    $content .= '<table border="1" cellspacing="0" cellpadding="5" width="100%">  
                    <thead>
                        <tr>
                            <th nowrap>'.$_Period.'</th>
                            <th nowrap>Count</th>
                        </tr>
                </thead>';
				
				
				if($_QueryPer == 'quarterly'):
				
				
					foreach($_dataColumns as $_dataColumns1Val => $_dataColumns1ValData):
						$content .= '<tbody>
                        <tr>
                           <td>' .$_dataColumns1ValData[0]. '</td>
							
                           <td>' .$_dataColumns1ValData[1]. '</td>
                      </tr>
                     <tbody>';
					endforeach;	 
				else:

                  foreach($_dataColumns as $_dataColumns1Val => $_dataColumns1ValData):
					$content .= '<tbody>
                        <tr>
                           <td>' .$_dataColumns1ValData[0]. '</td>
							
                           <td>' .$_dataColumns1ValData[1]. '</td>
                      </tr>
                     <tbody>';
					
					endforeach;
                endif;				
				$content .= '</table>';
				$footer = '<table style="width:100%;color:#ccc;background:#17479d;padding:5px 0px;margin:0px;">
								<tr>
							<td width="30%"><span style="float:left!important;margin-left:10px;">Printed by: ' . $name . '&nbsp;' . $current_date . '</span></td>
							<td style="text-align:center;width:30%;">www.nakumatt.net</td>
							<td  width="30%">&nbsp;</td>
								</tr>
							</table>
							<h4 style="color:red;">The content is confidential and not meant to be shared in any form with any external persons / entities.</h4>
							</body>
							</html>';
				$html = $header . $content . $footer;
				
				$dompdf->load_html($html);
				// (Optional) Setup the paper size and orientation
				$dompdf->set_paper('A4', 'landscape');
				// Render the HTML as PDF
				$dompdf->render();
				// Output the generated PDF to Browser
				$filename = "Volume of Cases By Suppliers" . date('Y-m-d:H:i:s') . ".pdf";
				$dompdf->stream($filename);			
			   //pdf report
			 //pdf report
			
		    }     
		}
		 
		 
    }
	
	
	  //1.2.1.3.7 Volume of Cases By Suppliers or Products for Quality Complaints
    public function getExportContentsummeryreportSupplier($_QueryFD,$_QueryTD,$_QueryPer,$_QueryORI,$_QueryCat,$_QuerySubCat,$_QueryReportType,$_QueryReportMonthStart,$_QueryReportMonthEnd,$_Wstart,$_Wend, $_Qstart,$_Qend,$_QueryStatus,$_QuerySid,$_QuerySuppSku,$_Query_Sku,$_Qbranchname,$_Qfromyear,$_Qtoyear){
	
        global $db, $app_list_strings, $sugar_config;
		$ReportName = 'volumesupplier';
        $this->view = 'volumesupplier';
		$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1

		//$this->view_object_map['getAllSupplierName'] = $this->getAllSupplierName();
		$this->view_object_map['getAllSupplierFromCases'] = $this->getAllSupplierFromCases();
		$this->view_object_map['getAllSKUFromCases'] = $this->getAllSKUFromCases();
		
        $this->view_object_map['getTimePeriod'] = $this->getTimePeriod();
        $this->view_object_map['createMonthdd'] = $this->createMonthdd();
        $this->view_object_map['creatWeeklydd'] = $this->creatWeeklydd();
        $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1

        $this->view_object_map['getAllCaseCategory'] = $this->getAllCaseCategory();
        $this->view_object_map['getAllSupplierDetails'] = $this->getAllSupplierDetailsReports();
        $this->view_object_map['getAllSupplierDepartment'] = $this->getAllSupplierDepartment();
        $this->view_object_map['site_url'] = $sugar_config['site_url'];

		$volumesupplier = $queryCase = $_Yearquery = $_ColumnsDate = $volumeDate = $_DailyLoopC = $_DateEnteredArray = $volumesupplier_grid = $_NoOfQuarters = $_GetOneQuarters = $_DateEntered1Array = $_percentageRecord = $_yearRecord =  array();
        $_WeeklyGlobal = $_QuaterlyGlobal = $_MonthGlobal = $_Dailyglobal = 0;
		
		
		$condition = $condition_group=$_StartMonth = $_EndMonth = $_StartW= $_EndW  =$_StartQ  =$_EndQ = $_QuaMyt='';
		
		
        $groupby = '';
       
		
		if ($_Qfromyear && $_Qtoyear) {
			$from = $_Qfromyear;
			$to = $_Qtoyear;		
			if ($_Qfromyear != $_Qtoyear) {
			$end_date = $_curdate;
			$start_date = date('Y-m-1', strtotime("-1 year"));
			} else {
			$start_date = date('Y-m-d', strtotime("$from-01-01"));
			$end_date = date('Y-m-d', strtotime("$from-12-31"));
			}
			$condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($start_date)) . "' AND '" . date("Y-m-d", strtotime($end_date)) . "' AND ";
			}else
		{
			if ($_QueryFD && $_QueryTD) {
			$condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($_QueryFD)) . "' AND '" . date("Y-m-d", strtotime($_QueryTD)) . "' AND ";
			}
		}
		
		
		if ($_QueryCat == "all") {
		$condition .= "";
		$condition_group .= "";	
		}else
		{
		 $condition .= "  cases_cstm.category_c = '" . $_QueryCat . "' AND ";
		 $condition_group .= ",cases_cstm.category_c";
		}

		if ($_QueryStatus == "all") {
		$condition .= "";
		$condition_group .= "";	
		}else
		{
		 $condition .= "  cases.status= '" . $_QueryStatus . "' AND ";
		 $condition_group .= ",cases.status";
		}

		if ($_QueryORI == "all")  {
		$condition .= " ";
		$condition_group .= "";	
		}else
		{
		$condition .= "  cases_cstm.origin_c = '" . $_QueryORI . "'  AND ";
		$condition_group .= ",cases_cstm.origin_c";
		}
		
		if ($_QuerySubCat == "all") {
		$condition .= " ";
		$condition_group .= "";	
		}else
		{
		$condition .= "  cases_cstm.subcategory_c = '" . $_QuerySubCat . "'  AND ";
		$condition_group .= ",cases_cstm.subcategory_c";
		}
		
		if ($_Qbranchname == "all"  || $_Qbranchname == "" )  {
		$condition .= " ";
		$condition_group .= "";	
		}else
		{
		$condition .= "  cases.branch_store_name = '" . $_Qbranchname . "'  AND ";
		$condition_group .= ",cases.branch_store_name";
		}
				
		if( $_QuerySuppSku == 'supplier' ):
		$mul_supid='';
		if ($_QuerySid) {
		$_QuerySid  = $_QuerySid;
		if($_QuerySid  == "all")
		{
		$condition .= " ";
		$condition_group .= "";	
		}else{
		//$condition .= "  cases.prod_supplier_id IN (" .$_QuerySid . ") AND ";
		//$condition_group .= ",cases.prod_supplier_id";
		}
		}
		endif;

		if( $_QuerySuppSku == 'sku'):
		$mul_skuid  ='';
		if ($_Query_Sku) {
		$mul_skuid =  $_Query_Sku;
		if($mul_skuid  == "all")
		{
		$condition .= " ";
		$condition_group .= "";	
		}else{
	//	$condition .= "  cases.prod_sku  IN ( " . $mul_skuid . ") AND ";
		//$condition_group .= ",cases.prod_sku";
		}
		}
		endif;

                if(!empty($_QueryReportMonthStart)):
                $_StartMonth = $_QueryReportMonthStart;
                endif;

                if(!empty($_QueryReportMonthEnd)):
                $_EndMonth = $_QueryReportMonthEnd;
                endif;

                if(!empty($_Wstart)):
                $_StartW = $_Wstart;
                endif;

                if(!empty($_Wend)):
                $_EndW = $_Wend;
                endif;

                if(!empty($_Qstart)):
                $_StartQ = $_Qstart;
                endif;

                if(!empty($_Qend)):
                $_EndQ = $_Qend;
                endif;

				
                if ($_REQUEST['supplier_dept_id']) {
                $condition .= "  naku_suppliers.supplier_department = '" . trim($_REQUEST['supplier_dept_id']) . "' AND ";
                $condition_group .='';
                }
                /* checking query starting */

                $start_date = date("Y-m-d", strtotime($_REQUEST['from_date']));
                $end_date = date("Y-m-d", strtotime($_REQUEST['to_date']));

                $start_date = $_REQUEST['from_date']; //fromdate for post
                $this->view_object_map['getFromDate'] = $start_date;
                $end_date = $_REQUEST['to_date']; //todate for post
                $this->view_object_map['getToDate'] = $end_date;
                $_Periodpost = $_REQUEST['period']; //period for post
                $this->view_object_map['getPeriod'] = $_Periodpost;
                $_Originpost = $_REQUEST['origin']; //origin for post
                $this->view_object_map['getOrigin'] = $_Originpost;
                $_Categorypost = $_REQUEST['category_id']; //categoryid for post

                //new cases
             
             if($_QueryPer == 'weekly'):
    
                if(date("m") <= 06){
                $_CurrentYear = date("Y"); // current year
                $_NextYears = date("Y")-1; //previous year 

                $start_date = date($_NextYears.'-07-01'); //common from date
                $end_date = date($_CurrentYear.'-06-30');
                $_WeekLoopCount = $this->datediff('ww', $start_date, $end_date )." Week<br>";

                }else{
                $_CurrentYear = date("Y"); // current year
                $_NextYears = date("Y") + 1;  // post year
                $start_date = date($_CurrentYear.'-07-01'); //common from date
                $end_date = date($_NextYears.'-06-30');
                $_WeekLoopCount = $this->datediff('ww', $start_date, $end_date )." Week<br>";

                }

                for($i = 0;$i<=$_WeekLoopCount;$i++)
                {
                $_DailyLoopC[] = date ("Y-m-d", strtotime("+ $i week", strtotime($start_date)));
                }

                $_WeeklyGlobal = 1;

                $condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d", strtotime($start_date)) . "' AND '" . date("y-m-d", strtotime($end_date)) . "' AND ";

				 if(isset($_REQUEST['suppliersku'])):

                        $default_query_case = " SELECT count(cases.id) as myt,(SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c  "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition . " cases.deleted=0 ) as mytotalfor,   
                                                                                        cases.prod_sku,cases.prod_supplier_name, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition . " cases.deleted=0  GROUP BY week(cases.date_entered) ".$condition_group ." ORDER BY cases.date_entered DESC";

                    else:

                        $default_query_case = " SELECT count(cases.id) as myt,
                         (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                        . " where " . $condition . " cases.deleted=0 ) as mytotalfor,   
                             cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                        . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                        . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                        . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                        . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                        . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                        . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                        . " cases.date_entered , cases.assigned_user_id  FROM cases "
                        . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                        . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                        . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                        . " where " . $condition . " cases.deleted=0  GROUP BY week(cases.date_entered) ".$condition_group ." ORDER BY cases.date_entered DESC";
                    endif;
                $result = $db->query($default_query_case);
                $total = $result->num_rows;
                if($total > 0):
                    while ($row = $db->fetchByAssoc($result)) {
                        $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                        $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                        $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                        $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
						
						$total_cases = $row['mytotalfor'];
						$num_amount = $row['myt'];
						$count1 = $num_amount / $total_cases;
						$count2 = $count1 * 100;
						$count = number_format($count2, 0);
						$row['mypercentage'] = $count;
					
					
                        $volumesupplier[] = $row;
                    }
				else:
					$row['emptyrecord'] = "N/A";
					// $volumesupplier[] = $row;
				endif;
            elseif($_QueryPer == "monthly"):
                
                $_MonthGlobal = 1;
			    $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
				$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
				$start_date  = $_Year."-".$_Month."-"."1";  //start date
				$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
				$_MonthLoopCount = $this->datediff('m',date("y-m-d",strtotime($start_date )),date("y-m-d",strtotime($end_date)));				 
				/*month logic end */
				for($i=0;$i<=$_MonthLoopCount+1;$i++)
				{
				$_DailyLoopC[] =  date ("M-Y", strtotime("+ $i month", strtotime($start_date)));
				}

                // $_MonthLoopCount = $this->datediff('m',date("y-m-d",strtotime($_REQUEST['from_date'])),date("y-m-d",strtotime($_REQUEST['to_date'])));		

                for($i = 0; $i<=$_MonthLoopCount+1; $i++)
                {
                $_DailyLoopC[] = date ("M-Y", strtotime("+ $i month", strtotime($start_date)));
                }
                $condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d",strtotime($start_date)) . "' AND '" . date("y-m-d",strtotime($end_date)) . "' AND ";

                if($_QuerySuppSku== "supplier"):
                 $default_query_case = " SELECT count(cases.id) as myt,cases.date_entered, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition . " cases.deleted=0 ) as mytotalfor, 				
				cases.prod_sku,cases.prod_supplier_name, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition . " cases.deleted=0  GROUP BY month(cases.date_entered) ".$condition_group ." ORDER BY cases.date_entered DESC";
                else:
                 $default_query_case = " SELECT count(cases.id) as myt,cases.date_entered, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition . " cases.deleted=0 ) as mytotalfor,
				cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition . " cases.deleted=0  GROUP BY month(cases.date_entered) ".$condition_group ." ORDER BY cases.date_entered DESC";
                endif;
    //month(cases.date_entered),cases.prod_supplier_id ORDER BY cases.date_entered DESC";
                $result = $db->query($default_query_case);
                $total = $result->num_rows;
                if($total > 0):
                    while ($row = $db->fetchByAssoc($result)) {
                    $row['date_entered'] = date("m-Y", strtotime($row['date_entered']));
                    $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                    $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                    $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';

                    $num_amount = $row['myt'];
                    if($row['mytotalfor'] != 0){
                        $total_cases = $row['mytotalfor'];
                        $count1 = $num_amount / $total_cases;
                        $count2 = $count1 * 100;
                        $count = number_format($count2, 0);
                        $row['mypercentage'] = $count;
                    }
                    $volumesupplier[] = $row;

                    }
                else:
                    $row['emptyrecord'] = "N/A";
                    // $volumesupplier[] = $row;
                endif;
            elseif($_QueryPer == "quarterly"):
                $_QuaterlyGlobal = 1;
                /*quater logic start*/
			    $_OpenQ =$_StartW ;
			    $_EndQ = $_EndW ;
				/* end */ 
				$_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				
				$this->view_object_map['creatQudd'] = $this->creatQuarterdd($start_date,$end_date);
				//echo "<pre>";
				//print_r($this->view_object_map['creatQudd'] );
                
				$_GetQuarters = $this->creatQuarterdd($start_date,$end_date);

				foreach($_GetQuarters as $_GetQuarters1Key=>$_GetQuarters1)
				{
				$_Startq = explode("_",$_GetQuarters1Key); 
				$_DailyLoopC[$_GetQuarters1Key] = $_GetQuarters1;
				$_GetPeroid[$_GetQuarters1Key."_".$_GetQuarters1] = $this->checkReportPeriodQuartervolsupplier($condition,$condition_group,$_Startq[0],$_Startq[1],$ReportName, $_QuerySuppSku);
				$_DateEntered1ArrayMyt[$volumesupplierDataQ['date_entered']]+= $volumesupplierDataQ['myt'];  //myt total 
				$_DateEntered1ArrayMyPer[$volumesupplierDataQ['date_entered']]+= $volumesupplierDataQ['mypercentage'];  
                }
				 if(isset($_QuerySuppSku)):
                $default_query_case = " SELECT count(cases.id) as myt,cases.date_entered, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition . " cases.deleted=0 ) as mytotalfor,   cases.prod_sku,cases.prod_supplier_name,cases.prod_sku, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition . " cases.deleted=0  group by QUARTER(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";

                else:
                $default_query_case = " SELECT count(cases.id) as myt,cases.date_entered, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition . " cases.deleted=0 ) as mytotalfor,   cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition . " cases.deleted=0  group by QUARTER(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";

                
                endif;
				
                $result = $db->query($default_query_case);
                $total = $result->num_rows;
                if($total > 0):
                    while ($row = $db->fetchByAssoc($result)) {
                        $row['date_entered'] = date("Y-m-d", strtotime($row['date_entered']));
                        $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                        $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                        $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';
						
						$total_cases = $row['mytotalfor'];
						$num_amount = $row['myt'];
						$count1 = $num_amount / $total_cases;
						$count2 = $count1 * 100;
						$count = number_format($count2, 0);
						$row['mypercentage'] = $count;
					
                        $volumesupplier[] = $row;
                    }
                else:
                    $row['emptyrecord'] = "N/A";
                    // $volumesupplier[] = $row;
                endif;

            elseif($_QueryPer == "annual"):
                $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1
				$_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
				$_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year)  
			    $start_date  = $_Year."-".$_Month."-"."1";  //start date
				$end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d"))));  // first get current date-1 @current date
				$_CurrentYear = date("Y"); // current year
				$_PreviousYears = date("Y")-1; //previous year 
				if ($_Qfromyear!= $_Qtoyear) {
					$_Year =  array($_PreviousYears,$_CurrentYear);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}else{
				    $_Year =  array($_Qfromyear);
					foreach($_Year as $_Year1)
					{
					$_DailyLoopC[$_Year1] = $_Year1;
					}
				}

				
                //$_YearlyLoopCount = $this->datediff('yyyy',date("y-m-d",strtotime($_REQUEST['from_date'])),date("y-m-d",strtotime($_REQUEST['to_date'])));
                
				$from = $_Qfromyear;
				$to = $_Qtoyear;
				
				if ($_Qfromyear != $_Qtoyear) {
				$end_date = $_curdate;
				$start_date = date('Y-m-1', strtotime("-1 year"));
				} else {
				$start_date = date('Y-m-d', strtotime("$from-01-01"));
				$end_date = date('Y-m-d', strtotime("$from-12-31"));
				}
				
				
				
                //$condition .= "  DATE(cases.date_entered) BETWEEN '" .date("y-m-d", strtotime($start_date)) . "' AND '" . date("y-m-d", strtotime($end_date)) . "' AND ";
				 if(isset($_QuerySuppSku)):
                  $default_query_case = " SELECT count(cases.id) as myt,cases.date_entered, (SELECT COUNT(cases.id) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition . " cases.deleted=0 ) as mytotalfor,   cases.prod_sku,cases.prod_supplier_name,cases.prod_sku, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition . " cases.deleted=0  group by year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";

                else:
                 $default_query_case = " SELECT count(cases.id) as myt,cases.date_entered, (SELECT COUNT(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0 "
                . " where " . $condition . " cases.deleted=0 ) as mytotalfor,   cases.prod_supplier_id,cases.prod_supplier_name,cases.prod_sku, "
                . " cases.id,cases.name,cases.customer_id,cases_cstm.category_c,cases_cstm.member_tier_c,"
                . " cases_cstm.customer_name_c,cases_cstm.email_c,cases_cstm.member_tier_c,cases_cstm.mobile_number_c,cases_cstm.loyalty_id_c,"
                . " cases_cstm.origin_c,cases_cstm.subcategory_c, cases.case_number , cases.priority , cases.status , "
                . " naku_casesubcategory.sla,naku_casesubcategory.estimate_resolution_date, "
                . " LTRIM(RTRIM(CONCAT(IFNULL(jt0.first_name,''),' ',IFNULL(jt0.last_name,'')))) created_by_name , "
                . " jt0.created_by created_by_name_owner , 'Users' created_by_name_mod,"
                . " cases.date_entered , cases.assigned_user_id  FROM cases "
                . " LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN naku_casesubcategory ON cases_cstm.subcategory_c = naku_casesubcategory.id "
                . " LEFT JOIN users jt0 ON cases.assigned_user_id=jt0.id AND jt0.deleted=0 AND jt0.deleted=0"
                . " where " . $condition . " cases.deleted=0  group by year(cases.date_entered)".$condition_group." ORDER BY cases.date_entered ASC";

                
                endif;
				
                $result = $db->query($default_query_case);
                $total = $result->num_rows;
                if($total > 0):
                    while ($row = $db->fetchByAssoc($result)) {
                        $row['date_entered'] = date("Y", strtotime($row['date_entered']));
                        $row['category_c'] = $this->getCaseCategoryName($row['category_c']);
                        $row['origin_c'] = ($row['origin_c']) ? $app_list_strings['origin_list'][$row['origin_c']] : '';
                        $row['priority'] = ($row['priority']) ? $app_list_strings['case_priority_dom'][$row['priority']] : '';

                        $total_cases = $row['mytotalfor'];
                        $num_amount = $row['myt'];
                        $count1 = $num_amount / $total_cases;
                        $count2 = $count1 * 100;
                        $count = number_format($count2, 0);
                        $row['mypercentage'] = $count;

                        $volumesupplier[] = $row;
                    }
                else:
                    $row['emptyrecord'] = "N/A";
                endif;

            else:
			endif;
            
			
		
		 $_DateEntered1ArrayMyt = $_DateEntered1ArrayMyPer=$_DateEntered1ArrayTotalfor =  array();
            if($_WeeklyGlobal == 1)
            {
                if(count($volumesupplier)):
                    foreach($volumesupplier as $volumesupplierData)
                    {
                    $_DateEntered1Array[$volumesupplierData['date_entered']] = $volumesupplierData['date_entered']."_".$volumesupplierData['category_c']."_".$volumesupplierData['origin_c']."_".$volumesupplierData['mytotalfor'];
                    }
                endif;
            }else{
                if(count($volumesupplier)):
				 
						//echo array_sum($_MYT);
                    foreach($volumesupplier as $volumesupplierData)
                        {
				        if($_QueryPer == 'daily'):
						 $_DateEnteredArray[] = date('Y-m-d',strtotime($volumesupplierData['date_entered']));
						else:
						 $_DateEnteredArray[] = $volumesupplierData['date_entered'];
						endif;
                        $_DateEntered1Array[$volumesupplierData['date_entered']] = array($volumesupplierData['date_entered'], $volumesupplierData['category_c'], $volumesupplierData['origin_c'], $volumesupplierData['myt'], $volumesupplierData['mypercentage']);
						$_DateEntered1ArrayMyt[$volumesupplierData['date_entered']]+= $volumesupplierData['myt'];  //myt total array
						$_DateEntered1ArrayMyPer[$volumesupplierData['date_entered']]+= $volumesupplierData['mypercentage'];  //myt percentange array
						$_DateEntered1ArrayTotalfor = $volumesupplierData['mytotalfor'];
						}
                endif;
            }
			
			$ExportSummery = 1; // us this varrible for export specific 
	      if(count($_DateEnteredArray) > 0):	 
		//echo "<pre>";
		 //print_r($_DateEntered1ArrayTotalfor);
		 //die;
					// echo "<br>";
            if(!empty($_DateEntered1Array)):
                foreach($_DateEntered1Array as $_DateEntered1Array1)
                {
                 $_yearRecord[]  = $_DateEntered1Array1[3];
				 $_percentageRecord[]  = $_DateEntered1Array1[4];
                }
            endif;
            //$i = 0;
            if($_QueryPer == 'monthly'){//for month start

			     $_MonthStartArray = array_keys($_DailyLoopC,$_StartMonth);
				 $_MonthEndArray =  array_keys($_DailyLoopC,$_EndMonth);
				 $_Totvalue = $_MonthEndArray[0]-$_MonthStartArray[0];
			     $_DailyLoopC = array_slice($_DailyLoopC,$_MonthStartArray[0],$_Totvalue+1);
				 //for month end
				}

				$i = 1;
                if(count($_DailyLoopC) > 0):
				if($_QuaterlyGlobal==1):
				$_OpenQua = array();
				for($_OpenQ;$_OpenQ<=$_EndQ;$_OpenQ++){
				$_OpenQua[] = $_OpenQ;
				}
				$temp2 = array();
				//for($p = $_StartQ; $p <= $_EndQ; $p++){
				//$temp2[] = $p;
				//}
				
				
				foreach($_GetPeroid as $_GetPeroidKey => $_GetPeroidData)
					 { 
					// if($_QueryPer == 'quarterly'):
					// if(!in_array($i,$temp2)){
					// $i++;
						//continue;
						
					// }
					// endif;
					 
					 $_GetPeroidDisaply = $_GetPeroidKey;
					 $_GetPeroidDisaply =  explode("_",$_GetPeroidDisaply);
					 $_Qendate = date ("Y-m-d", strtotime("+ 3 month", strtotime($_GetPeroidKey)));
					 $_GetPeroidSd = date("M y",strtotime($_GetPeroidKey));
					 $_GetPeroided = date("M y",strtotime($_Qendate));
					 if($_REQUEST['category_id'] == 'all'):
						$_Catname = 'All';
					 else:
						$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
					 endif;
					 if(in_array($_GetPeroidDisaply[2],$_OpenQua)):
					 $_GetPeroidKey = explode("_",$_GetPeroidKey);
					 if($_GetPeroidData==0):
					 //$volumesupplier_grid[] = array($_GetPeroidKey[3], 0);
					 else:
					$first_day_this_Quarter = date('Y-m-01',strtotime($_GetPeroidKey[0]));
					$last_day_this_Quarter  = date('Y-m-t',strtotime($_GetPeroidKey[1]));
					$conditionQ ='';
					if($_REQUEST['getSupplierandsku'] == 'supplier'):
					 $_SupnameTotal = $this->getAllSupplierName($_REQUEST['getsupplierid']);
					else:
					$_SupnameTotal = explode(",",$_REQUEST['getSupplierSKU']);
					endif;
					/***quarter code*******/
					$_FirstDateQuarter = explode("_",$_POST['queryeQs']);
                    $first_day_SelectedQat_from = $_FirstDateQuarter[0];
					$_LastDateQuarter = explode("_",$_POST['queryeQe']);
					$last_day_SelectedQat_To = $_LastDateQuarter[1];
						foreach($_SupnameTotal as $check1):
						    $conditionQ .= "  DATE(cases.date_entered) BETWEEN '" . $first_day_this_Quarter . "' AND '" . $last_day_this_Quarter . "' AND ";
						    $_DisplayGrid ="";
						    $supplier = $_REQUEST['getSupplierandsku'];
						   if($_REQUEST['getSupplierandsku'] == 'supplier'){
						        $check1 =  $check1['supplier_id'];
						   		$_DisplayGrid = $this->displayBySupplierQuarterExport($check1,$checkSupplyName,$condition,$condition_group,$conditionQ,$supplier,$_REQUEST['getsupplierid'],$first_day_SelectedQat_from,$last_day_SelectedQat_To);
								$_Myt = $_DisplayGrid['myt'];
							
								if($_DisplayGrid['prod_supplier_name'] != ""):
                                $volumesupplier_grid[] = array($_GetPeroidKey[3],$_DisplayGrid['myt']);
							   endif;
							}else if($_REQUEST['getSupplierandsku'] == 'sku'){
							    $check1 = $check1;
								$_DisplayGrid = $this->displayBySupplierQuarterExport($check1,$checkSupplyName,$condition,$condition_group,$conditionQ,$supplier,$_SupnameTotal,$first_day_SelectedQat_from,$last_day_SelectedQat_To);
								if($_DisplayGrid['prod_sku'] != ""):
					             $volumesupplier_grid[] = array($_GetPeroidKey[3],$_DisplayGrid['myt']);
								endif;
							}							
						 endforeach;
						
						 
				    // $volumesupplier_grid[] = array($_GetPeroidKey[3],$_GetPeroidData);
					 endif;
				 endif;
				 $i++;}
                else:
                   $temp2 = array();
						for($p = $_StartW ; $p <= $_EndW ; $p++){
						$temp2w[] = $p;
						}
						foreach($_DailyLoopC as $_DailyLoopCDataKey => $_DailyLoopCData)
					 { 
					 
					 if($_QueryPer == 'weekly'):
					 if(!in_array($i,$temp2w)){
					 $i++;
						continue;
						
					 }
					  endif;
				   if($_WeeklyGlobal == 1):
						/*weekly interval*/
						
					    $_WeekStartdate = $_DailyLoopCData; //weekly date start
					    $_WeekEnddate =  date("Y-m-d", strtotime("+ 1 week", strtotime($_DailyLoopCData))); //weekly date ended
					    $_WeekEnddate =  date("Y-m-d", strtotime("-1 day", strtotime($_WeekEnddate)));
						$_WeekDateInterval = $this->returnBetweenDates($_WeekStartdate, $_WeekEnddate); 
					    $_GetPeroid = $this->checkReportPeriodreportcc($condition,$condition_group,$_WeekStartdate,$_WeekEnddate);
						//echo "<pre>";
						$_WeekStartdate = date("d M Y",strtotime($_WeekStartdate));
						$_WeekEnddate = date("d M Y",strtotime($_WeekEnddate));
						
						if($_REQUEST['category_id'] == 'all'):
						$_Catname = 'All';
						else:
						$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
						endif;
						
						
						if($_GetPeroid==0):
							$volumesupplier_grid[] = array("week ".$i." (".$_WeekStartdate." - ".$_WeekEnddate.")",0);
							
						else:
							$volumesupplier_grid[] = array("week ".$i." (".$_WeekStartdate." - ".$_WeekEnddate.")",$_GetPeroid);
							
						
                        endif;						
                      /*weekly interval*/
						
					elseif($_MonthGlobal ==1):
					if($_REQUEST['category_id'] == 'all'):
						$_Catname = 'All';
						else:
						$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
						endif;
						$_DailyLoopCDataMonth = $_DailyLoopCData;
						$_DailyLoopCDataDis = $_DailyLoopCData;
						$_DailyLoopCDataDis = date("M-Y",strtotime($_DailyLoopCDataDis));
						$_DailyLoopCData = date("m-Y",strtotime($_DailyLoopCData));
						if (in_array($_DailyLoopCData,$_DateEnteredArray))
						{
						//$key = array_search($_DailyLoopCData, $_DateEnteredArray);
						$first_day_this_month = date('Y-m-01',strtotime($_DailyLoopCDataMonth));
						$last_day_this_month  = date('Y-m-t',strtotime($_DailyLoopCDataMonth));
						
						 $conditionMonth ='';
						 if($_REQUEST['getSupplierandsku'] == 'supplier'):
						 $_SupnameTotal = $this->getAllSupplierName($_REQUEST['getsupplierid']);
						 else:
						 $_SupnameTotal = explode(",",$_REQUEST['getSupplierSKU']);
						 endif;
						 $first_day_SelectedMonth_from = date('Y-m-01',strtotime($_POST['querySmonth']));
				         $last_day_SelectedMonth_To = date('Y-m-t',strtotime($_POST['queryEmonth']));
						 foreach($_SupnameTotal as $check1):
						 
						  $conditionMonth .= "  DATE(cases.date_entered) BETWEEN '" . $first_day_this_month . "' AND '" .  $last_day_this_month . "' AND ";
						  $_DisplayGrid ="";
						  $supplier = $_REQUEST['getSupplierandsku'];
						  if($_REQUEST['getSupplierandsku'] == 'supplier'){
						  $check1 = $check1['supplier_id'];
						  $_DisplayGrid = $this->displayBySupplierMonthexport($check1,$checkSupplyName,$condition,$condition_group,$conditionMonth,$supplier,$_REQUEST['getsupplierid'],$ExportSummery,$first_day_SelectedMonth_from,$last_day_SelectedMonth_To);
						  if($_DisplayGrid['prod_supplier_name'] != ""):
						   $volumesupplier_grid[] = array($_DailyLoopCDataDis,$_DisplayGrid['myt']);
						  endif;
						  
						  }else if($_REQUEST['getSupplierandsku'] == 'sku'){
						  $check1 = $check1;
						  $_DisplayGrid = $this->displayBySupplierMonthexport($check1,$checkSupplyName,$condition,$condition_group,$conditionMonth,$supplier,$_SupnameTotal,$ExportSummery,$first_day_SelectedMonth_from,$last_day_SelectedMonth_To);
						  if($_DisplayGrid['prod_sku'] != ""):
						   $volumesupplier_grid[] = array($_DailyLoopCDataDis,$_DisplayGrid['myt']);
						  endif;
						  
						  }
						  
						 endforeach;
  						//$_MonthMyt = $_DateEntered1ArrayMyt[$_DateEntered1Array[$_DailyLoopCData][0]];
                       
						}
						else
						{
						 // $volumesupplier_grid[] = array($_DailyLoopCDataDis,0);  
						}
					
					
                    else:
					
				
						if($_REQUEST['category_id'] == 'all'):
						$_Catname = 'All';
						else:
						$_Catname = $this->getCaseCategoryName($_REQUEST['category_id']);
						endif;
						
						
						if($_POST['getperiod'] != 'daily'): 
						if (in_array($_DailyLoopCDataKey, $_DateEnteredArray)):
						    if ($_POST['getFromyear'] != $_POST['getToyear']) {
							$end_date = $_curdate;
							$start_date = date('Y-m-1', strtotime("-1 year"));
							} else {
							$start_date = date('Y-m-d', strtotime("$from-01-01"));
							$end_date = date('Y-m-d', strtotime("$from-12-31"));
							}
							$first_day_this_year = $start_date;
							$last_day_this_year  = $end_date;
					        $conditionYear ='';
							if($_REQUEST['getSupplierandsku'] == 'supplier'): 
							$_SupnameTotal =  $this->getAllSupplierName($_REQUEST['getsupplierid']);
							else:
							//$_SupnameTotal = $_REQUEST['getSupplierSKU'];
							$_SupnameTotal = explode(",",$_REQUEST['getSupplierSKU']);
							endif;
							
							foreach($_SupnameTotal as $check1):

								   $conditionYear .= "  DATE(cases.date_entered) BETWEEN '" . $first_day_this_year . "' AND '" . $last_day_this_year . "' AND ";
								   $_DisplayGrid ="";
									$supplier = $_REQUEST['getSupplierandsku'];
								   if($_REQUEST['getSupplierandsku'] == 'supplier'){
										$check1 =  $check1['supplier_id'];
										$_DisplayGrid = $this->displayBySupplierYearReport($check1,$checkSupplyName,$condition,$condition_group,$conditionYear,$supplier,$_REQUEST['getsupplierid'],$ExportSummery);
										if($_DisplayGrid['prod_supplier_name'] != ""):
									      $_YearDis = date("Y",strtotime($_DisplayGrid['date_entered']));
										  $volumesupplier_grid[] =  array($_YearDis,$_DisplayGrid['myt']);
										endif;
									}else if($_REQUEST['getSupplierandsku'] == 'sku'){
										$check1 =  $check1;
									    $sku = $_REQUEST['getSupplierandsku'];
										$_DisplayGrid = $this->displayBySupplierYearReport($check1,$checkSupplyName,$condition,$condition_group,$conditionYear,$sku,$_REQUEST['getSupplierSKU'],$ExportSummery);
										
										if($_DisplayGrid['prod_sku'] != ""):
										  $_YearDis = date("Y",strtotime($_DisplayGrid['date_entered']));
										  $volumesupplier_grid[] =  array($_YearDis,$_DisplayGrid['myt']);
										endif;
									}							
								 endforeach;	
						
						 endif;
						else:
						
							if (in_array($_DailyLoopCData,$_DateEnteredArray))
							{
                            $volumesupplier_grid[] =  array($_DailyLoopCData,$_DateEntered1ArrayTotalfor);
							}else
							{
							$volumesupplier_grid[] =  array($_DailyLoopCData,0);
							}
						endif;
					
						
					endif;
					    
					$i++;	}

				endif;
				else:
                   if($_QuaterlyGlobal==1):
				   foreach($_GetOneQuarters as $_GetPeroidKey=>$_GetPeroidVal):
                      if($_GetPeroidVal==0):
						$volumesupplier_grid[] = "<tr><td>".$_GetPeroidKey."</td>
						<td colspan=3>We can't find records for this period</td>
						</tr>";
					   else:
						$volumesupplier_grid[] = "<tr><td>".$_GetPeroidKey."</td>
						<td>".""."</td>
						<td>".""."</td>
						<td onclick='checkclick(this.title)' id=Dailydata_".$_GetPeroidKey." title=daily_".$_GetPeroidKey.">".$_GetPeroidVal."</td>
						</tr>";
					   endif;
						$volumesupplier_grid[] = "</tr>";
						$volumesupplier_grid[] ="<tr class=dailyresulthide id=dailyresult_".$_GetPeroidKey." style=display:none>
						<td colspan='4' class='parent-TD'>
						</td></tr>";
					endforeach;	
				   endif;
                endif;
               else:
			  $volumesupplier_grid[] = array("","");
			   endif;
				
return $volumesupplier_grid;  
// echo "<pre>";
//print_r($volumesupplier_grid);

    
}		


    public function getAllSupplierName($id) {
         global $db;
         $query = "SELECT distinct(naku_suppliers.supplier_id) as supplier_id, naku_suppliers.name FROM naku_suppliers naku_suppliers join naku_itemsuppliers naku_itemsuppliers ON naku_suppliers.supplier_id = naku_itemsuppliers.supplier_id JOIN cases ON cases.prod_sku = naku_itemsuppliers.id WHERE cases.deleted =0 AND naku_suppliers.supplier_id IN (".$id.")";
         $result = $db->query($query);
         $getAllSupplierName = array();
         while($data = $db->fetchByAssoc($result)){
              $data['name'] = $data['name'] ;
              $getAllSupplierName[] =$data;
         }
			$this->view_object_map['getAllSupplierName'] = $getAllSupplierName;//supplier popup @Ashok Dated: 09-06-2017 
            return $getAllSupplierName;
    }
		
	
	public function getAllSupplierFromCases() {
         global $db;
         $query = "SELECT distinct(naku_suppliers.supplier_id) as supplier_id, naku_suppliers.name FROM naku_suppliers naku_suppliers join naku_itemsuppliers naku_itemsuppliers ON naku_suppliers.supplier_id = naku_itemsuppliers.supplier_id JOIN cases ON cases.prod_sku = naku_itemsuppliers.id WHERE cases.deleted =0";
        $result = $db->query($query);
         $getAllSupplierFromCases = array();
         while($data = $db->fetchByAssoc($result)){
              $data['supplier_id'] = $data['supplier_id'];
              $data['name'] = $data['name'] ;
              $getAllSupplierFromCases[] =$data;
         }
			$this->view_object_map['getAllSupplierFromCases'] = $getAllSupplierFromCases;//supplier popup @Ashok Dated: 24-05-2017 
            return $getAllSupplierFromCases;
    }
	
	 /**
     * This method is Get All supplier details name, id , phone, fax, department from table 'naku_Suppliers'
     *
     */
    public function getAllSKUFromCases() {
         global $db;
         $query = "SELECT distinct(prod_sku) as prod_sku , quality_description as product_description FROM cases WHERE prod_sku !='' AND deleted =0 group by prod_sku ";
        $result = $db->query($query);
         $getAllSKUFromCases = array();
         while($data = $db->fetchByAssoc($result)){
              $data['prod_sku'] = $data['prod_sku'];
              $data['product_description'] = $data['product_description'] ;
              $getAllSKUFromCases[] =$data;
         }
			$this->view_object_map['getAllSKUFromCases'] = $getAllSKUFromCases;//SKU popup @Ashok Dated: 24-05-2017 
            return $getAllSKUFromCases;
    }
	/**
     * This method is get list of Cases by CRM Magento
     *
     */
    public function action_EditView() {
        global $db;
        $conn = $this->connectionCRMDB();
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $list_branch = array();
        $sql = "SELECT store_id,branch_name,store_country,store_city FROM nakumatt_stores WHERE status = 1";
        $result = $conn->query($sql);
        if (!$result) {
            echo "Connection error on connecting nakumatt store";
        } else {
            while ($row = $db->fetchByAssoc($result)) {

                $list_branch[] = $row;
            }
        }
        $conn->close();
        $this->view = 'edit';
        $this->view_object_map['edit'] = $list_branch;
    }

    public function action_getRedemptionRate() {
        global $db;
        $conn = $this->connectionCRMDB();
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $member_tier_c = $_POST['member_tier_c'];
        $branch_name = $_POST['branch_store_name'];

        //Local
        /* $sql ="SELECT mmrr.currency_amount,sw.name FROM m2d_magento_reward_rate mmrr 
          JOIN m2d_nakumatt_redemptiontype_items mnri ON mmrr.redemption_type_id = mnri.id
          JOIN m2d_nakumatt_tier mnt ON mmrr.tier_id = mnt.tier_id
          JOIN m2d_store_website sw ON sw.website_id = mmrr.website_id
          JOIN m2d_nakumatt_stores  mns ON mns.store_country = sw.name AND mns.branch_name = 'NAKUMATT UKAY'
          WHERE mnri.name ='Redemption for school fees' AND mnt.tier_name= '".$member_tier_c."'  AND mns.branch_name = '".$branch_name."' ";

         */
        //server
        $sql = " SELECT mmrr.currency_amount,sw.name FROM magento_reward_rate mmrr 
            JOIN nakumatt_redemptiontype_items mnri ON mmrr.redemption_type_id = mnri.id 
            JOIN nakumatt_tier_items mnt ON mmrr.tier_id = mnt.id 
            JOIN store_website sw ON sw.website_id = mmrr.website_id 
            JOIN nakumatt_stores mns ON UPPER(mns.store_country) = UPPER(sw.name) 
            WHERE mnri.name ='Redemption of points for School fees' AND mnt.name= '" . $member_tier_c . "' AND mns.branch_name = '" . $branch_name . "' ";


        $result = $conn->query($sql);
        if (!$result) {
            echo "Connection error";
        } else {
            $row = $db->fetchByAssoc($result);
        }
        $conn->close();

        echo json_encode($row);
        exit;
    }

    ///////////EOC////////////////////////////////
    //Author: Ashok DAted: 14/04/2017 Desc: Calculate the field based on closed BRD point no 20
    public function action_DetailView() {
        global $current_user, $db;
        $timedate = new TimeDate();
        //print_r($_REQUEST);
        $id = $_REQUEST['record'];
        $query = "SELECT cases.id,"
                . " cases.status ,"
                . " cases.date_modified ,"
                . " cases.date_entered  "
                . " FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " where cases.deleted=0 AND cases.id='" . $id . "'";

        $result = $db->query($query);
        $row = $db->fetchByAssoc($result);

        $date_entered = $row['date_entered'];
        $date_modified = $row['date_modified'];
        $start_date = date("Y-m-d", strtotime($date_entered));
        $end_date = date("Y-m-d", strtotime($date_modified));
        $days = $this->datediff('d', $start_date, $end_date);

        $this->view = 'detail';
        $this->view_object_map['calculate_days'] = $days;
    }

    //Author: Ashok DAted: 16/04/2017 Desc: Calculate the field based on closed BRD point no 20
    public function action_smsfeedcases() {
        global $db, $app_list_strings, $current_user;
        $table_id = $_REQUEST['record'];
        $date_modified = date('Y-m-d H:i:s');
        //$url =  "index.php?module=Cases&action=smsfeedcases&record=52ab5537-a2a0-f152-b42f-58ee2b90e1c3&messsage=yes";

        if (isset($_REQUEST['messsage']) && $_REQUEST['messsage'] == 'yes') {
            $status = 'Closed';
            $date_modified = $date_modified;
            $bean = new aCase();
            $bean->retrieve($table_id);
            $bean->status = $status;
            $bean->date_modified = $date_modified;
            $bean->save();
        } elseif (isset($_REQUEST['messsage']) && $_REQUEST['messsage'] == 'no') {

            $status = 'Reopen';
            $date_modified = $date_modified;
            $bean = new aCase();
            $bean->retrieve($table_id);
            $bean->status = $status;
            $bean->date_modified = $date_modified;
            $bean->save();

            $note_bean = BeanFactory::newBean('Notes');
            $note_bean->name = "SMS Response - NO - " . $bean->case_number;
            $note_bean->description = $bean->resolution;
            $note_bean->date_modified = $date_modified;
            $note_bean->parent_type = 'Cases';
            $note_bean->parent_id = $table_id;

            $note_bean->save();

            $query_on = "select users.reports_to_id  from users JOIN  cases on cases.assigned_user_id =usesr.id where cases.id ='" . $table_id . "' AND deleted =0 ";
            $result_on = $db->query($query_on);
            $row_on = $db->fetchByAssoc($result_on);
            $supervisorId = $row_on['reports_to_id'];
            //get User Details
            $myUser = new User();
            //$myUser->retrieve_by_string_fields(array('department' => 'Loyalty' ));
            $user = BeanFactory::getBean('Users', $supervisorId);
            $primary_email = $user->emailAddress->getPrimaryAddress($user);
            $user_name = $user->user_name;

            //for supervisor
            $subject = "Customer not satisfied with Resolution provide";
            $message = '<html><body>';
            $message .= "Dear " . $user_name . ",<br/><br/> A case has been reopen , Please veirfy - Case No. " . $case_number . "</b>";
            $message .= "Thank You.<br/><br/>NAKUMATT HOLDINGS LIMITED <br />Head Office Road C,Off Enterpise Road,<br />P.O.Box 78355-00507, Nairobi, Kenya<br />Tel: +254 20 650 137/8/9,<br />";
            $message .= "+254 733 632 130,+254 722 204 931<br />Fax: +254 20 650150<br />Email:nakumatt@nakumatt.net<br />";
            $message .= "</body></html>";
            $email = "ashok.gupta@zensar.com"; //$primary_email;//supervisor email
            //EMAIL functionality
            require_once('include/SugarPHPMailer.php');
            $emailObj = new Email();
            $defaults = $emailObj->getSystemDefaultEmail();
            $mail = new SugarPHPMailer();
            $mail->setMailerForSystem();
            $mail->From = "reports@nakumatt.net"; //$defaults['email']; 
            $mail->FromName = "Nakumat Holdings"; //$defaults['name']; 
            $mail->Subject = $subject;
            $mail->Body_html = from_html($message);
            $mail->IsHTML(true); //Omit or comment out this line if plain text
            $mail->Body = $mail->Body_html; //$message; 
            $mail->prepForOutbound();
            $mail->AddAddress($email);
            if (!$mail->send()) {
                $GLOBALS['log']->info("Mailer error: " . $mail->ErrorInfo);
            }
        }

        $this->view = 'smsfeedcases';
        //$this->view_object_map['smsfeedcases'] = "Ashok sms";           
    }

    //Audit LOG 

    public function action_auditlogusers() {
        global $db, $app_list_strings, $sugar_config;
        $this->view = 'auditlogusers';

        //Fetch all the users
        $query_fetch_all_users = "select users.id as user_id, CONCAT_WS(' ',users.first_name, users.last_name, '(', users.user_name,')') AS user_name from users users where users.deleted=0 and status='Active'";
        $result_allusers = $db->query($query_fetch_all_users);
        $alluser = array();
        while ($row_allusers = $db->fetchByAssoc($result_allusers)) {
            $alluser[] = $row_allusers;
        }
        $this->view_object_map['all_users'] = $alluser;

        //Cases
        $bean = BeanFactory::getBean($this->module);
        $allField = array();
        if (!empty($bean->field_name_map)) {
            foreach ($bean->field_name_map as $field_nm_arr) {
                if ($field_nm_arr['audited']) {
                    $allField[] = $field_nm_arr['name'];
                }
            }
            $allField = implode("','", $allField);
        }
        //Campaigns
        $beanCamp = BeanFactory::getBean("Campaigns");
        $allFieldCamp = array();
        if (!empty($beanCamp->field_name_map)) {
            foreach ($beanCamp->field_name_map as $field_nm_arr) {
                if ($field_nm_arr['audited']) {
                    $allFieldCamp[] = $field_nm_arr['name'];
                }
            }
            $allFieldCamp = implode("','", $allFieldCamp);
        }


        //Campaigns Activity camp_activity_audit
        $beanCampAct = BeanFactory::getBean("Camp_Activity");
        $allFieldCampAct = array();
        if (!empty($beanCampAct->field_name_map)) {
            foreach ($beanCampAct->field_name_map as $field_nm_arr) {
                if ($field_nm_arr['audited']) {
                    $allFieldCampAct[] = $field_nm_arr['name'];
                }
            }
            $allFieldCampAct = implode("','", $allFieldCampAct);
        }
        //Campaigns  type Activity camp_typeactivity_audit
        $beanCampTypeAct = BeanFactory::getBean("Camp_TypeActivity");
        $allFieldCampTypeAct = array();
        if (!empty($beanCampTypeAct->field_name_map)) {
            foreach ($beanCampTypeAct->field_name_map as $field_nm_arr) {
                if ($field_nm_arr['audited']) {
                    $allFieldCampTypeAct[] = $field_nm_arr['name'];
                }
            }
            $allFieldCampTypeAct = implode("','", $allFieldCampTypeAct);
        }
        $filteruser = $_REQUEST['all_user'];
        if (isset($_REQUEST['all_user']) && $_REQUEST['all_user'] != '') {
            $assignedUsers = $_REQUEST['all_user'];
            $assignedUsers = "AND u.id = '" . $assignedUsers . "'  ";
        }
        $this->view_object_map['getUsers'] = $assignedUsers;
		$this->view_object_map['onygetUsers'] =$_REQUEST['all_user'];

        $from_date = date("Y-m-d", strtotime($_REQUEST['from_date']));
        $to_date = date("Y-m-d", strtotime($_REQUEST['to_date']));
        $from_date = $_REQUEST['from_date']; //fromdate for post
        $this->view_object_map['getFromDate'] = $from_date;
        $to_date = $_REQUEST['to_date']; //todate for post
        $this->view_object_map['getToDate'] = $to_date;


        $condCase = '';
        if ($from_date && $to_date) {
            $condCase .= " AND  DATE(ma.date_created) BETWEEN '" . date("Y-m-d", strtotime($from_date)) . "' AND '" . date("Y-m-d", strtotime($to_date)) . "'  ";
        }
        $query .= "SELECT 'Cases' as module, m.name, LTRIM(RTRIM(CONCAT(IFNULL(u.first_name,''),' ',IFNULL(u.last_name,'')))) as  user_name, ma.field_name, ma.before_value_string, ma.after_value_string , ma.date_created as date_changed, ma.ip_address as IP_ADDRESS, ma.parent_id as parent_id, ma.id as audit_id, m.case_number as numbers FROM cases m 
		JOIN cases_audit ma on ma.parent_id = m.id and ma.field_name IN ('" . $allField . "') JOIN cases_cstm mc on mc.id_c = m.id JOIN users u on u.id = ma.created_by WHERE 1=1 " . $condCase . "  {$assignedUsers} ";
        //$query .= $condCase;

        $condCamp = '';
        if ($from_date && $to_date) {
            $condCamp .= " AND  DATE(mac.date_created) BETWEEN '" . date("Y-m-d", strtotime($from_date)) . "' AND '" . date("Y-m-d", strtotime($to_date)) . "'  ";
        }
        $query .= "	
		UNION
			SELECT 'Campaigns' as module, mc.name, LTRIM(RTRIM(CONCAT(IFNULL(u.first_name,''),' ',IFNULL(u.last_name,'')))) as  user_name, mac.field_name, mac.before_value_string, mac.after_value_string, mac.date_created as date_changed, mac.ip_address as IP_ADDRESS, mac.parent_id as parent_id, mac.id as audit_id , mc.campaign_id_c as numbers FROM campaigns mc JOIN campaigns_audit mac on mac.parent_id = mc.id and mac.field_name IN ('" . $allFieldCamp . "') JOIN users u on u.id = mac.created_by WHERE 1=1 " . $condCamp . "  {$assignedUsers} ";

        $condCampAct = '';
        if ($from_date && $to_date) {
            $condCampAct .= " AND  DATE(maca.date_created) BETWEEN '" . date("Y-m-d", strtotime($from_date)) . "' AND '" . date("Y-m-d", strtotime($to_date)) . "'  ";
        }
        $query .= "	UNION
			SELECT 'Campaigns Activity' as module, mca.name, LTRIM(RTRIM(CONCAT(IFNULL(u.first_name,''),' ',IFNULL(u.last_name,'')))) as  user_name, maca.field_name, maca.before_value_string, maca.after_value_string, maca.date_created as date_changed, maca.ip_address as IP_ADDRESS, maca.parent_id as parent_id, maca.id as audit_id ,  mca.name as numbers FROM camp_activity mca JOIN camp_activity_audit maca on maca.parent_id = mca.id and maca.field_name IN ('" . $allFieldCampAct . "') JOIN users u on u.id = maca.created_by WHERE 1=1 " . $condCampAct . "  {$assignedUsers} ";

        $condCampTypeAct = '';
        if ($from_date && $to_date) {
            $condCampTypeAct .= " AND  DATE(macta.date_created) BETWEEN '" . date("Y-m-d", strtotime($from_date)) . "' AND '" . date("Y-m-d", strtotime($to_date)) . "'  ";
        }
        $query .= "	UNION
			SELECT 'Campaigns Type Activity' as module, mcta.type, LTRIM(RTRIM(CONCAT(IFNULL(u.first_name,''),' ',IFNULL(u.last_name,'')))) as  user_name, macta.field_name, macta.before_value_string, macta.after_value_string, macta.date_created as date_changed, macta.ip_address as IP_ADDRESS, macta.parent_id as parent_id, macta.id as audit_id ,  ' ' as numbers FROM camp_typeactivity mcta JOIN camp_typeactivity_audit macta on macta.parent_id = mcta.id and macta.field_name IN ('" . $allFieldCampTypeAct . "') JOIN users u on u.id = macta.created_by WHERE 1=1 " . $condCampTypeAct . "  {$assignedUsers} ";

        $query .=" ORDER BY date_changed desc ";

        $result = $db->query($query);
        $total = $result->num_rows;

        $auditlog = array();
        if ($total > 0) {
            while ($row = $db->fetchByAssoc($result)) {

                $auditlog[] = $row;
            }
        }
        $this->view_object_map['auditlogusers'] = $auditlog;
        //$aaa = array($filteruser,$from_date,$to_date);
        //return 	$aaa;
    }

    public function action_displayaudit() {
        global $db, $app_list_strings, $sugar_config;
        $this->view = 'displayaudit';

        $id = $_REQUEST['record'];
        if ($_REQUEST['audit_module'] == 'Cases') {

            $tablename = "cases_audit";

            $query .= "SELECT 'Cases' as module, m.name, LTRIM(RTRIM(CONCAT(IFNULL(u.first_name,''),' ',IFNULL(u.last_name,'')))) as  user_name, u.user_name as user_id, ma.field_name, ma.before_value_string, ma.after_value_string , ma.date_created as date_changed, ma.ip_address as IP_ADDRESS, ma.parent_id as parent_id, ma.id as audit_id, m.case_number as numbers FROM cases m 
			JOIN cases_audit ma on ma.parent_id = m.id JOIN cases_cstm mc on mc.id_c = m.id JOIN users u on u.id = ma.created_by WHERE ma.id ='" . $id . "'";
        }
        if ($_REQUEST['audit_module'] == 'Campaigns') {
            $tablename = "campaigns_audit";

            $query = " SELECT 'Campaigns' as module, mc.name, LTRIM(RTRIM(CONCAT(IFNULL(u.first_name,''),' ',IFNULL(u.last_name,'')))) as  user_name, u.user_name as user_id, mac.field_name, mac.before_value_string, mac.after_value_string, mac.date_created as date_changed, mac.ip_address as IP_ADDRESS, mac.parent_id as parent_id, mac.id as audit_id , mc.campaign_id_c as numbers FROM campaigns mc JOIN campaigns_audit mac on mac.parent_id = mc.id JOIN users u on u.id = mac.created_by WHERE mac.id ='" . $id . "'";
        }
        if ($_REQUEST['audit_module'] == 'Camp_TypeActivity') {
            $tablename = "camp_typeactivity_audit";

            $query = "SELECT 'Campaigns Type Activity' as module, mcta.type, LTRIM(RTRIM(CONCAT(IFNULL(u.first_name,''),' ',IFNULL(u.last_name,'')))) as  user_name, macta.field_name, macta.before_value_string, macta.after_value_string, macta.date_created as date_changed, macta.ip_address as IP_ADDRESS, macta.parent_id as parent_id, macta.id as audit_id ,  ' ' as numbers FROM camp_typeactivity mcta JOIN camp_typeactivity_audit macta on macta.parent_id = mcta.id JOIN users u on u.id = macta.created_by WHERE macta.id ='" . $id . "'";
        }
        if ($_REQUEST['audit_module'] == 'Camp_Activity') {
            $tablename = "camp_activity_audit";

            $query = "SELECT 'Campaigns Activity' as module, mca.name, LTRIM(RTRIM(CONCAT(IFNULL(u.first_name,''),' ',IFNULL(u.last_name,'')))) as  user_name, maca.field_name, maca.before_value_string, maca.after_value_string, maca.date_created as date_changed, maca.ip_address as IP_ADDRESS, maca.parent_id as parent_id, maca.id as audit_id ,  mca.name as numbers FROM camp_activity mca JOIN camp_activity_audit maca on maca.parent_id = mca.id JOIN users u on u.id = maca.created_by WHERE maca.id = '" . $id . "'";
        }

        $result = $GLOBALS['db']->query($query);
        $count = $result->num_rows;

        $log = array();
        if ($count > 0) {
            $row = $db->fetchByAssoc($result);

            if ($row['IP_ADDRESS'] == '::1') {
                $ipAddress = '120.0.0.1';
            } else {
                $ipAddress = $row['IP_ADDRESS'];
            }


            $data['list'] = array('module' => $row['module'], 'user_id' => $row['user_id'], 'ipAddress' => $ipAddress, 'user_name' => $row['user_name'], 'numbers' => $row['numbers'], 'before_value_string' => $row['before_value_string'], 'after_value_string' => $row['after_value_string']);
        }

        $this->view_object_map['displayaudit'] = $data['list'];
    }

    //Export function to fetch the selected one

    public function export_auditlogusers($_QueryFD, $_QueryTD, $_QueryUser) {

        global $db, $app_list_strings, $sugar_config;
        $condition = $condition_group = '';
        if ($_QueryFD || $_QueryTD || $_QueryUser) {

            //Cases
            $bean = BeanFactory::getBean($this->module);
            $allField = array();
            if (!empty($bean->field_name_map)) {
                foreach ($bean->field_name_map as $field_nm_arr) {
                    if ($field_nm_arr['audited']) {
                        $allField[] = $field_nm_arr['name'];
                    }
                }
                $allField = implode("','", $allField);
            }
            //Campaigns
            $beanCamp = BeanFactory::getBean("Campaigns");
            $allFieldCamp = array();
            if (!empty($beanCamp->field_name_map)) {
                foreach ($beanCamp->field_name_map as $field_nm_arr) {
                    if ($field_nm_arr['audited']) {
                        $allFieldCamp[] = $field_nm_arr['name'];
                    }
                }
                $allFieldCamp = implode("','", $allFieldCamp);
            }


            //Campaigns Activity camp_activity_audit
            $beanCampAct = BeanFactory::getBean("Camp_Activity");
            $allFieldCampAct = array();
            if (!empty($beanCampAct->field_name_map)) {
                foreach ($beanCampAct->field_name_map as $field_nm_arr) {
                    if ($field_nm_arr['audited']) {
                        $allFieldCampAct[] = $field_nm_arr['name'];
                    }
                }
                $allFieldCampAct = implode("','", $allFieldCampAct);
            }
            //Campaigns  type Activity camp_typeactivity_audit
            $beanCampTypeAct = BeanFactory::getBean("Camp_TypeActivity");
            $allFieldCampTypeAct = array();
            if (!empty($beanCampTypeAct->field_name_map)) {
                foreach ($beanCampTypeAct->field_name_map as $field_nm_arr) {
                    if ($field_nm_arr['audited']) {
                        $allFieldCampTypeAct[] = $field_nm_arr['name'];
                    }
                }
                $allFieldCampTypeAct = implode("','", $allFieldCampTypeAct);
            }

            $from_date = $to_date = '';
            if (!empty($_QueryFD) && $_QueryFD != '') {
                $from_date .= date("Y-m-d", strtotime($_QueryFD));
            }
            if (!empty($_QueryTD) && $_QueryTD != '') {
                $to_date .= date("Y-m-d", strtotime($_QueryTD));
            }
			

           $condCase = $query='';
        if ($from_date && $to_date) {
            $condCase .= " AND  DATE(ma.date_created) BETWEEN '" . date("Y-m-d", strtotime($from_date)) . "' AND '" . date("Y-m-d", strtotime($to_date)) . "'  ";
        }
        $query .= "SELECT 'Cases' as module, m.name, LTRIM(RTRIM(CONCAT(IFNULL(u.first_name,''),' ',IFNULL(u.last_name,'')))) as  user_name, ma.field_name, ma.before_value_string, ma.after_value_string , ma.date_created as date_changed, ma.ip_address as IP_ADDRESS, ma.parent_id as parent_id, ma.id as audit_id, m.case_number as numbers FROM cases m JOIN cases_audit ma on ma.parent_id = m.id and ma.field_name IN ('" . $allField . "') JOIN cases_cstm mc on mc.id_c = m.id JOIN users u on u.id = ma.created_by WHERE 1=1 " . $condCase ." AND u.id  ='".$_QueryUser."'";
       // $query .= $condCase;

        $condCamp = '';
        if ($from_date && $to_date) {
            $condCamp .= " AND  DATE(mac.date_created) BETWEEN '" . date("Y-m-d", strtotime($from_date)) . "' AND '" . date("Y-m-d", strtotime($to_date)) . "'  ";
        }
        $query .= "	
		UNION
			SELECT 'Campaigns' as module, mc.name, LTRIM(RTRIM(CONCAT(IFNULL(u.first_name,''),' ',IFNULL(u.last_name,'')))) as  user_name, mac.field_name, mac.before_value_string, mac.after_value_string, mac.date_created as date_changed, mac.ip_address as IP_ADDRESS, mac.parent_id as parent_id, mac.id as audit_id , mc.campaign_id_c as numbers FROM campaigns mc JOIN campaigns_audit mac on mac.parent_id = mc.id and mac.field_name IN ('" . $allFieldCamp . "') JOIN users u on u.id = mac.created_by WHERE 1=1 " . $condCamp ;

        $condCampAct = '';
        if ($from_date && $to_date) {
            $condCampAct .= " AND  DATE(maca.date_created) BETWEEN '" . date("Y-m-d", strtotime($from_date)) . "' AND '" . date("Y-m-d", strtotime($to_date)) . "'  ";
        }
        $query .= "	UNION
			SELECT 'Campaigns Activity' as module, mca.name, LTRIM(RTRIM(CONCAT(IFNULL(u.first_name,''),' ',IFNULL(u.last_name,'')))) as  user_name, maca.field_name, maca.before_value_string, maca.after_value_string, maca.date_created as date_changed, maca.ip_address as IP_ADDRESS, maca.parent_id as parent_id, maca.id as audit_id ,  mca.name as numbers FROM camp_activity mca JOIN camp_activity_audit maca on maca.parent_id = mca.id and maca.field_name IN ('" . $allFieldCampAct . "') JOIN users u on u.id = maca.created_by WHERE 1=1 " . $condCampAct ;

			$condCampTypeAct = '';
			if ($from_date && $to_date) {
				$condCampTypeAct .= " AND  DATE(macta.date_created) BETWEEN '" . date("Y-m-d", strtotime($from_date)) . "' AND '" . date("Y-m-d", strtotime($to_date)) . "'  ";
			}
		$query .= "	UNION
			SELECT 'Campaigns Type Activity' as module, mcta.type, LTRIM(RTRIM(CONCAT(IFNULL(u.first_name,''),' ',IFNULL(u.last_name,'')))) as  user_name, macta.field_name, macta.before_value_string, macta.after_value_string, macta.date_created as date_changed, macta.ip_address as IP_ADDRESS, macta.parent_id as parent_id, macta.id as audit_id ,  ' ' as numbers FROM camp_typeactivity mcta JOIN camp_typeactivity_audit macta on macta.parent_id = mcta.id and macta.field_name IN ('" . $allFieldCampTypeAct . "') JOIN users u on u.id = macta.created_by WHERE 1=1 " . $condCampTypeAct ;

		$query .=" ORDER BY date_changed desc ";
            $result = $db->query($query);
            $total = $result->num_rows;
            $expauditlog = array();
            if ($total > 0) {
                while ($row = $db->fetchByAssoc($result)) {

                    $expauditlog[] = $row;
                }
            }
        }
		
	
        return $expauditlog;
    }

    //Export Audit Log

    public function action_exportAudit() {
        global $db, $app_list_strings;
        $condition = $_QueryFD = $_QueryTD = $_QueryUser;

        if (isset($_REQUEST['queryfromdate'])) {
            $_QueryFD = $_REQUEST['queryfromdate'];
        }
        if (isset($_REQUEST['querytodate'])) {
            $_QueryTD = $_REQUEST['querytodate'];
        }
        if (isset($_REQUEST['queryusers'])) {
            $_QueryUser = $_REQUEST['queryusers'];
        }
		
		if (isset($_REQUEST['onygetysers'])) {
            $_QueryUserOnly = $_REQUEST['onygetysers'];
        }
		
		//echo $_REQUEST['onygetysers'];die('Ashok');
		
        $allresultAudit = $this->export_auditlogusers($_QueryFD, $_QueryTD, $_REQUEST['onygetysers']);
        if ($_POST['file_type'] == 'csv') { //Export CSV
            //CSV File name and Header
            $filename = "Audit" . date('Y-m-d:H:i:s') . ".csv";
            $fp = fopen('php://output', 'w');
            $header = array('Time', 'Action Group', 'Action', 'IP Address', 'Username', 'Impacted Entities');
            header('Content-type: application/csv');
            header('Content-Disposition: attachment; filename=' . $filename);
            fputcsv($fp, $header);

            foreach ($allresultAudit as $k => $v) {
                if ($v['IP_ADDRESS'] == '::1') {
                    $ipAddress = '120.0.0.1';
                } else {
                    $ipAddress = $v['IP_ADDRESS'];
                }
                $audit['csv'] = array($v['date_changed'], $v['module'], 'Modified', $ipAddress, $v['user_name'], $v['numbers']);
                fputcsv($fp, $audit['csv']); //Genrate CSV
            }


            fclose($fp);
            exit;
        } elseif ($_POST['file_type'] == 'xls') { //Export XLS
            $list = array();
           $header = array('Time', 'Action Group', 'Action', 'IP Address', 'Username', 'Impacted Entities');
            $fichier = "Audit" . date('Y-m-d:H:i:s') . ".xls";
            header("Content-Type: text/csv;charset=utf-8");
            header("Content-Disposition: attachment;filename=\"$fichier\"");
            header("Pragma: no-cache");
            header("Expires: 0");
            $fp = fopen('php://output', 'w');
            fputcsv($fp, $header);
			
			 foreach ($allresultAudit as $k => $v) {
                if ($v['IP_ADDRESS'] == '::1') {
                    $ipAddress = '120.0.0.1';
                } else {
                    $ipAddress = $v['IP_ADDRESS'];
                }
                 $audit['list'] = array($v['date_changed'], $v['module'], 'Modified', $ipAddress, $v['user_name'], $v['numbers']);
                fputcsv($fp, $audit['list']); //Genrate xls
            }
			
          //  $audit['list'] = array($v['date_changed'], $v['module'], 'Modified', $ipAddress, $v['user_name'], $v['numbers']);

            //fputcsv($fp, $audit['list']); //Genrate XLS

            fclose($fp);
            exit();
        }
    }

}

?>