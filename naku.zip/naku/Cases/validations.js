$(document).ready(function () {
hideclosebutton();
    $('#loyalty_id_c').focus();
    $('#dob_c').prop("readonly", true);
    $('#repair_date_to_supplier').prop("readonly", true);
    $('#complaint_date').prop("readonly", true);
    $('#customer_approval_date').prop("readonly", true);
    $('#purchase_date_repair').prop("readonly", true);
    $('#date_of_faxed_email').prop("readonly", true);
    $('#date_of_collection_repair').prop("readonly", true);
    $('#date_complaint_forwarded').prop("readonly", true);
    $('#purchase_date').prop("readonly", true);
    $('#expiry_date').prop("readonly", true);
    $('#date_sent_to_supplier').prop("readonly", true);
    $('#school_cheque_issuedate').prop("readonly", true);
    $('#school_cheque_dispatch').prop("readonly", true);
    
    $("#dob_c").prop("readonly", true);
    //disable  priority for edit
     $("#priority").css("background-color", "#DEDEDE");
     $("#priority").css("pointer-events", "none");

    //$("#priority").load($(this).val());
    
    
   // if($('#name').val() === ''){ 
	
      //  $('#origin_c').val();
  //  }
    onEdit();
    defaultval();
    
    var edate ='';
    chequeDispatchDateVal(edate);
    var num = '';
    mobile_number(num);
    var dateenter = '';
    birthdate_validation(dateenter);
    //product_code_no 
    $('#product_code_no').change(function () {

        var value_entered = $('#product_code_no').val();
        if(value_entered =="" || !($.isNumeric(value_entered))){
            
            alert ("Product Code must be numeric");
             $('#product_code_no').val('');
             $('#product_code_no').focus();
        }  
    }); 
    //till no 
    $('#till_no').change(function () {

        var value_entered = $('#till_no').val();
        if(value_entered =="" || !($.isNumeric(value_entered))){
            
            alert ("Till No must be numeric");
             $('#till_no').val('');
             $('#till_no').focus();
        }  
    }); 
    //repair_product_code
     $('#repair_product_code').change(function () {

        var value_entered = $('#repair_product_code').val();
        if(value_entered =="" || !($.isNumeric(value_entered))){
            
            alert ("Product Code must be numeric");
             $('#repair_product_code').val('');
             $('#repair_product_code').focus();
        }  
    }); 
    
    $('#email').change(function () {
        validateFormSupplEmail();
        
    }); 
    $('#email_c').change(function () {
        validateFormCustEmail();
        
    });    
    
    amoutPayableCal();
    removeValidDefault();
     
    //purchase date validations    
    var pdate = '';
    purchaseDateVal(pdate);
   
   //purchase date Repair validations  
   var prdate ='';
    repairPurchaseDate(prdate);
    
	//Hide subcategory during create @Ashok@03-Aug-2017
	 $("#subcategory_c").prop("disabled",true);
     $('#subcategory_c').css('background-color', '#DEDEDE');
     $("#category_c").change( function(){
		$("#subcategory_c").prop("disabled",false);
        $('#subcategory_c').css('background-color', '#ffffff');
	 });
   /*  $("#subcategory_c").prop("disabled",true);
     $('#subcategory_c').css('background-color', '#DEDEDE');
     $("#category_c").change( function(){
         $("#subcategory_c").prop("disabled",false);
         $('#subcategory_c').css('background-color', '#ffffff');
       
        var category ='';
        category = $("#category_c option:selected").text();
        if($("#member_type_c").val() == 'corporate' || $("#member_type_c").val() == 'guest' ){
          
          if(category == 'Loyalty'){
            alert("Loyalty applies only for loyal member.");
            $("#subcategory_c").prop("disabled",true);
            $('#subcategory_c').css('background-color', '#DEDEDE');
          }else{
               $("#subcategory_c").prop("disabled",false);
               $('#subcategory_c').css('background-color', '#ffffff');
          }
        }
     });*/
    
    //date validations
    $("#expiry_date_trigger").hide();
    $("#date_sent_to_supplier_trigger").hide();
    
    // if origin is branch make brannch visible and mandatory dated: 23-jan-2017
   //make origin_c mandatory @Ashok On 06-Apr-2017
    addToValidate('EditView','origin_c','origin_c',true,'');  
    document.getElementById('origin_c_label').innerHTML += '<font color="red">*<font>';
	
	
   if($('#origin_c').val() == 2){
     
	 $('#origin_c').css('pointer-events','none');
     $('#origin_c').css('background-color', '#DEDEDE');
	 
	 $('#branch_store_name').css('pointer-events','none');
     $('#branch_store_name').css('background-color', '#DEDEDE');
   }else if($('#origin_c').val() == 3){
		 $('#origin_c').css('pointer-events','none');
		 $('#origin_c').css('background-color', '#DEDEDE');
	 
		$('#branch_store_name').css('pointer-events','fill');
		$('#branch_store_name').css('background-color', '#ffffff');
   }else{
	    $('#origin_c').css('pointer-events','fill');
         $('#origin_c').css('background-color', '#ffffff');
	   $('#branch_store_name').css('pointer-events','none');
      $('#branch_store_name').css('background-color', '#DEDEDE');
   }
    $('#origin_c').change(function () { 
        if($('#origin_c').val() == 2){
			 $('#origin_c').val('2');
			 $('#branch_store_name').css('background-color', '#ffffff');
			 $('#branch_store_name').val();
			 $('#branch_store_name').css('pointer-events','fill');

        }else if($('#origin_c').val() == 3){
				$('#branch_store_name').css('pointer-events','fill');
               $('#branch_store_name').css('background-color', '#ffffff');
			   $('#origin_c').val('3');
			
        }else{
            $('#branch_store_name').val('');
            $('#branch_store_name').css('pointer-events','none');
            $('#branch_store_name').css('background-color', '#DEDEDE');
          
        }
    });
    var set_record = $('#edit_record').val();
    if(set_record =='undefined' || set_record != '' || set_record != null ){
        $('#case_number').hide();
        $('#case_number_label').hide();

    }else{
        $('#case_number_label').show();
        $('#case_number').show();
    }

	
  //date validation to block the past date repair_date_to_supplier
Calendar.setup ({
    inputField : "repair_date_to_supplier",
    ifFormat : "%m/%d/%Y %I:%M%P",
    daFormat : "%m/%d/%Y %I:%M%P",
    button : "repair_date_to_supplier_trigger",
    singleClick : true,
    dateStr : "",
    startWeekday: 0,
    step : 1,
    weekNumbers:false,
    customMinDate : new Date(),
});

    //date validation to block the past date customer_approval_date
Calendar.setup ({
    inputField : "customer_approval_date",
    ifFormat : "%m/%d/%Y %I:%M%P",
    daFormat : "%m/%d/%Y %I:%M%P",
    button : "customer_approval_date_trigger",
    singleClick : true,
    dateStr : "",
    startWeekday: 0,
    step : 1,
    weekNumbers:false,
    customMinDate : new Date(),
});


   //date validation to block the past date date_sent_to_supplier
Calendar.setup ({
   inputField : "date_sent_to_supplier",
    ifFormat : "%m/%d/%Y %I:%M%P",
    daFormat : "%m/%d/%Y %I:%M%P",
    button : "date_sent_to_supplier_trigger",
    singleClick : true,
    dateStr : "",
    startWeekday: 0,
    step : 1,
    weekNumbers:false,
    customMinDate : new Date(),
});



    //date validation to block the past date date_of_faxed_email
Calendar.setup ({
    inputField : "date_of_faxed_email",
    ifFormat : "%m/%d/%Y %I:%M%P",
    daFormat : "%m/%d/%Y %I:%M%P",
    button : "date_of_faxed_email_trigger",
    singleClick : true,
    dateStr : "",
    startWeekday: 0,
    step : 1,
    weekNumbers:false,
    customMinDate : new Date()
});

   //date validation to block the past date date_of_collection_repair
Calendar.setup ({
    inputField : "date_of_collection_repair",
    ifFormat : "%m/%d/%Y %I:%M%P",
    daFormat : "%m/%d/%Y %I:%M%P",
    button : "date_of_collection_repair_trigger",
    singleClick : true,
    dateStr : "",
    startWeekday: 0,
    step : 1,
    weekNumbers:false,
    customMinDate : new Date()
});

Calendar.setup ({
    inputField : "school_cheque_issuedate",
    ifFormat : "%m/%d/%Y %I:%M%P",
    daFormat : "%m/%d/%Y %I:%M%P",
    button : "school_cheque_issuedate_trigger",
    singleClick : true,
    dateStr : "",
    startWeekday: 0,
    step : 1,
    weekNumbers:false,
   // customMinDate : new Date()
});

//school_cheque_dispatch
Calendar.setup ({
    inputField : "school_cheque_dispatch",
    ifFormat : "%m/%d/%Y %I:%M%P",
    daFormat : "%m/%d/%Y %I:%M%P",
    button : "school_cheque_dispatch_trigger",
    singleClick : true,
    dateStr : "",
    startWeekday: 0,
    step : 1,
    weekNumbers:false,
});

//school_cheque_dispatch
Calendar.setup ({
    inputField : "school_cheque_dispatch",
    ifFormat : "%m/%d/%Y %I:%M%P",
    daFormat : "%m/%d/%Y %I:%M%P",
    button : "school_cheque_dispatch_trigger",
    singleClick : true,
    dateStr : "",
    startWeekday: 0,
    step : 1,
    weekNumbers:false,
});

  //date validation to block the past date dob_c
Calendar.setup ({
    inputField : "dob_c",
    //ifFormat : "%m/%d/%Y %I:%M%P",
    daFormat : "%m/%d/%Y %I:%M%P",
    button : "dob_c_trigger",
    singleClick : true,
    dateStr : "",
    startWeekday: 0,
    step : 1,
    weekNumbers:false
});

//date validation to block the past date purchase_date
Calendar.setup ({
    inputField : "purchase_date",
    ifFormat : "%m/%d/%Y %I:%M%P",
    daFormat : "%m/%d/%Y %I:%M%P",
    button : "purchase_date_trigger",
    singleClick : true,
    dateStr : "",
    startWeekday: 0,
    step : 1,
    weekNumbers:false
});

Calendar.setup ({
    inputField : "expiry_date",
    ifFormat : "%m/%d/%Y %I:%M%P",
    daFormat : "%m/%d/%Y %I:%M%P",
    button : "expiry_date_trigger",
    singleClick : true,
    dateStr : "",
    startWeekday: 0,
    step : 1,
    weekNumbers:false
});



var url_data=$('#siteurl').val();
//22-08-2017 @Ashok on click cancel

 $("#CANCEL_HEADER").on("click", function() {
	var url= url_data+'/index.php?module=Cases&action=list_case_dashlet';
	window.location.href =url;
	
});
$("#CANCEL_FOOTER").on("click", function() {
	var url= url_data+'/index.php?module=Cases&action=list_case_dashlet';
	window.location.href =url;
});



});
function onEdit() {
   
    var set_record = $('#edit_record').val(); 
    if (set_record != '' && set_record != null || set_record =='undefined') {
      $("#btn_email").hide();
      $("#btn_clr").hide(); 
        //make status non - editable @Ashok dated: 19-04-2017 
		if ($('#status').val() == 'Closed'){
               //general field
				$("#status").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#description").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#resolution").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#filename_file").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#assigned_user_name").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#btn_assigned_user_name").hide();
                $("#btn_clr_assigned_user_name").hide();
                $("#btn_email").hide(); $("#btn_clr").hide();
                $("#remove_button").hide();//upload remove button
                
                //product field product replaced
                $("#product_value").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#quality_description").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#purchase_date").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#purchase_date_trigger").hide();
                $("#expiry_date").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#till_no").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#branch_name").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#receipt_no").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#nature_of_complaint").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#prod_sku").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#btn_prod_sku").hide();
                $("#btn_clr_sku").hide();
                $("#branch_manager_comments").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                
                //product repair
                $("#repair_tag_no").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#repair_serial_no").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#repair_model_no").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#repair_nature_of_fault").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#repair_date_to_supplier").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#repair_date_to_supplier_trigger").css({"display": "none"});
                $("#bill_amount").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#suppliers_delivery_note_no").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#date_of_faxed_email").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#date_of_faxed_email_trigger").css({"display": "none"});
                $("#customer_description").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#date_of_collection_repair").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#date_of_collection_repair_trigger").hide();
                
                $("#supplier_comments_repair").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#customer_approval_date").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#customer_approval_date_trigger").css({"display": "none"});
                $("#date_sent_to_supplier").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                $("#date_sent_to_supplier_trigger").hide();
                
                //issue creditnote
                $("#credit_note").css({"background-color": "#DEDEDE", "pointer-events": "none"});
                //school field
                
		}
       // $('#name').attr('readonly', 'true'); // mark it as read only
       // $('#name').css('background-color', '#DEDEDE'); // change the background color
		
		
		//Change the code for feedback
		
		var subcat_str = $("#subcategory_c option:selected").text(); 
		var subcat = subcat_str.toUpperCase();
		var subcat_feedback_str = 'Feedback';
		var subcat_feedback = subcat_feedback_str.toUpperCase();
			
		$("#subcategory_c").prop("disabled", true);
		$("#subcategory_c").css('background-color', '#DEDEDE');
		if( subcat != subcat_feedback ){
			$("#category_c").prop("disabled", true);
			$('#category_c').css('background-color', '#DEDEDE');
			$('#name').css({"background-color": "#DEDEDE", "pointer-events": "none"});
        }else if( subcat == subcat_feedback ){
			$("#category_c").prop("disabled", false);
			$('#category_c').css('background-color', '#FFFFFF');
				$("#subcategory_c").prop("disabled", true);
				$("#subcategory_c").css('background-color', '#DEDEDE');				
				$('#name').css({"background-color": "#FFFFFF", "pointer-events": "fill"});
			$("#category_c").change(function() {
				$("#subcategory_c").prop("disabled", false);
				$("#subcategory_c").css('background-color', '#FFFFFF');				
				$('#name').css({"background-color": "#FFFFFF", "pointer-events": "fill"});
			});
        }else{
			$("#category_c").prop("disabled", true);
			$('#category_c').css('background-color', '#DEDEDE');
			$("#subcategory_c").prop("disabled", true);
			$('#subcategory_c').css('background-color', '#DEDEDE');
			$('#name').css({"background-color": "#FFFFFF", "pointer-events": "fill"});
		}
		
		//EOC
		
        $("#priority").prop("disabled", true);//add this line for disable priority becasue at the time of create case magento priority not changed becasue this is based on subcategory by akhilesh
        $('#priority').css('background-color', '#DEDEDE');
        
        $("#origin_c").prop("disabled", true);
        $('#origin_c').css('background-color', '#DEDEDE');

        $("#created_by_name").prop("readonly", true);
        $("#created_by_id").prop("readonly", true);
        $("#btn_created_by_name").prop("readonly", true);
        $("#btn_clr_created_by_name").prop("readonly", true);
        $('#created_by_name').css('background-color', '#DEDEDE');

        $("#customer_name_c").prop("readonly", true);
        $('#customer_name_c').css('background-color', '#DEDEDE');

        $("#mobile_number_c").prop("readonly", true);
        $('#mobile_number_c').css('background-color', '#DEDEDE');

        $("#email_c").prop("readonly", true);
        $('#email_c').css('background-color', '#DEDEDE');

        $("#gender_c").prop("disabled", true);
        $('#gender_c').css('background-color', '#DEDEDE');

        $("#member_type_c").prop("disabled", true);
        $('#member_type_c').css('background-color', '#DEDEDE');

        $("#loyalty_id_c").prop("readonly", true);
        $('#loyalty_id_c').css('background-color', '#DEDEDE');

        $("#member_tier_c").prop("readonly", true);
        $('#member_tier_c').css('background-color', '#DEDEDE');

        $("#dob_c").prop("readonly", true);
        $('#dob_c').css('background-color', '#DEDEDE');
        $("#dob_c_trigger").hide();

        //school fees redemption validations
        $("#school_parent_name").prop("readonly", true);
        $('#school_parent_name').css('background-color', '#DEDEDE');
        $("#school_points_redeemed").prop("readonly", true);
        $('#school_points_redeemed').css('background-color', '#DEDEDE');
        $("#school_school_name").prop("readonly", true);
        $('#school_school_name').css('background-color', '#DEDEDE');
        $("#school_child_name").prop("readonly", true);
        $('#school_child_name').css('background-color', '#DEDEDE');
        $("#school_amount_payable").prop("readonly", true);
        $('#school_amount_payable').css('background-color', '#DEDEDE');
        $("#school_redemption_rate").prop("readonly", true);
        $('#school_redemption_rate').css('background-color', '#DEDEDE');
        
        //08-02-2017 by Ashok for receipt and till no in loyalty school fees redemtion
        $("#school_receipt_no").prop("readonly", true);
        $('#school_receipt_no').css('background-color', '#DEDEDE');
        $("#school_till_no").prop("readonly", true);
        $('#school_till_no').css('background-color', '#DEDEDE');
        
        $("#school_cheque_status").css("background-color", "#FFFFFF");
        $("#school_cheque_status").css("pointer-events", "block");
        //$("#school_cheque_status").val("Inprogress");
       
        $("input[type=radio]").attr('disabled', true);
    } else {
         $("input[type=radio]").attr('disabled', false);
        $("#school_cheque_status").css("background-color", "#DEDEDE");
        $("#school_cheque_status").css("pointer-events", "block");
       // $("#school_cheque_status").val("Inprogress");
        
        $('#name').attr('readonly', false); // mark it as read only
        $('#name').css('background-color', '#ffffff'); // change the background color

        $("#category_c").prop("disabled", false);
        $('#category_c').css('background-color', '#ffffff');
        $("#subcategory_c").prop("disabled", false);
        $('#subcategory_c').css('background-color', '#ffffff');

        $("#origin_c").prop("disabled", false);
        $('#origin_c').css('background-color', '#ffffff');

        $("#created_by_name").prop("readonly", false);
        $("#created_by_id").prop("readonly", false);
        $("#btn_created_by_name").prop("readonly", false);
        $("#btn_clr_created_by_name").prop("readonly", false);
        $('#created_by_name').css('background-color', '#ffffff');

        $("#customer_name_c").prop("readonly", false);
        $('#customer_name_c').css('background-color', '#ffffff');

        $("#mobile_number_c").prop("readonly", false);
        $('#mobile_number_c').css('background-color', '#ffffff');

        $("#email_c").prop("readonly", false);
        $('#email_c').css('background-color', '#ffffff');

        $("#gender_c").prop("disabled", false);
        $('#gender_c').css('background-color', '#ffffff');

        $("#member_type_c").prop("disabled", false);
        $('#member_type_c').css('background-color', '#ffffff');

        $("#loyalty_id_c").prop("readonly", false);
        $('#loyalty_id_c').css('background-color', '#ffffff');

        $("#member_tier_c").prop("readonly", false);
        $('#member_tier_c').css('background-color', '#ffffff');

        $("#dob_c").prop("readonly", true);
        $('#dob_c').css('background-color', '#ffffff');
        $("#dob_c_trigger").show();

        //school fees redemption validations
        $("#school_parent_name").prop("readonly", false);
        $('#school_parent_name').css('background-color', '#ffffff');
        $("#school_points_redeemed").prop("readonly", false);
        $('#school_points_redeemed').css('background-color', '#ffffff');
        $("#school_school_name").prop("readonly", false);
        $('#school_school_name').css('background-color', '#ffffff');
        $("#school_child_name").prop("readonly", false);
        $('#school_child_name').css('background-color', '#ffffff');
        $("#school_amount_payable").prop("readonly", false);
        $('#school_amount_payable').css('background-color', '#ffffff');
        $("#school_redemption_rate").prop("readonly", false);
        $('#school_redemption_rate').css('background-color', '#ffffff');
        
        //08-02-2017 by Ashok for receipt and till no in loyalty school fees redemtion
        $("#school_receipt_no").prop("readonly", false);
        $('#school_receipt_no').css('background-color', '#ffffff');
        $("#school_till_no").prop("readonly", false);
        $('#school_till_no').css('background-color', '#ffffff');
    }
}

function defaultval() {
    $("#btn_created_by_name").hide();
    $("#btn_clr_created_by_name").hide();
}

function mobile_number(number) {
    var totnum = number.length;
	if(totnum > 1){	
    if (/^\d+$/.test(number)) {
            caseHistoryGuest(number);
    } else if (totnum > 0) {
        alert(" Not A Valid Mobile Number ");
        $("#mobile_number_c").val('');
    }
   }
}
/*
function mobile_number(number) {
    var totnum = number.length;
	if(totnum > 1){
	
    if (/^\d+$/.test(number)) {
        if (totnum === 10) {
            caseHistoryGuest(number);
        } else if ((totnum < 10)) {
            alert(" Not A Valid Mobile Number aa");
            $("#mobile_number_c").val('');
        }
    } else if (totnum > 0) {
        alert(" Not A Valid Mobile Number bb");
        $("#mobile_number_c").val('');
    }
   }
}*/

//birthdate validations
function birthdate_validation(dateenter) {

	var expireDateStr = dateenter;
	var expireDateArr = expireDateStr.split("/");
	var birthdaydate = new Date(expireDateArr[2] , expireDateArr[0] -1, expireDateArr[1]);
	
    var today = new Date();
    if (birthdaydate > today) {
        alert("You cannot select future date");
        $('#dob_c').val('');
        $('#dob_c').focus();
        $("#dob_c").prop("readonly", true);
    } 
}

function caseHistoryGuest(number) {
    if (number == "") {
        document.getElementById("case_history").innerHTML = "";
        return;
    } else if (number.length !== 10) {
        document.getElementById("case_history").innerHTML = "";
        return;
    } else {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        var urlcase = "";
        url = urlcase + "?entryPoint=ajax_casehistory&guest=yes&mobile_number=" + number;

        /* var urlcase = "./ajax_casehistory.php";
         url = urlcase+"?loyalty_id_c="+number;
         */
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("casehistory").innerHTML = xmlhttp.responseText;

            }
        };
        xmlhttp.open("GET", url, true);
        xmlhttp.send();
    }
}
    
function amoutPayableCal() {
   
     $('#school_redemption_rate ,#school_points_redeemed').change(function () {
         var value_entered_rate = $('#school_points_redeemed').val();
        if(value_entered_rate !="" && ($.isNumeric(value_entered_rate))){
            var points = parseFloat($('#school_points_redeemed').val()) || 0;
       
       
            var rate = parseFloat($('#school_redemption_rate').val()) || 0;
            var amt =''; amt = (points * rate).toFixed(2);
            $('#school_amount_payable').val(amt);
            $("#school_amount_payable").prop("readonly", true);
            $('#school_amount_payable').css('background-color' , '#DEDEDE'); 
            $('#school_amount_payable').focus();

           //    alert( $('#school_amount_payable').val());
        }else{ 
             //alert ("Field must be numeric");
             $('#school_points_redeemed').val('');
             $('#school_points_redeemed').focus();
             $('#school_amount_payable').val(0);
             
         }
     });
}

function removeValidDefault(){
            removeFromValidate('EditView','prod_repair_status');
            removeFromValidate('EditView','prod_repair_sku');
            removeFromValidate('EditView','repair_supplier_name');
            removeFromValidate('EditView','complaint_date');
            removeFromValidate('EditView','repair_product_code');
            removeFromValidate('EditView','product_repair_description');
            removeFromValidate('EditView','repair_serial_no');
            removeFromValidate('EditView','repair_model_no');
            removeFromValidate('EditView','repair_nature_of_fault');
            removeFromValidate('EditView','repair_date_to_supplier');
            removeFromValidate('EditView','repair_delivery_note_no');
            removeFromValidate('EditView','supplier_comments_repair');
            removeFromValidate('EditView','customer_approval_date');
            //removeFromValidate('EditView','till_no_repair');
            removeFromValidate('EditView','purchase_date_repair');
            removeFromValidate('EditView','date_of_faxed_email');
            removeFromValidate('EditView','school_points_redeemed');
            removeFromValidate('EditView','suppliers_delivery_note_no');
            removeFromValidate('EditView','suppliers_comments_repair');
            removeFromValidate('EditView','date_of_collection_repair');
            removeFromValidate('EditView','branch_manager_name_repair');
            removeFromValidate('EditView','verified_in_fully');
            removeFromValidate('EditView','released_by_repair');
            removeFromValidate('EditView','branch_mg_pr');
            removeFromValidate('EditView','verified_in_pr_no');
            removeFromValidate('EditView','released_pr_no');
            removeFromValidate('EditView','supplier_name_repair');

            removeFromValidate('EditView','prod_sku');
            removeFromValidate('EditView','prod_supplier_name');
            removeFromValidate('EditView','po_box');
            removeFromValidate('EditView','email');
            removeFromValidate('EditView','fax_no');
            removeFromValidate('EditView','branch_name');
            removeFromValidate('EditView','date_complaint_forwarded');
            removeFromValidate('EditView','grn_no');
            removeFromValidate('EditView','product_value');
            //removeFromValidate('EditView','user_id_c');
            removeFromValidate('EditView','compiled_by');
            //removeFromValidate('EditView','user_id1_c');
            removeFromValidate('EditView','send_to_head_office_by');
            //removeFromValidate('EditView','user_id2_c');
            removeFromValidate('EditView','verified_by');
            removeFromValidate('EditView','product_code_no');
            removeFromValidate('EditView','mode_of_transmission');
            removeFromValidate('EditView','quality_description');
            removeFromValidate('EditView','purchase_date');
            removeFromValidate('EditView','receipt_no');
            removeFromValidate('EditView','till_no');
            removeFromValidate('EditView','expiry_date'); 
            removeFromValidate('EditView','nature_of_complaint');
            removeFromValidate('EditView','product_replaced');
            removeFromValidate('EditView','credit_note');
            removeFromValidate('EditView','date_sent_to_supplier');
            removeFromValidate('EditView','branch_manager_comments');

            removeFromValidate('EditView','school_parent_name');
            removeFromValidate('EditView','school_school_name');
            removeFromValidate('EditView','school_child_name');
            removeFromValidate('EditView','school_amount_payable');
            removeFromValidate('EditView','school_points_redeemed');
            removeFromValidate('EditView','school_redemption_rate');
            removeFromValidate('EditView','school_cheque_status');
            removeFromValidate('EditView','school_cheque_no');
            removeFromValidate('EditView','school_cheque_issuedate');
            removeFromValidate('EditView','school_voucher_No');
            removeFromValidate('EditView','school_particulars');
            removeFromValidate('EditView','school_cheque_dispatch');
            
            removeFromValidate('EditView','school_receipt_no');
            removeFromValidate('EditView','school_till_no');
}

 //email customer
    function validateFormCustEmail() {
        var x = $('#email_c').val();
        var atpos = x.indexOf("@");
        var dotpos = x.lastIndexOf(".");
        if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length) {
            alert("Not a valid e-mail address");
            $('#email_c').val('');
        }
    }
    
     function validateFormSupplEmail() {
        var xe = $('#email').val();
        var atpos = xe.indexOf("@");
        var dotpos = xe.lastIndexOf(".");
        if (atpos<1 || dotpos<atpos+2 || dotpos+2>=xe.length) {
            alert("Not a valid e-mail address");
            $('#email').val('');
        }
    }
    
    //Purchase date validations
function purchaseDateVal(pdate) {
    if(pdate != ''){
       var purDate = pdate;
		var purchaseDateArr = purDate.split("/");
		var purchaseDate = new Date(purchaseDateArr[2] , purchaseDateArr[0] -1, purchaseDateArr[1]);
		var today = new Date();
		if (purchaseDate > today) {
			alert("You cannot select future date");
			$('#purchase_date').val('');
			$('#purchase_date').focus();
			$("#purchase_date").prop("readonly", true);
		}else{
			$('#expiry_date').focus();
			$("#expiry_date_trigger").show();
		}
    }
}
function repairPurchaseDate(prdate) {
     if(prdate != ''){
        var dtSels = new Date(prdate.split("/").reverse().join("-"));
        var month = dtSels.getMonth() + 1;
        var day = dtSels.getDate();
        var year = dtSels.getFullYear();
        var date = month + "/" + day + "/" + year;
        var purchaseDateRep = new Date(date);
        var todayNow = new Date();
        if (purchaseDateRep > todayNow) {
            alert("You cannot select future date");
            $('#purchase_date_repair').val('');
        } else {
            $('#date_of_faxed_email').focus();
        }
    }
}

function expiryDateVal(edate){
    var purchasedate = $('#purchase_date').val();
    if(edate != '' || purchasedate !=''){
            var edtSels = new Date(edate.split("/").reverse().join("-"));
            var emonth = edtSels.getMonth() + 1;
            var eday = edtSels.getDate();
            var eyear = edtSels.getFullYear();
            var edate = emonth + "/" + eday + "/" + eyear;
            var expiryDateRep = new Date(edate);

            
            var pdtSels = new Date(purchasedate.split("/").reverse().join("-"));
            var pmonth = pdtSels.getMonth() + 1;
            var pday = pdtSels.getDate();
            var pyear = pdtSels.getFullYear();
            var pdate = pmonth + "/" + pday + "/" + pyear;
            var purchaseDateRep = new Date(pdate);
            
            if (expiryDateRep < purchaseDateRep) {
                alert("You cannot select past date");
                $('#expiry_date').val('');
            } 
    }else{
        alert("Please enter purchase date");
        $("#expiry_date").prop("readonly", true);
        $("#expiry_date_trigger").hide();
        
    }
}
//date sent to supplier
function sentToSupplierDateVal(supplierSentdate){
	var today = new Date();
	var emonth = today.getMonth() + 1;
	var eday = today.getDate();
	var eyear = today.getFullYear();
	var todatdate = emonth + "/" + eday + "/" + eyear;
					
	var supDate = supplierSentdate;
	var supplierSentdateArr = supDate.split("/");
	var supDate = new Date(supplierSentdateArr[2] , supplierSentdateArr[0] -1, supplierSentdateArr[1]);
	
	var smonth = supDate.getMonth() + 1;
	var sday = supDate.getDate();
	var syear = supDate.getFullYear();
	var toSdatdate = smonth + "/" + sday + "/" + syear;
		
	if (toSdatdate < todatdate) {
		alert("You cannot select past date");//alert("Date cannot be less than purchase date");
		$('#date_sent_to_supplier').val('');
	} 
	
}	

function chequeDispatchDateVal(edate){
    var school_cheque_issuedate = $('#school_cheque_issuedate').val();
    if(edate != '' || school_cheque_issuedate !=''){
	
			var edtSelsArr = edate.split("/");
			var dispatchDateRep = new Date(edtSelsArr[2] , edtSelsArr[0] -1, edtSelsArr[1]);
           
		    var pdtSelsArr = school_cheque_issuedate.split("/");
			var school_cheque_issuedate = new Date(pdtSelsArr[2] , pdtSelsArr[0] -1, pdtSelsArr[1]);
            
            if (dispatchDateRep < school_cheque_issuedate) {
                alert("Cannot select date less then cheque issue date");
                $('#school_cheque_dispatch').val('');
            } 
    }else{
        $("#school_cheque_dispatch").prop("readonly", true);
        $("#school_cheque_dispatch_trigger").hide();
        
    }
}

    
	
	function hideclosebutton(){
			// Cross button of calendar @Ashok Dated: 28-08-2017
			$("#container_dob_c_trigger").find(".container-close").eq(1).hide();
			$("#container_purchase_date_trigger").find(".container-close").eq(1).hide();
			$("#container_expiry_date_trigger").find(".container-close").eq(1).hide();
			$("#container_repair_date_to_supplier_trigger").find(".container-close").eq(1).hide();
			$("#container_customer_approval_date_trigger").find(".container-close").eq(1).hide();
			$("#container_date_sent_to_supplier_trigger").find(".container-close").eq(1).hide();

			$("#container_date_of_faxed_email_trigger").find(".container-close").eq(1).hide();
			$("#container_date_of_collection_repair_trigger").find(".container-close").eq(1).hide();
			$("#container_school_cheque_issuedate_trigger").find(".container-close").eq(1).hide();
			$("#container_school_cheque_dispatch_trigger").find(".container-close").eq(1).hide();
			//EOC close button
	}