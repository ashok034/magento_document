<?php
// Do not store anything in this file that is not part of the array or the hook version.  This file will	
// be automatically rebuilt in the future. 
 $hook_version = 1; 
$hook_array = Array(); 
// position, file, function 
$hook_array['before_save'] = Array(); 
$hook_array['before_save'][] = Array(1, 'Cases push feed', 'modules/Cases/SugarFeeds/CaseFeed.php','CaseFeed', 'pushFeed');
$hook_array['before_save'][] = Array(2, 'Check child cases closed before parent case close', 'custom/modules/Cases/logic_hook/beforeCloseCase.php','before_close_cases', 'before_close');
$hook_array['before_save'][] = Array(3, 'assign case to finance team', 'custom/modules/Cases/logic_hook/assign_case.php','assign_class', 'assignCases');
$hook_array['before_save'][] = Array(4, 'auto increment voucher no', 'custom/modules/Cases/logic_hook/autoincrement.php','autoincremet_class', 'autoincremetCases');
$hook_array['before_save'][] = Array(5, 'auto increment delivery note no', 'custom/modules/Cases/logic_hook/autoincrement.php','autoincremet_class', 'autoincremetDeliveryNoteNo');
//$hook_array['before_save'][] = Array(6, 'file upload functionality', 'custom/modules/Cases/logic_hook/file_upload.php','upload_class', 'uploadFiles');
$hook_array['after_save'] = Array();  
//$hook_array['after_save'][] = Array(1, 'send product Quality Complaint form to supplier', 'custom/modules/Cases/logic_hook/product_quality_email.php', 'ComplaintForm', 'ComplaintFormToSupplier');
$hook_array['after_save'][] = Array(2, 'Send Email based on Status', 'custom/modules/Cases/logic_hook/send_email.php','send_email_class', 'sendEmailCases');
$hook_array['after_save'][] = Array(3, 'Send SMS to Customer on resolved', 'custom/modules/Cases/logic_hook/smsfeedforcustomer.php','smsfeedforcustomer', 'sendSMS');
//$hook_array['after_save'][] = Array(2, 'assign case to finance team', 'custom/modules/Cases/logic_hook/assign_case.php','assign_class', 'assignCases');//comment this line and call before_save hook.

//@Ashok : Dated: 17/08/2017 - new requirement where user will notify for every case creation
$hook_array['after_save'][] = Array(4, 'Send Email To Users', 'custom/modules/Cases/logic_hook/send_email_users.php','send_email_user_class', 'sendEmailUserCases');


$hook_array['process_record'] = Array(); 
$hook_array['process_record'][] = Array(1, 'Cases display category and sub cat', 'custom/modules/Cases/logic_hook/fetch_catandsub.php','logic_hooks_class', 'display_catsubcat');

$hook_array['before_delete'] = Array(); 
$hook_array['before_delete'][] = Array(3, 'Check cases before delete', 'custom/modules/Cases/logic_hook/beforeDelete.php','before_delete_class', 'before_delete_method');
?>