<?php

if (!defined('sugarEntry'))
    define('sugarEntry', true);
/* * *******************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 * ****************************************************************************** */
require_once('include/MVC/Controller/SugarController.php');
require_once('custom/include/rolehack.php');
define('FACEBOOK_SDK_V4_SRC_DIR', 'custom/include/facebook/src/Facebook/');
require_once('custom/include/facebook/src/Facebook/autoload.php');
require_once 'custom/include/twitter/src/twitter.class.php';

class CampaignsController extends SugarController {

    public $module = 'Campaigns';

    /**
     * This method is Display to list of all Campaigns
     *
     */
    public function action_listView() {
        global $db, $current_user;
        $list_campaigns = array();
        $condition = '';
        if (isset($_REQUEST['query']) == 'true') {
            if ((isset($_REQUEST['range_start_date_advanced']) || isset($_REQUEST['campaign_id_c_advanced']) || isset($_REQUEST['campaign_type_advanced']) || isset($_REQUEST['range_end_date_advanced']) || isset($_REQUEST['name_advanced']) || isset($_REQUEST['campaign_subtype_advanced']) || isset($_REQUEST['status_advanced']))) {

                //Campaign ID
                if (!empty($_REQUEST['campaign_id_c_advanced'])) {
                    $condition .= " AND cmp.campaign_id_c = '" . $_REQUEST['campaign_id_c_advanced'] . "' ";
                }
                //Campaign Name
                if (!empty($_REQUEST['name_advanced'])) {
                    $condition .= " AND cmp.name LIKE '%" . $_REQUEST['name_advanced'] . "%' ";
                }
                //Campaign Start Date
                if (!empty($_REQUEST['range_start_date_advanced'])) {
                    $condition .= " AND cmp.start_date >= '" . date("Y-m-d", strtotime($_REQUEST['range_start_date_advanced'])) . "' ";
                }
                //Campaign End Date
                if (!empty($_REQUEST['range_end_date_advanced'])) {
                    $condition .= " AND cmp.end_date <= '" . date("Y-m-d", strtotime($_REQUEST['range_end_date_advanced'])) . "' ";
                }
                //Campaign Type
                if (!empty($_REQUEST['campaign_type_advanced'])) {
                    $typewhere = ' AND ( ';
                    foreach ($_REQUEST['campaign_type_advanced'] as $cmptype) {
                        $typewhere .=' cmp.campaign_type LIKE \'%' . $cmptype . '%\' OR ';
                    }
                    $typewhere = substr($typewhere, 0, -3) . ' ) ';
                    $campaign_type_advanced = (isset($_REQUEST['campaign_type_advanced'])) ? $typewhere : '';
                    $condition .=!empty($campaign_type_advanced) ? $campaign_type_advanced : "";
                }
                //Campaign SubType
                if (!empty($_REQUEST['campaign_subtype_advanced'])) {
                    $subtypewhere = ' AND ( ';
                    foreach ($_REQUEST['campaign_subtype_advanced'] as $cmpsubtype) {
                        $subtypewhere .=' cmp.campaign_subtype LIKE \'%' . $cmpsubtype . '%\' OR ';
                    }
                    $subtypewhere = substr($subtypewhere, 0, -3) . ' ) ';
                    $campaign_subtype_advanced = (isset($_REQUEST['campaign_subtype_advanced'])) ? $subtypewhere : '';
                    $condition .=!empty($campaign_subtype_advanced) ? $campaign_subtype_advanced : "";
                }
                //Campaign Status
                if (!empty($_REQUEST['status_advanced'])) {
                    $status = "'" . implode("','", $_REQUEST['status_advanced']) . "'";
                    $condition .= ' AND cmp.status IN (' . $status . ')';
                }
                // $condition .=" AND ";
                $query_campaign = 'Select cmp.id, cmp.campaign_id_c, cmp.name, cmp.status, cmp.date_entered, cmp.campaign_type, '
                        . 'cmp.campaign_subtype, concat(us.first_name," ",us.last_name) as created_by_name '
                        . 'FROM campaigns as cmp LEFT JOIN users as us ON us.id=cmp.created_by '
                        . 'WHERE cmp.deleted=0 ' . $condition . ' ORDER BY cmp.date_entered DESC';

                $result = $db->query($query_campaign);
                while ($row = $db->fetchByAssoc($result)) {
                    $row['date_entered'] = date('d/m/Y H:i A', strtotime($row['date_entered']));
                    $row['campaign_type'] = implode(',', $this->getCMPTypeNameBYID($row['campaign_type']));
                    $row['campaign_subtype'] = implode(',', $this->getCMPSubTypeNameBYID($row['campaign_subtype']));
                    $list_campaigns[] = $row;
                }
                $this->view_object_map['range_start_date_advanced'] = $_REQUEST['range_start_date_advanced'];
                $this->view_object_map['campaign_id_c_advanced'] = $_REQUEST['campaign_id_c_advanced'];
                $this->view_object_map['campaign_type_advanced'] = $_REQUEST['campaign_type_advanced'];
                $this->view_object_map['range_end_date_advanced'] = $_REQUEST['range_end_date_advanced'];
                $this->view_object_map['name_advanced'] = $_REQUEST['name_advanced'];
                $this->view_object_map['campaign_subtype_advanced'] = $_REQUEST['campaign_subtype_advanced'];
                $this->view_object_map['status_advanced'] = $_REQUEST['status_advanced'];
                $this->view_object_map['list_subtype'] = $this->getCMPSubTypeName($_REQUEST['campaign_type_advanced']);
            }
        } else {

            $query_campaign = 'Select cmp.id, cmp.campaign_id_c, cmp.name, cmp.status, cmp.date_entered, cmp.campaign_type, '
                    . 'cmp.campaign_subtype, concat(us.first_name," ",us.last_name) as created_by_name '
                    . 'FROM campaigns as cmp LEFT JOIN users as us ON us.id=cmp.created_by '
                    . 'WHERE cmp.deleted=0 ' . $condition . ' ORDER BY cmp.date_entered DESC';
            $result = $db->query($query_campaign);
            while ($row = $db->fetchByAssoc($result)) {
                $row['date_entered'] = date('d/m/Y H:i A', strtotime($row['date_entered']));
                $row['campaign_type'] = implode(',', $this->getCMPTypeNameBYID($row['campaign_type']));
                $row['campaign_subtype'] = implode(',', $this->getCMPSubTypeNameBYID($row['campaign_subtype']));
                $list_campaigns[] = $row;
            }
            $this->view_object_map['list_subtype'] = array();
        }
        // echo'<pre>';  print_r($list_campaigns); //This is for DEBUG Code
        $this->view_object_map['list_type'] = $this->getCMPTypeName();
        //$this->view_object_map['list_subtype'] = $this->getCMPSubTypeName();
        $this->view_object_map['list_campaigns'] = $list_campaigns;
        
        //start Roles and Permission Hacks by Akhilesh
        $uid        = $current_user->id; //Logged in User ID
        $category   = "Campaigns"; //Module name
        $type       = "module"; //Nochnage
        $rootAction = "campaign"; //Root or Parent Action name according to magento Root action

        $subActionView = "view"; //View ICON
        $viewIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionView, $type);
        $this->view_object_map['viewIcon'] = $viewIcon;
        
        $subActionSearch  = "search"; //Search ICON
        $searchIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionSearch, $type);
        $this->view_object_map['searchIcon'] = $searchIcon;
        
        $subActionCreate  = "create"; //Create ICON
        $createIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionCreate, $type);
        $this->view_object_map['createIcon'] = $createIcon;
        
        $subActionEdit = "edit"; //Edit ICON
        $editIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionEdit, $type);
        $this->view_object_map['editIcon'] = $editIcon;
        
        $subActionExport  = "export"; //Export ICON
        $exportIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionExport, $type);
        $this->view_object_map['exportIcon'] = $exportIcon;
        
        $subActionDelete  = "delete"; //Export ICON
        $deleteIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionDelete, $type);
        $this->view_object_map['deleteIcon'] = $deleteIcon;
        
        $subActionClone = "clone"; //Clone ICON
        $cloneIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionClone, $type);
        $this->view_object_map['cloneIcon'] = $cloneIcon;
        
        $subActionApprove  = "approve"; //approve ICON
        $approveIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionApprove, $type);
        $this->view_object_map['approveIcon'] = $approveIcon;
        
        $subActionReject  = "reject"; //reject ICON
        $rejectIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionReject, $type);
        $this->view_object_map['rejectIcon'] = $rejectIcon;
        
        $this->view_object_map['adminRole'] = $current_user->isAdmin();//$GLOBALS['current_user']
        //end Roles and Permission Hacks by Akhilesh
        
        $this->view = 'list';
    }

    /**
     * This method is Get all campaign type name
     */
    function getCMPTypeName() {
        global $db;
        $type = array();
        $sql = "SELECT id, name FROM camp_type WHERE deleted=0 ORDER BY name ASC";
        $result = $db->query($sql);
        while ($row = $db->fetchByAssoc($result)) {
            $type[] = $row;
        }
        return $type;
    }

    /**
     * This method is Get all campaign Subtype name according to campaign  
    */
     public function getCMPSubTypeName($camptypeID) {
      if (!empty($camptypeID)) {
            global $db;
            $subtype  = array();
            $sql = "SELECT id,name FROM `camp_subtype` where deleted=0 AND type_id IN (" . sprintf("'%s'", implode("', '", $camptypeID)) . ")";
            $result = $db->query($sql);
            while ($row = $db->fetchByAssoc($result)) {
              $subtype[] = $row;
            }
            return $subtype;
        }
      }

    /**
     * This method for delete campaigns
     */
    function action_deleteCampaign() {
        if (!empty($_POST['cid'])) {
            foreach ($_POST['cid'] as $cid) {
                $sql = "SELECT id FROM campaigns WHERE id='" . $cid . "'";
                $results = $GLOBALS['db']->query($sql);
                if ($results->num_rows > 0) {
                    $bean = BeanFactory::getBean('Campaigns', $cid);
                    $bean->deleted = 1;
                    $bean->save();
                }
            }
            echo 1;
            exit;
        }
    }

    /**
     * This method for export campaigns
     */
    function action_exportCampaign() {
        if (!isset($_POST['mass']) OR ! is_array($_POST['mass'])) {
            //echo 'No rows selected for export';
            SugarApplication::appendErrorMessage('<span class="msg-error">No rows selected for export.</span>');
            $queryParams = array(
                'module' => 'Campaigns',
                'action' => 'index'
            );
            SugarApplication::redirect('index.php?' . http_build_query($queryParams));
        } else {
            if (!empty($_POST['mass'])) {
                global $db;
                $list = array();
                $list['tableheading'] = array('Campaign ID', 'Campaign Name', 'Campaign Description', 'Campaign Type', 'Campaign SubType', 'Start Date', 'End Date', 'Status', 'Created Date', 'Created By', 'Country', 'Budget', 'Expected Revenue', 'Campaign Cost', 'Campaign Owner');
                $fichier = "CampaignsList" . date('Y-m-d:H:i:s') . ".xls";
                header("Content-Type: text/csv;charset=utf-8");
                header("Content-Disposition: attachment;filename=\"$fichier\"");
                header("Pragma: no-cache");
                header("Expires: 0");
                $fp = fopen('php://output', 'w');
                fputcsv($fp, $list['tableheading']);
                //Fetch data
                $IDs = implode('","', $_POST['mass']);
                $condition = ' cmp.id IN ("' . $IDs . '")';
                $sql = 'Select cmp.id, cmp.campaign_id_c, cmp.name, cmp.content, cmp.campaign_type, cmp.campaign_subtype, '
                        . 'cmp.start_date, cmp.end_date, cmp.status, cmp.date_entered, concat(us.first_name," ",us.last_name) as created_by_name, '
                        . 'cmp.country, cmp.budget, cmp.expected_revenue, cmp.campaign_cost, cmp.campaign_owner '
                        . 'FROM campaigns as cmp LEFT JOIN users as us ON us.id=cmp.created_by '
                        . 'WHERE ' . $condition . ' AND cmp.deleted=0 ORDER BY cmp.id ASC';
                $result = $db->query($sql);
                while ($row = $db->fetchByAssoc($result)) {
                    $row['campaign_type'] = implode(',', $this->getCMPTypeNameBYID($row['campaign_type']));
                    $row['campaign_subtype'] = implode(',', $this->getCMPSubTypeNameBYID($row['campaign_subtype']));
                    $data['list'] = array($row['campaign_id_c'], $row['name'], $row['content'], $row['campaign_type'], $row['campaign_subtype'], $row['start_date'], $row['end_date'], $row['status'], $row['date_entered'], $row['created_by_name'], $row['country'], $row['budget'], $row['expected_revenue'], $row['campaign_cost'], $row['campaign_owner']);
                    fputcsv($fp, $data['list']); //Genrate XLS
                }
                fclose($fp);
                exit();
            }
        }
    }

    /**
     * This method is Get Campaign Types By ID
     */
    public function getCMPTypeNameBYID($cmp_type_ids) {
        global $db;
        if (!empty($cmp_type_ids)) {
            $type = array();
            $sql = "SELECT name FROM camp_type WHERE deleted=0 AND id IN (" . sprintf("'%s'", implode("', '", explode(',', $cmp_type_ids))) . ")";
            $result = $db->query($sql);
            while ($row = $db->fetchByAssoc($result)) {
                $type[] = $row['name'];
            }
            return $type;
        }
    }

    /**
     * This method is Get Campaigns Subtypes BY ID
     *
     */
    public function getCMPSubTypeNameBYID($cmp_subtype_ids) {
        global $db;
        if (!empty($cmp_subtype_ids)) {
            $subtype = array();
            $sql = "SELECT name FROM camp_subtype WHERE deleted=0 AND id IN (" . sprintf("'%s'", implode("', '", explode(',', $cmp_subtype_ids))) . ")";
            $result = $db->query($sql);
            while ($row = $db->fetchByAssoc($result)) {
                $subtype[] = $row['name'];
            }
            return $subtype;
        }
    }

    /**
     * This method is Display to add/edit Campaigns
     *
     */
    public function action_detailView() {

        $this->view = 'detail';
        //get campaign type
        $sql = "SELECT id,name FROM `camp_type` where deleted=0";
        $result = $GLOBALS['db']->query($sql);
        while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
            $cData[$row['id']] = $row['name'];
        }
        $this->view_object_map['Camp_Type'] = $cData;
        $this->view_object_map['camp_id'] = $this->get_campaign_no();
        // get all subtype record
        $sql = "SELECT * FROM `camp_subtype` where deleted=0";
        $result_subtype = $GLOBALS['db']->query($sql);
        if ($result_subtype->num_rows > 0) {
            $camp_subtype = array();
            while ($row = $GLOBALS['db']->fetchByAssoc($result_subtype)) {
                $camp_subtype[] = $row;
            }
            $this->view_object_map['camp_subtype'] = $camp_subtype;
        }
        if (isset($_GET['record'])) {
            $sql = "SELECT * FROM `campaigns` where id='" . $_GET['record'] . "'";
            $result = $GLOBALS['db']->query($sql);
            while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
                if ($row['start_date'] == '0000-00-00' || $row['start_date'] == NULL)
                    $row['start_date'] = '';
                else
                    $row['start_date'] = date("m/d/Y", strtotime($row['start_date']));
                if ($row['end_date'] == '0000-00-00' || $row['end_date'] == NULL)
                    $row['end_date'] = '';
                else
                    $row['end_date'] = date("m/d/Y", strtotime($row['end_date']));
                $campaign = $row;
            }
            $this->view_object_map['campaign'] = $campaign;
            $sql_sup = "SELECT id,supplier_id,supplier_cost,cost_type,cmp_id FROM `camp_supplier` where deleted=0 AND cmp_id='" . $_GET['record'] . "' order by id";
            $result_sup = $GLOBALS['db']->query($sql_sup);
            $campaign_sup = array();
            while ($row_sup = $GLOBALS['db']->fetchByAssoc($result_sup)) {

                //start fetch sup name by sup id
                if (!empty($row_sup['supplier_id'])) {
                    $arr_sup_name = array();
                    $sql_sup1 = "SELECT id,name FROM `naku_suppliers` where deleted=0 AND id = '" . $row_sup['supplier_id'] . "'";
                    $result_sup1 = $GLOBALS['db']->query($sql_sup1);
                    while ($row_sup1 = $GLOBALS['db']->fetchByAssoc($result_sup1)) {
                        $row_sup['sup_name'] = $row_sup1['name'];
                    }
                } else {
                    $row_sup['sup_name'] = '';
                }
                $campaign_sup[] = $row_sup;
                //end fetch sup name by sup id
            }
            // fetch campaign activity
            $sql = "SELECT * FROM `camp_activity` where deleted=0 AND cmp_id='" . $_GET['record'] . "'";
            $result = $GLOBALS['db']->query($sql);
            $camp_subtype1 = array();
            while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
                //event start datetime
                if ($row['event_start_datetime'] == '0000-00-00 00:00:00' || $row['event_start_datetime'] == NULL) {
                    $row['event_start_datetime'] = '';
                } else {
                    $event_start_datetime = new DateTime($row['event_start_datetime']);
                    $row['event_start_datetime'] = $event_start_datetime->format('m/d/Y h:i:s a');
                }

                if ($row['event_end_datetime'] == '0000-00-00 00:00:00' || $row['event_end_datetime'] == NULL) {
                    $row['event_end_datetime'] = '';
                } else {
                    $event_end_datetime = new DateTime($row['event_end_datetime']);
                    $row['event_end_datetime'] = $event_end_datetime->format('m/d/Y h:i:s a');
                }
                //event end datetime 
                //get Branch name BY ID
                if (!empty($row['store_type'])) {
                    if ($row['store_type'] == 1) { //echo'instore';
                        $row['event_place'] = $this->getBranchNameBYID($row['event_place']);
                    } else { //echo'outstore';
                        $row['event_place'] = $row['event_place'];
                    }
                }
                //end
                //get Poll name
                if (!empty($row['polls_id'])) {
                    $row['polls_id'] = $this->getPollNameBYID($row['polls_id']);
                }
                //end
                if ($row['start_date'] == '0000-00-00' || $row['start_date'] == NULL)
                    $row['start_date'] = '';
                else
                    $row['start_date'] = date("m/d/Y", strtotime($row['start_date']));
                if ($row['end_date'] == '0000-00-00' || $row['end_date'] == NULL)
                    $row['end_date'] = '';
                else
                    $row['end_date'] = date("m/d/Y", strtotime($row['end_date']));
                //start fetch asset id and name
                if (!empty($row['asset_id_c'])) {
                    $arr_asset_name = array();
                    $sql_asset = "SELECT id,name FROM `asset_assets` where deleted=0 AND id IN (" . sprintf("'%s'", implode("', '", explode(',', $row['asset_id_c']))) . ")";
                    $result_asset = $GLOBALS['db']->query($sql_asset);
                    $camp_asset = array();
                    while ($row_asset = $GLOBALS['db']->fetchByAssoc($result_asset)) {
                        $arr_asset_name[$row_asset['id']] = $row_asset['name'];
                    }
                    $row['asset_name_c'] = $arr_asset_name;
                } else {
                    $row['asset_name_c'] = '';
                }
                //end fetch asset id and name
                //start fetch promotion id and name
                if (!empty($row['promotion_id_c'])) {
                    //09-05-17
                    global $sugar_config, $db;
                    $conn = $this->connectionCRMDB();
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }
                    $camp_prom_name = array();
                    //$sql_prom_name    = "SELECT row_id, name, promo_name, core_promotion, auto_coupon_code, reward_type, reward_value, reward_days FROM ". $sugar_config['crm_salesrule'] ." WHERE is_active = 1 AND customer_segment = ".$row_type_activity['marketing_list_id']." AND row_id IN (" . sprintf("'%s'", implode("', '", explode(',', $row_type_activity['promotion_id_c']))) . ")";
                    $sql_prom_name = "SELECT row_id, name, promo_name, core_promotion, auto_coupon_code, reward_type, reward_value, reward_days FROM " . $sugar_config['crm_salesrule'] . " WHERE is_active = 1 AND row_id IN (" . sprintf("'%s'", implode("', '", explode(',', $row['promotion_id_c']))) . ")";
                    $result_prom_name = $conn->query($sql_prom_name);
                    while ($row_prom_name = $db->fetchByAssoc($result_prom_name)) {
                        $camp_prom_name[] = $row_prom_name;
                    }
                    /* $arr_prom_name = array();
                      $sql_prom_name = "SELECT id,name FROM `naku_promotions` where deleted=0 AND id IN (" . sprintf("'%s'", implode("', '", explode(',', $row['promotion_id_c']))) . ")";
                      $result_prom_name = $GLOBALS['db']->query($sql_prom_name);
                      $camp_prom_name = array();
                      while ($row_prom_name = $GLOBALS['db']->fetchByAssoc($result_prom_name)) {
                      $camp_prom_name[$row_prom_name['id']] = $row_prom_name['name'];
                      } */
                    $row['prom_name_c'] = $camp_prom_name;
                } else {
                    $row['prom_name_c'] = '';
                }
                //end fetch promotion id and name
                //start fetch coupon id and name
                if (!empty($row['coupon_id_c'])) {
                    $sql_coupon_name = "SELECT id,name FROM `naku_coupons` where deleted=0 AND id IN (" . sprintf("'%s'", implode("', '", explode(',', $row['coupon_id_c']))) . ")";
                    $result_coupon_name = $GLOBALS['db']->query($sql_coupon_name);
                    $camp_coupon_name = array();
                    while ($row_coupon_name = $GLOBALS['db']->fetchByAssoc($result_coupon_name)) {
                        $camp_coupon_name[$row_coupon_name['id']] = $row_coupon_name['name'];
                    }
                    $row['coupon_name_c'] = $camp_coupon_name;
                } else {
                    $row['coupon_name_c'] = '';
                }
                //end fetch coupon id and name
                // start fetch marketing list name
                $marketinglist_name = $this->get_marketing_list_name($row['marketing_list_id']);
                $row['marketinglist_name'] = $marketinglist_name;
                //end fetch marketing list name
                //start fetch template id and name
                if (!empty($row['template_id_c'])) {
                    $arr_asset_name = array();
                    $sql_templ = "SELECT id,name FROM `email_templates` where deleted=0 AND id='" . $row['template_id_c'] . "'";
                    $result_templ = $GLOBALS['db']->query($sql_templ);
                    $arr_templ_name = array();
                    while ($row_templ = $GLOBALS['db']->fetchByAssoc($result_templ)) {
                        $row['template_name_c'] = $row_templ['name'];
                    }
                } else {
                    $row['template_name_c'] = '';
                }
                //end fetch template id and name
                $camp_subtype1[$row['cmp_subtype_id']] = $row;
            }
            //echo '<pre>'; print_r($camp_subtype1['6d16935d-2681-a659-e3ab-584a9a486c0f']['coupon_name_c']); 
            //fetch campaign type activity
            $sql_type_activity = "SELECT * FROM `camp_typeactivity` where deleted=0 AND cmp_id='" . $_GET['record'] . "'";
            $result_type_activity = $GLOBALS['db']->query($sql_type_activity);
            $camp_type_activity = array();
            while ($row_type_activity = $GLOBALS['db']->fetchByAssoc($result_type_activity)) {
                //start to fetch detail of trigger based, activity based,datebased data	
                //start fetch link product portfolio
                if (!empty($row_type_activity['link_product_portfolio'])) {
                    $product_name_list = $this->get_product_portfolio_list_name($row_type_activity['link_product_portfolio']);
                    $row_type_activity['product_portfolio'] = $product_name_list;
                } else {
                    $row_type_activity['product_portfolio'] = '';
                }
                //end fetch link product portfolio
                //start fetch template id and name
                if (!empty($row_type_activity['template_id'])) {
                    $sql_temp_name = "SELECT id,name FROM `email_templates` where deleted=0 AND id = '" . $row_type_activity['template_id'] . "'";
                    $result_temp_name = $GLOBALS['db']->query($sql_temp_name);
                    $camp_temp_name = '';
                    while ($row_temp_name = $GLOBALS['db']->fetchByAssoc($result_temp_name)) {
                        $camp_temp_name = $row_temp_name['name'];
                    }
                    $row_type_activity['template_name'] = $camp_temp_name;
                } else {
                    $row_type_activity['template_name'] = '';
                }
                //end fetch template id and name
                //start fetch promotion id and name
                if (!empty($row_type_activity['promotion_id_c'])) {
                    //09-05-17
                    global $sugar_config, $db;
                    $conn = $this->connectionCRMDB();
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }
                    $camp_prom_name = array();
                    //$sql_prom_name    = "SELECT row_id, name, promo_name, core_promotion, auto_coupon_code, reward_type, reward_value, reward_days FROM ". $sugar_config['crm_salesrule'] ." WHERE is_active = 1 AND customer_segment = ".$row_type_activity['marketing_list_id']." AND row_id IN (" . sprintf("'%s'", implode("', '", explode(',', $row_type_activity['promotion_id_c']))) . ")";
                    $sql_prom_name = "SELECT row_id, name, promo_name, core_promotion, auto_coupon_code, reward_type, reward_value, reward_days FROM " . $sugar_config['crm_salesrule'] . " WHERE is_active = 1 AND row_id IN (" . sprintf("'%s'", implode("', '", explode(',', $row_type_activity['promotion_id_c']))) . ")";
                    $result_prom_name = $conn->query($sql_prom_name);
                    while ($row_prom_name = $db->fetchByAssoc($result_prom_name)) {
                        $camp_prom_name[] = $row_prom_name;
                    }
                    /* $arr_prom_name = array();
                      $sql_prom_name = "SELECT id,name FROM `naku_promotions` where deleted=0 AND id IN (" . sprintf("'%s'", implode("', '", explode(',', $row_type_activity['promotion_id_c']))) . ")";
                      $result_prom_name = $GLOBALS['db']->query($sql_prom_name);
                      $camp_prom_name = array();
                      while ($row_prom_name = $GLOBALS['db']->fetchByAssoc($result_prom_name)) {
                      $camp_prom_name[$row_prom_name['id']] = $row_prom_name['name'];
                      } */
                    $row_type_activity['prom_name_c'] = $camp_prom_name;
                } else {
                    $row_type_activity['prom_name_c'] = '';
                }
                //end fetch promotion id and name
                //start fetch coupon id and name
                if (!empty($row_type_activity['link_coupon_code'])) {
                    $sql_coupon_name = "SELECT id,name FROM `naku_coupons` where deleted=0 AND id IN (" . sprintf("'%s'", implode("', '", explode(',', $row_type_activity['link_coupon_code']))) . ")";
                    $result_coupon_name = $GLOBALS['db']->query($sql_coupon_name);
                    $camp_coupon_name1 = array();
                    while ($row_coupon_name = $GLOBALS['db']->fetchByAssoc($result_coupon_name)) {
                        $camp_coupon_name1[] = $row_coupon_name['name'];
                    }
                    $row_type_activity['coupon_name_c'] = $camp_coupon_name1;
                } else {
                    $row_type_activity['coupon_name_c'] = '';
                }
                //end fetch coupon id and name
                // start fetch marketing list name
                $marketinglist_name = $this->get_marketing_list_name($row_type_activity['marketing_list_id_c']);
                $row_type_activity['marketinglist_name'] = $marketinglist_name;
                //end fetch marketing list name
                $camp_type_activity[] = $row_type_activity;

                //end to fetch detail of trigger based, activity based,datebased data	
                $camp_type_activity[$row_type_activity['cmp_activity_id']][] = $row_type_activity;
            }

            $this->view_object_map['campaign'] = $campaign;
            $this->view_object_map['campaign_sup'] = $campaign_sup;
            $this->view_object_map['campaign_sup_count'] = count($campaign_sup);
            $this->view_object_map['campaign_activity'] = $camp_subtype1;
            $this->view_object_map['camp_type_activity'] = $camp_type_activity;
        }
    }

    public function action_editView() {
        
        //start Roles and Permission Hacks by Akhilesh
        global $db, $current_user;
        $uid        = $current_user->id; //Logged in User ID
        $category   = "Campaigns"; //Module name
        $type       = "module"; //Nochnage
        $rootAction = "campaign"; //Root or Parent Action name according to magento Root action
        
        $subActionApprove  = "approve"; //approve ICON
        $approveIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionApprove, $type);
        $this->view_object_map['approveIcon'] = $approveIcon;
        
        $subActionReject  = "reject"; //reject ICON
        $rejectIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionReject, $type);
        $this->view_object_map['rejectIcon'] = $rejectIcon;
        
        $this->view_object_map['adminRole'] = $current_user->isAdmin();//$GLOBALS['current_user']
        //end Roles and Permission Hacks by Akhilesh
        
        //get campaign type
        $sql = "SELECT id,name FROM `camp_type` where deleted=0";
        $result = $GLOBALS['db']->query($sql);
        while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
            $cData[$row['id']] = $row['name'];
        }
        $this->view_object_map['Camp_Type'] = $cData;
        $this->view_object_map['camp_id'] = $this->get_campaign_no();
        // get all subtype record
        $sql = "SELECT * FROM `camp_subtype` where deleted=0";
        $result_subtype = $GLOBALS['db']->query($sql);
        if ($result_subtype->num_rows > 0) {
            $camp_subtype = array();
            while ($row = $GLOBALS['db']->fetchByAssoc($result_subtype)) {
                $camp_subtype[] = $row;
            }
            $this->view_object_map['camp_subtype'] = $camp_subtype;
        }

        // get selected record
        if (isset($_GET['id'])) {
            $sql = "SELECT * FROM `campaigns` where id='" . $_GET['id'] . "'";
            $result = $GLOBALS['db']->query($sql);
            while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
                if ($row['start_date'] == '0000-00-00' || $row['start_date'] == NULL)
                    $row['start_date'] = '';
                else
                    $row['start_date'] = date("m/d/Y", strtotime($row['start_date']));
                if ($row['end_date'] == '0000-00-00' || $row['end_date'] == NULL)
                    $row['end_date'] = '';
                else
                    $row['end_date'] = date("m/d/Y", strtotime($row['end_date']));
                $campaign = $row;
            }
            $this->view_object_map['campaign'] = $campaign;
            $sql_sup = "SELECT id,supplier_id,supplier_cost,cost_type,cmp_id FROM `camp_supplier` where deleted=0 AND cmp_id='" . $_GET['id'] . "' order by id";
            $result_sup = $GLOBALS['db']->query($sql_sup);
            $campaign_sup = array();
            while ($row_sup = $GLOBALS['db']->fetchByAssoc($result_sup)) {

                //start fetch sup name by sup id
                if (!empty($row_sup['supplier_id'])) {
                    $arr_sup_name = array();
                    $sql_sup1 = "SELECT id,name FROM `naku_suppliers` where deleted=0 AND id = '" . $row_sup['supplier_id'] . "'";
                    $result_sup1 = $GLOBALS['db']->query($sql_sup1);
                    while ($row_sup1 = $GLOBALS['db']->fetchByAssoc($result_sup1)) {
                        $row_sup['sup_name'] = $row_sup1['name'];
                    }
                } else {
                    $row_sup['sup_name'] = '';
                }
                $campaign_sup[] = $row_sup;
                //end fetch sup name by sup id
            }
            // fetch campaign activity
            $sql = "SELECT * FROM `camp_activity` where deleted=0 AND cmp_id='" . $_GET['id'] . "'";
            $result = $GLOBALS['db']->query($sql);
            $camp_subtype1 = array();
            while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
                //event start datetime
                if ($row['event_start_datetime'] == '0000-00-00 00:00:00' || $row['event_start_datetime'] == NULL) {
                    $row['event_start_datetime'] = '';
                } else {
                    $event_start_datetime = new DateTime($row['event_start_datetime']);
                    $explode_event_start_datetime = explode(' ', $event_start_datetime->format('m/d/Y h:i:s a'));
                    $event_duration_from_date = $explode_event_start_datetime[0]; //date
                    $explode_hrsmin = explode(':', $explode_event_start_datetime[1]);
                    $date_start_hours = $explode_hrsmin[0]; //hrs
                    $date_start_minutes = $explode_hrsmin[1]; //min
                    $date_start_meridiem = $explode_event_start_datetime[2]; //am pm
                    $row['event_duration_from_date'] = $event_duration_from_date;
                    $row['date_start_hours'] = $date_start_hours;
                    $row['date_start_minutes'] = $date_start_minutes;
                    $row['date_start_meridiem'] = $date_start_meridiem;
                }
                //event end datetime
                if ($row['event_end_datetime'] == '0000-00-00 00:00:00' || $row['event_end_datetime'] == NULL) {
                    $row['event_end_datetime'] = '';
                } else {
                    $event_end_datetime = new DateTime($row['event_end_datetime']);
                    $explode_event_end_datetime = explode(' ', $event_end_datetime->format('m/d/Y h:i:s a'));
                    $event_duration_to_date = $explode_event_end_datetime[0]; //date
                    $explode_hrsmin = explode(':', $explode_event_end_datetime[1]);
                    $date_end_hours = $explode_hrsmin[0]; //hrs
                    $date_end_minutes = $explode_hrsmin[1]; //min
                    $date_end_meridiem = $explode_event_end_datetime[2]; //am pm
                    $row['event_duration_to_date'] = $event_duration_to_date;
                    $row['date_end_hours'] = $date_end_hours;
                    $row['date_end_minutes'] = $date_end_minutes;
                    $row['date_end_meridiem'] = $date_end_meridiem;
                }

                $row['event_place'] = explode('::', $row['event_place']);

                if ($row['start_date'] == '0000-00-00' || $row['start_date'] == NULL)
                    $row['start_date'] = '';
                else
                    $row['start_date'] = date("m/d/Y", strtotime($row['start_date']));
                if ($row['end_date'] == '0000-00-00' || $row['end_date'] == NULL)
                    $row['end_date'] = '';
                else
                    $row['end_date'] = date("m/d/Y", strtotime($row['end_date']));
                //start fetch asset id and name
                if (!empty($row['asset_id_c'])) {
                    $arr_asset_name = array();
                    $sql_asset = "SELECT id,name FROM `asset_assets` where deleted=0 AND id IN (" . sprintf("'%s'", implode("', '", explode(',', $row['asset_id_c']))) . ")";
                    $result_asset = $GLOBALS['db']->query($sql_asset);
                    $camp_asset = array();
                    while ($row_asset = $GLOBALS['db']->fetchByAssoc($result_asset)) {
                        $arr_asset_name[$row_asset['id']] = $row_asset['name'];
                    }
                    $row['asset_name_c'] = $arr_asset_name;
                } else {
                    $row['asset_name_c'] = '';
                }
                //end fetch asset id and name
                if (!empty($row['promotion_id_c'])) {
                    $camp_prom_name = $this->getEditPromotionsListCRM($row['promotion_id_c'], $row['marketing_list_id']);
                    $row['prom_name_c'] = $camp_prom_name;
                } else {
                    $row['prom_name_c'] = '';
                }////09-05-17
                //start fetch promotion id and name
                /* if (!empty($row['promotion_id_c'])) {
                  $arr_prom_name = array();
                  $sql_prom_name = "SELECT id,name FROM `naku_promotions` where deleted=0 AND id IN (" . sprintf("'%s'", implode("', '", explode(',', $row['promotion_id_c']))) . ")";
                  $result_prom_name = $GLOBALS['db']->query($sql_prom_name);
                  $camp_prom_name = array();
                  while ($row_prom_name = $GLOBALS['db']->fetchByAssoc($result_prom_name)) {
                  $camp_prom_name[$row_prom_name['id']] = $row_prom_name['name'];
                  }
                  $row['prom_name_c'] = $camp_prom_name;
                  } else {
                  $row['prom_name_c'] = '';
                  } */
                //end fetch promotion id and name
                //start fetch coupon id and name
                if (!empty($row['coupon_id_c'])) {
                    $sql_coupon_name = "SELECT id,name FROM `naku_coupons` where deleted=0 AND id IN (" . sprintf("'%s'", implode("', '", explode(',', $row['coupon_id_c']))) . ")";
                    $result_coupon_name = $GLOBALS['db']->query($sql_coupon_name);
                    $camp_coupon_name = array();
                    while ($row_coupon_name = $GLOBALS['db']->fetchByAssoc($result_coupon_name)) {
                        $camp_coupon_name[$row_coupon_name['id']] = $row_coupon_name['name'];
                    }
                    $row['coupon_name_c'] = $camp_coupon_name;
                } else {
                    $row['coupon_name_c'] = '';
                }
                //end fetch coupon id and name
                // start fetch marketing list name
                $marketinglist_name = $this->get_marketing_list_name($row['marketing_list_id']);
                $row['marketinglist_name'] = $marketinglist_name;
                //end fetch marketing list name
                //start fetch template id and name
                if (!empty($row['template_id_c'])) {
                    $arr_asset_name = array();
                    $sql_templ = "SELECT id,name FROM `email_templates` where deleted=0 AND id='" . $row['template_id_c'] . "'";
                    $result_templ = $GLOBALS['db']->query($sql_templ);
                    $arr_templ_name = array();
                    while ($row_templ = $GLOBALS['db']->fetchByAssoc($result_templ)) {
                        $row['template_name_c'] = $row_templ['name'];
                    }
                } else {
                    $row['template_name_c'] = '';
                }
                //end fetch template id and name
                $camp_subtype1[$row['cmp_subtype_id']] = $row;
            }

            //fetch campaign type activity
            $sql_type_activity = "SELECT * FROM `camp_typeactivity` where deleted=0 AND cmp_id='" . $_GET['id'] . "'";
            $result_type_activity = $GLOBALS['db']->query($sql_type_activity);
            $camp_type_activity = array();
            while ($row_type_activity = $GLOBALS['db']->fetchByAssoc($result_type_activity)) {
                $camp_type_activity[$row_type_activity['cmp_activity_id']][] = $row_type_activity;
            }
            //echo '<pre>'; print_r($camp_subtype1);
            $this->view_object_map['campaign'] = $campaign;
            $this->view_object_map['campaign_sup'] = $campaign_sup;
            $this->view_object_map['campaign_sup_count'] = count($campaign_sup);
            $this->view_object_map['campaign_activity'] = $camp_subtype1;
            $this->view_object_map['camp_type_activity'] = $camp_type_activity;
            $this->view_object_map['getAllBranchName'] = $this->getBranchName(); //get all branch name through magento CRM
            $this->view_object_map['getAllPolls'] = $this->getPolls(); //get all polls name through magento CRM
        }
        
        $this->view = 'edit';
    }

    public function action_getCamppActivity() {
        if (!empty($_POST['name'])) {
            if (isset($_SESSION['Normal_Activity_' . $_POST['name']])) {
                if ($_POST['campid'] != $_SESSION['Normal_Activity_' . $_POST['name']]['campagin_id']) {
                    unset($_SESSION['Normal_Activity_' . $_POST['name']]['campagin_id']);
                }
                $row_type_activity1 = $_SESSION['Normal_Activity_' . $_POST['name']];
                $row_type_activity['id'] = '';
                $row_type_activity['name'] = $row_type_activity1['normal_activty_subtype_name'];
                $row_type_activity['date_entered'] = '';
                $row_type_activity['date_modified'] = '';
                $row_type_activity['modified_user_id'] = '';
                $row_type_activity['created_by'] = '';
                $row_type_activity['description'] = '';
                $row_type_activity['deleted'] = 0;
                $row_type_activity['assigned_user_id'] = '';
                $row_type_activity['cmp_id'] = $row_type_activity1['campagin_id'];
                $row_type_activity['cmp_subtype_id'] = $row_type_activity1['normal_activty_subtype_id'];
                $row_type_activity['start_date'] = '';
                $row_type_activity['activity_cost'] = '';
                $row_type_activity['activity_cost_type'] = '';
                $row_type_activity['marketing_list_id'] = $row_type_activity1['normal_activty_marketing_list_id'];
                //$row_type_activity['coupon_id_c'] = implode(',', $row_type_activity1['get_coupon_id_normal_acti']);
                //$row_type_activity['promotion_id_c'] = implode(',', $row_type_activity1['get_promotion_id_normal_acti']);
                $row_type_activity['promotion_id_c'] = implode(',', $row_type_activity1['promo_check']); //09-05-17
                $row_type_activity['event_desc'] = '';
                $row_type_activity['event_place'] = '';
                $row_type_activity['event_name'] = '';
                $row_type_activity['latitude'] = '';
                $row_type_activity['longitude'] = '';
                $row_type_activity['asset_id_c'] = '';
                $row_type_activity['template_id_c'] = $row_type_activity1['get_normal_activty_template_id'];
                $row_type_activity['store_type'] = '';
                $row_type_activity['template_name'] = $row_type_activity1['normal_activty_template_id'];
                $row_type_activity['polls_id'] = $row_type_activity1['polls_id'];

                //print_r($row_type_activity); 
                //start fetch promotion id and name
                if (!empty($row_type_activity['promotion_id_c'])) {
                    //09-05-17
                    global $sugar_config, $db;
                    $conn = $this->connectionCRMDB();
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }
                    $camp_prom_name = array();
                    //$sql_prom_name    = "SELECT row_id, name, promo_name, core_promotion, auto_coupon_code, reward_type, reward_value, reward_days FROM ". $sugar_config['crm_salesrule'] ." WHERE is_active = 1 AND customer_segment = ".$row_type_activity['marketing_list_id']." AND row_id IN (" . sprintf("'%s'", implode("', '", explode(',', $row_type_activity['promotion_id_c']))) . ")";
                    $sql_prom_name = "SELECT row_id, name, promo_name, core_promotion, auto_coupon_code, reward_type, reward_value, reward_days FROM " . $sugar_config['crm_salesrule'] . " WHERE is_active = 1 AND row_id IN (" . sprintf("'%s'", implode("', '", explode(',', $row_type_activity['promotion_id_c']))) . ")";
                    $result_prom_name = $conn->query($sql_prom_name);
                    while ($row_prom_name = $db->fetchByAssoc($result_prom_name)) {
                        $camp_prom_name[] = $row_prom_name;
                    }
                    $conn->close();
                    /* $arr_prom_name = array();
                      $sql_prom_name = "SELECT id,name FROM `naku_promotions` where deleted=0 AND id IN (" . sprintf("'%s'", implode("', '", explode(',', $row_type_activity['promotion_id_c']))) . ")";
                      $result_prom_name = $GLOBALS['db']->query($sql_prom_name);
                      $camp_prom_name = array();
                      while ($row_prom_name = $GLOBALS['db']->fetchByAssoc($result_prom_name)) {
                      $camp_prom_name[$row_prom_name['id']] = $row_prom_name['name'];
                      } */
                    $row_type_activity['prom_name_c'] = $camp_prom_name;
                } else {
                    $row_type_activity['prom_name_c'] = '';
                }
                //end fetch promotion id and name
                //start fetch coupon id and name
                if (!empty($row_type_activity['coupon_id_c'])) {
                    $sql_coupon_name = "SELECT id,name FROM `naku_coupons` where deleted=0 AND id IN (" . sprintf("'%s'", implode("', '", explode(',', $row_type_activity['coupon_id_c']))) . ")";
                    $result_coupon_name = $GLOBALS['db']->query($sql_coupon_name);
                    $camp_coupon_name = array();
                    while ($row_coupon_name = $GLOBALS['db']->fetchByAssoc($result_coupon_name)) {
                        $camp_coupon_name[$row_coupon_name['id']] = $row_coupon_name['name'];
                    }
                    $row_type_activity['coupon_name_c'] = $camp_coupon_name;
                } else {
                    $row_type_activity['coupon_name_c'] = '';
                }
                //end fetch coupon id and name	
                // start fetch marketing list name
                $row_type_activity['marketinglist_name'] = $row_type_activity1['normal_activty_marketing_list_name'];
                //end fetch marketing list name
                //echo '<pre>';
                //print_r($row_type_activity);
                echo json_encode($row_type_activity);
                exit;
            } else if (!empty($_POST['camp_activityid'])) {
                $sql_type_activity = "SELECT * FROM `camp_activity` where deleted=0 AND id='" . $_POST['camp_activityid'] . "'";
                $result_type_activity = $GLOBALS['db']->query($sql_type_activity);
                $camp_type_activity = array();
                while ($row_type_activity = $GLOBALS['db']->fetchByAssoc($result_type_activity)) {
                    //start fetch template id and name
                    if (!empty($row_type_activity['template_id_c'])) {
                        $sql_temp_name = "SELECT id,name FROM `email_templates` where deleted=0 AND id = '" . $row_type_activity['template_id_c'] . "'";
                        $result_temp_name = $GLOBALS['db']->query($sql_temp_name);
                        $camp_temp_name = '';
                        while ($row_temp_name = $GLOBALS['db']->fetchByAssoc($result_temp_name)) {
                            $camp_temp_name = $row_temp_name['name'];
                        }
                        $row_type_activity['template_name'] = $camp_temp_name;
                    } else {
                        $row_type_activity['template_name'] = '';
                    }
                    //end fetch template id and name
                    //start fetch promotion id and name
                    if (!empty($row_type_activity['promotion_id_c'])) {
                        /* $arr_prom_name = array();
                          $sql_prom_name = "SELECT id,name FROM `naku_promotions` where deleted=0 AND id IN (" . sprintf("'%s'", implode("', '", explode(',', $row_type_activity['promotion_id_c']))) . ")";
                          $result_prom_name = $GLOBALS['db']->query($sql_prom_name);
                          $camp_prom_name = array();
                          while ($row_prom_name = $GLOBALS['db']->fetchByAssoc($result_prom_name)) {
                          $camp_prom_name[$row_prom_name['id']] = $row_prom_name['name'];
                          } */
                        //09-05-17
                        global $sugar_config, $db;
                        $conn = $this->connectionCRMDB();
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }
                        $camp_prom_name = array();
                        //$sql_prom_name    = "SELECT row_id, name, promo_name, core_promotion, auto_coupon_code, reward_type, reward_value, reward_days FROM ". $sugar_config['crm_salesrule'] ." WHERE is_active = 1 AND customer_segment = ".$row_type_activity['marketing_list_id']." AND row_id IN (" . sprintf("'%s'", implode("', '", explode(',', $row_type_activity['promotion_id_c']))) . ")";
                        $sql_prom_name = "SELECT row_id, name, promo_name, core_promotion, auto_coupon_code, reward_type, reward_value, reward_days FROM " . $sugar_config['crm_salesrule'] . " WHERE is_active = 1 AND row_id IN (" . sprintf("'%s'", implode("', '", explode(',', $row_type_activity['promotion_id_c']))) . ")";
                        $result_prom_name = $conn->query($sql_prom_name);
                        while ($row_prom_name = $db->fetchByAssoc($result_prom_name)) {
                            $camp_prom_name[] = $row_prom_name;
                        }
                        $conn->close();
                        $row_type_activity['prom_name_c'] = $camp_prom_name;
                    } else {
                        $row_type_activity['prom_name_c'] = '';
                    }
                    //end fetch promotion id and name
                    //start fetch coupon id and name
                    if (!empty($row_type_activity['coupon_id_c'])) {
                        $sql_coupon_name = "SELECT id,name FROM `naku_coupons` where deleted=0 AND id IN (" . sprintf("'%s'", implode("', '", explode(',', $row_type_activity['coupon_id_c']))) . ")";
                        $result_coupon_name = $GLOBALS['db']->query($sql_coupon_name);
                        $camp_coupon_name = array();
                        while ($row_coupon_name = $GLOBALS['db']->fetchByAssoc($result_coupon_name)) {
                            $camp_coupon_name[$row_coupon_name['id']] = $row_coupon_name['name'];
                        }
                        $row_type_activity['coupon_name_c'] = $camp_coupon_name;
                    } else {
                        $row_type_activity['coupon_name_c'] = '';
                    }
                    //end fetch coupon id and name
                    // start fetch marketing list name
                    $marketinglist_name = $this->get_marketing_list_name($row_type_activity['marketing_list_id']);
                    $row_type_activity['marketinglist_name'] = $marketinglist_name;
                    //end fetch marketing list name
                    //echo '<pre>';
                    //print_r($row_type_activity);
                    echo json_encode($row_type_activity);
                }
            }
        }

        exit;
    }

    public function action_getCampaignTypeActivity() {
        if (!empty($_POST['ctypeid'])) {
            $sql_type_activity = "SELECT * FROM `camp_typeactivity` where deleted=0 AND id='" . $_POST['ctypeid'] . "'";
            $result_type_activity = $GLOBALS['db']->query($sql_type_activity);
            $camp_type_activity = array();
            while ($row_type_activity = $GLOBALS['db']->fetchByAssoc($result_type_activity)) {
                //start fetch link product portfolio
                if (!empty($row_type_activity['link_product_portfolio'])) {
                    $product_name_list = $this->get_product_portfolio_list_name($row_type_activity['link_product_portfolio']);
                    $row_type_activity['product_portfolio'] = $product_name_list;
                } else {
                    $row_type_activity['product_portfolio'] = '';
                }
                //end fetch link product portfolio
                //start fetch template id and name
                if (!empty($row_type_activity['template_id'])) {
                    $sql_temp_name = "SELECT id,name FROM `email_templates` where deleted=0 AND id = '" . $row_type_activity['template_id'] . "'";
                    $result_temp_name = $GLOBALS['db']->query($sql_temp_name);
                    $camp_temp_name = '';
                    while ($row_temp_name = $GLOBALS['db']->fetchByAssoc($result_temp_name)) {
                        $camp_temp_name = $row_temp_name['name'];
                    }
                    $row_type_activity['template_name'] = $camp_temp_name;
                } else {
                    $row_type_activity['template_name'] = '';
                }
                //end fetch template id and name
                //09-05-17
                if (!empty($row_type_activity['promotion_id_c'])) {
                    global $sugar_config, $db;
                    $conn = $this->connectionCRMDB();
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }
                    $camp_prom_name = array();
                    //$sql_prom_name    = "SELECT row_id, name, promo_name, core_promotion, auto_coupon_code, reward_type, reward_value, reward_days FROM ". $sugar_config['crm_salesrule'] ." WHERE is_active = 1 AND customer_segment = ".$row_type_activity['marketing_list_id_c']." AND row_id IN (" . sprintf("'%s'", implode("', '", explode(',', $row_type_activity['promotion_id_c']))) . ")";
                    $sql_prom_name = "SELECT row_id, name, promo_name, core_promotion, auto_coupon_code, reward_type, reward_value, reward_days FROM " . $sugar_config['crm_salesrule'] . " WHERE is_active = 1 AND row_id IN (" . sprintf("'%s'", implode("', '", explode(',', $row_type_activity['promotion_id_c']))) . ")";
                    $result_prom_name = $conn->query($sql_prom_name);
                    while ($row_prom_name = $db->fetchByAssoc($result_prom_name)) {
                        $camp_prom_name[] = $row_prom_name;
                    }
                    $conn->close();
                    //$camp_prom_name =  $this->getEditPromotionsListCRM($row_type_activity['promotion_id_c'],$row_type_activity['marketing_list_id']);
                    $row_type_activity['prom_name_c'] = $camp_prom_name;
                } else {
                    $row_type_activity['prom_name_c'] = '';
                }
                //start fetch promotion id and name
                /* if (!empty($row_type_activity['promotion_id_c'])) {
                  $arr_prom_name = array();
                  $sql_prom_name = "SELECT id,name FROM `naku_promotions` where deleted=0 AND id IN (" . sprintf("'%s'", implode("', '", explode(',', $row_type_activity['promotion_id_c']))) . ")";
                  $result_prom_name = $GLOBALS['db']->query($sql_prom_name);
                  $camp_prom_name = array();
                  while ($row_prom_name = $GLOBALS['db']->fetchByAssoc($result_prom_name)) {
                  $camp_prom_name[$row_prom_name['id']] = $row_prom_name['name'];
                  }
                  $row_type_activity['prom_name_c'] = $camp_prom_name;
                  } else {
                  $row_type_activity['prom_name_c'] = '';
                  } */
                //end fetch promotion id and name
                //start fetch coupon id and name
                if (!empty($row_type_activity['link_coupon_code'])) {
                    $sql_coupon_name = "SELECT id,name FROM `naku_coupons` where deleted=0 AND id IN (" . sprintf("'%s'", implode("', '", explode(',', $row_type_activity['link_coupon_code']))) . ")";
                    $result_coupon_name = $GLOBALS['db']->query($sql_coupon_name);
                    $camp_coupon_name = array();
                    while ($row_coupon_name = $GLOBALS['db']->fetchByAssoc($result_coupon_name)) {
                        $camp_coupon_name[$row_coupon_name['id']] = $row_coupon_name['name'];
                    }
                    $row_type_activity['coupon_name_c'] = $camp_coupon_name;
                } else {
                    $row_type_activity['coupon_name_c'] = '';
                }
                //end fetch coupon id and name
                // start fetch marketing list name
                $marketinglist_name = $this->get_marketing_list_name($row_type_activity['marketing_list_id_c']);
                $row_type_activity['marketinglist_name'] = $marketinglist_name;
                //end fetch marketing list name
                $camp_type_activity[] = $row_type_activity;
            }
            //echo '<pre>'; print_r($camp_type_activity[0]);
            echo json_encode($camp_type_activity[0]);
        }
        exit;
    }

    public function action_SaveNormalActivity() {
        //echo '<pre>';
        //print_r($_POST);
        $_SESSION['Normal_Activity_' . $_POST['normal_activty_subtype_name']] = $_POST;
        exit;
    }

    public function action_getsubtype() {
        if (!empty($_POST['cid'])) {
            $data_str = '';
            $sql = "SELECT id,name FROM `camp_subtype` where deleted=0 AND type_id IN (" . sprintf("'%s'", implode("', '", $_POST['cid'])) . ")";
            $result = $GLOBALS['db']->query($sql);
            while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
                $data_str.="<option value='" . $row['id'] . "' >" . $row['name'] . "</option>";
            }
            echo $data_str;
            exit;
        }
    }

    /**
     * This method is save Campaigns Basic infomation
     *
     */
    public function action_SaveCampaign() {
        if (!empty($_POST)) {
            if (empty($_POST['campaign_id'])) {
                $bean = BeanFactory::newBean('Campaigns');
                $bean->campaign_id_c = $_POST['id'];
                $bean->start_date = date('Y-m-d', strtotime($_POST['start_date']));
                $bean->end_date = date('Y-m-d', strtotime($_POST['end_date']));
                $bean->name = $_POST['name'];
                $bean->campaign_type = implode(',', $_POST['campaign_type']);
                $bean->campaign_subtype = implode(',', $_POST['campaign_subtype']);
                $bean->content = $_POST['content'];
                $bean->country = $_POST['country'];
                $bean->status = 'Saved';
                $bean->save();
                if (!empty($bean->id)) {
                    SugarApplication::appendErrorMessage('<span class="msg-success">Campaign information saved successfully.</span>');
                    $queryParams = array(
                        'module' => 'Campaigns',
                        'action' => 'EditView',
                        'id' => $bean->id,
                        'camp_tab_id' => 1,
                    );
                    SugarApplication::redirect('index.php?' . http_build_query($queryParams));
                }
            } else {
                $bean1 = BeanFactory::getBean('Campaigns', $_POST['campaign_id']);      //Retrieve bean
                $bean1->update_date_modified = false;      //Set modified flag
                $bean1->start_date = date('Y-m-d', strtotime($_POST['start_date']));
                $bean1->end_date = date('Y-m-d', strtotime($_POST['end_date']));
                $bean1->name = $_POST['name'];
                $bean1->campaign_type = implode(',', $_POST['campaign_type']);
                $bean1->campaign_subtype = implode(',', $_POST['campaign_subtype']);
                $bean1->content = $_POST['content'];
                $bean1->country = $_POST['country'];
                $bean1->save();
                if (!empty($bean1->id)) {
                    SugarApplication::appendErrorMessage('<span class="msg-success">Campaign information saved successfully.</span>');
                    $queryParams = array(
                        'module' => 'Campaigns',
                        'action' => 'EditView',
                        'id' => $bean1->id,
                        'camp_tab_id' => 1,
                    );
                    SugarApplication::redirect('index.php?' . http_build_query($queryParams));
                }
            }
        }
    }

    /**
     * This method is save Campaigns Financial infomation
     *
     */
    public function action_SaveCampaignFinancial() {
        if (!empty($_POST)) {
            if ($_POST['cid'] != '') {

                $bean1 = BeanFactory::getBean('Campaigns', $_POST['cid']); //Retrieve bean
                $bean1->update_date_modified = false;      //Set modified flag
                $bean1->campaign_cost = $_POST['campaign_cost'];
                $bean1->expected_revenue = $_POST['estimated_revenue'];
                $bean1->budget = $_POST['allocate_budget'];
                $bean1->naku_cost_contribution_c = $_POST['naku_cost_contribution_c'];
                $bean1->naku_cost_type_c = ($_POST['naku_cost_type_c']) ? $_POST['naku_cost_type_c'] : '';
                $bean1->campaign_owner = $_POST['campaign_owner'];
                $bean1->save();

                if (!empty($_POST['supplier_id'])) {
                    for ($i = 0; $i < count($_POST['supplier_id']); $i++) {

                        if (!empty($_POST['camp_supplier_id'][$i])) {
                            //updated
                            //if((!empty($_POST['supplier_id'][$i])) && ($_POST['cost_contribution'][$i]!='') && (!empty($_POST['cost_contribution_type'][$i])) && (!empty($_POST['camp_supplier_id'][$i]))) 
                            //{
                            $bean2 = BeanFactory::getBean('Camp_Supplier', $_POST['camp_supplier_id'][$i]);
                            $bean2->update_date_modified = false;      //Set modified flag	
                            $bean2->cmp_id = $_POST['cid'];
                            $bean2->supplier_id = $_POST['get_supplier_id'][$i];
                            $bean2->supplier_cost = $_POST['cost_contribution'][$i];
                            //$bean2->cost_type = $_POST['cost_contribution_type'][$i];  					  						
                            $bean2->cost_type = $_POST['cost_contribution_type'][$i];
                            $bean2->save();
                            //}            
                        }
                        if ($_POST['camp_supplier_id'][$i] == '') {
                            // inserted
                            //if((!empty($_POST['supplier_id'][$i])) && ($_POST['cost_contribution'][$i]!='') && (!empty($_POST['cost_contribution_type'][$i]))) 
                            //{
                            $bean = BeanFactory::newBean('Camp_Supplier');
                            $bean->cmp_id = $_POST['cid'];
                            $bean->supplier_id = $_POST['get_supplier_id'][$i];
                            $bean->supplier_cost = $_POST['cost_contribution'][$i];
                            //$bean->cost_type = $_POST['cost_contribution_type'][$i];  					  
                            $bean->cost_type = $_POST['cost_contribution_type'][$i];
                            $bean->save();
                            //}	
                        }
                    }
                }

                if (!empty($bean1->id)) {
                    SugarApplication::appendErrorMessage('<span class="msg-success">Campaign financial information saved successfully.</span>');
                    $queryParams = array(
                        'module' => 'Campaigns',
                        'action' => 'EditView',
                        'id' => $_POST['cid'],
                        'camp_tab_id' => 2
                    );
                    SugarApplication::redirect('index.php?' . http_build_query($queryParams));
                }
            } else {
                SugarApplication::appendErrorMessage('<span class="msg-error">Please fill first campaign information.</span>');
                $queryParams = array(
                    'module' => 'Campaigns',
                    'action' => 'EditView',
                    'return_module' => 'Campaigns',
                    'return_action' => 'DetailView'
                );
                SugarApplication::redirect('index.php?' . http_build_query($queryParams));
            }
        }
    }

    /**
     * This method for get campaign number
     *
     */
    public function get_campaign_no() {
        $camp_id = substr(number_format(time() * rand(), 0, '', ''), 0, 7);
        if (!empty($camp_id)) {
            $sql = "SELECT campaign_id_c FROM `campaigns` where campaign_id_c='" . $camp_id . "'";
            $result = $GLOBALS['db']->query($sql);
            if (!empty($result->num_rows)) {
                $this->get_campaign_no();
            } else {
                return $camp_id;
            }
        }
    }

    /**
     * This method is save Subtype infomation
     *
     */
    public function action_SaveSubtype() {
		global $sugar_config;
        //echo '<pre>';
        //print_r($_POST); 
        if (!empty($_POST)) {
            //event start date time
            if (isset($_POST['event_duration_from_date'])) {
                $event_start_datetime = date('d/m/Y', strtotime($_POST['event_duration_from_date'])) . ' ' . $_POST['date_start_hours'] . ':' . $_POST['date_start_minutes'] . ' ' . $_POST['date_start_meridiem'];
                $event_start = DateTime::createFromFormat('d/m/Y H:i a', $event_start_datetime);
                $event_start_date = $event_start ? $event_start->format('Y-m-d H:i:s') : NULL;
            }
            //event end date time
            if (isset($_POST['event_duration_to_date'])) {
                $event_end_datetime = date('d/m/Y', strtotime($_POST['event_duration_to_date'])) . ' ' . $_POST['date_end_hours'] . ':' . $_POST['date_end_minutes'] . ' ' . $_POST['date_end_meridiem'];
                $event_end = DateTime::createFromFormat('d/m/Y H:i a', $event_end_datetime);
                $event_end_date = $event_end ? $event_end->format('Y-m-d H:i:s') : NULL;
            }
            if (isset($_POST['branch_id'])) {
                $event_place = implode('::', $_POST['branch_id']);
            }if (isset($_POST['event_place'])) {
                $filtered_array = array_filter($_POST['event_place'], function($var) {
                    return $var !== '';
                });
                $event_place = implode('::', $filtered_array);
            } //echo'<pre>';print_r($event_start);die;

            if ($_POST['cid'] != '') {
                $bean1 = BeanFactory::getBean('Campaigns', $_POST['cid']);      //Retrieve bean
                $bean1->update_date_modified = false;      //Set modified flag
				$workflowFlag = false;
				$bulksmsFlag = false;
                if ($_POST['status'] == 'Saved'){
                    $_POST['status'] = 'Pending Approval';
					$workflowFlag = true;
				}
				if ($_POST['status'] == 'Approved'){
					$bulksmsFlag = true;
				}
                $bean1->status = $_POST['status'];
                $bean1->date_modified = date('Y-m-d H:i:s'); //add by akhilesh 30-06-2017
                $bean1->save();
                $sql = "SELECT name FROM `campaigns` where id='" . $_POST['cid'] . "'";
                $result = $GLOBALS['db']->query($sql);
                $campaignname = '';
                while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
                    $campaignname = $row['name'];
                }

                if (!empty($_POST['cid']) && !empty($_POST['subtype_count'])) {
                    for ($i = 1; $i <= $_POST['subtype_count']; $i++) {
                        if (empty($_POST['campaign_activity_id_' . $i])) { //add action
                            $bean = BeanFactory::newBean('Camp_Activity');
                            $bean->cmp_id = filter_var($_POST['cid'], FILTER_SANITIZE_STRING) ? filter_var($_POST['cid'], FILTER_SANITIZE_STRING) : NULL;
                            $bean->cmp_subtype_id = filter_var($_POST['campaign_subtype_id_' . $i], FILTER_SANITIZE_STRING) ? filter_var($_POST['campaign_subtype_id_' . $i], FILTER_SANITIZE_STRING) : NULL;
                            if ($_POST['duration_from_date_' . $i]) {
                                //$bean->start_date = ($_POST['duration_from_date_'.$i])?$_POST['duration_from_date_'.$i]:'';
                                $bean->start_date = date("Y-m-d", strtotime($_POST['duration_from_date_' . $i]));  //($_POST['duration_from_date_'.$i])?$_POST['duration_from_date_'.$i]:'';
                            }
                            if ($_POST['duration_to_date_' . $i]) {
                                //$bean->end_date = ($_POST['duration_to_date_'.$i])?$_POST['duration_to_date_'.$i]:''; 
                                $bean->end_date = date("Y-m-d", strtotime($_POST['duration_to_date_' . $i])); //($_POST['duration_to_date_'.$i])?$_POST['duration_to_date_'.$i]:''; 
                            }
                            //$bean->activity_cost = filter_var($_POST['activity_cost_'.$i], FILTER_SANITIZE_STRING)?filter_var($_POST['activity_cost_'.$i], FILTER_SANITIZE_STRING):NULL;
                            $bean->activity_cost = $_POST['activity_cost_' . $i];
                            $bean->activity_cost_type = $_POST['activity_cost_type_' . $i];
                            if (isset($_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['normal_activty_marketing_list_id'])) {
                                $_POST['get_marketing_list_id_' . $i] = $_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['normal_activty_marketing_list_id'];
                            }
                            if (isset($_POST['get_marketing_list_id_' . $i])) {
                                $bean->marketing_list_id = filter_var($_POST['get_marketing_list_id_' . $i], FILTER_SANITIZE_STRING) ? filter_var($_POST['get_marketing_list_id_' . $i], FILTER_SANITIZE_STRING) : NULL;
                            }
                            if (isset($_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['get_normal_activty_template_id'])) {
                                $_POST['main_get_template_id_' . $i] = $_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['get_normal_activty_template_id'];
                            }
                            if (isset($_POST['main_get_template_id_' . $i])) {
                                $bean->template_id_c = filter_var($_POST['main_get_template_id_' . $i], FILTER_SANITIZE_STRING) ? filter_var($_POST['main_get_template_id_' . $i], FILTER_SANITIZE_STRING) : NULL;
                            }
                            if (isset($_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['get_promotion_id_normal_acti'])) {
                                $_POST['get_promotion_id_' . $i] = $_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['get_promotion_id_normal_acti'];
                            }
                            if (isset($_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['get_coupon_id_normal_acti'])) {
                                $_POST['get_coupon_id_' . $i] = $_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['get_coupon_id_normal_acti'];
                            }
                            if (isset($_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['polls_id'])) { //Insert Polls
                                $_POST['polls_id_' . $i] = $_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['polls_id'];
                                $bean->polls_id = $_POST['polls_id_' . $i];
                            }
                            if (isset($_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['promo_check'])) {
                                $_POST['promo_check_' . $i] = $_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['promo_check'];
                            }//09-05-17
                            /* if (!empty($_POST['get_promotion_id_' . $i]) && !empty($_POST['get_coupon_id_' . $i])) {
                              $promotionsWithCoupons = $this->promoToCoupon($_POST['get_promotion_id_' . $i], $_POST['get_coupon_id_' . $i]);
                              $arr = explode("@", $promotionsWithCoupons);
                              $bean->coupon_id_c = count($arr[1]) > 0 ? $arr[1] : NULL;
                              $bean->promotion_id_c = count($arr[0]) > 0 ? $arr[0] : NULL;
                              } */
                            if (!empty($_POST['promo_check_' . $i])) {//aarav
                                $bean->promotion_id_c = implode(',', $_POST['promo_check_' . $i]);
                            }//09-05-17
                            $bean->name = filter_var($_POST['campaign_subtype_autofill_' . $i], FILTER_SANITIZE_STRING) ? filter_var($_POST['campaign_subtype_autofill_' . $i], FILTER_SANITIZE_STRING) : NULL;
                            $bean->date_entered = date('Y-m-d H:i:s');
                            $bean->date_modified = date('Y-m-d H:i:s');
                            $bean->event_desc = filter_var($_POST['campaign_subtype_autofill_' . $i], FILTER_SANITIZE_STRING) == "Website Event" && filter_var($_POST['event_desc'], FILTER_SANITIZE_STRING) ? filter_var($_POST['event_desc'], FILTER_SANITIZE_STRING) : NULL;
                            $bean->event_name = filter_var($_POST['campaign_subtype_autofill_' . $i], FILTER_SANITIZE_STRING) == "Website Event" && filter_var($_POST['event_name'], FILTER_SANITIZE_STRING) ? filter_var($_POST['event_name'], FILTER_SANITIZE_STRING) : NULL;
                            //$bean->event_place = filter_var($_POST['campaign_subtype_autofill_'.$i], FILTER_SANITIZE_STRING)=="Website Event" && filter_var($_POST['event_place'], FILTER_SANITIZE_STRING)?filter_var($_POST['event_place'], FILTER_SANITIZE_STRING):NULL;
                            $bean->event_place = $event_place ? $event_place : '';
                            if (isset($_POST['ab_test_c_' . $i]))
                                $bean->ab_test_c = 1;
                            else
                                $bean->ab_test_c = 0;
                            $bean->longitude = filter_var($_POST['campaign_subtype_autofill_' . $i], FILTER_SANITIZE_STRING) == "Website Event" && filter_var($_POST['longitude'], FILTER_SANITIZE_STRING) ? filter_var($_POST['longitude'], FILTER_SANITIZE_STRING) : NULL;
                            $bean->latitude = filter_var($_POST['campaign_subtype_autofill_' . $i], FILTER_SANITIZE_STRING) == "Website Event" && filter_var($_POST['latitude'], FILTER_SANITIZE_STRING) ? filter_var($_POST['latitude'], FILTER_SANITIZE_STRING) : NULL;
                            $bean->event_start_datetime = $event_start_date ? $event_start_date : '';
                            $bean->event_end_datetime = $event_end_date ? $event_end_date : '';
                            $bean->store_type = $_POST['store_type'] ? $_POST['store_type'] : '';
                            if ($_POST['campaign_subtype_autofill_' . $i] == 'Website Event') {
                                $bean->asset_id_c = filter_var($_POST['campaign_subtype_autofill_' . $i], FILTER_SANITIZE_STRING) == "Website Event" && filter_var($_POST['website_event_asset_list'], FILTER_SANITIZE_STRING) && filter_var($_POST['website_event_asset_detail'], FILTER_SANITIZE_STRING) ? filter_var($_POST['get_asset_list_id'] . ',' . $_POST['get_asset_detail_id'], FILTER_SANITIZE_STRING) : NULL;
                            } else {
                                $bean->asset_id_c = implode(',', $_POST['get_websiteasset_detail_id_' . $i]);
                            }
                            if (isset($_POST['main_get_template_id_' . $i])) {
                                // start update last used in campaign
                                if ($_POST['main_type_template_id_' . $i] != $_POST['main_get_template_id_' . $i]) {
                                    $bean_email_templates = BeanFactory::getBean('EmailTemplates', $_POST['main_get_template_id_' . $i]);
                                    $bean_email_templates->update_date_modified = false;
                                    $bean_email_templates->lastused_c = date('Y-m-d');
                                    $bean_email_templates->lastused_asset_in_camp = $campaignname;
                                    $bean_email_templates->save();
                                }
                                // end  update last used in campaign
                            }
                            if ($_POST['campaign_subtype_link_asset_' . $i] != $bean->asset_id_c) {
                                if (!empty($bean->asset_id_c)) {
                                    $assetids = explode(',', $bean->asset_id_c);
                                    if (!empty($assetids)) {
                                        foreach ($assetids as $asids) {
                                            $bean_asset = BeanFactory::getBean('Asset_Assets', $asids);
                                            $bean_asset->update_date_modified = false;
                                            $bean_asset->lastused = date('Y-m-d');
                                            $bean_asset->lastused_asset_in_camp = $campaignname;
                                            $bean_asset->save();
                                        }
                                    }
                                }
                            }
                            $bean->save();
                            if (!empty($_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]])) {
                                unset($_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]);
                                //echo '<pre>'; print_r($_SESSION['Normal_Activity_'.$_POST['name']]);					
                                //exit;
                            }
                        } else { //update action
                            $bean_update = BeanFactory::getBean('Camp_Activity', $_POST['campaign_activity_id_' . $i]);
                            $bean_update->update_date_modified = false;      //Set modified flag							
                            $bean_update->cmp_id = filter_var($_POST['cid'], FILTER_SANITIZE_STRING) ? filter_var($_POST['cid'], FILTER_SANITIZE_STRING) : NULL;
                            $bean_update->cmp_subtype_id = filter_var($_POST['campaign_subtype_id_' . $i], FILTER_SANITIZE_STRING) ? filter_var($_POST['campaign_subtype_id_' . $i], FILTER_SANITIZE_STRING) : NULL;
                            if ($_POST['duration_from_date_' . $i]) {
                                //$bean_update->start_date = ($_POST['duration_from_date_'.$i])?$_POST['duration_from_date_'.$i]:'';
                                $bean_update->start_date = date("Y-m-d", strtotime($_POST['duration_from_date_' . $i])); //($_POST['duration_from_date_'.$i])?$_POST['duration_from_date_'.$i]:'';
                            }
                            if ($_POST['duration_to_date_' . $i]) {
                                //$bean_update->end_date = ($_POST['duration_to_date_'.$i])?$_POST['duration_to_date_'.$i]:''; 
                                $bean_update->end_date = date("Y-m-d", strtotime($_POST['duration_to_date_' . $i])); //($_POST['duration_to_date_'.$i])?$_POST['duration_to_date_'.$i]:''; 
                            }
                            //$bean_update->activity_cost = filter_var($_POST['activity_cost_'.$i], FILTER_SANITIZE_STRING)?filter_var($_POST['activity_cost_'.$i], FILTER_SANITIZE_STRING):NULL;
                            $bean_update->activity_cost = $_POST['activity_cost_' . $i];
                            $bean_update->activity_cost_type = $_POST['activity_cost_type_' . $i];
                            if (isset($_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['normal_activty_marketing_list_id'])) {
                                $_POST['get_marketing_list_id_' . $i] = $_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['normal_activty_marketing_list_id'];
                            }
                            if (isset($_POST['get_marketing_list_id_' . $i])) {
                                $bean_update->marketing_list_id = filter_var($_POST['get_marketing_list_id_' . $i], FILTER_SANITIZE_STRING) ? filter_var($_POST['get_marketing_list_id_' . $i], FILTER_SANITIZE_STRING) : NULL;
                            }
                            if (isset($_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['get_normal_activty_template_id'])) {
                                $_POST['main_get_template_id_' . $i] = $_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['get_normal_activty_template_id'];
                            }
                            if (isset($_POST['main_get_template_id_' . $i])) {
                                $bean_update->template_id_c = filter_var($_POST['main_get_template_id_' . $i], FILTER_SANITIZE_STRING) ? filter_var($_POST['main_get_template_id_' . $i], FILTER_SANITIZE_STRING) : NULL;
                            }
                            if (isset($_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['get_promotion_id_normal_acti'])) {
                                $_POST['get_promotion_id_' . $i] = $_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['get_promotion_id_normal_acti'];
                            }
                            if (isset($_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['get_coupon_id_normal_acti'])) {
                                $_POST['get_coupon_id_' . $i] = $_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['get_coupon_id_normal_acti'];
                            }
                            if (isset($_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['polls_id'])) { //Update Polls
                                $_POST['polls_id_' . $i] = $_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['polls_id'];
                                $bean_update->polls_id = $_POST['polls_id_' . $i];
                            }
                            if (isset($_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['promo_check'])) {
                                $_POST['promo_check_' . $i] = $_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]['promo_check'];
                            }//09-05-17
                            /* if (!empty($_POST['get_promotion_id_' . $i]) && !empty($_POST['get_coupon_id_' . $i])) {
                              $promotionsWithCoupons = $this->promoToCoupon($_POST['get_promotion_id_' . $i], $_POST['get_coupon_id_' . $i]);
                              $arr = explode("@", $promotionsWithCoupons);
                              $bean_update->coupon_id_c = count($arr[1]) > 0 ? $arr[1] : NULL;
                              $bean_update->promotion_id_c = count($arr[0]) > 0 ? $arr[0] : NULL;
                              } */
                            if (isset($_POST['promo_check_' . $i])) {//change !empty to isset 09-05-17
                                $bean_update->promotion_id_c = implode(',', $_POST['promo_check_' . $i]);
                            }//09-05-17
                            $bean_update->name = filter_var($_POST['campaign_subtype_autofill_' . $i], FILTER_SANITIZE_STRING) ? filter_var($_POST['campaign_subtype_autofill_' . $i], FILTER_SANITIZE_STRING) : NULL;
                            $bean_update->date_entered = date('Y-m-d H:i:s');
                            $bean_update->date_modified = date('Y-m-d H:i:s');
                            $bean_update->event_desc = filter_var($_POST['campaign_subtype_autofill_' . $i], FILTER_SANITIZE_STRING) == "Website Event" && filter_var($_POST['event_desc'], FILTER_SANITIZE_STRING) ? filter_var($_POST['event_desc'], FILTER_SANITIZE_STRING) : NULL;
                            $bean_update->event_name = filter_var($_POST['campaign_subtype_autofill_' . $i], FILTER_SANITIZE_STRING) == "Website Event" && filter_var($_POST['event_name'], FILTER_SANITIZE_STRING) ? filter_var($_POST['event_name'], FILTER_SANITIZE_STRING) : NULL;
                            //$bean_update->event_place = filter_var($_POST['campaign_subtype_autofill_'.$i], FILTER_SANITIZE_STRING)=="Website Event" && filter_var($_POST['event_place'], FILTER_SANITIZE_STRING)?filter_var($_POST['event_place'], FILTER_SANITIZE_STRING):NULL;
                            if (isset($_POST['ab_test_c_' . $i]))
                                $bean_update->ab_test_c = 1;
                            else
                                $bean_update->ab_test_c = 0;

                            $bean_update->event_place = $event_place ? $event_place : '';
                            $bean_update->store_type = $_POST['store_type'] ? $_POST['store_type'] : '';
                            $bean_update->longitude = filter_var($_POST['campaign_subtype_autofill_' . $i], FILTER_SANITIZE_STRING) == "Website Event" && filter_var($_POST['longitude'], FILTER_SANITIZE_STRING) ? filter_var($_POST['longitude'], FILTER_SANITIZE_STRING) : NULL;
                            $bean_update->latitude = filter_var($_POST['campaign_subtype_autofill_' . $i], FILTER_SANITIZE_STRING) == "Website Event" && filter_var($_POST['latitude'], FILTER_SANITIZE_STRING) ? filter_var($_POST['latitude'], FILTER_SANITIZE_STRING) : NULL;
                            $bean_update->asset_id_c = filter_var($_POST['campaign_subtype_autofill_' . $i], FILTER_SANITIZE_STRING) == "Website Event" && filter_var($_POST['website_event_asset_list'], FILTER_SANITIZE_STRING) && filter_var($_POST['website_event_asset_detail'], FILTER_SANITIZE_STRING) ? filter_var($_POST['get_asset_list_id'] . ',' . $_POST['get_asset_detail_id'], FILTER_SANITIZE_STRING) : NULL;
                            $bean_update->event_start_datetime = $event_start_date ? $event_start_date : '';
                            $bean_update->event_end_datetime = $event_end_date ? $event_end_date : '';
                            if ($_POST['campaign_subtype_autofill_' . $i] == 'Website Event') {
                                $bean_update->asset_id_c = filter_var($_POST['campaign_subtype_autofill_' . $i], FILTER_SANITIZE_STRING) == "Website Event" && filter_var($_POST['website_event_asset_list'], FILTER_SANITIZE_STRING) && filter_var($_POST['website_event_asset_detail'], FILTER_SANITIZE_STRING) ? filter_var($_POST['get_asset_list_id'] . ',' . $_POST['get_asset_detail_id'], FILTER_SANITIZE_STRING) : NULL;
                            } else {
                                if (!empty($_POST['get_websiteasset_detail_id_' . $i]))
                                    $bean_update->asset_id_c = implode(',', $_POST['get_websiteasset_detail_id_' . $i]);
                            }
                            if (isset($_POST['main_get_template_id_' . $i])) {
                                // start update last used in campaign
                                if ($_POST['main_type_template_id_' . $i] != $_POST['main_get_template_id_' . $i]) {
                                    $bean_email_templates = BeanFactory::getBean('EmailTemplates', $_POST['main_get_template_id_' . $i]);
                                    $bean_email_templates->update_date_modified = false;
                                    $bean_email_templates->lastused_c = date('Y-m-d');
                                    $bean_email_templates->lastused_asset_in_camp = $campaignname;
                                    $bean_email_templates->save();
                                }
                                // end  update last used in campaign
                            }
                            if ($_POST['campaign_subtype_link_asset_' . $i] != $bean_update->asset_id_c) {
                                if (!empty($bean_update->asset_id_c)) {
                                    $assetids = explode(',', $bean_update->asset_id_c);
                                    if (!empty($assetids)) {
                                        foreach ($assetids as $asids) {

                                            $bean_asset = BeanFactory::getBean('Asset_Assets', $asids);
                                            $bean_asset->update_date_modified = false;
                                            $bean_asset->lastused = date('Y-m-d');
                                            $bean_asset->lastused_asset_in_camp = $campaignname;
                                            $bean_asset->save();
                                        }
                                    }
                                }
                            }
                            $bean_update->save();
                            if (!empty($_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]])) {
                                unset($_SESSION['Normal_Activity_' . $_POST['campaign_subtype_autofill_' . $i]]);
                                //echo '<pre>'; print_r($_SESSION['Normal_Activity_'.$_POST['name']]);					
                                //exit;
                            }
                        }
                    }
                }
                if (!empty($bean1->id)) {
					if($workflowFlag){
					$conn = $this->connectionEcomDB();
					if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
					}
					$sql_cpl = "select * from core_config_data where path='campaign_sugarcrm_setting_section/general/campaign_approval_role_id'";
					$result_cpl = $conn->query($sql_cpl);
					$row = $result_cpl->fetch_array(MYSQLI_ASSOC);
					$sql_cpl = "SELECT ad.email from authorization_role as arole, admin_user as ad WHERE arole.user_id=ad.user_id and (arole.role_id=".$row['value']." or arole.parent_id=".$row['value'].")";
					$result_cpl = $conn->query($sql_cpl);
					while ($row_cpl = $result_cpl->fetch_assoc()) {
					//$row_cpl['email'] = "sudhansu.narendra@zensar.com";
					$template_name = "WorkFlow";
					$roleBean = BeanFactory::getBean('EmailTemplates')
                                ->retrieve_by_string_fields(array('name' => $template_name));
					require_once('include/SugarPHPMailer.php'); 
					$emailObj = new Email(); 
					$defaults = $emailObj->getSystemDefaultEmail(); 
					$mail = new SugarPHPMailer(); 
					$mail->setMailerForSystem(); 
					$mail->From = $sugar_config['mail_from_c'];//"reports@nakumatt.net";//$defaults['email']; 
					$mail->FromName = $sugar_config['mail_from_name_c'];//"Nakumat Holdings";//$defaults['name']; 
					$mail->Subject = "Campaign Created Successfully";
					$template_body = str_replace("{MODULE-NAME}", 'Campaign', $roleBean->body);
					$template_body = str_replace("{MODULE-DBNAME}", $bean1->name, $template_body);
					$template_body = str_replace("{MODULE-DBID}", $bean1->campaign_id_c, $template_body);
					$mail->Body_html = from_html($template_body);
					//$mail->Body = wordwrap($message, 900);
					$mail->IsHTML(true); //Omit or comment out this line if plain text
					$mail->Body = $mail->Body_html;//$message; 
					$mail->prepForOutbound(); 
					$mail->AddAddress($row_cpl['email']); 
					if (!$mail->send()) {
					  $GLOBALS['log']->info("Mailer error: " . $mail->ErrorInfo);
					} 			
					//echo $row_cpl['email'];
					}//exit;
					}
					if($bulksmsFlag){
					$this->callBulkSMS($_POST['cid']);
					}
                    SugarApplication::appendErrorMessage('<span class="msg-success">Campaign Subtype information saved successfully.</span>');
                    $queryParams = array(
                        'module' => 'Campaigns',
                        'action' => 'DetailView',
                        'record' => $_POST['cid']
                    );
                    SugarApplication::redirect('index.php?' . http_build_query($queryParams));
                }
            } else {
                SugarApplication::appendErrorMessage('<span class="msg-error">Please fill first campaign information.</span>');
                $queryParams = array(
                    'module' => 'Campaigns',
                    'action' => 'EditView',
                    'return_module' => 'Campaigns',
                    'return_action' => 'DetailView'
                );
                SugarApplication::redirect('index.php?' . http_build_query($queryParams));
            }
        }
    }

    /**
     * This method will return coupons w.r.t promo
     *
     */
    public function promoToCoupon($promo, $coupon) {
        for ($i = 0; $i < count($promo); $i++) {
            if (!empty($promo[$i]) && !empty($coupon[$i])) {
                $promoArray[] = $promo[$i];
                $couponArray[] = $coupon[$i];
            } elseif (!empty($promo[$i]) && empty($coupon[$i])) {
                $promoArray[] = $promo[$i];
                $couponArray[] = "NA";
            } elseif (empty($promo[$i]) && !empty($coupon[$i])) {
                return false;
            } elseif (empty($promo[$i]) && empty($coupon[$i])) {
                $promoArray[] = "";
                $couponArray[] = "";
            }
        }
        $promoToCouponString = '';
        if (!empty($promoArray) && !empty($promoArray)) {
            $promoToCouponString = implode(",", $promoArray) . "@" . implode(",", $couponArray);
        }
        return $promoToCouponString;
    }

    /**
     * This method is save trigger,date and activity subtypes infomation
     *
     */
    public function action_SaveSubtypesBased() {
        if (!empty($_POST)) {
            $campaignname = '';
            if (!empty($_POST['campagin_id'])) {

                //start  get campaign name
                $sql = "SELECT name FROM `campaigns` where id='" . $_POST['campagin_id'] . "'";
                $result = $GLOBALS['db']->query($sql);
                while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
                    $campaignname = $row['name'];
                }
            }

            //end  get campaign name	
            if ($_POST['trigger_camp_typeactivity_id'] != '') {
                // update record
                $bean_up = BeanFactory::getBean('Camp_TypeActivity', $_POST['trigger_camp_typeactivity_id']);
                $bean_up->update_date_modified = false;
                $type = $_POST['type'];
                $bean_up->cmp_id = $_POST['campagin_id'];
                $bean_up->cmp_activity_id = $_POST['subtype_id'];
                $bean_up->template_id = $_POST['get_template_id'];
                $bean_up->comments = $_POST['comments'];

                $arr = array();
                if ($type == 'trig') {
                    $bean_up->link_product_portfolio = implode(',', array_filter($_POST['trig_link_product_id']));
                    $bean_up->marketing_list_id_c = $_POST['trig_marketing_list_id'];
                    $bean_up->type = 'trigger';
                    /* $listPromoCoupon = $this->promoToCoupon(array_filter($_POST['get_promotion_id_' . $type]), array_filter($_POST['get_coupon_id_' . $type]));
                      $arr = explode('@', $listPromoCoupon); */ //09-05-17
                } else {
                    $bean_up->link_product_portfolio = '';
                }
                if ($type == 'date') {
                    $bean_up->date_activity = $_POST['select_date_based'];
                    $bean_up->marketing_list_id_c = $_POST['date_marketing_list_id'];
                    $bean_up->type = 'date';
                    /* $listPromoCoupon = $this->promoToCoupon(array_filter($_POST['get_promotion_id_' . $type]), array_filter($_POST['get_coupon_id_' . $type]));
                      $arr = explode('@', $listPromoCoupon); */ //09-05-17
                } else {
                    $bean_up->date_activity = '';
                }
                if ($type == 'activi') {
                    $bean_up->activity_based_activity = $_POST['select_activity_based'];
                    $bean_up->marketing_list_id_c = $_POST['act_marketing_list_id'];
                    $bean_up->type = 'activity';
                    /* $listPromoCoupon = $this->promoToCoupon(array_filter($_POST['get_promotion_id_' . $type]), array_filter($_POST['get_coupon_id_' . $type]));
                      $arr = explode('@', $listPromoCoupon); */ //09-05-17
                } else {
                    $bean_up->activity_based_activity = '';
                }

                /* $bean_up->promotion_id_c = $arr[0];
                  $bean_up->link_coupon_code = $arr[1]; */ //09-05-17
                $bean_up->promotion_id_c = implode(',', $_POST['promo_check']); //09-05-17
                $bean_up->save();
                // start update last used in campaign
                if ($_POST['activty_email_templates_id'] != $_POST['get_template_id']) {
                    if (!empty($_POST['get_template_id'])) {
                        $bean_email_templates = BeanFactory::getBean('EmailTemplates', $_POST['get_template_id']);
                        $bean_email_templates->update_date_modified = false;
                        $bean_email_templates->lastused_c = date('Y-m-d');
                        $bean_email_templates->lastused_asset_in_camp = $campaignname;
                        $bean_email_templates->save();
                    }
                }
                // end  update last used in campaign
                echo $bean_up->id;
                exit();
            } else {
                // save record
                $bean = BeanFactory::newBean('Camp_TypeActivity');
                $type = $_POST['type'];
                $bean->cmp_id = $_POST['campagin_id'];
                $bean->cmp_activity_id = $_POST['subtype_id'];
                $bean->template_id = $_POST['get_template_id'];
                $bean->comments = $_POST['comments'];

                $arr = array();
                if ($type == 'trig') {
                    $bean->link_product_portfolio = implode(',', array_filter($_POST['trig_link_product_id']));
                    $bean->marketing_list_id_c = $_POST['trig_marketing_list_id'];
                    $bean->type = 'trigger';
                    /* $listPromoCoupon = $this->promoToCoupon(array_filter($_POST['get_promotion_id_' . $type]), array_filter($_POST['get_coupon_id_' . $type]));
                      $arr = explode('@', $listPromoCoupon); */
                } else {
                    $bean->link_product_portfolio = '';
                }
                if ($type == 'date') {
                    $bean->date_activity = $_POST['select_date_based'];
                    $bean->marketing_list_id_c = $_POST['date_marketing_list_id'];
                    $bean->type = 'date';
                    /* $listPromoCoupon = $this->promoToCoupon(array_filter($_POST['get_promotion_id_' . $type]), array_filter($_POST['get_coupon_id_' . $type]));
                      $arr = explode('@', $listPromoCoupon); */
                } else {
                    $bean->date_activity = '';
                }
                if ($type == 'activi') {
                    $bean->activity_based_activity = $_POST['select_activity_based'];
                    $bean->marketing_list_id_c = $_POST['act_marketing_list_id'];
                    $bean->type = 'activity';
                    /* $listPromoCoupon = $this->promoToCoupon(array_filter($_POST['get_promotion_id_' . $type]), array_filter($_POST['get_coupon_id_' . $type]));
                      $arr = explode('@', $listPromoCoupon); */
                } else {
                    $bean->activity_based_activity = '';
                }

                /* $bean->promotion_id_c = $arr[0];
                  $bean->link_coupon_code = $arr[1]; */ //09-05-17
                $bean->promotion_id_c = implode(',', $_POST['promo_check']); //09-05-17
                $bean->save();
                // start update last used in campaign
                if ($_POST['activty_email_templates_id'] != $_POST['get_template_id']) {
                    if (!empty($_POST['get_template_id'])) {
                        $bean_email_templates = BeanFactory::getBean('EmailTemplates', $_POST['get_template_id']);
                        $bean_email_templates->update_date_modified = false;
                        $bean_email_templates->lastused_c = date('Y-m-d');
                        $bean_email_templates->lastused_asset_in_camp = $campaignname;
                        $bean_email_templates->save();
                    }
                }
                // end  update last used in campaign
                echo $bean->id;
                exit();
            }
        }
    }

    public function action_deleteCampaignTypeActivity() {
        if (!empty($_POST['tid'])) {
            $bean = BeanFactory::getBean('Camp_TypeActivity', $_POST['tid']);     //Retrieve bean
            $bean->deleted = 1;    //Set deleted to true
            $bean->save(); //Save
            echo 1;
            exit;
        }
    }

    public function action_deleteCampaignActivity() {
        if (!empty($_POST['name'])) {
            unset($_SESSION['Normal_Activity_' . $_POST['name']]);
        }
        if (!empty($_POST['tid'])) {
            $bean = BeanFactory::getBean('Camp_Activity', $_POST['tid']);     //Retrieve bean
            $bean->marketing_list_id = '';    //Set deleted to true
            $bean->coupon_id_c = '';    //Set deleted to true
            $bean->promotion_id_c = '';    //Set deleted to true
            $bean->template_id_c = '';    //Set deleted to true
            $bean->save(); //Save           
        }
        echo 1;
        exit;
    }

    public function action_clone() {
        if (!empty($_POST['record'])) {
            $sql = "SELECT * FROM `campaigns` where id='" . $_POST['record'] . "'";
            $result = $GLOBALS['db']->query($sql);
            $camp = array();
            while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
                $camp[] = $row;
            }
            if (!empty($camp)) {
                $bean = BeanFactory::newBean('Campaigns');
                $bean->campaign_id_c = $this->get_campaign_no();
                $bean->name = $camp[0]['name'] . '_clone';
                $bean->campaign_type = $camp[0]['campaign_type'];
                $bean->campaign_subtype = $camp[0]['campaign_subtype'];
                $bean->content = $camp[0]['content'];
                $bean->status = 'Saved';
                $bean->country = $camp[0]['country'];

                //financial
                $bean->campaign_cost = $camp[0]['campaign_cost'];
                $bean->expected_revenue = $camp[0]['expected_revenue'];
                $bean->budget = $camp[0]['budget'];
                $bean->campaign_owner = $camp[0]['campaign_owner'];
                $bean->naku_cost_contribution_c = $camp[0]['naku_cost_contribution_c'];
                $bean->naku_cost_type_c = $camp[0]['naku_cost_type_c'];
                $bean->save();


                if (!empty($bean->id)) {
                    // supplier
                    $sql_supplier = "SELECT * FROM `camp_supplier` where cmp_id='" . $_POST['record'] . "'";
                    $result_supplier = $GLOBALS['db']->query($sql_supplier);
                    $supplier = array();
                    while ($row_supplier = $GLOBALS['db']->fetchByAssoc($result_supplier)) {
                        $bean1 = BeanFactory::newBean('Camp_Supplier');
                        $bean1->cmp_id = $bean->id;
                        $bean1->supplier_id = $row_supplier['supplier_id'];
                        $bean1->supplier_cost = $row_supplier['supplier_cost'];
                        $bean1->cost_type = $row_supplier['cost_type'];
                        $bean1->save();
                    }

                    // campaign_activity					
                    $sql_campaign_activity = "SELECT * FROM `camp_activity` where cmp_id='" . $_POST['record'] . "'";
                    $result_campaign_activity = $GLOBALS['db']->query($sql_campaign_activity);
                    while ($row_campaign_activity = $GLOBALS['db']->fetchByAssoc($result_campaign_activity)) {

                        $bean2 = BeanFactory::newBean('Camp_Activity');
                        $bean2->cmp_id = $bean->id;
                        $bean2->cmp_subtype_id = $row_campaign_activity['cmp_subtype_id'];
                        $bean2->activity_cost = $row_campaign_activity['activity_cost'];
                        $bean2->activity_cost_type = $row_campaign_activity['activity_cost_type'];
                        $bean2->marketing_list_id = $row_campaign_activity['marketing_list_id'];
                        $bean2->template_id_c = $row_campaign_activity['template_id_c'];
                        $bean2->coupon_id_c = $row_campaign_activity['coupon_id_c'];
                        $bean2->promotion_id_c = $row_campaign_activity['promotion_id_c'];
                        $bean2->name = $row_campaign_activity['name'];
                        $bean2->date_entered = date('Y-m-d H:i:s');
                        $bean2->date_modified = date('Y-m-d H:i:s');
                        $bean2->event_desc = $row_campaign_activity['event_desc'];
                        $bean2->event_name = $row_campaign_activity['event_name'];
                        $bean2->event_place = $row_campaign_activity['event_place'];
                        $bean2->longitude = $row_campaign_activity['longitude'];
                        $bean2->latitude = $row_campaign_activity['latitude'];
                        $bean2->asset_id_c = $row_campaign_activity['asset_id_c'];
                        $bean2->ab_test_c = $row_campaign_activity['ab_test_c'];
                        $bean2->save();
                    }

                    // // campaign_sub type activity	
                    $sql_campaign_typeactivity = "SELECT * FROM `camp_typeactivity` where cmp_id='" . $_POST['record'] . "'";
                    $result_campaign_typeactivity = $GLOBALS['db']->query($sql_campaign_typeactivity);
                    while ($row_campaign_typeactivity = $GLOBALS['db']->fetchByAssoc($result_campaign_typeactivity)) {
                        $bean3 = BeanFactory::newBean('Camp_TypeActivity');
                        $bean3->cmp_id = $bean->id;
                        $bean3->cmp_activity_id = $row_campaign_typeactivity['cmp_activity_id'];
                        $bean3->template_id = $row_campaign_typeactivity['template_id'];
                        $bean3->comments = $row_campaign_typeactivity['comments'];
                        $bean3->link_product_portfolio = $row_campaign_typeactivity['link_product_portfolio'];
                        $bean3->type = $row_campaign_typeactivity['type'];
                        $bean3->date_activity = $row_campaign_typeactivity['date_activity'];
                        $bean3->activity_based_activity = $row_campaign_typeactivity['activity_based_activity'];
                        $bean3->promotion_id_c = $row_campaign_typeactivity['promotion_id_c'];
                        $bean3->marketing_list_id_c = $row_campaign_typeactivity['marketing_list_id_c'];
                        $bean3->link_coupon_code = $row_campaign_typeactivity['link_coupon_code'];
                        $bean3->save();
                    }
                }
            }
            echo true;
            exit;
        }
        /*SugarApplication::appendErrorMessage('<span class="msg-success">Campaign Clone created successfully.</span>');
        $queryParams = array(
            'module' => 'Campaigns',
            'action' => 'EditView',
            'id' => $bean->id
        );
        SugarApplication::redirect('index.php?' . http_build_query($queryParams));*/
    }

    public function action_updateActiveCampaign() {
		global $sugar_config;
        if (!empty($_POST['cid'])) {
			$changedCNT = 0;
			$unChangedCNT = 0;
            foreach ($_POST['cid'] as $cid) {
                $sql = "SELECT id, status, content FROM `campaigns` where id='" . $cid . "'";
                $result_subtype = $GLOBALS['db']->query($sql);
				$row = $GLOBALS['db']->fetchByAssoc($result_subtype);
                if (count($row) > 0 && $row['status'] == 'Pending Approval') {
                    $bean1 = BeanFactory::getBean('Campaigns', $cid);
                    $bean1->update_date_modified = false;
                    $bean1->status = 'Active';
                    $bean1->save();
					$sql = "SELECT asset_id_c FROM `camp_activity` where cmp_id='" . $cid . "' and name='Social Media'";
					$result_activity = $GLOBALS['db']->query($sql);
					$rowActivity = $GLOBALS['db']->fetchByAssoc($result_activity);
					if(count($rowActivity) > 0 && $rowActivity['asset_id_c'] != ''){
					$tempArr = explode(",",$rowActivity['asset_id_c']);
					$finalArr = "'" . implode ( "', '", $tempArr ) . "'";
					$sql = "select file_name from asset_assets where id IN (" . $finalArr . ")";
					$result_asset = $GLOBALS['db']->query($sql);
					//$rowAsset = $GLOBALS['db']->fetchByAssoc($result_asset);
					while($imageAsset = $GLOBALS['db']->fetchByAssoc($result_asset)){
							$multiple_photos[] = $sugar_config['fb_url_cdn'].$imageAsset['file_name'];
							$multiple_twitterphotos[] = $_SERVER['DOCUMENT_ROOT'].'/cdn/'.$imageAsset['file_name'];
					}
					//echo "<pre>";
					//print_r($multiple_photos);exit;
					$fb = new Facebook\Facebook([
									 'app_id' => $sugar_config['fb_app_id'],
									 'app_secret' => $sugar_config['fb_app_secret'],
									 'default_graph_version' => 'v2.2',
									 'fileUpload' => true,
									]);
					$page_id = $sugar_config['fb_page_id'];
					$endpoint = "/".$page_id."/photos";
					$pageAccessToken = $sugar_config['fb_page_access_token'];
					$photos = array();
					foreach ($multiple_photos as $file_url) {
					try {
							 array_push($photos, $fb->post('/me/photos',['url' =>$file_url,'published' => FALSE,], $pageAccessToken));
							} catch(Facebook\Exceptions\FacebookResponseException $e) {
							 echo 'Graph returned an error: '.$e->getMessage();
							 exit;
							} catch(Facebook\Exceptions\FacebookSDKException $e) {
							 echo 'Facebook SDK returned an error: '.$e->getMessage();
							 exit;
							}						
					}
					$cnt = 0;
					foreach ($photos as $photo){
					$data_post['attached_media['.$cnt.']'] = '{"media_fbid":"'.$photo->getDecodedBody()['id'].'"}';
					$cnt++;
					}
					$data_post['message'] = $row['content'];					
					try {
							 $response = $fb->post('/'.$sugar_config['fb_page_id'].'/feed', $data_post, $pageAccessToken);
							} catch(Facebook\Exceptions\FacebookResponseException $e) {
							 echo 'Graph returned an error: '.$e->getMessage();
							 exit;
							} catch(Facebook\Exceptions\FacebookSDKException $e) {
							 echo 'Facebook SDK returned an error: '.$e->getMessage();
							 exit;
							}
					//twitter code starts here
					$consumerTKey = 'OQWTJAcD3ZgBBHsPXL5PbbSuf';
					$consumerTSecret = 'bygr4yIvMIQh7MrztSCSiX1fQLHNhx2F8cbhjVgmNiZUV7qxoU';
					$accessTToken = '871238583356731393-7Q41L8rWwra71SlTPGneG6tam8Lu5fE';
					$accessTTokenSecret = 'yKQjYmij2KIHypL7yfx4CBRzvI0mhh0QOaBDGIU2smyrx';
					$twitter = new Twitter($consumerTKey, $consumerTSecret, $accessTToken, $accessTTokenSecret);

					try {
					//$multiple_photos[] = $_SERVER['DOCUMENT_ROOT']."/cdn/Website/1496002454_Banner_1024x960_Website_HotDeal1_May-2017.jpg";
						$tweet = $twitter->send($row['content'], $multiple_twitterphotos); // you can add $imagePath or array of image paths as second argument

					} catch (TwitterException $e) {
						echo 'Error: ' . $e->getMessage();
					}	
					}	
					$changedCNT++;
                }
				
				if (count($row) > 0 && $row['status'] == 'Saved') {
                    $unChangedCNT++;
                }
				
				if (count($row) > 0 && $row['status'] == 'Inactive') {
                    $bean1 = BeanFactory::getBean('Campaigns', $cid);
                    $bean1->update_date_modified = false;
                    $bean1->status = 'Active';
                    $bean1->save();
					$changedCNT++;
                }
				
				if (count($row) > 0 && $row['status'] == 'Active') {
                    $unChangedCNT++;
                }
            }
            //$campIDs = sprintf("'%s'", implode("', '", $_POST['cid']));
            //include('cronscript_activity.php');
			$msg = "";
			if($changedCNT > 0) {
			$msg .= $changedCNT." Campaign status has been changed successfully.";
			}
			if($unChangedCNT > 0) {
			$msg .= $unChangedCNT." Campaign status has not been changed. They are either in Saved or Active state.";
			}
            echo $msg;
            exit;
        }
    }

    public function action_updateInActiveCampaign() {
        if (!empty($_POST['cid'])) {

            foreach ($_POST['cid'] as $cid) {
                $sql = "SELECT id FROM `campaigns` where id='" . $cid . "'";
                $result_subtype = $GLOBALS['db']->query($sql);
                if ($result_subtype->num_rows > 0) {
                    $bean1 = BeanFactory::getBean('Campaigns', $cid);
                    $bean1->update_date_modified = false;
                    $bean1->status = 'Inactive';
                    $bean1->save();
                }
            }
            echo 1;
            exit;
        }
    }

    public function action_hasDuplicatesCampaignsOnSameDate() {
        //Fixed defect D39 31/07/2017
        global $sugar_config;
        $campaign_type = explode(',',strtolower($_POST['campaign_type']));
        //if (in_array("54561030-48a3-386d-67f1-581ae2709846", $_POST['campaign_type'])) {
        if (in_array(strtolower($sugar_config['camp_type']), $campaign_type)) {
            if ($_POST['campaign_id'] != '') {
                $sql = "SELECT c.id,c.campaign_type FROM `campaigns` as c LEFT JOIN camp_type as ct ON ct.id = '". $sugar_config['camp_type'] ."' WHERE c.start_date <= '" . $_POST['sdatecampaign'] . "' AND c.end_date >= '" . $_POST['edatecampaign'] . "' AND c.id <> '" . $_POST['campaign_id'] . "'";
                //$sql = "SELECT id,campaign_type FROM `campaigns` where start_date <= '" . $_POST['sdatecampaign'] . "' AND end_date >= '" . $_POST['edatecampaign'] . "' AND campaign_type IN ('54561030-48a3-386d-67f1-581ae2709846') AND id <> '" . $_POST['campaign_id'] . "'";
            } else {
                $sql = "SELECT c.id,c.campaign_type FROM `campaigns` as c LEFT JOIN camp_type as ct ON ct.id = '". $sugar_config['camp_type'] ."' WHERE c.start_date <= '" . $_POST['sdatecampaign'] . "' AND c.end_date >= '" . $_POST['edatecampaign'] . "'";
                //$sql = "SELECT id,campaign_type FROM `campaigns` where start_date <= '" . $_POST['sdatecampaign'] . "' AND end_date >= '" . $_POST['edatecampaign'] . "' AND campaign_type IN ('54561030-48a3-386d-67f1-581ae2709846')";
            }
            $result_subtype = $GLOBALS['db']->query($sql);
            if ($result_subtype->num_rows > 0) {
                echo 'error';
                exit;
            } else {
                echo 'success';
                exit;
            }
        } else {
            echo 'success';
            exit;
        }
    }

    // its for marketing list
    public function action_MarketView() {
        global $mod_strings, $sugar_config;
        $servername = $sugar_config['mk_server_name'];
        $username = $sugar_config['mk_username'];
        $password = $sugar_config['mk_password'];
        $dbname = $sugar_config['mk_db_name'];
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql = "SELECT COUNT(*) FROM magento_customersegment_segment WHERE is_active = 1";
        $result = $conn->query($sql);
        $numrows = $result->fetch_row();
        // number of rows to show per page
        $rowsperpage = 25;
        // find out total pages
        $totalpages = ceil($numrows[0] / $rowsperpage);

        // get the current page or set a default
        if (isset($_GET['currentpage']) && is_numeric($_GET['currentpage'])) {
            // cast var as int
            $currentpage = (int) $_GET['currentpage'];
        } else {
            // default page num
            $currentpage = 1;
        } // end if
        // if current page is greater than total pages...
        if ($currentpage > $totalpages) {
            // set current page to last page
            $currentpage = $totalpages;
        } // end if
        // if current page is less than first page...
        if ($currentpage < 1) {
            // set current page to first page
            $currentpage = 1;
        } // end if
        // the offset of the list, based on current page 
        $offset = ($currentpage - 1) * $rowsperpage;

        $sql = "SELECT segment_id,name FROM magento_customersegment_segment WHERE is_active = 1 LIMIT $offset, $rowsperpage";
        $result = $conn->query($sql);

        while ($row = $result->fetch_assoc()) {
            $arr[] = $row;
            //echo "id: " . $row["segment_id"] . " - Name: " . $row["name"] . " " . $row["is_active"] . "<br>";
        }
        //echo "<pre>";
        //print_r($arr);exit;
        $this->view_object_map['currentpage'] = $currentpage;
        $this->view_object_map['dataRows'] = $arr;
        $this->view_object_map['totalpages'] = $totalpages;
        $this->view_object_map['rowsperpage'] = $rowsperpage;
        $this->view_object_map['numRows'] = $numrows[0];
        if ($currentpage > 1) {
            $this->view_object_map['prevDisabled'] = '';
            // show << link to go back to page 1
            //echo " <a href='{$_SERVER['PHP_SELF']}?module=Campaigns&action=MarketView&currentpage=1'><<</a> ";
            // get previous page num
            $prevpage = $currentpage - 1;
            // show < link to go back to 1 page
            //echo " <a href='{$_SERVER['PHP_SELF']}?module=Campaigns&action=MarketView&currentpage=$prevpage'><</a> ";
        } else { // end if
            $this->view_object_map['prevDisabled'] = 'disabled=""';
            $prevpage = 0;
        }
        //
        // if not on last page, show forward and last page links
        if ($currentpage == 1) {
            $paginationText = $currentpage . "-" . $rowsperpage . " Of " . $numrows[0];
        } else {
            $paginationText = ($currentpage + 1) . "-" . ($currentpage + $rowsperpage - 1) . " Of " . $numrows[0];
        }
        if ($currentpage != $totalpages) {
            $this->view_object_map['nextDisabled'] = '';
            // get next page
            $nextpage = $currentpage + 1;
            // echo forward link for next page 
            //echo " <a href='{$_SERVER['PHP_SELF']}?module=Campaigns&action=MarketView&currentpage=$nextpage'>></a> ";
            // echo forward link for lastpage
            //echo " <a href='{$_SERVER['PHP_SELF']}?module=Campaigns&action=MarketView&currentpage=$totalpages'>>></a> ";
        } else {
            $this->view_object_map['nextDisabled'] = 'disabled=""';
            $nextpage = 0;
        }
        $this->view_object_map['paginationText'] = $paginationText;
        $this->view_object_map['prevpage'] = $prevpage;
        $this->view_object_map['nextpage'] = $nextpage;
        $conn->close();
        $this->view = 'popup';
    }

    public function get_marketing_list_name($id) {
        $mkname = '';
        if (!empty($id)) {
            global $mod_strings, $sugar_config;
            $servername = $sugar_config['mk_server_name'];
            $username = $sugar_config['mk_username'];
            $password = $sugar_config['mk_password'];
            $dbname = $sugar_config['mk_db_name'];
            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            $sql = "SELECT segment_id,name FROM magento_customersegment_segment WHERE is_active = 1 AND segment_id=$id";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $mkname = $row['name'];
                }
            }
            $conn->close();
        }
        return $mkname;
    }

    //09-05-17
    public function action_getPromotionsListCRM() {
        if (!empty($_POST['marketing_id'])) {
            global $sugar_config, $db;
            $marketing_id = $_POST['marketing_id'];
            $conn = $this->connectionCRMDB();
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            $data = array();
            $sql = "SELECT row_id, name, promo_name, core_promotion, auto_coupon_code, reward_type, reward_value, reward_days FROM " . $sugar_config['crm_salesrule'] . " WHERE customer_segment = " . $marketing_id . " AND is_active = 1";
            $result = $conn->query($sql);
            while ($row = $db->fetchByAssoc($result)) {
                $data[] = $row;
            }
            if (count($data) > 0) {
                echo json_encode($data);
            } else {
                echo json_encode(array('flag' => '0'));
            }
            $conn->close();
            exit;
        }
    }

    //09-05-17
    public function getEditPromotionsListCRM($promo_id, $marketing_id) {
        // echo$promo_id;echo'<br/>';//echo$marketing_id;
        if (!empty($promo_id) && !empty($marketing_id)) {
            global $sugar_config, $db;
            $conn = $this->connectionCRMDB();
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            $data = array();
            $sql = "SELECT row_id, name, promo_name, core_promotion, auto_coupon_code, reward_type, reward_value, reward_days FROM " . $sugar_config['crm_salesrule'] . " WHERE is_active = 1 AND customer_segment = " . $marketing_id . " AND row_id IN (" . sprintf("'%s'", implode("', '", explode(',', $promo_id))) . ")";
            $result = $conn->query($sql);
            while ($row = $db->fetchByAssoc($result)) {
                $data[] = $row;
            }
            $conn->close();
            return $data;
        }
    }

    //09-05-17
    public function action_getPromotionsListByProduct() {
        if (!empty($_POST['product_sku'])) {
            global $sugar_config, $db;
            $product_sku = $_POST['product_sku'];
            $conn = $this->connectionCRMDB();
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            $data = array();
            $sql = "SELECT row_id, name, promo_name, core_promotion, auto_coupon_code, reward_type, reward_value, reward_days FROM " . $sugar_config['crm_salesrule'] . " WHERE base_sku = '" . $product_sku . "' AND is_active = 1";
            $result = $conn->query($sql);
            while ($row = $db->fetchByAssoc($result)) {
                $data[] = $row;
            }
            if (count($data) > 0) {
                echo json_encode($data);
            } else {
                echo json_encode(array('flag' => '0'));
            }
            $conn->close();
            exit;
        }
    }

    public function action_calendar() {
        global $sugar_config, $current_user;
        $uid = $current_user->id; //Logged in User ID
        $category = "Campaigns"; //Module name
        $type = "module"; //Nochnage
        $rootAction = "campaign"; //Root or Parent Action name according to magento Root action

        $subActionCreateCal = "markitingcalendar_create"; //create ICON
        $createCalIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionCreateCal, $type);

        $subActionEditCal = "markitingcalendar_edit"; //edit ICON
        $editCalIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionEditCal, $type);

        $subActionViewCal = "markitingcalendar_view"; //view ICON
        $viewCalIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionViewCal, $type);

        $subActionSearchCal = "markitingcalendar_search"; //Search ICON
        $searchCalIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionSearchCal, $type);

        $subActionExportCal = "markitingcalendar_export"; //export ICON
        $exportCalIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionExportCal, $type);

        $adminRole = $current_user->isAdmin();

        $this->view_object_map['createCalIcon'] = $createCalIcon;
        $this->view_object_map['editCalIcon'] = $editCalIcon;
        $this->view_object_map['viewCalIcon'] = $viewCalIcon;
        $this->view_object_map['searchCalIcon'] = $searchCalIcon;
        $this->view_object_map['exportCalIcon'] = $exportCalIcon;
        $this->view_object_map['adminRole'] = $adminRole;
        //end Roles and Permission Hacks by Akhilesh

        $this->view = 'calendar';
        // get type
        $sql = "SELECT id,name FROM `camp_type` where deleted=0";
        $result = $GLOBALS['db']->query($sql);
        while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
            $cData[$row['id']] = $row['name'];
        }
        $this->view_object_map['Camp_Type'] = $cData;
        $condition = '';
        if (!empty($_POST['campaign_type'])) {

            $csql = ' AND (';
            foreach ($_POST['campaign_type'] as $ctype) {
                $csql .=' campaign_type LIKE \'%' . $ctype . '%\' OR ';
            }
            $csql = substr($csql, 0, -3) . ' ) ';

            $condition .= $csql;
        }
        if (!empty($_POST['campaign_subtype'])) {
            $ssql = ' AND (';
            foreach ($_POST['campaign_subtype'] as $stype) {
                $ssql .=' campaign_subtype LIKE \'%' . $stype . '%\' OR ';
            }
            $ssql = substr($ssql, 0, -3) . ' ) ';

            $condition .= $ssql;
        }

        $sql = "SELECT id,content AS description,name AS title,start_date AS start,end_date AS end,status,campaign_type,campaign_subtype FROM `campaigns` where deleted=0 AND status IN('Pending Approval','Approved','Active','Completed') $condition";

        $result = $GLOBALS['db']->query($sql);
        $campaign = array();
        while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
            //if(isset($row['start_date']) && isset($row['end_date']))
            //{
            //if(($row['start_date']!='' || $row['start_date']!=NULL || $row['start_date']!='0000-00-00') || ($row['end_date']!='' || $row['end_date']!=NULL || $row['end_date']!='0000-00-00'))
            //{

            $row['end'] = date('Y-m-d', strtotime($row['end'] . ' +1 day'));


            if ($row['status'] == 'Pending Approval')
                $row['className'] = 'blueBorder';
            if ($row['status'] == 'Approved')
                $row['className'] = 'greyBorder';
            if ($row['status'] == 'Completed')
                $row['className'] = 'lightgreyBorder';
            if ($row['status'] == 'Active')
                $row['className'] = 'greenBorder';
            if (!empty($row['description'])) {
                // fetch campaign type
                $sql_ctype = "SELECT id,name FROM `camp_type` where deleted=0 AND id IN (" . sprintf("'%s'", implode("', '", explode(',', $row['campaign_type']))) . ")";
                $result_ctype = $GLOBALS['db']->query($sql_ctype);
                $ctypeData = array();
                while ($row_ctype = $GLOBALS['db']->fetchByAssoc($result_ctype)) {
                    $ctypeData[] = $row_ctype['name'];
                }

                // fetch campaign sub type
                $sql_camp_subtype = "SELECT id,name FROM `camp_subtype` where deleted=0 AND id IN (" . sprintf("'%s'", implode("', '", explode(',', $row['campaign_subtype']))) . ")";
                $result_camp_subtype = $GLOBALS['db']->query($sql_camp_subtype);
                $stypeData = array();
                while ($row_camp_subtype = $GLOBALS['db']->fetchByAssoc($result_camp_subtype)) {
                    $stypeData[] = $row_camp_subtype['name'];
                }

                $str = 'Name : ' . $row['title'];
                $str.='<br>Start : ' . $row['start'];
                $str.='<br>End : ' . $row['end'];
                $str.='<br>Campaign Type : ' . implode(',', $ctypeData);
                $str.='<br>Campaign Sub Type : ' . implode(',', $stypeData);
                $str.='<br>Description : ' . $row['description'];
                $row['description'] = $str;
            } else {
                $row['description'] = '';
            }
            if ($viewCalIcon === true || $adminRole == 1) {
                $row['url'] = $sugar_config['site_url'] . '/index.php?module=Campaigns&action=DetailView&record=' . $row['id'] . '&loc=cal';
            } else {
                $row['url'] = '';
            }
            $campaign[] = $row;
        }
        $this->view_object_map['campaign'] = json_encode($campaign);
		if (!empty($_POST['campaign_type'])) {
		$this->view_object_map['campaignType'] = implode(",",$_POST['campaign_type']);
		$_SESSION['campaignTypeCal'] = implode(",",$_POST['campaign_type']);
		} else {
		unset($_SESSION['campaignTypeCal']);
		}
		if (!empty($_POST['campaign_subtype'])) {
		$_SESSION['campaignSubTypeCal'] = implode(",",$_POST['campaign_subtype']);
		$this->view_object_map['campaignSubtype'] = implode(",",$_POST['campaign_subtype']);
		}  else {
		unset($_SESSION['campaignSubTypeCal']);
		}
    }

    public function action_calendar_export() {
        global $sugar_config;
        $this->view = 'calendar';
        // get type
        $sql = "SELECT id,name FROM `camp_type` where deleted=0";
        $result = $GLOBALS['db']->query($sql);
        while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
            $cData[$row['id']] = $row['name'];
        }
        $this->view_object_map['Camp_Type'] = $cData;
        $condition = '';
        if (!empty($_POST['campaign_type'])) {
            $condition .= "AND campaign_type IN (" . sprintf("'%s'", implode("', '", $_POST['campaign_type'])) . ")";
        }
        if (!empty($_POST['campaign_subtype'])) {
            $condition .= "AND campaign_subtype IN (" . sprintf("'%s'", implode("', '", $_POST['campaign_subtype'])) . ")";
        }

        $sql = "SELECT id,content AS description,name AS title,start_date AS start,end_date AS end,status FROM `campaigns` where deleted=0 $condition";

        $result = $GLOBALS['db']->query($sql);
        $campaign = array();
        while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
            if ($row['status'] == 'Approved' || $row['status'] == 'Pending Approval')
                $row['className'] = 'greyBorder';
            if ($row['status'] == 'Active')
                $row['className'] = 'greenBorder';
            if ($row['status'] == 'Completed')
                $row['className'] = 'lightgreyBorder';
            if ($row['status'] == 'Saved')
                $row['className'] = 'blueBorder';


            if (empty($row['description'])) {
                $row['description'] = '';
            }
            $row['url'] = $sugar_config['site_url'] . '/index.php?module=Campaigns&action=DetailView&record=' . $row['id'];
            $campaign[] = $row;
        }

        //$camp_data = json_encode($campaign);
		$this->view_object_map['campaign'] = $camp_data;
        $this->view = 'calendarpopup'; 
        //include('/create_pdf/campaignexport.php');
        //exit;
    }

    function action_calendar_export_data() {
	if (!empty($_SESSION['campaignTypeCal'])) {
	$_POST['campaign_type'] = explode(",",$_SESSION['campaignTypeCal']);
	}
	if (!empty($_SESSION['campaignSubTypeCal'])) {
    $_POST['campaign_subtype'] = explode(",",$_SESSION['campaignSubTypeCal']);	
	}
	$sql = "SELECT id,name FROM `camp_type` where deleted=0";
        $result = $GLOBALS['db']->query($sql);
        while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
            $cData[$row['id']] = $row['name'];
        }
        $this->view_object_map['Camp_Type'] = $cData;
        $condition = '';
        if (!empty($_POST['campaign_type'])) {

            $csql = ' AND (';
            foreach ($_POST['campaign_type'] as $ctype) {
                $csql .=' campaign_type LIKE \'%' . $ctype . '%\' OR ';
            }
            $csql = substr($csql, 0, -3) . ' ) ';

            $condition .= $csql;
        }
        if (!empty($_POST['campaign_subtype'])) {
            $ssql = ' AND (';
            foreach ($_POST['campaign_subtype'] as $stype) {
                $ssql .=' campaign_subtype LIKE \'%' . $stype . '%\' OR ';
            }
            $ssql = substr($ssql, 0, -3) . ' ) ';

            $condition .= $ssql;
        }

        $sql = "SELECT id,content AS description,name AS title,start_date AS start,end_date AS end,status,campaign_type,campaign_subtype FROM `campaigns` where deleted=0 AND status IN('Pending Approval','Approved','Active','Completed') $condition";

        $result = $GLOBALS['db']->query($sql);
        $campaign = array();
        while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
            $row['end'] = date('Y-m-d', strtotime($row['end'] . ' +1 day'));
            if ($row['status'] == 'Pending Approval')
                $row['className'] = 'blueBorder';
            if ($row['status'] == 'Approved')
                $row['className'] = 'greyBorder';
            if ($row['status'] == 'Completed')
                $row['className'] = 'lightgreyBorder';
            if ($row['status'] == 'Active')
                $row['className'] = 'greenBorder';
            if (!empty($row['description'])) {
                $sql_ctype = "SELECT id,name FROM `camp_type` where deleted=0 AND id IN (" . sprintf("'%s'", implode("', '", explode(',', $row['campaign_type']))) . ")";
                $result_ctype = $GLOBALS['db']->query($sql_ctype);
                $ctypeData = array();
                while ($row_ctype = $GLOBALS['db']->fetchByAssoc($result_ctype)) {
                    $ctypeData[] = $row_ctype['name'];
                }
                $sql_camp_subtype = "SELECT id,name FROM `camp_subtype` where deleted=0 AND id IN (" . sprintf("'%s'", implode("', '", explode(',', $row['campaign_subtype']))) . ")";
                $result_camp_subtype = $GLOBALS['db']->query($sql_camp_subtype);
                $stypeData = array();
                while ($row_camp_subtype = $GLOBALS['db']->fetchByAssoc($result_camp_subtype)) {
                    $stypeData[] = $row_camp_subtype['name'];
                }
                $str = 'Name : ' . $row['title'];
                $str.='<br>Start : ' . $row['start'];
                $str.='<br>End : ' . $row['end'];
                $str.='<br>Campaign Type : ' . implode(',', $ctypeData);
                $str.='<br>Campaign Sub Type : ' . implode(',', $stypeData);
                $str.='<br>Description : ' . $row['description'];
                $row['description'] = $str;
            } else {
                $row['description'] = '';
            }
            if ($viewCalIcon === true || $adminRole == 1) {
                $row['url'] = $sugar_config['site_url'] . '/index.php?module=Campaigns&action=DetailView&record=' . $row['id'] . '&loc=cal';
            } else {
                $row['url'] = '';
            }
            $campaign[] = $row;
        }
		$this->view_object_map['campaign'] = json_encode($campaign);
        $this->view = 'calendarpopup';
    }

    /**
     * Get Branch name from magento CRM 
     *
     */
    public function getBranchName() {
        global $sugar_config;
        $conn = $this->connectionCRMDB();
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $list_branch = array();
        $sql = "SELECT store_id,branch_name FROM " . $sugar_config['crm_store'];
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $res = preg_replace("/[^a-zA-Z0-9]/", "", $row['branch_name']); //remove special character coming
                $row['branch_name'] = trim($res);
                $list_branch[] = $row;
            }
        }
        $conn->close();
        return $list_branch;
        //echo'<pre>';print_r($list_branch);
    }

    /**
     *  Get Branch name by ID from magento CRM 
     *
     */
    public function getBranchNameBYID($storeid) {
        global $sugar_config;
        $conn = $this->connectionCRMDB();
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $list_branch = array();
        $sql = "SELECT branch_name FROM " . $sugar_config['crm_store'] . " WHERE store_id IN (" . sprintf("'%s'", implode("', '", explode('::', $storeid))) . ")";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $res = preg_replace("/[^a-zA-Z0-9]/", "", $row['branch_name']);
                $list_branch[] = trim($res);
            }
        }
        $conn->close();
        return implode('::', $list_branch);
    }

    /**
     * This method is DB connection of CRM Magento 
     *
     */
    public function connectionCRMDB() {
        global $sugar_config;
        $servername = $sugar_config['crm_host'];
        $username = $sugar_config['crm_user'];
        $password = $sugar_config['crm_password'];
        $dbname = $sugar_config['crm_db'];
        $conn = new mysqli($servername, $username, $password, $dbname);
        return $conn;
    }

    /**
     *  Get Polls in Magento CRM DB
     *
     */
    public function getPolls() {
        global $sugar_config;
        $conn = $this->connectionCRMDB();
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $list_polls = array();
        $sql = "SELECT polls_id,title FROM " . $sugar_config['crm_polls'] . " WHERE status = 1";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $list_polls[] = $row;
            }
        }
        $conn->close();
        return $list_polls;
    }

    /**
     *  Get Polls in Magento CRM DB
     *
     */
    public function getPollNameBYID($poll_id) {
        global $sugar_config;
        $conn = $this->connectionCRMDB();
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $poll_name = array();
        $sql = "SELECT title FROM " . $sugar_config['crm_polls'] . " WHERE polls_id = " . $poll_id . " AND status = 1";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_row()) {
                $poll_name[] = $row[0];
            }
        }
        $conn->close();
        return $poll_name[0];
    }

    /**
     *  Get List of Base Product with Associated Product via Magento Ecomm 
     *
     */
    public function action_ListProductPortfolio() {
        global $sugar_config;
        $servername = $sugar_config['mk_server_name'];
        $username = $sugar_config['mk_username'];
        $password = $sugar_config['mk_password'];
        $dbname = $sugar_config['mk_db_name'];
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql_cpl = "SELECT COUNT(*) FROM " . $sugar_config['crm_catalog_product_link'] . " as cpl LEFT JOIN " . $sugar_config['crm_catalog_product_entity'] . " as cpe ON cpe.row_id = cpl.product_id WHERE cpl.link_type_id = 1 GROUP BY cpl.product_id";
        $result_cpl = $conn->query($sql_cpl);
        $numrows = $result_cpl->fetch_row();

        // number of rows to show per page
        $rowsperpage = 10;
        // find out total pages
        $totalpages = ceil($numrows[0] / $rowsperpage);

        // get the current page or set a default
        if (isset($_GET['currentpage']) && is_numeric($_GET['currentpage'])) {
            // cast var as int
            $currentpage = (int) $_GET['currentpage'];
        } else {
            // default page num
            $currentpage = 1;
        } // end if
        // if current page is greater than total pages...
        if ($currentpage > $totalpages) {
            // set current page to last page
            $currentpage = $totalpages;
        } // end if
        // if current page is less than first page...
        if ($currentpage < 1) {
            // set current page to first page
            $currentpage = 1;
        } // end if
        // the offset of the list, based on current page 
        $offset = ($currentpage - 1) * $rowsperpage;

        $sql = "SELECT cpl.product_id, cpe.sku, cpl.linked_product_id as associated_product_id FROM " . $sugar_config['crm_catalog_product_link'] . " as cpl LEFT JOIN " . $sugar_config['crm_catalog_product_entity'] . " as cpe ON cpe.row_id = cpl.product_id WHERE cpl.link_type_id = 1 GROUP BY cpl.product_id LIMIT $offset, $rowsperpage";
        $result = $conn->query($sql);

        while ($row = $result->fetch_assoc()) {
            $data["product_id"] = $row["product_id"];
            $data['name'] = $row['sku'];
            $arr[] = $data;
            //echo "product id: " . $row["product_id"] . " - SKU: " . $row["sku"] . " - Associated ID: " . $row["associated_product_id"] . "<br>";
        }
        //echo "<pre>";
        //print_r($arr);exit;
        $this->view_object_map['currentpage'] = $currentpage;
        $this->view_object_map['dataRows'] = $arr;
        $this->view_object_map['totalpages'] = $totalpages;
        $this->view_object_map['rowsperpage'] = $rowsperpage;
        $this->view_object_map['numRows'] = $numrows[0];
        if ($currentpage > 1) {
            $this->view_object_map['prevDisabled'] = '';
            // show << link to go back to page 1
            //echo " <a href='{$_SERVER['PHP_SELF']}?module=Campaigns&action=MarketView&currentpage=1'><<</a> ";
            // get previous page num
            $prevpage = $currentpage - 1;
            // show < link to go back to 1 page
            //echo " <a href='{$_SERVER['PHP_SELF']}?module=Campaigns&action=MarketView&currentpage=$prevpage'><</a> ";
        } else { // end if
            $this->view_object_map['prevDisabled'] = 'disabled=""';
            $prevpage = 0;
        }
        //
        // if not on last page, show forward and last page links
        if ($currentpage == 1) {
            $paginationText = $currentpage . "-" . $rowsperpage . " Of " . $numrows[0];
        } else {
            $paginationText = ($currentpage + 1) . "-" . ($currentpage + $rowsperpage - 1) . " Of " . $numrows[0];
        }
        if ($currentpage != $totalpages) {
            $this->view_object_map['nextDisabled'] = '';
            // get next page
            $nextpage = $currentpage + 1;
            // echo forward link for next page 
            //echo " <a href='{$_SERVER['PHP_SELF']}?module=Campaigns&action=MarketView&currentpage=$nextpage'>></a> ";
            // echo forward link for lastpage
            //echo " <a href='{$_SERVER['PHP_SELF']}?module=Campaigns&action=MarketView&currentpage=$totalpages'>>></a> ";
        } else {
            $this->view_object_map['nextDisabled'] = 'disabled=""';
            $nextpage = 0;
        }
        $this->view_object_map['paginationText'] = $paginationText;
        $this->view_object_map['prevpage'] = $prevpage;
        $this->view_object_map['nextpage'] = $nextpage;
        $conn->close();
        $this->view = 'productpopup';
    }

    /**
     * This method is DB connection of CRM Magento 
     *
     */
    public function connectionEcomDB() {
        global $sugar_config;
        $servername = $sugar_config['mk_server_name'];
        $username = $sugar_config['mk_username'];
        $password = $sugar_config['mk_password'];
        $dbname = $sugar_config['mk_db_name'];
        $conn = new mysqli($servername, $username, $password, $dbname);
        return $conn;
    }

    /**
     * This method is get associated product
     *
     */
    public function action_getAssociatedProducts() {
        global $sugar_config;
        if (!empty($_POST) && !empty($_POST['base_product_id'])) {
            $conn = $this->connectionEcomDB();
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            $sql_cpl = "SELECT cpl.product_id, cpl.linked_product_id as associated_product_id FROM " . $sugar_config['crm_catalog_product_link'] . " as cpl WHERE cpl.product_id =" . $_POST['base_product_id'] . " AND cpl.link_type_id=1";
            $result_cpl = $conn->query($sql_cpl);
            $num = 1;
            while ($row_cpl = $result_cpl->fetch_assoc()) {
                if (!empty($row_cpl['product_id']) && !empty($row_cpl['associated_product_id'])) {
                    $sql_eav = "SELECT ent.entity_type_id, att.attribute_id, cpev.value, cpe.sku FROM " . $sugar_config['crm_eav_entity_type'] . " as ent LEFT JOIN "
                            . $sugar_config['crm_eav_attribute'] . " as att ON att.entity_type_id = ent.entity_type_id LEFT JOIN "
                            . $sugar_config['crm_catalog_product_entity_varchar'] . " as cpev ON cpev.attribute_id = att.attribute_id LEFT JOIN "
                            . $sugar_config['crm_catalog_product_entity'] . " as cpe ON cpe.row_id =" . $row_cpl['associated_product_id']
                            . " WHERE att.attribute_code='name' AND ent.entity_type_code='catalog_product' AND "
                            . " cpev.row_id =" . $row_cpl['associated_product_id'] . " GROUP BY ent.entity_type_id";
                    $result_eav = $conn->query($sql_eav);
                    while ($row_eav = $result_eav->fetch_assoc()) {
                        $row_data['num'] = $num;
                        $row_data['sku'] = $row_eav['sku'];
                        $row_data['asso_product_id'] = $row_cpl['associated_product_id'];
                        $row_data['product_name'] = $row_eav['value'];
                        $data[] = $row_data;
                    }
                }
                $num++;
            }
            //print_r($data);
            echo json_encode($data);
            exit();
        }
    }

    /**
     * This method is get list of base product name
     *
     */
    public function get_product_portfolio_list_name($ids) {
        if (!empty($ids)) {
            global $sugar_config;
            $product_name = array();
            $conn = $this->connectionEcomDB();
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            $sql = "SELECT cpe.row_id, cpe.sku FROM " . $sugar_config['crm_catalog_product_entity'] . " as cpe WHERE cpe.row_id IN (" . sprintf("'%s'", implode("', '", explode(',', $ids))) . ")";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $product_name[$row['row_id']] = $row['sku'];
                }
            }
            $conn->close();
        }
        return $product_name;
    }

    //Report to understand Campaign Spend by Campaign Type
    public function action_camptypereport() 
    {
        $this->view = 'camptypereport';
        global $sugar_config;
        //get campaign type
        $sql = "SELECT id,name FROM `camp_type` where deleted=0";
        $result = $GLOBALS['db']->query($sql);
                
        //Set CampaignType options
        $cData['all'] = 'All';
        while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
            $cData[$row['id']] = $row['name'];
        }  
        $current_date = date("Y-m-d");
        
        //set Quarer options for from and to dropdonwn for Yearly type 
        $edateOfQtr = date('Y-m-d', strtotime($current_date."-1 days"));
        $sdateOfQtr = date('Y-m-1', strtotime("-1 year", strtotime($edateOfQtr)));
        $this->view_object_map['quarterOptions'] = $this->getKenyanQuarters(
            $sdateOfQtr, $edateOfQtr
        );
        $quarterOptions = $this->view_object_map['quarterOptions'];
        
        $this->view_object_map['Camp_Type'] = $cData;
        $postSubtype = $_POST['campaign_subtype'];
        $postedCampTypeID = $_POST['campaign_type'];
        $from = $_POST['from_date'];
        $to = $_POST['to_date'];
        $grpByCondition = '';
        $postedCampSubtypeID = $_POST['campaign_subtype'];
                
        
        if ($_POST['report'] == 'y') {
                if ($from != $to) {
                    $edate = date('Y-m-d', strtotime($current_date."-1 days"));
                    $sdate = date('Y-m-1', strtotime("-1 year"));
                } else {
                    $sdate = date('Y-m-d', strtotime("$from-01-01"));
                    $edate = date('Y-m-d', strtotime("$from-12-31"));
                }
                $grpByCondition .= 'year(camp.start_date),';
        }
        if ($_POST['report'] == 'q') {
            $sdate = date('Y-m-d', strtotime($quarterOptions[$from]['sdate']));
            $edate = date('Y-m-d', strtotime($quarterOptions[$to]['edate']));
            $grpByCondition .= 'QUARTER(camp.start_date), year(camp.start_date),';
        }   

        //Check is specific campaign subtype selected or "All" subtypes data required
        $isSpecificCampSubType = 0;
        if (!empty($postedCampSubtypeID) && $postedCampSubtypeID != 'all' ) {
            $isSpecificCampSubType = 1;
        }

        //Check is specific CAMPAIGN TYPE selected or "All" CAMPAIGN TYPE data required
        $isSpecificCampType = 0;
        if (!empty($postedCampTypeID) && $postedCampTypeID != 'all' ) {
            $isSpecificCampType = 1;
        }
       
        // get campaign type
        if (!empty($_POST['campaign_type']) && !empty($_POST['campaign_subtype']) 
            && !empty($_POST['report']) && !empty($_POST['from_date']) && !empty($_POST['to_date'])
        ) {
            $subtype = $_POST['campaign_subtype'];
            $camptype = $_POST['campaign_type'];
            //get campaign type
            $sql_ctype = "SELECT * FROM `camp_type` where deleted=0 AND id='" .
                $_POST['campaign_type'] . "'";
            $ctype_name = '';
            $result_ctype = $GLOBALS['db']->query($sql_ctype);
            while ($row_ctype = $GLOBALS['db']->fetchByAssoc($result_ctype)) {
                $ctype_name = $row_ctype['name'];
            }
            if (empty($ctype_name)) {
                $ctype_name = 'All';
            }
            $main_query = "Select GROUP_CONCAT(camp.id), 
                GROUP_CONCAT(DISTINCT activity.cmp_id) as activity_ids,
                GROUP_CONCAT(DISTINCT csubtype.name) as csubtype_name, 
                SUM(DISTINCTROW camp.budget) as campaign_total_budget, 
                SUM(
                    IF(activity.activity_cost_type = 'percentage', 
                        (camp.budget*activity.activity_cost)/100, 
                        activity.activity_cost
                    ) 
                ) as camp_type_budget,
                GROUP_CONCAT(DISTINCT ctype.name) as ctype,
                SUM( " .
                    (($isSpecificCampSubType == 1) ? " IF(activity.cmp_subtype_id like '%" . $postedCampSubtypeID ."%' ," : "" ).
                        (($isSpecificCampType == 1) ? " IF (ctype.id = '" . $postedCampTypeID . "', " : "" ).
                            " IF(activity.activity_cost_type = 'percentage', (camp.budget * activity.activity_cost)/100, activity.activity_cost)" .
                        (($isSpecificCampType == 1) ? " , 0) " : "" ).
                    (($isSpecificCampSubType == 1) ? ", 0)" : "" ).
                ") as activity_spend 
                , camp.start_date 
                from campaigns camp 
                LEFT JOIN camp_activity activity on camp.id = activity.cmp_id 
                LEFT JOIN camp_subtype csubtype on activity.cmp_subtype_id = csubtype.id 
                LEFT JOIN camp_type ctype on csubtype.type_id = ctype.id 
                WHERE camp.campaign_subtype LIKE CONCAT('%',activity.cmp_subtype_id, '%')  AND
                 camp.deleted = 0 
                AND camp.budget IS NOT NULL" .
                (($isSpecificCampType == 1) ? " AND ctype.id = '".trim($postedCampTypeID)."'" : "" ).
                " AND camp.start_date BETWEEN '" . $sdate . "' AND '" . $edate . "' " .
                //" AND camp.end_date BETWEEN '" . $sdate . "' AND '" . $edate . "' " .
                " GROUP BY ". substr(trim($grpByCondition), 0, -1); 

            // $main_query = "Select camp.id, camp.start_date,
            //     GROUP_CONCAT(DISTINCT ctype.name) as ctype, 
            //     GROUP_CONCAT(DISTINCT csubtype.name) as csubtype_name,
            //     SUM(DISTINCTROW camp.budget) as camp_budget,
            //     camp.start_date,camp.end_date,
            //     SUM(IF(activity.activity_cost_type = 'percentage', (camp.budget*activity.activity_cost)/100, activity.activity_cost) ) as activity_spend 
            //     from campaigns camp
            //     LEFT JOIN camp_activity activity on camp.id = activity.cmp_id 
            //     LEFT JOIN camp_subtype csubtype on activity.cmp_subtype_id = csubtype.id 
            //     LEFT JOIN camp_type ctype on csubtype.type_id = ctype.id 
            //     WHERE camp.campaign_subtype LIKE CONCAT('%',activity.cmp_subtype_id, '%') 
            //     AND camp.deleted = 0 
            //     AND camp.budget IS NOT NULL ".
            //     " AND camp.start_date BETWEEN '" . $sdate . "' AND '" . $edate . "' " .
            //     " AND camp.end_date BETWEEN '" . $sdate . "' AND '" . $edate . "' " .
            //     ($postSubtype != 'all' ? " AND activity.cmp_subtype_id like '%".$postSubtype."%'" : '') .
            //     ($postCampType != 'all' ? " AND ctype.id like '%".$postCampType."%'" : '').
            //     " GROUP BY ". substr(trim($grpByCondition), 0, -1); 

            if ($_POST['report'] == 'y') {
                $_YearlyLoopCount = $this->datediff('yyyy', $sdate, $edate);
                    for ($i = 0; $i <= $_YearlyLoopCount; $i++) {
                        $_YearlyLoopC[] = date("Y", strtotime("+$i year", strtotime($sdate)));
                }
            }
                         
            if (!empty($main_query)) {
                $result = $GLOBALS['db']->query($main_query);
                while ($row = $GLOBALS['db']->fetchByAssoc($result)) { 
                    $row['data'] = '';
                   if ($_POST['report'] == 'y') { 
                        //$row['year'] = date('Y', strtotime($sdate)) .' to ' . date('Y', strtotime($edate));
                        $row['year'] = date('Y', strtotime($row['start_date']));
                        $report_data[$row['year']] = $row;
                    }
                    if ($_POST['report'] == 'q') {
						foreach ($quarterOptions as $key => $quarter) {
                            if ($row['start_date'] >= $quarter['sdate']
                                //Need to confirm from BA edate is required or not in quarter decision
                                && $row['start_date'] <= $quarter['edate']
                            ) {
                                $row['quater'] = $key;
                            }
                        }
                        //$row['quater'] = date("Y-m-d", strtotime($row['start_date']));
                        $report_data[$row['quater']] = $row;
                    }
                }
                if (!empty($_YearlyLoopC) && $_POST['report'] == 'y') {
                    foreach ($_YearlyLoopC as $yr_loop_c) {
                        if (is_array($report_data) && array_key_exists($yr_loop_c, $report_data)) {
                            $report_data[$yr_loop_c]['data'] = date("Y", strtotime($sdate));
                            $report_data_final[$yr_loop_c] = $report_data[$yr_loop_c];
                        } else {
                            $report_data[$yr_loop_c]['year'] = $yr_loop_c;
                            $report_data[$yr_loop_c]['data'] = 'N';
                            $report_data_final[$yr_loop_c] = $report_data[$yr_loop_c];
                        }
                    }
                }
				if (!empty($quarterOptions) && $_POST['report'] == 'q') {
                    foreach ($quarterOptions as $quter_key => $quater) {
                        if (is_array($report_data) && array_key_exists($quter_key, $report_data)) {
                            $report_data[$quter_key]['data'] = 'Y';
                            $report_data[$quter_key]['quater'] = $quater['name']." (".$quater['year'].')';
                            $report_data_final[$quater['sdate']] = $report_data[$quter_key];
                        } else {
                            $report_data[$yr_loop_c]['year'] = $quter_key;
                            $report_data[$quter_key]['data'] = 'N';
                            $report_data_final[$quater['sdate']] = $report_data[$quter_key];
                        }
                    }
                }
            }
            
            $this->view_object_map['report_data'] = $report_data_final;
            $this->view_object_map['ctype_name'] = $ctype_name;
            $this->view_object_map['csubtype_name'] = $subtype;

            // export functionality
            //echo '<pre>'; print_r($report_data_final); exit;
            $output = '';
            if (!empty($_POST['export'])) {
                $output .= '"Time Range",Campaign Type","Campaign SubType","Campaign Budget",Campaign Spend","Campaign Spend Contribution %"';

                $output .= "\n";

                foreach ($report_data as $k => $val) {
                    if ($_POST['report'] == 'y') {
                        $output .= $val['year'] . ',';
                    }
                    if ($_POST['report'] == 'q') {
                        $output .= $val['quater'] . ',';
                    }
                    if (!empty($val['data'])) {
                        //$output .= $this->view_object_map['ctype_name'] . ',';
                        $output .= $val['ctype'] . ',';
                        $output .= $val['csubtype_name'] . ',';
                        $output .= $val['camp_type_budget'] . ',';
                        $output .= $val['activity_spend'] . ',';
                        //$output .= ($val['activity_spend'] * 100) / $val['camp_budget'] . '%,';
                        $output .= $val['camp_type_budget'] > 0 ? 
                                    round($val['activity_spend'] / $val['camp_type_budget'],2) . '%,'
                                    : 0;
                    } else {
                        $output .= 'No Records found' . ',';
                        $output .= '' . ',';
                        $output .= '' . ',';
                        $output .= '' . ',';
                        $output .= '' . ',';
                        $output .= '' . ',';
                    }
                    $output .= "\n";
                }
                $filename = "spent_by_camptype_report." . $_POST['file_type'];
                header('Content-type: application/csv');
                header('Content-Disposition: attachment; filename=' . $filename);
                echo $output;
                exit;
            }
            // export functionality
        }
    }

    //Get the list of subtypes depending on the type provided
    public function action_getsubtype_report() 
    {
        global $app_list_strings;
        if (!empty($_POST['cid'])) {
            $specificSubTypes = $_POST['allowedSubtypes'];
            if ($specificSubTypes == 1) {
                $allowedsubtypes = '';
                foreach ($app_list_strings['allowedSubTypes'] as $key=>$val) {
                    $allowedsubtypes.= "'".$val."',";
                }    
            }
            
            $data_str = '';
            $sql = "SELECT id,name FROM `camp_subtype` where deleted=0 ".
            ($_POST['cid'] != 'all' ? " AND type_id = '" . $_POST['cid'] . "'" : "") .
            ($specificSubTypes == 1 ? " AND name IN(".substr($allowedsubtypes,0,-1). ")" : "");

            $result = $GLOBALS['db']->query($sql);
            //$data_str.="<option value='all' >All</option>";
            while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
                $data_str.="<option value='" . $row['id'] . "' >" . $row['name'] . "</option>";
            }
            echo $data_str;
            exit;
        }
    }
    
    // Report to understand Campaign Response Rate
    public function action_responserate() 
    {
        global $sugar_config, $app_list_strings;
        $this->view = 'responserate';

        //set Month Options for from and to dropdown for Monthly type report
        $this->view_object_map['createMonthdd'] = $this->createMonthdd();
        
        //array of allowed subtypes to be used with Reposnserate report
        $this->view_object_map['allowedSubTypes'] = $app_list_strings['allowedSubTypes'];
         

        //get campaign type
        $sql = "SELECT id,name FROM `camp_type` where deleted=0";
        $result = $GLOBALS['db']->query($sql);
        while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
            $cData[$row['id']] = $row['name'];
        }
        $responseTable = $sugar_config['url_response_table'];
        $this->view_object_map['Camp_Type'] = $cData;

        $current_date = date("Y-m-d");

         //set Quarer options for from and to dropdonwn for Yearly type 
        $edateOfQtr = date('Y-m-d', strtotime($current_date."-1 days"));
        $sdateOfQtr = date('Y-m-1', strtotime("-1 year", strtotime($edateOfQtr)));
        $this->view_object_map['quarterOptions'] = $this->getKenyanQuarters(
            $sdateOfQtr, $edateOfQtr
        );
        $quarterOptions = $this->view_object_map['quarterOptions'];
       
        // get campaign type
        if (!empty($_POST['campaign_type']) && !empty($_POST['campaign_subtype']) 
            && !empty($_POST['report']) && !empty($_POST['campaign_status']) 
            && !empty($_POST['campaign_id'])
        ) {
            //get campaign type
            $sql_ctype = "SELECT * FROM `camp_type` where deleted=0 AND id='" . $_POST['campaign_type'] . "'";
            $ctype_name = '';
            $result_ctype = $GLOBALS['db']->query($sql_ctype);
            while ($row_ctype = $GLOBALS['db']->fetchByAssoc($result_ctype)) {
                $ctype_name = $row_ctype['name'];
            }

            // get campaign type
            //get sub campaign type
            $sql_csubtype = "SELECT * FROM `camp_subtype` where deleted=0 AND id='" . $_POST['campaign_subtype'] . "'";
            $csubtype_name = '';
            $result_csubtype = $GLOBALS['db']->query($sql_csubtype);
            while ($row_csubtype = $GLOBALS['db']->fetchByAssoc($result_csubtype)) {
                $csubtype_name = $row_csubtype['name'];
            }

            $from = $_POST['from_date'];
            $to = $_POST['to_date'];
            $grpByCondition = '';
            $postedCampID = $_POST['campaign_id'];

            //Check is specific campaign selected or "All" campaign data required
            
            $isSpecificCampaign = 0;
            if (!empty($postedCampID) && $postedCampID != 'all' ) {
                $isSpecificCampaign = 1;
            }

            $grpByCondition .= (!empty($isSpecificCampaign) ?  "camp.id," : " ");
            if ($_POST['report'] == 'y') {
                if ($from != $to) {
                    $edate = date('Y-m-d', strtotime($current_date."-1 days"));
                    $sdate = date('Y-m-1', strtotime("-1 year"));
                } else {
                    $sdate = date('Y-m-d', strtotime("$from-01-01"));
                    $edate = date('Y-m-d', strtotime("$from-12-31"));
                }
                $grpByCondition .= 'year(camp.start_date),';
            }
            if ($_POST['report'] == 'm') {
                $sdate = date('Y-m-1', strtotime($from));
                $edate = date('Y-m-t', strtotime($to));
                $grpByCondition .= 'month(camp.start_date),';
            }
            if ($_POST['report'] == 'q') {
                $sdate = date('Y-m-d', strtotime($quarterOptions[$from]['sdate']));
                $edate = date('Y-m-d', strtotime($quarterOptions[$to]['edate']));
                $grpByCondition .= 'QUARTER(camp.start_date), year(camp.start_date),';
            }
            if ($_POST['report'] == 'd') {
               $sdate = date('Y-m-d', strtotime($from));
               $edate = date('Y-m-d', strtotime($to));
               $grpByCondition .= 'date(camp.start_date),';
            }
           
            if (in_array($_POST['report'] ,array('m', 'y','q', 'd'))) {
                $main_query = "SELECT camp.id, ctype.name as ctype,
                GROUP_CONCAT(DISTINCT camp.campaign_id_c) as campaign_id_c, 
                camp.content,camp.name, camp.campaign_subtype,
                camp.start_date,camp.end_date, target.campaign_id, 
                SUM(DISTINCTROW target.targeted_customers) as targeted_customers,
                count(responseTable.customer_id) AS responses 
                FROM `campaigns` as camp
                left join camp_targeted_customer as target on camp.id = target.campaign_id 
                left join " . $responseTable . " as responseTable on responseTable.campaign_id=camp.id 
                left join camp_type as ctype on camp.campaign_type = ctype.id
                where camp.deleted=0 AND camp.campaign_subtype like '%" . $_POST['campaign_subtype'] . "%' 
                AND camp.start_date BETWEEN '" . $sdate . "' AND '" . $edate . "' " .
                " AND camp.end_date BETWEEN '" . $sdate . "' AND '" . $edate . "' " .
                (($isSpecificCampaign == 1) ? " AND camp.id =  '$postedCampID' " : "") .
                " AND responseTable.subtype like '%" . $_POST['campaign_subtype'] . "%' ".              
                //" AND target.insterted_date BETWEEN '" . $sdate . "' AND '" . $edate . "'" .
                //" AND responseTable.inserted_date BETWEEN '" . $sdate . "' AND '" . $edate . "'".
                " GROUP BY ". substr($grpByCondition, 0, -1); // substr used to remove the last comma (,) in the string              exit;
            }

            if ($_POST['report'] == 'm') {
                $_MonthlyLoopCount = $this->datediff('m', $sdate, $edate);
                for ($i = 0; $i <= $_MonthlyLoopCount + 1; $i++) {
                    $_MonthlyLoopC[] = date("m-Y", strtotime("+ $i month", strtotime($_POST['from_date'])));
                }
            }
            if ($_POST['report'] == 'y') {
                $_YearlyLoopCount = $this->datediff('yyyy', $sdate, $edate);
                for ($i = 0; $i <= $_YearlyLoopCount; $i++) {
                    $_YearlyLoopC[] = date("Y", strtotime("+$i year", strtotime($sdate)));
                }
            }
            if ($_POST['report'] == 'd') {
                $_DailyLoopCount = $this->datediff('d', $sdate, $edate);
                for ($i = 0; $i <= $_DailyLoopCount; $i++) {
                    $_DailyLoopC[] = date("Y-m-d", strtotime("+$i day", strtotime($_POST['from_date'])));
                }
            }

            if (!empty($main_query)) {
                $result = $GLOBALS['db']->query($main_query);
                while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
                    $row['data'] = '';
                    if ($_POST['report'] == 'm') {
                        $row['month'] = date("m-Y", strtotime($row['start_date']));
                        $report_data[$row['month']] = $row;
                    }
                    if ($_POST['report'] == 'y') { 
                        //$row['year'] = date('Y', strtotime($sdate)) .' to ' . date('Y', strtotime($edate));
                        $row['year'] = date('Y', strtotime($row['start_date']));
                        $report_data[$row['year']] = $row;
                    }
                    if ($_POST['report'] == 'd') {
                        $row['day'] = date("Y-m-d", strtotime($row['start_date']));
                        $report_data[$row['day']] = $row;
                    }
                    if ($_POST['report'] == 'q') {
                        foreach ($quarterOptions as $key => $quarter) {
                            if ($row['start_date'] >= $quarter['sdate']
                                //Need to confirm from BA edate is required or not in quarter decision
                                && $row['start_date'] <= $quarter['edate']
                            ) {
                                $row['quater'] = $key;
                            }
                        }
                        //$row['quater'] = date("Y-m-d", strtotime($row['start_date']));
                        $report_data[$row['quater']] = $row;
                    }
                    if ($_POST['report'] == 'w') {
                        $row['week'] = date("Y-m-d", strtotime($row['start_date']));
                        $report_data[$row['week']] = $row;
                    }
                } 
               
                if (!empty($_MonthlyLoopC) && $_POST['report'] == 'm') {
                    foreach ($_MonthlyLoopC as $mon_loop_c) {
                        if (is_array($report_data) && array_key_exists($mon_loop_c, $report_data)) {
                            $report_data[$mon_loop_c]['month'] = date('M-Y',strtotime("1-$mon_loop_c"));
                            $report_data[$mon_loop_c]['data'] = 'Y';
                            $report_data_final[$mon_loop_c] = $report_data[$mon_loop_c];
                        } else {
                            $report_data[$mon_loop_c]['month'] = date('M-Y',strtotime("1-$mon_loop_c"));
                            $report_data[$mon_loop_c]['data'] = 'N';
                            $report_data_final[$mon_loop_c] = $report_data[$mon_loop_c];
                        }
                    }
                } 
                if (!empty($_YearlyLoopC) && $_POST['report'] == 'y') {
                    foreach ($_YearlyLoopC as $yr_loop_c) {
                        if (is_array($report_data) && array_key_exists($yr_loop_c, $report_data)) {
                            $report_data[$yr_loop_c]['data'] = 'Y';
                            $report_data_final[$yr_loop_c] = $report_data[$yr_loop_c];
                        } else {
                            $report_data[$yr_loop_c]['year'] = $yr_loop_c;
                            $report_data[$yr_loop_c]['data'] = 'N';
                            $report_data_final[$yr_loop_c] = $report_data[$yr_loop_c];
                        }
                    }
                }
                if (!empty($_DailyLoopC) && $_POST['report'] == 'd') {
                    foreach ($_DailyLoopC as $daily_loop_c) {
                        if (is_array($report_data) && array_key_exists($daily_loop_c, $report_data)) {
                            $report_data[$daily_loop_c]['data'] = 'Y';
                            $report_data_final[$daily_loop_c] = $report_data[$daily_loop_c];
                        } else {
                            $report_data[$daily_loop_c]['day'] = $daily_loop_c;
                            $report_data[$daily_loop_c]['data'] = 'N';
                            $report_data_final[$daily_loop_c] = $report_data[$daily_loop_c];
                        }
                    }
                }
                if (!empty($quarterOptions) && $_POST['report'] == 'q') {
                    foreach ($quarterOptions as $quter_key => $quater) {
                        if (is_array($report_data) && array_key_exists($quter_key, $report_data)) {
                            $report_data[$quter_key]['data'] = 'Y';
                            $report_data[$quter_key]['quater'] = $quater['name']." (".$quater['year'].')';
                            $report_data_final[$quater['sdate']] = $report_data[$quter_key];
                        } else {
                            $report_data[$yr_loop_c]['year'] = $quter_key;
                            $report_data[$quter_key]['data'] = 'N';
                            $report_data_final[$quater['sdate']] = $report_data[$quter_key];
                        }
                    }
                }
            }
            
            $this->view_object_map['report_data'] = $report_data_final;
            $this->view_object_map['ctype_name'] = $ctype_name;
            $this->view_object_map['csubtype_name'] = $csubtype_name;

            // export functionality         
            $output = '';
            if (!empty($_POST['export'])) {
                $output .= '"Time Range","Campaign Type","Campaign SubType","Campaign ID","Campaign Description","Targeted Customers","Responses","Response Rate"';
                $output .= "\n";

                foreach ($report_data_final as $k => $val) {
                    if ($_POST['report'] == 'm') {
                        $output .= $val['month'] . ',';
                    }
                    if ($_POST['report'] == 'y') {
                        $output .= $val['year'] . ',';
                    }
                    if ($_POST['report'] == 'd') {
                        $output .= $val['day'] . ',';
                    }
                    if ($_POST['report'] == 'q') {
                        $output .= $val['quater'] . ',';
                    }
                    if ($val['data'] == 'Y') {
                        $output .= $this->view_object_map['ctype_name'] . ',';
                        $output .= $this->view_object_map['csubtype_name'] . ',';
                        $output .= $val['campaign_id_c'] . ',';
                        $output .= $val['content'] . ',';
                        $output .= $val['targeted_customers'] . ',';
                        $output .= $val['responses'] . ',';
                        //$output .= round((100 * $val['responses']) / $val['targeted_customers'],2) . '%,';
                        $output .= round($val['responses'] / $val['targeted_customers'],2) . '%,';
                    } else {

                        $output .= 'No Records found' . ',';
                        $output .= '' . ',';
                        $output .= '' . ',';
                        $output .= '' . ',';
                        $output .= '' . ',';
                        $output .= '' . ',';
                        $output .= '' . ',';
                    }
                    $output .= "\n";
                }

                $filename = "campaign_responserate_report." . $_POST['file_type'];
                header('Content-type: application/csv');
                header('Content-Disposition: attachment; filename=' . $filename);
                echo $output;
                exit;
            }
            // export functionality 
        }
    }

    public function datediff($interval, $datefrom, $dateto, $using_timestamps = false) {
        /*
          $interval can be:
          yyyy - Number of full years
          q - Number of full quarters
          m - Number of full months
          y - Difference between day numbers
          (eg 1st Jan 2004 is "1", the first day. 2nd Feb 2003 is "33". The datediff is "-32".)
          d - Number of full days
          w - Number of full weekdays
          ww - Number of full weeks
          h - Number of full hours
          n - Number of full minutes
          s - Number of full seconds (default)
         */

        if (!$using_timestamps) {
            $datefrom = strtotime($datefrom, 0);
            $dateto = strtotime($dateto, 0);
        }
        $difference = $dateto - $datefrom; // Difference in seconds

        switch ($interval) {

            case 'yyyy': // Number of full years

                $years_difference = floor($difference / 31536000);
                if (mktime(date("H", $datefrom), date("i", $datefrom), date("s", $datefrom), date("n", $datefrom), date("j", $datefrom), date("Y", $datefrom) + $years_difference) > $dateto) {
                    $years_difference--;
                }
                if (mktime(date("H", $dateto), date("i", $dateto), date("s", $dateto), date("n", $dateto), date("j", $dateto), date("Y", $dateto) - ($years_difference + 1)) > $datefrom) {
                    $years_difference++;
                }
                $datediff = $years_difference;
                break;

            case "q": // Number of full quarters

                $quarters_difference = floor($difference / 8035200);
                while (mktime(date("H", $datefrom), date("i", $datefrom), date("s", $datefrom), date("n", $datefrom) + ($quarters_difference * 3), date("j", $dateto), date("Y", $datefrom)) < $dateto) {
                    $months_difference++;
                }
                $quarters_difference--;
                $datediff = $quarters_difference;
                break;

            case "m": // Number of full months

                $months_difference = floor($difference / 2678400);
                while (mktime(date("H", $datefrom), date("i", $datefrom), date("s", $datefrom), date("n", $datefrom) + ($months_difference), date("j", $dateto), date("Y", $datefrom)) < $dateto) {
                    $months_difference++;
                }
                $months_difference--;
                $datediff = $months_difference;
                break;

            case 'y': // Difference between day numbers

                $datediff = date("z", $dateto) - date("z", $datefrom);
                break;

            case "d": // Number of full days

                $datediff = floor($difference / 86400);
                break;

            case "w": // Number of full weekdays

                $days_difference = floor($difference / 86400);
                $weeks_difference = floor($days_difference / 7); // Complete weeks
                $first_day = date("w", $datefrom);
                $days_remainder = floor($days_difference % 7);
                $odd_days = $first_day + $days_remainder; // Do we have a Saturday or Sunday in the remainder?
                if ($odd_days > 7) { // Sunday
                    $days_remainder--;
                }
                if ($odd_days > 6) { // Saturday
                    $days_remainder--;
                }
                $datediff = ($weeks_difference * 5) + $days_remainder;
                break;

            case "ww": // Number of full weeks

                $datediff = floor($difference / 604800);
                break;




            default: // Number of full seconds (default)

                $datediff = $difference;
                break;
        }

        return $datediff;
    }

    public function getQuarters($start, $end) {

        $StartDate = DateTime::createFromFormat('m-d-Y', $start);
        $EndDate = DateTime::createFromFormat('m-d-Y', $end);

        $quarters = new DatePeriod($StartDate, new DateInterval('P3M'), $EndDate);

        $p = 0;
        $r = [];
        foreach ($quarters as $quarter) {
            if (!$p) {
                $q = [$quarter];
                $p++;
            } else {
                $q[] = $quarter;
                $p = 0;
                $r[] = $q;
            }
        }
        if (count($r) > 0):
            return $r;
        else:
            return 'no-quarters';
        endif;
    }

    public function checkReportPeriodQuarter($subtype = null, $sdate, $edate, $getquarters = null) {
        global $db, $app_list_strings, $sugar_config;
        $_Yrow = array();


        $query_query_Y = "SELECT campaigns.id,campaigns.content,campaigns.campaign_subtype,campaigns.start_date,campaigns.end_date, camp_targeted_customer.campaign_id,sum(targeted_customers) AS targated_customers, count(" . $sugar_config['url_response_table'] . ".customer_id) AS responses 
				FROM `campaigns` 
				left join camp_targeted_customer on campaigns.id = camp_targeted_customer.campaign_id 
				left join " . $sugar_config['url_response_table'] . " on " . $sugar_config['url_response_table'] . ".campaign_id=campaigns.id where campaigns.deleted=0 AND campaign_subtype like '%" . $subtype . "%' 
				AND campaigns.start_date BETWEEN '" . $sdate . "' AND '" . $edate . "' AND campaigns.end_date BETWEEN '" . $sdate . "' AND '" . $edate . "' 
				AND camp_targeted_customer.insterted_date BETWEEN '" . $sdate . "' AND '" . $edate . "' 
				AND " . $sugar_config['url_response_table'] . ".inserted_date BETWEEN '" . $sdate . "' AND '" . $edate . "' GROUP BY QUARTER(campaigns.start_date)";
        $resultY = $db->query($query_query_Y);

        if (!empty($resultY)) {
            foreach ($resultY as $resulty) {
                $_Yrow[] = $resulty;
            }
        }
        //	return $_Yrow;
        //echo '<pre>';
        //	print_r($_Yrow); 
        /* exit;
          if(isset($getquarters)):
          return array_sum($_Yrow);
          else:
          return array_sum($_Yrow);
          endif; */
    }
    
    /**
     * This method gives time period
     */
    public function getTimePeriod() {
        return [
            "" => "Select",
            "daily" => "Daily",
            "weekly" => "Weekly",
            "monthly" => "Monthly",
            "quarterly" => "Quarterly",
            "annual" => "Annual",
        ];
    }

    /**
     * Below ation to generate 
     */
    public function action_liftReport() {
        $this->view_object_map['checloutput'] = "Test";
        $this->view = 'liftreport';
        $this->view_object_map['getTimePeriod'] = $this->getTimePeriod();
        //get campaign type
        $sql = "SELECT id,name FROM `camp_type` where deleted=0";
        $result = $GLOBALS['db']->query($sql);
        while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
            $cData[$row['id']] = $row['name'];
        }
        $this->view_object_map['Camp_Type'] = $cData;
    }

    //Get campaign options by status
    public function action_getcampaignsByStatus() 
    {
        $data_str = 'black';
        if (!empty($_POST['status'])) {
            $data_str = '';
            if ($_POST['status'] != 'all') { 
                if ($_POST['status'] == 'active') {
                    //condition for active campaigns
                    $camapignDurationCondition = " AND start_date <='".date('Y-m-d')."' AND end_date >='".date('Y-m-d')."'";
                } else {
                    //condition for ended campaigns
                    $camapignDurationCondition = " AND end_date <'".date('Y-m-d')."'";
                }
            }
            $sql = "SELECT id,name FROM `campaigns` where deleted=0 " .
            (!empty($camapignDurationCondition) ? $camapignDurationCondition : '');
            if (!empty($_POST['selectedCampSubtype'])) {
                $sql.= " AND campaign_subtype like '%".$_POST['selectedCampSubtype']. "%'";
            }
            $result = $GLOBALS['db']->query($sql);
            
            $data_str.='<option value="">Select</option>';
            if (mysqli_num_rows($result) > 0) {
                $data_str.='<option value="all" '.
                ((!empty($_POST["selectedCamp"]) && $_POST["selectedCamp"] == 'all') ? " selected" : "") .
                ' >All</option>';
                while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
                    $data_str.="<option value='" . $row['id'] . "'" . ((!empty($_POST['selectedCamp']) && $_POST['selectedCamp'] == $row['id']) ? ' selected' : '') . ">" . $row['name'] . "</option>";
                }    
            }
        }
        echo $data_str;
        exit;
    }

    public function createMonthdd()
    {
        /*month logic start */
        $_curdate = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d")))); // first get current date-1
        $_Month = date("m", strtotime("- 12 month",strtotime($_curdate))); // last 12 month 
        $_Year = date("Y", strtotime("- 12 month",strtotime($_curdate))); // last 12 month(Year) 
        $start_date = $_Year."-".$_Month."-"."1"; //start date
        $end_date = date("Y-m-d", strtotime("- 1 days",strtotime(date("Y-m-d")))); // first get current date-1 @current date
        $_MonthLoopCount = $this->datediff('m',date("y-m-d",strtotime($start_date )),date("y-m-d",strtotime($end_date))); 

        /*end logic start */
        for($i=0;$i<=$_MonthLoopCount+1;$i++)
        {
            $_DailyLoopC[date ("M-Y", strtotime("+ $i month", strtotime($start_date)))] = date ("M-Y", strtotime("+ $i month", strtotime($start_date)));
        }
        return $_DailyLoopC;
    }

    /*
    *Below function return array of quarter details between a period provided
    * Kenya Q1 - 1 July - 30 Sep
    * Kenya Q2 - 1 Oct  - 31 Dec
    * Kenya Q3 - 1 Jan  - 31 Mar
    * Kenya Q4 - 1 Apr  - 30 June
    */
    public function getKenyanQuarters($sdate, $edate) 
    {
        //$current_date = date("Y-m-d");
        //$edate = date('Y-m-d', strtotime($current_date."-1 days"));
        //$sdate = date('Y-m-1', strtotime("-1 year", strtotime($edate)));
        $quarters = array();
        $month = date('m', strtotime($sdate));

        if( $month >=1 &&  $month <= 3){
            $sdate =  date('Y-01-1', strtotime($sdate));
        } elseif($month >= 4 && $month <= 6){
            $sdate =  date('Y-04-1', strtotime($sdate));
        } elseif($month >= 7 && $month <= 9){
            $sdate =  date('Y-07-1', strtotime($sdate));
        } elseif($month >= 10 && $month <= 12){
            $sdate =  date('Y-10-1', strtotime($sdate));
        }

        for($i=1;    $i <= 5;   $i++) {
             $monthCount = date('m', strtotime($sdate));
             $year = date('Y', strtotime($sdate));
             if( $monthCount >=1 &&  $monthCount <= 3){
                $x = 'q3'. ($year-1) .'-' . $year;
                $quarters[$x]['name'] = 'Q3';
                $quarters[$x]['year'] =  $year-1 .' - ' . $year;
                $quarters[$x]['sdate'] =  $sdate;
                $quarters[$x]['edate'] =  date('Y-m-t', strtotime("+2 months", strtotime($sdate)));
             } elseif($monthCount >= 4 && $monthCount <= 6) {
                $x = 'q4'. ($year-1) .'-' . $year;
                $quarters[$x]['name'] = 'Q4';
                $quarters[$x]['year'] =  $year-1 .' - ' . $year;
                $quarters[$x]['sdate'] =  $sdate;
                $quarters[$x]['edate'] =  date('Y-m-t', strtotime("+2 months", strtotime($sdate)));
             } elseif($monthCount >= 7 && $monthCount <= 9){
                $x = 'q1'. $year .'-' . ($year+1);
                $quarters[$x]['name'] = 'Q1';
                $quarters[$x]['year'] =  $year .' - ' . ($year+1);
                $quarters[$x]['sdate'] =  $sdate;
                $quarters[$x]['edate'] =  date('Y-m-t', strtotime("+2 months", strtotime($sdate)));
             } elseif($monthCount >= 10 && $monthCount <= 12){
                $x = 'q2'. $year.'-' .($year+1);
                $label = 
                $quarters[$x]['name'] = 'Q2';
                $quarters[$x]['year'] =  $year .' - ' . ($year+1);
                $quarters[$x]['sdate'] =  $sdate;
                $quarters[$x]['edate'] =  date('Y-m-t', strtotime("+2 months", strtotime($sdate)));
             }
             $sdate = date('Y-m-d', strtotime( "+3 months", strtotime($sdate)));
        }
        return $quarters;
    }
	
	function action_loginCURL() {
        $ss = array('dd'=>'ss');
		echo $camp_data = json_encode($ss);
		exit;
    }
	
	public function callBulkSMS($cid) {
		$messages = array("campId" => $cid);
		$data = json_encode($messages);
        $curl = curl_init(); 
		curl_setopt_array($curl, array(
		  CURLOPT_URL => "https://crmuat.nakumatt.net/nakumattsugCRM6524/cronscript_activity_sms.php",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "POST",
		  CURLOPT_POSTFIELDS => $data,
		  CURLOPT_SSL_VERIFYHOST => 0,
		  CURLOPT_SSL_VERIFYPEER => 0,
		  CURLOPT_HTTPHEADER => array(
			"content-type: application/json"
		  ),
		));
		
	curl_exec($curl);
    }
}
