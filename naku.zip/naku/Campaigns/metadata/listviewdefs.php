<?php
if (!defined('sugarEntry') || !sugarEntry)
    die('Not A Valid Entry Point');
/* * *******************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 * ****************************************************************************** */

global $theme, $mod_strings, $sugar_config, $current_user;
//start Roles and Permission Hacks by Akhilesh
require_once('custom/include/rolehack.php');
$uid = $current_user->id; //Logged in User ID
$category = "Campaigns"; //Module name
$type = "module"; //Nochnage
$rootAction = "campaign"; //Root or Parent Action name according to magento Root action

$subActionEdit = "edit"; //Edit ICON
$editIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionEdit, $type);

$subActionClone = "clone"; //Clone ICON
$cloneIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionClone, $type);

$subActionView = "view"; //View ICON
$viewIcon = RoleHack::getCustomRole($uid, $category, $rootAction, $subActionView, $type);

$adminRole = $current_user->isAdmin();
//end Roles and Permission Hacks by Akhilesh
if(($editIcon === true && $cloneIcon === true && $viewIcon === true) || ($adminRole == 1)){
    $listViewDefs['Campaigns'] = array(
        'CAMPAIGN_ID_C' => array(
            'width' => '20',
            'label' => 'Campaign ID',
            'default' => true),
        'NAME' => array(
            'width' => '20',
            'label' => 'Campaign Name',
            'link' => true,
            'default' => true),
        'STATUS' => array(
            'width' => '10',
            'label' => 'LBL_LIST_STATUS',
            'default' => true),
        'responce_rate_c' => array(
            'width' => '2',
            'label' => 'LBL_RESPONSE_RATE',
            'sortable' => false,
            'default' => true),
        'DATE_ENTERED' => array(
            'width' => '10',
            'label' => 'LBL_DATE_ENTERED',
            'default' => true),
        'CREATED_BY_NAME' =>
        array(
            'width' => '10%',
            'label' => 'LBL_CREATED',
            'default' => true,
            'link' => false,
        ),
        'CAMPAIGN_TYPE' => array(
            'width' => '10',
            'label' => 'LBL_LIST_TYPE',
            'default' => true),
        'CAMPAIGN_SUBTYPE' => array(
            'width' => '10',
            'label' => 'LBL_SUB_TYPE',
            'default' => true),
        'update_c' => array(
            'width' => '2',
            'label' => 'Edit',
            'link' => true,
            'sortable' => false,
            'default' => true),
          'clone_c' => array(
            'width' => '2',
            'label' => 'Clone',
            'link' => true,
            'sortable' => false,
            'default' => true),
    );
}else{
    if ($editIcon === true) {

        $listViewDefs['Campaigns'] = array(
            'CAMPAIGN_ID_C' => array(
                'width' => '20',
                'label' => 'Campaign ID',
                'default' => true),
            'NAME' => array(
                'width' => '20',
                'label' => 'Campaign Name',
                'link' => true,
                'default' => true),
            'STATUS' => array(
                'width' => '10',
                'label' => 'LBL_LIST_STATUS',
                'default' => true),
            'responce_rate_c' => array(
                'width' => '2',
                'label' => 'LBL_RESPONSE_RATE',
                'sortable' => false,
                'default' => true),
            'DATE_ENTERED' => array(
                'width' => '10',
                'label' => 'LBL_DATE_ENTERED',
                'default' => true),
            'CREATED_BY_NAME' =>
            array(
                'width' => '10%',
                'label' => 'LBL_CREATED',
                'default' => true,
                'link' => false,
            ),
            'CAMPAIGN_TYPE' => array(
                'width' => '10',
                'label' => 'LBL_LIST_TYPE',
                'default' => true),
            'CAMPAIGN_SUBTYPE' => array(
                'width' => '10',
                'label' => 'LBL_SUB_TYPE',
                'default' => true),
            'update_c' => array(
                'width' => '2',
                'label' => 'Edit',
                'link' => true,
                'sortable' => false,
                'default' => true),
        );
    }elseif ($cloneIcon === true) {
       
        $listViewDefs['Campaigns'] = array(
        'CAMPAIGN_ID_C' => array(
            'width' => '20',
            'label' => 'Campaign ID',
            'default' => true),
        'NAME' => array(
            'width' => '20',
            'label' => 'Campaign Name',
            'link' => true,
            'default' => true),
        'STATUS' => array(
            'width' => '10',
            'label' => 'LBL_LIST_STATUS',
            'default' => true),
        'responce_rate_c' => array(
            'width' => '2',
            'label' => 'LBL_RESPONSE_RATE',
            'sortable' => false,
            'default' => true),
        'DATE_ENTERED' => array(
            'width' => '10',
            'label' => 'LBL_DATE_ENTERED',
            'default' => true),
        'CREATED_BY_NAME' =>
        array(
            'width' => '10%',
            'label' => 'LBL_CREATED',
            'default' => true,
            'link' => false,
        ),
        'CAMPAIGN_TYPE' => array(
            'width' => '10',
            'label' => 'LBL_LIST_TYPE',
            'default' => true),
        'CAMPAIGN_SUBTYPE' => array(
            'width' => '10',
            'label' => 'LBL_SUB_TYPE',
            'default' => true),
        'clone_c' => array(
            'width' => '2',
            'label' => 'Clone',
            'link' => true,
            'sortable' => false,
            'default' => true),
        );
    }elseif ($viewIcon === true) {
        $listViewDefs['Campaigns'] = array(
        'CAMPAIGN_ID_C' => array(
            'width' => '20',
            'label' => 'Campaign ID',
            'default' => true),
        'NAME' => array(
            'width' => '20',
            'label' => 'Campaign Name',
            'link' => true,
            'default' => true),
        'STATUS' => array(
            'width' => '10',
            'label' => 'LBL_LIST_STATUS',
            'default' => true),
        'responce_rate_c' => array(
            'width' => '2',
            'label' => 'LBL_RESPONSE_RATE',
            'sortable' => false,
            'default' => true),
        'DATE_ENTERED' => array(
            'width' => '10',
            'label' => 'LBL_DATE_ENTERED',
            'default' => true),
        'CREATED_BY_NAME' =>
        array(
            'width' => '10%',
            'label' => 'LBL_CREATED',
            'default' => true,
            'link' => false,
        ),
        'CAMPAIGN_TYPE' => array(
            'width' => '10',
            'label' => 'LBL_LIST_TYPE',
            'default' => true),
        'CAMPAIGN_SUBTYPE' => array(
            'width' => '10',
            'label' => 'LBL_SUB_TYPE',
            'default' => true),
    );
    }else {
        $listViewDefs['Campaigns'] = array(
        'CAMPAIGN_ID_C' => array(
            'width' => '20',
            'label' => 'Campaign ID',
            'default' => true),
        'NAME' => array(
            'width' => '20',
            'label' => 'Campaign Name',
            'link' => false,
            'default' => true),
        'STATUS' => array(
            'width' => '10',
            'label' => 'LBL_LIST_STATUS',
            'default' => true),
        'responce_rate_c' => array(
            'width' => '2',
            'label' => 'LBL_RESPONSE_RATE',
            'sortable' => false,
            'default' => true),
        'DATE_ENTERED' => array(
            'width' => '10',
            'label' => 'LBL_DATE_ENTERED',
            'default' => true),
        'CREATED_BY_NAME' =>
        array(
            'width' => '10%',
            'label' => 'LBL_CREATED',
            'default' => true,
            'link' => false,
        ),
        'CAMPAIGN_TYPE' => array(
            'width' => '10',
            'label' => 'LBL_LIST_TYPE',
            'default' => true),
        'CAMPAIGN_SUBTYPE' => array(
            'width' => '10',
            'label' => 'LBL_SUB_TYPE',
            'default' => true),
        );
    }
}
?>
<script type="text/javascript">
    function updateActiveStatusCampaign() {

        var url_data = '<?php echo $sugar_config['site_url']; ?>';

        var checkValues = $('input[name=mass[]]:checked').map(function () {
            return $(this).val();
        }).get();

        $('#loading_image').show();
        $.ajax({
            url: url_data + '/index.php?module=Campaigns&action=updateActiveCampaign',
            data: {cid: checkValues},
            type: 'post',
            success: function (output) {
                if (output == true) {
                    //alert(output);
                    $('#loading_image').hide();
                    alert('Campaign status has been changed successfully');
                    window.location.reload();
                }
            }
        });

    }
    function updateInActiveStatusCampaign() {
        var url_data = '<?php echo $sugar_config['site_url']; ?>';

        var checkValues = $('input[name=mass[]]:checked').map(function () {
            return $(this).val();
        }).get();


        $.ajax({
            url: url_data + '/index.php?module=Campaigns&action=updateInActiveCampaign',
            data: {cid: checkValues},
            type: 'post',
            success: function (output) {
                if (output == 1) {
                    alert('Campaign status has been changed successfully');
                    window.location.reload();
                }
            }
        });
    }
</script>