<?php
error_reporting(0);
/* * *******************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 * ****************************************************************************** */

$sql = "SELECT id,name FROM `camp_type` where deleted=0";
$result = $GLOBALS['db']->query($sql);
$cData = array();
while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
    $cData[$row['id']] = $row['name'];
}
$cData_subtype[] = 'Select';
global $sugar_config;

$searchdefs['Campaigns'] = array(
    'templateMeta' => array(
        'maxColumns' => '3',
        'maxColumnsBasic' => '4',
        'widths' => array('label' => '10', 'field' => '30'),
    ),
    'layout' => array(
        'basic_search' => array(
            'name',
            array('name' => 'current_user_only', 'label' => 'LBL_CURRENT_USER_FILTER', 'type' => 'bool'),
        ),
        'advanced_search' => array(
            array('name' => 'start_date', 'type' => 'date', 'displayParams' => array('showFormats' => true)),
            array('name' => 'campaign_id_c', 'type' => 'varchar', 'label' => 'LBL_CAMPAIGN_ID_C'),
            array('name' => 'campaign_type', 'options' => $cData),
            array('name' => 'end_date', 'type' => 'date', 'displayParams' => array('showFormats' => true)),
            'name',
            'campaign_subtype_advanced' => array(
                'name' => 'campaign_subtype',
                'width' => '10',
                'label' => 'LBL_SUB_TYPE',
                'type' => 'enum',
                'options' => $cData_subtype),
            'status',
        ),
    ),
);
?>
<script type="text/javascript">
    $(document).ready(function () {
        $("#campaign_type_advanced").click(function () {
            var url_data = '<?php echo $sugar_config['site_url']; ?>';

            $.ajax({
                url: url_data + '/index.php?module=Campaigns&action=getsubtype',
                data: {cid: $('select#campaign_type_advanced').val()},
                type: 'post',
                success: function (output) {
                    $('#campaign_subtype_advanced').html(output);
                }
            });
        });
    });
</script>