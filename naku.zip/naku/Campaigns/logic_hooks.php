<?php
// Do not store anything in this file that is not part of the array or the hook version.  This file will	
// be automatically rebuilt in the future. 
 $hook_version = 1; 
$hook_array = Array(); 
// position, file, function 
$hook_array['process_record'] = Array(); 
$hook_array['process_record'][] = Array(1, 'Clone', 'custom/modules/Campaigns/logic_hook/clone.php','clone_campaign', 'clone_camp'); 
$hook_array['process_record'][] = Array(1, 'Type', 'custom/modules/Campaigns/logic_hook/type.php','campaign_type', 'camp_type'); 
$hook_array['process_record'][] = Array(1, 'Sub-Type', 'custom/modules/Campaigns/logic_hook/subtype.php','campaign_subtype', 'camp_subtype'); 
$hook_array['process_record'][] = Array(1, 'Update', 'custom/modules/Campaigns/logic_hook/update.php','campaign_update', 'camp_update'); 






?>