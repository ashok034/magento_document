//Campaign Start Date
Calendar.setup ({
    inputField : "start_date",
    ifFormat : "%m/%d/%Y %I:%M%P",
    daFormat : "%m/%d/%Y %I:%M%P",
    button : "start_date_trigger",
    singleClick : true,
    dateStr : "",
    startWeekday: 0,
    step : 1,
    weekNumbers:false,
    customMinDate : new Date()
});
//Campaign End Date
Calendar.setup ({
   inputField : "end_date",
   ifFormat : "%m/%d/%Y %I:%M%P",
   daFormat : "%m/%d/%Y %I:%M%P",
   button : "end_date_trigger",
   singleClick : true,
   dateStr : "",
   startWeekday: 0,
   step : 1,
   weekNumbers:false,
   customMinDate : new Date()
});

function getSuppliersList(id=''){
    open_popup('naku_Suppliers',600,400,'',true,false,{"call_back_function":"set_return","form_name":"EditViewFinancial","field_to_name_array":{"id":"get_supplier_id"+id,"name":"supplier_id"+id}},'single',true);
}
function getPromotionsList(id=''){
    open_popup('naku_Promotions',600,400,'',true,false,{"call_back_function":"set_return","form_name":"EditViewSubtype","field_to_name_array":{"id":"get_promotion_id_"+id,"name":"promotion_id_"+id}},'single',true);
}
function getCouponsList(id=''){
    open_popup('naku_Coupons',600,400,'',true,false,{"call_back_function":"set_return","form_name":"EditViewSubtype","field_to_name_array":{"id":"get_coupon_id_"+id,"name":"coupon_id_"+id}},'single',true);
}
function getTrigPromotionsList(id=''){
    open_popup('naku_Promotions',600,400,'',true,false,{"call_back_function":"set_return","form_name":"EditViewTrigger","field_to_name_array":{"id":"get_promotion_id_trig"+id,"name":"promotion_id_trig"+id}},'single',true);
}
function getTrigCouponsList(id=''){
    open_popup('naku_Coupons',600,400,'',true,false,{"call_back_function":"set_return","form_name":"EditViewTrigger","field_to_name_array":{"id":"get_coupon_id_trig"+id,"name":"coupon_id_trig"+id}},'single',true);
}
function getProductsList1(id=''){
    open_popup('naku_ProductPortfolio',600,400,'',true,false,{"call_back_function":"set_return","form_name":"EditViewTrigger","field_to_name_array":{"id":"get_product_id"+id,"product_portfolio_id":"trig_link_product"+id}},'single',true);
}
function getProductsList(id='',trig=''){//working 
    //alert('id='+id);alert('trig='+trig);
    window.open($('#siteurl').val()+'/index.php?module=Campaigns&action=ListProductPortfolio&mkid='+id+'&trig='+trig, '_blank', 'width=600, height=400', 'toolbar=0,location=0,menubar=0');
}
function getDatePromotionsList(id=''){
    open_popup('naku_Promotions',600,400,'',true,false,{"call_back_function":"set_return","form_name":"EditViewDate","field_to_name_array":{"id":"get_promotion_id_date"+id,"name":"promotion_id_date"+id}},'single',true);
}
function getDateCouponsList(id=''){
    open_popup('naku_Coupons',600,400,'',true,false,{"call_back_function":"set_return","form_name":"EditViewDate","field_to_name_array":{"id":"get_coupon_id_date"+id,"name":"coupon_id_date"+id}},'single',true);
}
function getActivityPromotionsList(id=''){
    open_popup('naku_Promotions',600,400,'',true,false,{"call_back_function":"set_return","form_name":"EditViewActivity","field_to_name_array":{"id":"get_promotion_id_activi"+id,"name":"promotion_id_activi"+id}},'single',true);
}
function getActivityCouponsList(id=''){
    open_popup('naku_Coupons',600,400,'',true,false,{"call_back_function":"set_return","form_name":"EditViewActivity","field_to_name_array":{"id":"get_coupon_id_activi"+id,"name":"coupon_id_activi"+id}},'single',true);
}
function getTemplatesList(formname){
    var subtype_name  = $(".nameval").val().toLowerCase();
    open_popup('EmailTemplates',600,400,'&type_advanced='+subtype_name,true,false,{"call_back_function":"set_return","form_name":formname,"field_to_name_array":{"id":"get_template_id","name":"template_id"}},'single',true);
}
function getAssetList(){
    open_popup('Asset_Assets',600,400,'',true,false,{"call_back_function":"set_return","form_name":"EditViewSubtype","field_to_name_array":{"id":"get_asset_list_id","name":"website_event_asset_list"}},'single',true);
}
function getAssetDetail(){
    open_popup('Asset_Assets',600,400,'',true,false,{"call_back_function":"set_return","form_name":"EditViewSubtype","field_to_name_array":{"id":"get_asset_detail_id","name":"website_event_asset_detail"}},'single',true);
}
function getwebsiteAssetDetail(id=''){
    open_popup('Asset_Assets',600,400,'',true,false,{"call_back_function":"set_return","form_name":"EditViewSubtype","field_to_name_array":{"id":"get_websiteasset_detail_id_"+id,"name":"website_asset_detail_"+id}},'single',true);
}
function getMarketingList(id='',trig='',flag=''){
    window.open($('#siteurl').val()+'/index.php?module=Campaigns&action=MarketView&mkid='+id+'&trig='+trig+'&flag='+flag, '_blank', 'width=600, height=400', 'toolbar=0,location=0,menubar=0');
}
function getMainTemplatesList(id='',subtype_name=''){
    open_popup('EmailTemplates',600,400,'&type_advanced='+subtype_name,true,false,{"call_back_function":"set_return","form_name":"EditViewSubtype","field_to_name_array":{"id":"main_get_template_id_"+id,"name":"main_template_id_"+id}},'single',true);
}
function getNormalActivityPromotionsList(id=''){
    open_popup('naku_Promotions',600,400,'',true,false,{"call_back_function":"set_return","form_name":"EditViewNormalActivity","field_to_name_array":{"id":"get_promotion_id_normal_acti"+id,"name":"promotion_id_normal_acti"+id}},'single',true);
}
function getNormalActivityCouponsList(id=''){
    open_popup('naku_Coupons',600,400,'',true,false,{"call_back_function":"set_return","form_name":"EditViewNormalActivity","field_to_name_array":{"id":"get_coupon_id_normal_acti"+id,"name":"coupon_id_normal_acti"+id}},'single',true);
}
function getTemplatesListNormalActivity(formname){
    var subtype_name  = $(".nameval").val().toLowerCase();
    open_popup('EmailTemplates',600,400,'&type_advanced='+subtype_name,true,false,{"call_back_function":"set_return","form_name":formname,"field_to_name_array":{"id":"get_normal_activty_template_id","name":"normal_activty_template_id"}},'single',true);
}
$(document).ready(function() { 

	// subtype checking
	var r_sms=$(".radio_SMS").attr("name");
	var r_sms_val=$('input[name='+ r_sms +']:checked').val();
	if(r_sms_val)
	{
		$(".radio_SMS").attr('disabled', 'disabled');
	}	
	// subtype checking

	// subtype checking
	var r_email=$(".radio_Email").attr("name");
	var r_email_val=$('input[name='+ r_email +']:checked').val();
	if(r_email_val)
	{
		$(".radio_Email").attr('disabled', 'disabled');
	}	
	// subtype checking

	// for message 
    $(".message_case").delay(3000).fadeOut();
	if($("#campaign_cost").val()=='Nakumatt'){
            $("#supplierid_campaigncost").hide();
            $("#block_naku_cost_contribution_c").hide();		
            $("#block_naku_cost_type_c").hide();		
	}	
	else if($("#campaign_cost").val()=='Supplier'){
            $("#supplierid_campaigncost").show();
            $("#block_naku_cost_contribution_c").hide();
            $("#block_naku_cost_type_c").hide();		
	}
	else if($("#campaign_cost").val()=='Both'){
            $("#supplierid_campaigncost").show();
            $("#block_naku_cost_contribution_c").show();	
            $("#block_naku_cost_type_c").show();	
	}
	else{
            $("#supplierid_campaigncost").hide();
            $("#block_naku_cost_contribution_c").hide();
            $("#block_naku_cost_type_c").hide();
	}
    //Campaign information validation
    $('#EditViewCampaign').validate({
        rules: {
            start_date: {
                required: true,
                date: true
            },
            end_date: {
                required: true,				
                date: true
            },
            name: {
                required: true
            },
            country: {
                required: true
            }
        },
        submitHandler: function() {
            var chk_val=dateValidationstart_date();
            if(chk_val == false){
                return false;
            }
            var startdate=$('#start_date').val();
            var enddate=$('#end_date').val();
            var url_data=$('#siteurl').val();
            var strtdate = new Date(startdate);
            var sdate_campaign=strtdate.getFullYear()+'-'+parseInt(strtdate.getMonth()+1)+'-'+strtdate.getDate();
            var endate = new Date(enddate); 
            var edate_campaign=endate.getFullYear()+'-'+parseInt(endate.getMonth()+1)+'-'+endate.getDate();
            //Fixed defect D39 31/07/2017
            var items = $("#campaign_type option:selected").map(function() {
                            return $(this).text();
                        }).get();
           // console.log(items.join());
            if(edate_campaign && sdate_campaign){
                $.ajax({ 
                    url: url_data+'/index.php?module=Campaigns&action=hasDuplicatesCampaignsOnSameDate',
                    data: { edatecampaign : edate_campaign,
                            sdatecampaign: sdate_campaign,
                            campaign_type: items.join(), //$('#campaign_type').val(),
                            campaign_id: $('#campaign_id').val(),
                    },
                    type: 'post',
                    success: function(data_suc) {
                        if(data_suc == 'error'){
                            var r = confirm("There are other campaigns running on the similar dates and in ATL category. Do you want to continue?");
                            if (r == true){
                                document.getElementById("EditViewCampaign").submit();								
                            } else {
                                return false;
                            }	
                        }
                        if(data_suc == 'success'){
                            document.getElementById("EditViewCampaign").submit();
                        }
                    }
                });	
            }
        }
    });

    //financial information validation
    $('#EditViewFinancial').validate({
        rules: {
            estimated_revenue: {
                required: true,
                number: true,
                min: 0
            },
            allocate_budget: {
                required: true,
                min: 0,
                number: true
            },
            campaign_cost: {
                required: true
            },
            campaign_owner: {
                required: true
            },
            naku_cost_contribution_c: {
                required: true,
                min: 0,
                number: true
            },
            cost_contribution1:{
                required: true,
                min: 0,
                number: true
            },
            cost_contribution:{
                required: true,
                min: 0,
                number: true
            }
        },
        submitHandler: function() {
            if($('#campaign_cost').val() == 'Both' || $('#campaign_cost').val() == 'Supplier'){
                // start validation of supplier
                var supplier_val = $('input[name="get_supplier_id[]"]').map(function(){
                    return this.value
                }).get();
			  
                var check=hasDuplicates(supplier_val);
                if(check == -1){
                    alert('A Supplier field is required'); 
                    return false;
                }
                if(check == true){
                    alert('A Supplier can not be added twice'); 
                    return false;
                }
                // end validation of supplier
                // start validation of cost contribution
                var cost_contribution_supp = $('input[name="cost_contribution[]"]').map(function(){
                   return this.value
                }).get();
                var check_blank=hasBlankChecks(cost_contribution_supp);
                if(check_blank == -2){
                    alert('A Cost Contribution field is required'); 
                    return false;
                }		
                if(check_blank == -1){
                    alert('Please enter a value greater than or equal to 0.'); 
                    return false;
                }			
                // end validation of cost contribution 
			
                var type    = $('#cost_contribution_type1').val();
                var budget  = $('#allocate_budget').val();
                var total = 0;
                $.each($('.cost_contribution'), function() {
                    total +=  Number($(this).val());                     
                });
                if($('#campaign_cost').val() == 'Both'){			
                    total +=  Number($('#naku_cost_contribution_c').val());					
                }
                if(type == 'kes'){				
                    if(total!=budget){//Total Cost can not exceed Allocate Budget when Cost Type in KES
                        alert('Cost contribution must be equal to allocate budget.'); 
                        $('.cost_contribution').addClass('error');
                        return false;
                    }
                    else{
                        return true;
                        $( "#EditViewFinancial" ).submit();
                    }
                }
                else{					
                    if(total!=100){//Total Cost can not exceed 100 when Cost Type in %
                        alert('Cost contribution must be equal to 100%.'); 
                        $('.cost_contribution').addClass('error');
                        return false;
                    }
                    else{
                        return true;
                        $( "#EditViewFinancial" ).submit();
                    }
                }
            }
            else{
                return true;
                $( "#EditViewFinancial" ).submit();
            }	
        }
    });

    //Assign the rules for supplier_id, cost_contribution & cost_contributio_type
    $.validator.addClassRules({
        supplier_id: {
            required: true
        },
        cost_contribution: {
            required: true,
            number:true,
        },
        cost_contribution_type: {
            required: true
        }
    }); 

    //Subtypes information validation
    var chck = $('input[type=checkbox]');
    $.validator.addMethod('activity_type_based', function () {
        return (chck.filter(':checked').length > 0);
    }, 'Check at least one Activity type');
    var chk_names = $.map(chck, function (el) {
        return $(el).prop("name");
    }).join(" ");

    //Subtype accordion popup validation & save form
    $('#EditViewSubtype').validate({
        rules: {
            groups: {
                checks: chk_names
            },
            event_name: {
                required: true
            },
            event_place: {
                required: true
            },
            website_event_asset_list: {
                required: true
            },
            website_event_asset_detail: {
                required: true
            },
            status :{
                required : true
            }
        },
        submitHandler: function(){
            var validatorFlag = true;
            // start validation of asset
            var s_type_count=$('#subtype_count').val();
            for (var stypec_loop=1;stypec_loop <= s_type_count; stypec_loop++){
                var asset_val = $('input[name="website_asset_detail_'+stypec_loop+'[]"]').map(function(){
                    return this.value
                }).get();                 
                var check=hasDuplicates(asset_val);
                if(check == true){
                    alert('A Asset can not be added twice'); 
                    validatorFlag = false;
                }
                var duration_from_date = $('input[name="duration_from_date_'+stypec_loop+'"]').val();
                if(duration_from_date == '') {
                    alert('A Duration From Date is required.');
                    validatorFlag = false;
                    break;
                }
                var duration_to_date = $('input[name="duration_to_date_'+stypec_loop+'"]').val();
                if(duration_to_date == '') {
                    alert('A Duration To Date is required.');
                    validatorFlag = false;
                    break;
                }
                var marketing_list      = $('input[name="marketing_list_id_'+stypec_loop+'"]').val();
                if(marketing_list == '') {
                    alert('A Marketing List is required.');
                    validatorFlag = false;
                    break;
                }
                /*var promotion_val = $('input[name="promotion_id_'+stypec_loop+'[]"]').map(function(){
                    return this.value
                }).get();              
                var check_prm=hasDuplicates(promotion_val);
                if(check_prm == true){
                    alert('A Promotion can not be added twice'); 
                    validatorFlag = false;
                  //return false;
                }
                var coupon_val = $('input[name="coupon_id_'+stypec_loop+'[]"]').map(function(){
                    return this.value
                 }).get();
				
                var check_cpn=hasDuplicates(coupon_val);
                if(check_cpn == true){
                    alert('A Coupon can not be added twice'); 
                    validatorFlag = false;
                  //return false;
                }
                var chk_cpn_prm=check_coupon_prom(coupon_val,promotion_val)
                if(chk_cpn_prm == -1) {
                    alert('A Promotion is required.'); 
                    validatorFlag = false;
                }*/
            } // end validation of asset
            //Event subtype
            /*var date_start_hours    = $('select[name="date_start_hours"]').val();
            var date_start_minutes  = $('select[name="date_start_minutes"]').val();
            var date_start_meridiem = $('select[name="date_start_meridiem"]').val();
            var date_end_hours      = $('select[name="date_end_hours"]').val();
            var date_end_minutes    = $('select[name="date_end_minutes"]').val();
            var date_end_meridiem   = $('select[name="date_end_meridiem"]').val();*/
            var event_duration_from_date    = $('input[name="event_duration_from_date"]').val();
            if(event_duration_from_date == '') {
                alert('A Duration From Date is required.');
                validatorFlag = false;
            }
            var event_duration_to_date      = $('input[name="event_duration_to_date"]').val();
            if(event_duration_to_date == '') {
                alert('A Duration To Date is required.');
                validatorFlag = false;
            }
            var event_name      = $('input[name="event_name"]').val();
            if(event_name == '') {
                alert('A Event name is required.');
                validatorFlag = false;
            }
            var website_event_asset_list      = $('input[name="website_event_asset_list"]').val();
            if(website_event_asset_list == '') {
                alert('A Link Banner List is required.');
                validatorFlag = false;
            }
            var website_event_asset_detail      = $('input[name="website_event_asset_detail"]').val();
            if(website_event_asset_detail == '') {
                alert('A Link Banner Detail is required.');
                validatorFlag = false;
            }
            // start validation of activity cost
            var activity_cost_val = $('input[class="activity_cost"]').map(function(){
               return this.value
            }).get();
             var activity_check_blank=hasNumericalChecks(activity_cost_val);
             /* if(activity_check_blank == -2)
              {
                            alert('Activity Cost field is required'); 
                            return false;
              }*/		
            if(activity_check_blank == -1){
                alert('Please enter a activity cost value greater than or equal to 0.'); 
                validatorFlag = false;
                //return false;
            } // end validation of cost contribution 
            
            var type    = $('#activity_cost_type_1').val();
            var budget  = $('#allocate_budget').val();
            var total_cost = 0;
            $.each($('.activity_cost'), function() {
                total_cost +=  Number($(this).val());                     
            });
            if(type == 'kes'){
                if(total_cost!=budget){ //Total Cost can not exceed Allocate Budget when Cost Type in KES
                    alert('Cost contribution must be equal to allocate budget.'); 
                    $('.activity_cost').addClass('error');
                    //return false;
                    validatorFlag = false;
                }
//                else{
//                    //return true;
//                    $( "#EditViewSubtype" ).submit();
//                }
            }else{
                if(total_cost!=100){ //Total Cost can not exceed 100 when Cost Type in %
                    alert('Cost contribution must be equal to 100%'); 
                    $('.activity_cost').addClass('error');
                   // return false;
                    validatorFlag = false;
                }
//                else{
//                    //return true;
//                    $( "#EditViewSubtype" ).submit();
//               }
            }
        if(validatorFlag){
            returnValue = true;
            $('#loading_image').show(); 	
        }
        else{
            returnValue = false;
        }
        return returnValue;
        }
    });
    
    //Trigger based popup validation & save form
    $('#EditViewTrigger').validate({
        rules: {
            template_id: {
                required: true
            },
            trig_link_product_name: {
                required: true
            },
            trig_marketing_list_name: {
                required: true
            }
        },
        submitHandler: function() {
            // subtype checking
            var r_sms=$(".radio_SMS").attr("name");
            var r_sms_val=$('input[name='+ r_sms +']:checked').val();
            if(r_sms_val) {
                $(".radio_SMS").attr('disabled', 'disabled');
            }	
            var r_email=$(".radio_Email").attr("name");
            var r_email_val=$('input[name='+ r_email +']:checked').val();
            if(r_email_val) {
                $(".radio_Email").attr('disabled', 'disabled');
            }	
            // subtype checking
				
            // start validation of promotion and coupon
            var promo_trig_val = $('input[name="promotion_id_trig[]"]').map(function(){
                return this.value
            }).get();                      
            var check_prm_trig=hasDuplicates(promo_trig_val);
            if(check_prm_trig == true){
                alert('A Promotion can not be added twice'); 
                return false;
            }  
                      
            var coupon_trig_val = $('input[name="coupon_id_trig[]"]').map(function(){
                return this.value
            }).get();                      
            var check_coupon_trig=hasDuplicates(coupon_trig_val);
            if(check_coupon_trig == true){
                alert('A Coupon can not be added twice'); 
                return false;
            }     
            var chk_cpn_prm_trig=check_coupon_prom(coupon_trig_val,promo_trig_val)
            if(chk_cpn_prm_trig == -1) {
                alert('A Promotion is required.'); 
                return false;
            }	
            //end validation of promotion and coupon
            
            var url_data=$('#siteurl').val();
            var datastring = $("#EditViewTrigger").serialize();
            //alert(datastring);
            // AJAX Code To Submit Form.
            $('#loadingPage').hide();
            $.ajax({
                type: "POST",
                url: url_data+'/index.php?module=Campaigns&action=SaveSubtypesBased',
                data: datastring,
                cache: false,
                success: function(result){
                    cancelTrigger();
                    $('#trigger_id_'+$('#number').val()).val(result);
                    //$('delete_trigger_'+$('#number').val()).val(result);
                    $('#trigger_based_'+$('#number').val()).attr("disabled","disabled");
                    //$('#trigger_subtype_attribute_'+$('#number').val()).attr("disabled","disabled");
                    $('#dialog1').dialog('close');
                    //$('#delete_trigger_'+$('#number').val()).attr("style", "display: none !important");
                    $('#block_delete_trigger_'+$('#number').val()).html('<input type="button" name="delete_trigger" id="delete_trigger_'+$('#number').val()+'" value="Delete" onclick="fundeleteTrigger(\''+result+'\',\''+$('#number').val()+'\');" />');
		},
                beforeSend: function(){
                    $('#loadingPage').show();
                },
                complete: function(){
                    alert('Subtype successfully saved.');
                    $('#loadingPage').hide();
                },
                error: function() {
                    alert('Some problem at the time of submittion');
                }
            });
        }
    });
    
    //Date based popup validation
    $('#EditViewDate').validate({
        rules: {
            template_id: {
                required: true
            },
            select_date_based: {
                required: true
            },
            date_marketing_list_name: {
                required: true
            }
        },
        submitHandler: function() {
		
            // subtype checking
            var r_sms=$(".radio_SMS").attr("name");
            var r_sms_val=$('input[name='+ r_sms +']:checked').val();
            if(r_sms_val) {
                $(".radio_SMS").attr('disabled', 'disabled');
            }	
            var r_email=$(".radio_Email").attr("name");
            var r_email_val=$('input[name='+ r_email +']:checked').val();
            if(r_email_val) {
                $(".radio_Email").attr('disabled', 'disabled');
            }	
            // subtype checking
		
            // start validation of promotion and coupon
           var promotion_id_date_val = $('input[name="promotion_id_date[]"]').map(function(){
                return this.value
            }).get();                      
            var check_promotion_id_date_val=hasDuplicates(promotion_id_date_val);
            if(check_promotion_id_date_val == true){
                alert('A Promotion can not be added twice'); 
                return false;
            }  
                      
            var coupon_id_date_val = $('input[name="coupon_id_date[]"]').map(function(){
                return this.value
            }).get();                      
            var check_coupon_id_date_val=hasDuplicates(coupon_id_date_val);
            if(check_coupon_id_date_val == true){
                alert('A Coupon can not be added twice'); 
                return false;
            } 
			
            var chk_cpn_prm_date=check_coupon_prom(coupon_id_date_val,promotion_id_date_val)
            if(chk_cpn_prm_date == -1) {
                alert('A Promotion is required.'); 
                return false;
            }	
            // end validation of promotion and coupon
            var url_data=$('#siteurl').val();
            var datastring = $("#EditViewDate").serialize();
            //alert(datastring);
            // AJAX Code To Submit Form.
            $('#loadingPage').hide();
            $.ajax({
                type: "POST",
                url: url_data+'/index.php?module=Campaigns&action=SaveSubtypesBased',
                data: datastring,
                cache: false,
                success: function(result){
                    cancelDatebased();
                    $('#date_based_id_'+$('#number').val()).val(result);
                    $('#date_based_'+$('#number').val()).attr("disabled","disabled");
                    $('#dialog2').dialog('close');
                    //$('#delete_date_based_'+$('#number').val()).attr("style", "display: none !important");
                    $('#block_delete_date_based_'+$('#number').val()).html('<input type="button" name="delete_date_based" id="delete_date_based_'+$('#number').val()+'" value="Delete" onclick="fundeleteTrigger(\''+result+'\',\''+$('#number').val()+'\');" />');					
                },
                beforeSend: function(){
                    $('#loadingPage').show();
                },
                complete: function(){
                    alert('Subtype successfully saved.');
                    $('#loadingPage').hide();
                },
                error: function() {
                    alert('some problem in submit form');
                }
            });
        }
    });
    
    //Activity based popup validation
    $('#EditViewActivity').validate({
        rules: {
            template_id: {
                required: true
            },
            select_activity_based: {
                required: true
            },
            act_marketing_list_name: {
                required: true
            }
        },
        submitHandler: function() {
		
            // subtype checking
            var r_sms=$(".radio_SMS").attr("name");
            var r_sms_val=$('input[name='+ r_sms +']:checked').val();
            if(r_sms_val) {
                $(".radio_SMS").attr('disabled', 'disabled');
            }	
            var r_email=$(".radio_Email").attr("name");
            var r_email_val=$('input[name='+ r_email +']:checked').val();
            if(r_email_val) {
                $(".radio_Email").attr('disabled', 'disabled');
            }	
            // subtype checking
		
            // start validation of promotion and coupon
            var promotion_id_activi_val = $('input[name="promotion_id_activi[]"]').map(function(){
                return this.value
            }).get();                      
            var check_promotion_id_activi_val=hasDuplicates(promotion_id_activi_val);
            if(check_promotion_id_activi_val == true){
                alert('A Promotion can not be added twice'); 
                return false;
            }  
                      
            var coupon_id_activi_val = $('input[name="coupon_id_activi[]"]').map(function(){
                return this.value
            }).get();                      
            var check_coupon_id_activi_val=hasDuplicates(coupon_id_activi_val);
            if(check_coupon_id_activi_val == true){
                alert('A Coupon can not be added twice'); 
                return false;
            }   
            var chk_cpn_prm_activity=check_coupon_prom(coupon_id_activi_val,promotion_id_activi_val)
            if(chk_cpn_prm_activity == -1) {
                alert('A Promotion is required.'); 
                return false;
            }	
			
            // end validation of promotion and coupon
            
            var url_data=$('#siteurl').val();
            var datastring = $("#EditViewActivity").serialize();
          
            // AJAX Code To Submit Form.
            $('#loadingPage').hide();
            $.ajax({
                type: "POST",
                url: url_data+'/index.php?module=Campaigns&action=SaveSubtypesBased',
                data: datastring,
                cache: false,
                success: function(result){
                    cancelActivitybased();
                    //alert("#delete_activity_based_"+$('#number').val());
                    $('#activity_based_id_'+$('#number').val()).val(result);
                    $('#activity_based_'+$('#number').val()).attr("disabled","disabled");
                    $('#dialog3').dialog('close');
                    $('#block_delete_activity_based_'+$('#number').val()).html('<input type="button" onclick="fundeleteTrigger(\''+result+'\',\''+$('#number').val()+'\');" value="Delete" id="delete_activity_based_'+$('#number').val()+'" name="delete_activity_based">');
                },
                beforeSend: function(){
                    $('#loadingPage').show();
                },
                complete: function(){
                    alert('Subtype successfully saved.');
                    $('#loadingPage').hide();
                },
                error: function() {
                    alert('some problem in submit form');
                }
            });
        }
    });

   
    // Normal Activity based popup validation
    $('#EditViewNormalActivity').validate({
        rules: {
            normal_activty_marketing_list_name: {
                required: true
            },
            normal_activty_template_id: {
                required: true
            }
        },
        submitHandler: function() {
		
            // subtype checking
            var r_sms=$(".radio_SMS").attr("name");
            var r_sms_val=$('input[name='+ r_sms +']:checked').val();
            if(r_sms_val) {
                $(".radio_SMS").attr('disabled', 'disabled');
            }	
            var r_email=$(".radio_Email").attr("name");
            var r_email_val=$('input[name='+ r_email +']:checked').val();
            if(r_email_val) {
                $(".radio_Email").attr('disabled', 'disabled');
            }
            // subtype checking
		
            // start validation of promotion and coupon
            var promotion_id_activi_val = $('input[name="promotion_id_normal_acti[]"]').map(function(){
                return this.value
            }).get();                      
            var check_promotion_id_activi_val=hasDuplicates(promotion_id_activi_val);
            if(check_promotion_id_activi_val == true){
                alert('A Promotion can not be added twice'); 
                return false;
            }  
                      
            var coupon_id_activi_val = $('input[name="coupon_id_normal_acti[]"]').map(function(){
                return this.value
            }).get();                      
            var check_coupon_id_activi_val=hasDuplicates(coupon_id_activi_val);
            if(check_coupon_id_activi_val == true){
                alert('A Coupon can not be added twice'); 
                return false;
            }   
            var chk_cpn_prm_activity=check_coupon_prom(coupon_id_activi_val,promotion_id_activi_val)
            if(chk_cpn_prm_activity == -1) {
                alert('A Promotion is required.'); 
                return false;
            }	
			
            // end validation of promotion and coupon
            
            var url_data=$('#siteurl').val();
            var datastring = $("#EditViewNormalActivity").serialize();
         
            // AJAX Code To Submit Form.
            $('#loadingPage').hide();
            $.ajax({
                type: "POST",
                url: url_data+'/index.php?module=Campaigns&action=SaveNormalActivity',
                data: datastring,
                cache: false,
                success: function(result){
                    cancelNormalActivitybased();
                    //$('#activity_based_id_'+$('#number').val()).val(result);
                    //$('#activity_based_'+$('#number').val()).attr("disabled","disabled");
                    $('#dialog4').dialog('close');
                    $('#block_delete_normal_activity_'+$('#number').val()).html('<input type="button" onclick="fundeleteNormalActivity(\''+result+'\','+$('#normal_activty_subtype_name').val()+',\''+$('#number').val()+'\');" value="Delete" id="delete_normal_activity_'+$('#number').val()+'" name="delete_normal_activity">');
                    $('#block_delete_normal_activity_'+$('#number').val()).html('<input type="button" onclick="fundeleteNormalActivity(\''+result+'\',\''+$('#normal_activty_subtype_name').val()+'\',\''+$('#number').val()+'\');" value="Delete" id="delete_normal_activity_'+$('#number').val()+'" name="delete_normal_activity">');
                },
                beforeSend: function(){
                    $('#loadingPage').show();
                },
                complete: function(){
                    alert('Subtype successfully saved.');
                    $('#loadingPage').hide();
                },
                error: function() {
                    alert('some problem in submit form');
                }
            });
        }
    });


   //opens the appropriate dialog
    $(".opener").click(function () {
        //takes the ID of appropriate dialogue
        var id = $(this).data('id');
		//alert(id);
       //open dialogue
        $(id).dialog("open");
    });
    //create all the dialogue
    $(".dialog").dialog({
        autoOpen: false,
        height: 600,
        width: 750,		
        modal: true        
    });
    //close dialog box
    $('.close_button').click(function () {
        $('.dialog').dialog('close');
        return false;
    });

	$(".ui-dialog-titlebar-close").click(function () {
		cancelTrigger();
		cancelDatebased();
		cancelActivitybased();
                cancelNormalActivitybased();
	});
	
	
    //Click activity type[Trigger based, Date based, Activity based] checkboxes enable "set subtype attribute" button & also open multiple calendar
    var subtype_val = $('#subtype_count').val();
    for(var s=1; s<=subtype_val;s++){
        //Campaign Activity - Email - From Date
        Calendar.setup ({
            inputField : "duration_from_date_"+s,
            ifFormat : "%m/%d/%Y %I:%M%P",
            daFormat : "%m/%d/%Y %I:%M%P",
            button : "duration_from_date_trigger_"+s,
            singleClick : true,
            dateStr : "",
            startWeekday: 0,
            step : 1,
            weekNumbers:false,
            customMinDate : new Date()
        });
        //Campaign Activity - Email - To Date
        Calendar.setup ({
            inputField : "duration_to_date_"+s,
            ifFormat : "%m/%d/%Y %I:%M%P",
            daFormat : "%m/%d/%Y %I:%M%P",
            button : "duration_to_date_trigger_"+s,
            singleClick : true,
            dateStr : "",
            startWeekday: 0,
            step : 1,
            weekNumbers:false,
            customMinDate : new Date()
        });
        //Trigger checkbox subtype
        $(document).on('click','#trigger_based_'+s,function(){
           $this=$(this);
            if($(this).prop('checked') == true){
                $this.parent().next().find('input[type="button"]').removeAttr("disabled");   
            }
            else {
                $this.parent().next().find('input[type="button"]').attr("disabled","disabled");   
            }
        });
        //Date checkbox subtype
        $(document).on('click','#date_based_'+s,function(){
           $this=$(this);
            if($(this).prop('checked') == true){
                $this.parent().next().find('input[type="button"]').removeAttr("disabled");   
            }
            else {
                $this.parent().next().find('input[type="button"]').attr("disabled","disabled");   
            }
        });
        //Activity checkbox subtype
        $(document).on('click','#activity_based_'+s,function(){
           $this=$(this);
            if($(this).prop('checked') == true){
                $this.parent().next().find('input[type="button"]').removeAttr("disabled");   
            }
            else {
                $this.parent().next().find('input[type="button"]').attr("disabled","disabled");   
            }
        });
		// Normal Activity checkbox subtype
        $(document).on('click','#normal_activity_'+s,function(){
           $this=$(this);
            if($(this).prop('checked') == true){
                $this.parent().next().find('input[type="button"]').removeAttr("disabled");   
            }
            else {
                $this.parent().next().find('input[type="button"]').attr("disabled","disabled");   
            }
        });
    }//End checkboxes enable/disable
    
    //Create accordion for Campaign Sub type
    $( "#accordion" ).accordion({
        collapsible: true,
        autoHeight: true
    });

    //Create Vertical Tabs
    $( "#tabs" ).tabs({ orientation: "vertical" });


    //Event Place Add more button functionality
    var max_fields_event    = 10;
    var wrapper_event       = $(".input_fields_event_place"); //Fields wrapper
    var add_button_event    = $(".add_field_event_place_button"); //Add button ID
    var ev;
    if($("#event_type_count").val()){
        ev=$("#event_type_count").val();
    }
    else{
        ev = 1; //initlal text box count
    }
    $(add_button_event).click(function(e){ //on add input button click
        e.preventDefault();
        if(ev < max_fields_event){ //max input box allowed
            ev++; //text box increment
            var appendhtml ='<div class="row addplace remove_event_edit_row_'+ev+'"">';
                    appendhtml +='<div class="item w15">';
                        appendhtml +='<label for="event_place">Event Place</label><span class="required">*</span>';
                    appendhtml +='</div>';
                    appendhtml +='<div class="item w30">';
                        appendhtml +='<input type="text" name="event_place[]" id="event_place'+ev+'" value="" required="required" >';
                    appendhtml +='</div>';
                     appendhtml +='<div class="item w15">';
                        appendhtml +='<input type="button" id="'+ev+'" class="get_map_button" onclick="getMap('+ev+')" value="Get MAP" />';
                    appendhtml +='</div>';
                    appendhtml +='<div class="row remove_event_edit_row_'+ev+'">';
                        appendhtml +='<div class="item w15">&nbsp;</div>';
                        appendhtml +='<div class="item w30 map_address'+ev+'">';
                        appendhtml +='</div>';
                    appendhtml +='</div><a href="#" class="remove_field_event">Remove</a></div>';
                    
            $(wrapper_event).append(appendhtml); //add input box
            $('#event_place'+ev).rules('add', {
                required: true
            });
        }
    });
    //Remove Event Place
    $(wrapper_event).on("click",".remove_field_event", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); ev--;
    });
     //Remove Event Place in Edit page
    $('.remove_event_edit_field').on("click", function(e){
        e.preventDefault();
        $('.remove_event_edit_row_'+this.id).remove();
    });
    //End Event Place Add more button functionality

    //Supplier ID & Campaign Cost Add more button functionality
    var max_fields      = 500; //maximum input boxes allowed
    var wrapper         = $(".input_fields_supplier_id"); //Fields wrapper
    var add_button      = $(".add_field_supplier_button"); //Add button ID
	
    var x;
    if($("#camp_sup_count").val()){
        x=$("#camp_sup_count").val();
    }else{
        x = 1; //initlal text box count
    }
    $(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
            x++; //text box increment
            var appendhtml ='<div class="row">';
                appendhtml +='<div class="item w15">';
                appendhtml +='<label for="supplier_id">Supplier ID<span class="required">*</span></label>';
            appendhtml +='</div>';
            appendhtml +='<div class="item w30">';
               appendhtml +='<input type="hidden" name="camp_supplier_id[]" id="camp_supplier_id'+x+'" value=""  >';
               appendhtml +='<input type="text" name="supplier_id[]" id="supplier_id'+x+'" class="supplier_id" value="" required="required" readonly >';
                 appendhtml +='<input type="hidden" name="get_supplier_id[]" id="get_supplier_id'+x+'" value="">';
                appendhtml +='<div id="button-holder">';
                    appendhtml +='<span class="id-ff multiple">';
                    appendhtml +="<button type=\"button\" name=\"btn_supplier_name\" id=\"btn_supplier_name\" tabindex=\"0\" title=\"Select Suppliers\" class=\"button firstChild\" value=\"Select Suppliers\" onclick='getSuppliersList("+x+")'>";
                        appendhtml +='<img src="custom/modules/Campaigns/img/magnifying_glass.png">';
                    appendhtml +='</button>';
                appendhtml +='</span>';
                appendhtml +='</div>';
            appendhtml +='</div>';
            appendhtml +='<div class="item w15">';
                appendhtml +='<label for="cost_contribution">Cost Contribution<span class="required">*</span></label>';
            appendhtml +='</div>';
            appendhtml +='<div class="item w30">';
                appendhtml +='<input type="text" name="cost_contribution[]" id="cost_contribution'+x+'" class="cost_contribution" value="" required="required" >';
                 appendhtml +='<select name="cost_contribution_type[]" id="cost_contribution_type'+x+'" style="pointer-events:none"  class="cost_contribution_type all_cost" required="required" >';
                    appendhtml +='<option value="">---Select---</option>';
                    appendhtml +='<option value="percentage">%</option>';
                    appendhtml +='<option value="kes">KES</option>';
                appendhtml +='</select>';
            appendhtml +='</div><a href="#" class="remove_field">Remove</a></div>';
            $(wrapper).append(appendhtml); //add input box
            
            $('#supplier_id'+x).rules('add', {
                required: true
            });
            $('#cost_contribution'+x).rules('add', {
                required: true,
                number:true,
                min:0
            });
            $('#cost_contribution_type'+x).rules('add', {
                required: true
            });
        }
        $(".cost_contribution_type").val($('#cost_contribution_type1').val());
    });

    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); x--;
    });

    //Remove Promotion & Coupon for Subtype section in Edit page
    $('.remove_promotion_edit_field').on("click", function(e){
        e.preventDefault();
        $('.remove_promo_row_'+this.id).remove();
    });
    
    //Remove Assets for Subtype section in Edit page
    $('.remove_asset_id_edit_field').on("click", function(e){
        e.preventDefault();
        //alert(this.id);
        $('.remove_asset_row_'+this.id).remove();
    });
 
    //Promotion ID Add more button functionality
    var s_type_cnt=$('#subtype_count').val();
    var stype_loop=1;
    for (; stype_loop <= s_type_cnt; stype_loop++) {
        //alert(stype_loop);
        //var wrapper_promotion         = $(".input_fields_promotion_id_"+stype_loop); //Fields wrapper
        var add_promotion_button       = $(".add_field_promotion_button_"+stype_loop); //Add button ID

        var a = 1; //initlal text box count
        $(add_promotion_button).click({param1: stype_loop},function(e){ //on add input button click
            e.preventDefault();
            //alert(e.data.param1);
            if($('[name="promotion_id_'+e.data.param1+'[]"]').length < max_fields){ //max input box allowed
                var b = e.data.param1;
                var c = b+"_"+a++;//text box increment
                var appendhtml ='<div class="row">';
                        appendhtml +='<div class="item w15">';
                            appendhtml +='<label for="promotion_id">Promotion ID</label>';
                        appendhtml +='</div>';
                        appendhtml +='<div class="item w30">';
                            appendhtml +='<input type="text" name="promotion_id_'+e.data.param1+'[]" id="promotion_id_'+c+'" class="promotion_id" value="" readonly />';
                            appendhtml +='<input type="hidden" name="get_promotion_id_'+e.data.param1+'[]" id="get_promotion_id_'+c+'" value="">';
                            appendhtml +='<input type="button" name="btn_promotion_name" id="btn_promotion_name" tabindex="0" title="Select Promotions" class="button firstChild" value="Search" onclick="getPromotionsList(\''+c+'\');" />';
                        appendhtml +='</div>';
                        appendhtml +='<div class="item w15">';
                            appendhtml +='<label for="coupon_id">Link Coupon</label>';
                        appendhtml +='</div>';
                        appendhtml +='<div class="item w30">';
                            appendhtml +='<input type="text" name="coupon_id_'+e.data.param1+'[]" id="coupon_id_'+c+'" class="coupon_id" value="" readonly>';
                            appendhtml +='<input type="hidden" name="get_coupon_id_'+e.data.param1+'[]" id="get_coupon_id_'+c+'" value="">';
                            appendhtml +='<input type="button" name="btn_coupon_name" id="btn_coupon_name" tabindex="0" title="Select Coupons" class="button firstChild" value="Search" onclick="getCouponsList(\''+c+'\');" />';
                    appendhtml +='</div>';
                    appendhtml +='<a href="#" class="remove_promotion_field">Remove</a></div>';
                    //$(wrapper_promotion).append(appendhtml); //add input box
                    $(".input_fields_promotion_id_"+e.data.param1).append(appendhtml);
            }
            $(".input_fields_promotion_id_"+e.data.param1).on("click",".remove_promotion_field", function(e){ //user click on remove text
                e.preventDefault(); $(this).parent('div').remove();
            }); 
        });
    }

    //Asset ID Add more button functionality
    var s_ass_cnt=$('#subtype_count').val();
    var sass_loop=1;
    for (; sass_loop <= s_ass_cnt; sass_loop++){
        //var wrapper_asset_detail       = $(".input_fields_asset_detail"); //Fields wrapper
        var add_detail_button    = $(".add_asset_detail_button_"+sass_loop); //Add button ID
        var as = 1; //initlal text box count
	$(add_detail_button).click({param1: sass_loop},function(e){    
            e.preventDefault();
            if($('[name="website_asset_detail_'+e.data.param1+'[]"]').length < max_fields){ //max input box allowed
                var ba = e.data.param1;
                var ca = ba+"_"+as++;//text box increment
                var appendhtml ='<div class="row">';
                    appendhtml +='<div class="item w15">';
                        appendhtml +='<label for="asset_id">Link Asset</label>';
                    appendhtml +='</div>';
                    appendhtml +='<div class="item w30">';
                       appendhtml +='<input type="text" name="website_asset_detail_'+e.data.param1+'[]" id="website_asset_detail_'+ca+'" value="" required readonly>';
                        appendhtml +='<input type="hidden" name="get_websiteasset_detail_id_'+e.data.param1+'[]" id="get_websiteasset_detail_id_'+ca+'" value="">';
                        appendhtml +='<input type="button" name="btn_link_asset_detail" id="btn_link_asset_detail" tabindex="0" title="Select Asset" class="button firstChild" value="Search" onclick="getwebsiteAssetDetail(\''+ca+'\');" />';
                    appendhtml +='</div>';
                    appendhtml +='<a href="#" class="remove_asset_id_field">Remove</a></div>';
                // $(wrapper_asset_detail).append(appendhtml); //add input box
                $(".input_fields_asset_detail_"+e.data.param1).append(appendhtml);
            }
            $(".input_fields_asset_detail_"+e.data.param1).on("click",".remove_asset_id_field", function(e){ //user click on remove text
                e.preventDefault(); $(this).parent('div').remove(); ca--;
            });
        });  
    }

    //Change Campaign Owner value accoding to Campaign Cost value
    $('#campaign_owner').css('pointer-events','none');//default disbale campaign owner
    $("#campaign_cost").change(function() {
        var value =  this.value;
        if(value=="Nakumatt"){
            $("#campaign_owner").val(value);
            $("#supplierid_campaigncost").hide();
            $("#block_naku_cost_contribution_c").hide();
            $("#block_naku_cost_type_c").hide();
            $('#campaign_owner').css('pointer-events','none');
        }
        if(value=="Both"){
            $("#campaign_owner").val(value);
            $("#supplierid_campaigncost").show();
            $("#block_naku_cost_contribution_c").show();
            $("#block_naku_cost_type_c").show();
            $('#campaign_owner').css('pointer-events','auto');
        }
        if(value == 'Supplier'){
            $("#campaign_owner").val('');
            $("#supplierid_campaigncost").show();
            $("#block_naku_cost_contribution_c").hide();
            $("#block_naku_cost_type_c").hide();
            $('#campaign_owner').css('pointer-events','auto');
        }
    });
    
    //When select Cost Type % then all Cost Type should be % & When select Cost Type KES then all Cost Type should be KES
    $("#cost_contribution_type1").change(function() {
        var value =  this.value;
        if(value == 'percentage'){
            $(".cost_contribution_type").val(value);
            $('.cost_contribution_type').css('pointer-events','none');
        }
        if(value == 'kes'){
            $(".cost_contribution_type").val(value);
            $('.cost_contribution_type').css('pointer-events','none');
        }
    });
    
    //When select Activity Cost Type % then all Activity Cost Type should be % & When select Activity Cost Type KES then all Activity Cost Type should be KES
    $("#activity_cost_type_1").change(function() {
        var value = this.value;
        var count = $('#subtype_count').val();
        for(var act=2;act<=count;act++){//alert(act);
            if(value == 'percentage'){
                $('#activity_cost_type_'+act).val(value);
               // $('#activity_cost_type_'+act).attr("disabled","disabled");
                $('#activity_cost_type_'+act).css('pointer-events','none');
            }
            if(value == 'kes'){
                $('#activity_cost_type_'+act).val(value);
                //$('#activity_cost_type_'+act).attr("disabled","disabled");
                $('#activity_cost_type_'+act).css('pointer-events','none');
            }
       }
    });
    
    //show hide fields depend on store type for website event
    if($("input[name='store_type']:radio:checked").val() == 1){ //display instore
        $(".addplace").hide(); $(".editplace").hide();
        $(".addplace input").prop('disabled',true);
        $(".editplace input").prop('disabled',true);
    }else{ //display outstore
        $(".addbranch").hide(); $(".editbranch").hide();
        $(".addbranch select").prop('disabled',true);
        $(".editbranch select").prop('disabled',true);
    }
    $(".addstore input[name='store_type']").click(function() {
        var storeValue = $(this).val();
        if(storeValue == 1){ //display instore
            $(".addplace").hide(); $(".addbranch").show();
            $(".addplace input").prop('disabled',true);
            $(".addbranch select").prop('disabled',false);
            $(".editbranch").show(); $(".editplace").show(); $(".editplace input").prop('disabled',true); //Added for clone
        }else{ //display outstore
            $(".addplace").show(); $(".addbranch").hide();
            $(".addplace input").prop('disabled',false);
            $(".addbranch select").prop('disabled',true);
            $(".editbranch").hide(); $(".editplace").show(); $(".editplace input").prop('disabled',false); //Added for clone
        }
    });
    $(".editstore input[name='store_type']").click(function() {
        var storeValue = $(this).val();
        if(storeValue == 1){ //display instore
            $(".editplace").hide(); $(".editbranch").show(); $(".addplace").hide();
            $(".editbranch select").prop('disabled',false);
            $(".editplace input").prop('disabled',true);
        }else{ //display outstore
            $(".editbranch").hide(); $(".editplace").show(); $(".addplace").show();
            $(".editbranch select").prop('disabled',true);
            $(".editplace input").prop('disabled',false);
        }
    });
});
//Genrate Map for event place
function getMap(id) {
    //alert(id);alert($('#event_place'+id).val());
    var event_place_val = $('#event_place'+id).val();
    var embed ="<iframe width='225' height='150' frameborder='0' scrolling='no' marginheight='0' marginwidth='0' src='https://maps.google.com/maps?&amp;q="+ encodeURIComponent( event_place_val ) +"&amp;output=embed'></iframe>";
    $(".map_address"+id).html(embed);
}
function getSubtype() {
    var url_data=$('#siteurl').val();
    $.ajax({ 
        url: url_data+'/index.php?module=Campaigns&action=getsubtype',
        data: { cid : $('select#campaign_type').val() },
        type: 'post',
        success: function(output) {
            $('#campaign_subtype').html(output);
        }
    });
}
function getSubtypeValue(id,name,number,trigger_id) {
    //date: 14-05-2017
    if(trigger_id){
        trigger_id = trigger_id;
    }else{
        trigger_id  = $('#trigger_id_'+number).val();
    }
    $(".trigger_camp_typeactivity_id").val(trigger_id);
    if(trigger_id) {		
        getCampaignTypeActivity(trigger_id);
    }
    $(".idval").val(id);
    $(".nameval").val(name);
    $("#number").val(number);
}
//Edit Trigger/Date/Activity Subtype Function
function getCampaignTypeActivity(trigger_id='') {
    var url_data=$('#siteurl').val();
    $('#loadingImageTrigger').show();
    $.ajax({
        url: url_data+'/index.php?module=Campaigns&action=getCampaignTypeActivity',
        data: { ctypeid : trigger_id },
        type: 'post',
        success: function(output) {
            $('#loadingImageTrigger').hide();
            var obj = jQuery.parseJSON(output);
            //Start Promotion & Coupon Section
            var promotion=obj.promotion_id_c;
            var coupon=obj.link_coupon_code;
            var wrapper_promotion_subtype_trig       = $(".input_fields_promotion_id_trig"); //Fields wrapper
            var promotion_array = promotion.split(',');
            var coupon_array = coupon.split(',');
            if(typeof promotion_array !== 'undefined' && promotion_array.length > 0) {
                var appendhtmlpromo ='          <table width="100%" cellpadding="0" cellspacing="0" class="promo_table" id="promo_table">';
                   appendhtmlpromo +='          <tr>';
                   appendhtmlpromo +='              <td nowrap>Select</td>';
                   appendhtmlpromo +='              <td nowrap>Promo Code</td>';
                   appendhtmlpromo +='              <td nowrap>Coupon Code</td>';
                   appendhtmlpromo +='              <td nowrap>Reward Type</td>';
                   appendhtmlpromo +='              <td nowrap>Reward Value</td>';
                   appendhtmlpromo +='              <td nowrap>Reward Days</td>';
                   appendhtmlpromo +='          </tr>';     
               $.each(obj.prom_name_c, function (index, promo_val) {
                   if(promo_val.row_id !=''){
                       var checked = 'checked="checked"';
                   }
                   appendhtmlpromo +='          <tr>';
                   appendhtmlpromo +='              <td><input title="Select this row" type="checkbox" class="checkbox" id="promo_check[]" name="promo_check[]" value="'+promo_val.row_id+'" '+checked+'></td>';
                   appendhtmlpromo +='              <td>'+promo_val.name+'</td>';
                   appendhtmlpromo +='              <td>'+promo_val.auto_coupon_code+'</td>';
                   appendhtmlpromo +='              <td>'+promo_val.reward_type+'</td>';
                   appendhtmlpromo +='              <td>'+promo_val.reward_value+'</td>';
                   appendhtmlpromo +='              <td>'+promo_val.reward_days+'</td>';
                   appendhtmlpromo +='           </tr>';
               });
                appendhtmlpromo +='          </table>';
                $('#trig_marketing_list_promo_list').append(appendhtmlpromo);
               //$(wrapper_promotion_subtype_trig).append('<input type="hidden" name="promotion_trig_count" id="promotion_trig_count" value="'+promotion_array.length+'" />');
                /*for(var i = 1; i < promotion_array.length; i++) {
                    var p=i+1;
                    $("#promotion_trig_count").val(p);
                    var appendhtml ='<div class="row">';
                            appendhtml +='<div class="item w15">';
                                appendhtml +='<label for="promotion_id_trig">Promotion ID</label>';
                           appendhtml +='</div>';
                           appendhtml +='<div class="item w30">';
                              appendhtml +='<input type="text" name="promotion_id_trig[]" id="promotion_id_trig'+p+'" class="promotion_id_trig" value="'+obj.prom_name_c[promotion_array[i]]+'" readonly >';
                                   appendhtml +='<input type="hidden" name="get_promotion_id_trig[]" id="get_promotion_id_trig'+p+'" value="'+promotion_array[i]+'">';
                                   appendhtml +='<input type="button" name="btn_trig_promotion_name" id="btn_trig_promotion_name" tabindex="0" title="Select Promotions" class="button firstChild" value="Search" onclick="getTrigPromotionsList('+p+');" />';
                           appendhtml +='</div>';
                           appendhtml +='<div class="item w15">';
                                appendhtml +='<label for="coupon_id_trig">Link Coupon</label>';              
                           appendhtml +='</div>';
                           appendhtml +='<div class="item w30">';
                                appendhtml +='<input type="text" name="coupon_id_trig[]" id="coupon_id_trig'+p+'" class="coupon_id_trig" value="'+obj.coupon_name_c[coupon_array[i]]+'" readonly >';
                                appendhtml +='<input type="hidden" name="get_coupon_id_trig[]" id="get_coupon_id_trig'+p+'" value="'+coupon_array[i]+'">';
                                appendhtml +='<input type="button" name="btn_trig_coupon_name" id="btn_trig_coupon_name" tabindex="0" title="Select Promotions" class="button firstChild" value="Search" onclick="getTrigCouponsList('+p+');" />';
                           appendhtml +='</div>';
                           appendhtml +='<a href="#" class="remove_promotion_subtype_field">Remove</a></div>';
                           $(wrapper_promotion_subtype_trig).append(appendhtml); //add input box
                }*/
            }
            /*$(wrapper_promotion_subtype_trig).on("click", ".remove_promotion_subtype_field", function (e) { //user click on remove text
                e.preventDefault();
                $(this).parent('div').remove();
                p--;
            });*/
            //End Promotion & Coupon Section
            
            //Start Product Portfolio Section
            var wrapper_link_product_trig  = $(".input_fields_link_product_trig"); //Fields wrapper
            var products=obj.link_product_portfolio;
            var products_array = products.split(',');
            if(typeof products_array !== 'undefined' && products_array.length > 0){
                //$(wrapper_link_product_trig).append('<input type="hidden" name="product_count" id="product_count" value="'+products_array.length+'" />');
                for(var j = 1; j < products_array.length; j++) {
                    var pp=j+1;	
                    $("#product_count").val(pp);
                    var appendhtml ='<div class="row">';
                            appendhtml +='<div class="item w15">';
                                appendhtml +='<label for="link_product_trig">Link Product Portfolio</label>';
                           appendhtml +='</div>';
                           appendhtml +='<div class="item w30">';
                              appendhtml +='<input type="text" name="trig_link_product_name[]" id="trig_link_product_name'+pp+'" class="trig_link_product" value="'+obj.product_portfolio[products_array[j]]+'" required="required" readonly />';
                                   appendhtml +='<input type="hidden" name="trig_link_product_id[]" id="trig_link_product_id'+pp+'" value="'+products_array[j]+'" />';
                                   appendhtml +='<input type="button" name="btn_link_product" id="btn_link_product" tabindex="0" title="Select Products" class="button firstChild" value="Search" onclick="getProductsList('+pp+',\'trig_link_product_\');" />';
                           appendhtml +='</div>';
                           appendhtml +='<a href="#" class="remove_product_field">Remove</a></div>';
                           $(wrapper_link_product_trig).append(appendhtml); //add input box
                }
            }
            $(wrapper_link_product_trig).on("click", ".remove_product_field", function (e) { //user click on remove text
                e.preventDefault();
                $(this).parent('div').remove();
                pp--;
            });
           //End Product Portfolio Section
            
            //Assign Values to all fileds
            $('#coupon_id_trig').val(obj.coupon_name_c[coupon_array[0]]);
            $('#get_coupon_id_trig').val(coupon_array[0]);
            //$('#promotion_id_trig').val(obj.prom_name_c[promotion_array[0]]);			
            //$('#get_promotion_id_trig').val(promotion_array[0]);
            //$('#trig_link_product').val(obj.product_portfolio[products_array[0]]);
            //$('#get_product_id').val(products_array[0]);
            //$('#product_count').val(products_array.length);
            $('#trig_link_product_name').val(obj.product_portfolio[products_array[0]]);
            $('#trig_link_product_id').val(products_array[0]);
            $('#template_id').val(obj.template_name);
            $('#get_template_id').val(obj.template_id);
            $('.activty_email_templates_id').val(obj.template_id);
            $('#comments').val(obj.comments);
            $('#trig_marketing_list_name').val(obj.marketinglist_name);
            $('#trig_marketing_list_id').val(obj.marketing_list_id_c);
            //$('#campaign_subtype').html(output);
        }
    });
}
function cancelTrigger() {
    $('#coupon_id_trig').val('');
    $('#get_coupon_id_trig').val('');
    //$('#promotion_id_trig').val('');
    //$('#get_promotion_id_trig').val('');
    $('#trig_marketing_list_promo_list').empty();
    $('#trig_link_product_name').val('');
    $('#trig_link_product_id').val('');
    $(".input_fields_link_product_trig").html('');
    $('#template_id').val('');
    $('#get_template_id').val('');
    $('.activty_email_templates_id').val('');
    $('#comments').val('');
    $(".input_fields_promotion_id_trig").html('');
    $('#trig_marketing_list_name').val('');
    $('#trig_marketing_list_id').val('');
}
function getSubtypeValue_date_based(id,name,number,date_based_id) {
    //date: 14-05-2017
    if(date_based_id){
        date_based_id = date_based_id;
    }else{
        date_based_id  = $('#date_based_id_'+number).val();
    }
    $(".date_based_camp_typeactivity_id").val(date_based_id);
    if(date_based_id){
        getCampaignTypeActivity_datebased(date_based_id);
    }
    $(".idval").val(id);
    $(".nameval").val(name);
    $("#number").val(number);
}
function getCampaignTypeActivity_datebased(date_based_id) {
    var url_data=$('#siteurl').val();
    $('#loadingImageDate').show();
    $.ajax({ 
        url: url_data+'/index.php?module=Campaigns&action=getCampaignTypeActivity',
        data: { ctypeid : date_based_id },
        type: 'post',
        success: function(output) {
            $('#loadingImageDate').hide();
            var obj = jQuery.parseJSON(output);
            var promotion=obj.promotion_id_c;
            var coupon=obj.link_coupon_code;
            var wrapper_promotion_subtype_date = $(".input_fields_promotion_id_date"); 
            var promotion_array = promotion.split(',');
            var coupon_array = coupon.split(',');
            if(typeof promotion_array !== 'undefined' && promotion_array.length > 0){
                var appendhtmlpromo ='          <table width="100%" cellpadding="0" cellspacing="0" class="promo_table">';
                   appendhtmlpromo +='          <tr>';
                   appendhtmlpromo +='              <td nowrap>Select</td>';
                   appendhtmlpromo +='              <td nowrap>Promo Code</td>';
                   appendhtmlpromo +='              <td nowrap>Coupon Code</td>';
                   appendhtmlpromo +='              <td nowrap>Reward Type</td>';
                   appendhtmlpromo +='              <td nowrap>Reward Value</td>';
                   appendhtmlpromo +='              <td nowrap>Reward Days</td>';
                   appendhtmlpromo +='          </tr>';     
               $.each(obj.prom_name_c, function (index, promo_val) {
                   if(promo_val.row_id !=''){
                       var checked = 'checked="checked"';
                   }
                   appendhtmlpromo +='          <tr>';
                   appendhtmlpromo +='              <td><input title="Select this row" type="checkbox" class="checkbox" id="promo_check[]" name="promo_check[]" value="'+promo_val.row_id+'" '+checked+'></td>';
                   appendhtmlpromo +='              <td>'+promo_val.name+'</td>';
                   appendhtmlpromo +='              <td>'+promo_val.auto_coupon_code+'</td>';
                   appendhtmlpromo +='              <td>'+promo_val.reward_type+'</td>';
                   appendhtmlpromo +='              <td>'+promo_val.reward_value+'</td>';
                   appendhtmlpromo +='              <td>'+promo_val.reward_days+'</td>';
                   appendhtmlpromo +='           </tr>';
               });
                appendhtmlpromo +='          </table>';
                $('#date_marketing_list_promo_list').append(appendhtmlpromo);
                //$(wrapper_promotion_subtype_date).append('<input type="hidden" name="promotion_date_count" id="promotion_date_count" value="'+promotion_array.length+'" />');
                /*for(var i = 1; i < promotion_array.length; i++) {
                    var p=i+1;
                    $("#promotion_date_count").val(p);
                    var appendhtml ='<div class="row">';
                    appendhtml +='<div class="item w15">';
                       appendhtml +='<label for="promotion_id_date">Promotion ID</label>';
                   appendhtml +='</div>';
                   appendhtml +='<div class="item w30">';
                      appendhtml +='<input type="text" name="promotion_id_date[]" id="promotion_id_date'+p+'" class="promotion_id_date" value="'+obj.prom_name_c[promotion_array[i]]+'" readonly>';
                       appendhtml +='<input type="hidden" name="get_promotion_id_date[]" id="get_promotion_id_date'+p+'" value="'+promotion_array[i]+'">';
                       appendhtml +='<input type="button" name="btn_date_promotion_name" id="btn_date_promotion_name" tabindex="0" title="Select Promotions" class="button firstChild" value="Search" onclick="getDatePromotionsList('+p+');" />';
                   appendhtml +='</div>';
                   appendhtml +='<div class="item w15">';
                       appendhtml +='<label for="coupon_id_date">Link Coupon</label>';
                   appendhtml +='</div>';
                   appendhtml +='<div class="item w30">';
                       appendhtml +='<input type="text" name="coupon_id_date[]" id="coupon_id_date'+p+'" class="coupon_id_date" value="'+obj.coupon_name_c[coupon_array[i]]+'" readonly>';
                       appendhtml +='<input type="hidden" name="get_coupon_id_date[]" id="get_coupon_id_date'+p+'" value="'+coupon_array[i]+'">';
                       appendhtml +='<input type="button" name="btn_date_coupon_name" id="btn_date_coupon_name" tabindex="0" title="Select Coupons" class="button firstChild" value="Search" onclick="getDateCouponsList('+p+');" />';
                   appendhtml +='</div>';
                   appendhtml +='<a href="#" class="remove_promotion_subtype_date_field">Remove</a></div>';
                    $(wrapper_promotion_subtype_date).append(appendhtml);
                }*/
            }
            /*$(wrapper_promotion_subtype_date).on("click", ".remove_promotion_subtype_date_field", function (e) { //user click on remove text
                e.preventDefault();
                $(this).parent('div').remove();
                p--;
            });*/
            $('#coupon_id_date').val(obj.coupon_name_c[coupon_array[0]]);
            $('#get_coupon_id_date').val(coupon_array[0]);
            //$('#promotion_id_date').val(obj.prom_name_c[promotion_array[0]]);			
            //$('#get_promotion_id_date').val(promotion_array[0]);          
            var select_activity = '.'+obj.date_activity+'_date';
            $(select_activity).prop('checked', true);
            $('.template_id_date').val(obj.template_name);
            $('.get_template_id_date').val(obj.template_id);
            $('.activty_email_templates_id').val(obj.template_id);
            $('.comments_date').val(obj.comments);
            $('#date_marketing_list_name').val(obj.marketinglist_name);
            $('#date_marketing_list_id').val(obj.marketing_list_id_c);
        }
    });
}
function cancelDatebased() {
	
    //$('#promotion_id_date').val('');
    $('#get_coupon_id_date').val('');
    $('#coupon_id_date').val('');
    //$('#get_promotion_id_date').val(''); 
    $('#date_marketing_list_promo_list').empty();
    $('.template_id_date').val('');
    $('.get_template_id_date').val('');
    $('.activty_email_templates_id').val('');
    $('.date_based_cls').prop("checked",false);
    $('.comments_date').val('');
    $('#date_marketing_list_name').val('');
    $('#date_marketing_list_id').val('');
    $(".input_fields_promotion_id_date").html('');
}
function getSubtypeValue_activity(id,name,number,activity_based_id) {
    //date: 14-05-2017
    if(activity_based_id){
        activity_based_id = activity_based_id;
    }else{
        activity_based_id  = $('#activity_based_id_'+number).val();
    }
    $(".activity_based_camp_typeactivity_id").val(activity_based_id);
    if(activity_based_id) {		
        getCampaignTypeActivity_activity(activity_based_id);
    } 
    $(".idval").val(id);
    $(".nameval").val(name);
    $("#number").val(number);
   
}
function getSubtypeNormalValue_activity(id,name,number,campaign_activity,campid) {
    //Display Polls dropdown only Email Normal Activity
    if (name == 'Email'){
        $('#PollsonEmail').show();
    } else{
        $('#PollsonEmail').hide();
    }
    $(".normal_activty_camp_typeactivity_id").val(campaign_activity);
    $(".idval").val(id);
    $(".nameval").val(name);
    $("#number").val(number);
    var url_data = $('#siteurl').val();
    $('#loadingImageNormal').show();
    $.ajax({
        url: url_data + '/index.php?module=Campaigns&action=getCamppActivity',
        data: { camp_activityid : campaign_activity, name:name, campid:campid},
        type: 'post',
        success: function(output) {
            $('#loadingImageNormal').hide();
            if (output) {
                var obj = jQuery.parseJSON(output);
                var promotion = obj.promotion_id_c;
                //var coupon = obj.coupon_id_c;
                var wrapper_promotion_subtype_activi = $(".input_fields_promotion_id_normal_acti");
                var promotion_array = promotion.split(',');
                //var coupon_array = coupon.split(',');
                // set value
                $('#normal_activty_subtype_id').val(obj.cmp_subtype_id);
                $('#normal_activty_subtype_name').val(obj.name);
                $('#normal_activty_marketing_list_name').val(obj.marketinglist_name);
                $('#normal_activty_marketing_list_id').val(obj.marketing_list_id);
                $('#normal_activty_template_id').val(obj.template_name);
                $('#get_normal_activty_template_id').val(obj.template_id_c);
                //$('#coupon_id_normal_acti').val(obj.coupon_name_c[coupon_array[0]]);
                //$('#get_coupon_id_normal_acti').val(coupon_array[0]);
                //$('#promotion_id_normal_acti').val(obj.prom_name_c[promotion_array[0]]);
                //$('#get_promotion_id_normal_acti').val(promotion_array[0]);
                $('#polls_id').val(obj.polls_id).attr('selected','selected');
                if((typeof promotion_array !== 'undefined' && promotion_array.length > 0) && promotion != ''){
                    var appendhtmlpromo ='          <table width="100%" cellpadding="0" cellspacing="0" class="promo_table">';
                       appendhtmlpromo +='          <tr>';
                       appendhtmlpromo +='              <td nowrap>Select</td>';
                       appendhtmlpromo +='              <td nowrap>Promo Code</td>';
                       appendhtmlpromo +='              <td nowrap>Coupon Code</td>';
                       appendhtmlpromo +='              <td nowrap>Reward Type</td>';
                       appendhtmlpromo +='              <td nowrap>Reward Value</td>';
                       appendhtmlpromo +='              <td nowrap>Reward Days</td>';
                       appendhtmlpromo +='          </tr>';     
                   $.each(obj.prom_name_c, function (index, promo_val) {
                       if(promo_val.row_id !=''){
                           var checked = 'checked="checked"';
                       }
                       appendhtmlpromo +='          <tr>';
                       appendhtmlpromo +='              <td><input title="Select this row" type="checkbox" class="checkbox" id="promo_check[]" name="promo_check[]" value="'+promo_val.row_id+'" '+checked+'></td>';
                       appendhtmlpromo +='              <td>'+promo_val.name+'</td>';
                       appendhtmlpromo +='              <td>'+promo_val.auto_coupon_code+'</td>';
                       appendhtmlpromo +='              <td>'+promo_val.reward_type+'</td>';
                       appendhtmlpromo +='              <td>'+promo_val.reward_value+'</td>';
                       appendhtmlpromo +='              <td>'+promo_val.reward_days+'</td>';
                       appendhtmlpromo +='           </tr>';
                   });
                    appendhtmlpromo +='          </table>';
                    $('#normal_activty_marketing_list_promo_list').append(appendhtmlpromo);
                }
                /*if(typeof promotion_array !== 'undefined' && promotion_array.length > 0){
                    for (var i = 1; i < promotion_array.length; i++) {
                        var na = i + 1;
                        $("#promotion_normal_count").val(na);
                        var appendhtml = '<div class="row">';
                        appendhtml += '<div class="item w15">';
                        appendhtml += '<label for="promotion_id_normal_acti">Promotion ID</label>';
                        appendhtml += '</div>';
                        appendhtml += '<div class="item w30">';
                        appendhtml += '<input type="text" name="promotion_id_normal_acti[]" id="promotion_id_normal_acti' + na + '" class="promotion_id_normal_acti" value="' + obj.prom_name_c[promotion_array[i]] + '"  readonly>';
                        appendhtml += '<input type="hidden" name="get_promotion_id_normal_acti[]" id="get_promotion_id_normal_acti' + na + '" value="' + promotion_array[i] + '" >';
                        appendhtml += '<input type="button" name="btn_normal_acti_promotion_name" id="btn_normal_acti_promotion_name" tabindex="0" title="Select Promotions" class="button firstChild" value="Search" onclick="getNormalActivityPromotionsList(' + na + ');" />';
                        appendhtml += '</div>';
                        appendhtml += '<div class="item w15">';
                        appendhtml += '<label for="coupon_id_normal_acti">Link Coupon</label>';
                        appendhtml += '</div>';
                        appendhtml += '<div class="item w30">';
                        appendhtml += '<input type="text" name="coupon_id_normal_acti[]" id="coupon_id_normal_acti' + na + '" class="coupon_id_normal_acti" value="' + obj.coupon_name_c[coupon_array[i]] + '" readonly>';
                        appendhtml += '<input type="hidden" name="get_coupon_id_normal_acti[]" id="get_coupon_id_normal_acti' + na + '" value="' + coupon_array[i] + '" >';
                        appendhtml += '<input type="button" name="btn_normal_acti_coupon_name" id="btn_normal_acti_coupon_name" tabindex="0" title="Select Promotions" class="button firstChild" value="Search" onclick="getNormalActivityCouponsList(' + na + ');" />';
                        appendhtml += '</div>';
                        appendhtml += '<a href="#" class="remove_promotion_normal_acti_subtype_field">Remove</a></div>';
                        $(wrapper_promotion_subtype_activi).append(appendhtml);
                    }
                }*/
                /*$(wrapper_promotion_subtype_activi).on("click", ".remove_promotion_normal_acti_subtype_field", function (e) { //user click on remove text
                    e.preventDefault();
                    $(this).parent('div').remove();
                    na--;
                });*/
            }
        }
    });
}
function cancelNormalActivitybased() {
    //$('#promotion_id_normal_acti').val('');
    $('#coupon_id_normal_acti').val('');
    $('#get_coupon_id_normal_acti').val('');
    //$('#get_promotion_id_normal_acti').val('');
    $('#normal_activty_marketing_list_promo_list').empty();
    $('#get_normal_activty_template_id').val('');	
    $('#normal_activty_template_id').val('');      
    $(".input_fields_promotion_id_normal_acti").html('');
    $('#normal_activty_marketing_list_name').val('');
    $('#normal_activty_marketing_list_id').val('');
}
function getCampaignTypeActivity_activity(activity_based_id) {
    var url_data=$('#siteurl').val();
    $('#loadingImageActivity').show();
    $.ajax({ 
        url: url_data+'/index.php?module=Campaigns&action=getCampaignTypeActivity',
        data: { ctypeid : activity_based_id },
        type: 'post',
        success: function(output) {
            $('#loadingImageActivity').hide();
            var obj = jQuery.parseJSON(output);
            var promotion=obj.promotion_id_c;
            var coupon=obj.link_coupon_code;
            var wrapper_promotion_subtype_activi = $(".input_fields_promotion_id_activi");
            var promotion_array = promotion.split(',');
            var coupon_array = coupon.split(',');
            if(typeof promotion_array !== 'undefined' && promotion_array.length > 0){
                var appendhtmlpromo ='          <table width="100%" cellpadding="0" cellspacing="0" class="promo_table">';
                   appendhtmlpromo +='          <tr>';
                   appendhtmlpromo +='              <td nowrap>Select</td>';
                   appendhtmlpromo +='              <td nowrap>Promo Code</td>';
                   appendhtmlpromo +='              <td nowrap>Coupon Code</td>';
                   appendhtmlpromo +='              <td nowrap>Reward Type</td>';
                   appendhtmlpromo +='              <td nowrap>Reward Value</td>';
                   appendhtmlpromo +='              <td nowrap>Reward Days</td>';
                   appendhtmlpromo +='          </tr>';     
               $.each(obj.prom_name_c, function (index, promo_val) {
                   if(promo_val.row_id !=''){
                       var checked = 'checked="checked"';
                   }
                   appendhtmlpromo +='          <tr>';
                   appendhtmlpromo +='              <td><input title="Select this row" type="checkbox" class="checkbox" id="promo_check[]" name="promo_check[]" value="'+promo_val.row_id+'" '+checked+'></td>';
                   appendhtmlpromo +='              <td>'+promo_val.name+'</td>';
                   appendhtmlpromo +='              <td>'+promo_val.auto_coupon_code+'</td>';
                   appendhtmlpromo +='              <td>'+promo_val.reward_type+'</td>';
                   appendhtmlpromo +='              <td>'+promo_val.reward_value+'</td>';
                   appendhtmlpromo +='              <td>'+promo_val.reward_days+'</td>';
                   appendhtmlpromo +='           </tr>';
               });
                appendhtmlpromo +='          </table>';
                $('#act_marketing_list_promo_list').append(appendhtmlpromo);
                /*for(var i = 1; i < promotion_array.length; i++) {
                    var r=i+1;
                    $("#promotion_activity_count").val(r);
                    var appendhtml ='<div class="row">';
                    appendhtml +='<div class="item w15">';
                       appendhtml +='<label for="promotion_id_activi">Promotion ID</label>';
                   appendhtml +='</div>';
                   appendhtml +='<div class="item w30">';
                       appendhtml +='<input type="text" name="promotion_id_activi[]" id="promotion_id_activi'+r+'" class="promotion_id_activi" value="'+obj.prom_name_c[promotion_array[i]]+'" readonly>';
                       appendhtml +='<input type="hidden" name="get_promotion_id_activi[]" id="get_promotion_id_activi'+r+'" value="'+promotion_array[i]+'">';
                       appendhtml +='<input type="button" name="btn_activi_promotion_name" id="btn_activi_promotion_name" tabindex="0" title="Select Promotions" class="button firstChild" value="Search" onclick="getActivityPromotionsList('+r+');" />';
                   appendhtml +='</div>';
                   appendhtml +='<div class="item w15">';
                       appendhtml +='<label for="coupon_id_activi">Link Coupon</label>';
                   appendhtml +='</div>';
                   appendhtml +='<div class="item w30">';
                       appendhtml +='<input type="text" name="coupon_id_activi[]" id="coupon_id_activi'+r+'" class="coupon_id_activi" value="'+obj.coupon_name_c[coupon_array[i]]+'" readonly>';
                       appendhtml +='<input type="hidden" name="get_coupon_id_activi[]" id="get_coupon_id_activi'+r+'" value="'+coupon_array[i]+'">';
                       appendhtml +='<input type="button" name="btn_activi_coupon_name" id="btn_activi_coupon_name" tabindex="0" title="Select Coupons" class="button firstChild" value="Search" onclick="getActivityCouponsList('+r+');" />';
                   appendhtml +='</div>';
                   appendhtml +='<a href="#" class="remove_promotion_subtype_activi_field">Remove</a></div>';
                    $(wrapper_promotion_subtype_activi).append(appendhtml);
                }*/
            }
            /*$(wrapper_promotion_subtype_activi).on("click", ".remove_promotion_subtype_activi_field", function (e) { //user click on remove text
                e.preventDefault();
                $(this).parent('div').remove();
                r--;
            });*/
            $('#coupon_id_activi').val(obj.coupon_name_c[coupon_array[0]]);
            $('#get_coupon_id_activi').val(coupon_array[0]);
            //$('#promotion_id_activi').val(obj.prom_name_c[promotion_array[0]]);			
            //$('#get_promotion_id_activi').val(promotion_array[0]); 
            
            var select_activity1 = '.'+obj.activity_based_activity+'_activity';
            $(select_activity1).prop('checked', true);
            $('.template_id_activity').val(obj.template_name);
            $('.get_template_id_activity').val(obj.template_id);
            $('.activty_email_templates_id').val(obj.template_id);
            $('.comments_activity').val(obj.comments);
            $('#act_marketing_list_name').val(obj.marketinglist_name);
            $('#act_marketing_list_id').val(obj.marketing_list_id_c);
        }
    });
}
function cancelActivitybased() {
    $('#act_marketing_list_promo_list').empty();
    //$('#promotion_id_activi').val('');
    $('#coupon_id_activi').val('');
    //$('#get_coupon_id_activi').val('');
    $('#get_promotion_id_activi').val(''); 
    $('.get_template_id_activity').val('');
    $('.activty_email_templates_id').val('');
    $('.template_id_activity').val('');
    $('.activity_based_cls').prop("checked",false);
    $('.comments_activity').val('');
    $(".input_fields_promotion_id_activi").html('');
    $('#act_marketing_list_name').val('');
    $('#act_marketing_list_id').val('');
}
function fundeleteTrigger(id,num) {
    if (confirm("This action will delete this subtype. Do you want to continue ?") == true) {
        var url_data=$('#siteurl').val();
        $('#loading_image').show(); //added 01-08-2017 before responce add loading image
        $.ajax({ 
            url: url_data+'/index.php?module=Campaigns&action=deleteCampaignTypeActivity',
            data: { tid : id },
            type: 'post',
            success: function(output) {
                if(output==1) {
                    $('#loading_image').hide(); //added 01-08-2017 before responce add loading image
                    $('#block_delete_trigger_'+num).hide();
                    $('input[name=subtype_attribute_'+num+']').attr('checked', false);
                    $('input[name=subtype_attribute_'+num+']').attr('disabled', false);
                    alert('Activity type deleted sucessfully.');
                    //window.location.reload();
                }
            }
        });
    }
}
function fundeleteNormalActivity(id,name,num) {
    if (confirm("This action will delete this subtype. Do you want to continue ?") == true) {	
        var url_data=$('#siteurl').val();
        $('#loading_image').show(); //added 01-08-2017 before responce add loading image
        $.ajax({
            url: url_data+'/index.php?module=Campaigns&action=deleteCampaignActivity',
            data: { tid : id, name : name },
            type: 'post',
            success: function(output) {
                if(output==1) {
                    $('#loading_image').hide(); //added 01-08-2017 before responce add loading image
                    $('#block_delete_normal_activity_'+num).hide();
                    $('input[name=subtype_attribute_'+num+']').attr('checked', false);
                    $('input[name=subtype_attribute_'+num+']').attr('disabled', false);
                    alert('Normal Activity deleted sucessfully.');
                    //window.location.reload();
                }
            }
        });
        $('#block_delete_normal_activity_'+num).hide();
        $('input[name=subtype_attribute_'+num+']').attr('checked', false);
        $('input[name=subtype_attribute_'+num+']').attr('disabled', false);
    }
}
function dateValidation_end() {
    var startdate=$('#start_date').val();
    var enddate=$('#end_date').val();	
    var date = new Date(startdate);
    var sdate=date.getMonth()+1+'/'+date.getDate()+'/'+date.getFullYear();	
    if(Date.parse(sdate) >= Date.parse(enddate)) {
        alert('End date must be greater than start date.');
        $('#end_date').val('');
    }	
}
function get_cost_type(){
    $(".cost_contribution_type").val($('#naku_cost_type_c').val());	
}
function dateValidationstart_date() {
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth()+1;
    var yyyy = today.getFullYear();
    var startdate=$('#start_date').val();
    var enddate=$('#end_date').val();
    var currentdate=mm+'/'+dd+'/'+yyyy;

    if(Date.parse(startdate) >= Date.parse(enddate)) {
        alert('End date must be greater than start date.');
        $('#start_date').val('');
        return false;
    }	
}
function check_coupon_prom(coupon_arr,prom_arr) {
    for (var i = 0; i < coupon_arr.length; ++i) {
        if(coupon_arr[i] != '' && prom_arr[i]=='') {
            return -1;
        }			
    }	 
}
function hasDuplicates(array) {
    var valuesSoFar = Object.create(null);
    for (var i = 0; i < array.length; ++i) {
        var value = array[i];
            if(value == '' ) {
                return -1;
            }
        if (value in valuesSoFar) {
            return true;
        }
        valuesSoFar[value] = true;
    }
    return false;
}
function hasNumericalChecks(array) {
    for (var i = 0; i < array.length; ++i) {
        var value = array[i];
        if(value < 0) {
            return -1;
        }
    }
    return false;
}
function hasBlankChecks(array) {
    for (var i = 0; i < array.length; ++i) {
        var value = array[i];
        if(value == ''){
            return -2;
        }
        if(value < 0){
            return -1;
        }
    }
    return false;
}
function dateValidation_activity_start_date(id) {
    var startdate_activity=$('#duration_from_date_'+id).val();	
    var enddate_activity=$('#duration_to_date_'+id).val();	
   
    var date = new Date($('#start_date').val());
    var sdate=date.getMonth()+1+'/'+date.getDate()+'/'+date.getFullYear();

    var edate = new Date($('#end_date').val());
    var enddate=edate.getMonth()+1+'/'+edate.getDate()+'/'+edate.getFullYear();
	
	 if(Date.parse(startdate_activity) >= Date.parse(enddate_activity)) {
        alert('To date must be greater than From date.');
        $('#duration_from_date_'+id).val('');
        return false;
    }			
    if(Date.parse(startdate_activity) < Date.parse(sdate)) {
        alert('From Date must be between campaign\'s start date and end date');
        $('#duration_from_date_'+id).val('');
    }
    if(Date.parse(startdate_activity) > Date.parse(enddate)) {
        alert('From Date must be between campaign\'s start date and end date');
        $('#duration_from_date_'+id).val('');
    }
}
function dateValidation_activity_end_date(id) {
    var enddate_activity=$('#duration_to_date_'+id).val();

    var strtdate = new Date($('#duration_from_date_'+id).val());
    var sdate_activity=strtdate.getMonth()+1+'/'+strtdate.getDate()+'/'+strtdate.getFullYear();

    var date = new Date($('#start_date').val());
    var sdate=date.getMonth()+1+'/'+date.getDate()+'/'+date.getFullYear();

    var edate = new Date($('#end_date').val());
    var enddate=edate.getMonth()+1+'/'+edate.getDate()+'/'+edate.getFullYear();

    if(Date.parse(enddate_activity) < Date.parse(sdate)){
        alert('To Date must be between campaign\'s start date and end date');
        $('#duration_to_date_'+id).val('');
    }
    if(Date.parse(enddate_activity) > Date.parse(enddate)){
        alert('To Date must be between campaign\'s start date and end date');
        $('#duration_to_date_'+id).val('');
    }
    if(Date.parse(sdate_activity) >= Date.parse(enddate_activity)){
        alert('End date must be greater than start date.');
        $('#duration_to_date_'+id).val('');
    }	
}
function remove_product_detail_trig() {
    //$('#trig_link_product').val('');
    //$('#get_product_id').val('');
    $('#trig_link_product_name').val('');
    $('#trig_link_product_id').val('');
}
function remove_prom_coupon_detail(id) {
    $('#promotion_id_'+id).val('');
    $('#get_promotion_id_'+id).val('');
    $('#coupon_id_'+id).val('');
    $('#get_coupon_id_'+id).val('');
}
function remove_prom_coupon_detail_trig() {
    $('#promotion_id_trig').val('');
    $('#coupon_id_trig').val('');
    $('#get_promotion_id_trig').val('');
    $('#get_coupon_id_trig').val('');
}
function remove_prom_coupon_detail_Normal_Activity() {
    $('#promotion_id_normal_acti').val('');
    $('#coupon_id_normal_acti').val('');
    $('#get_promotion_id_normal_acti').val('');
    $('#get_coupon_id_normal_acti').val('');
}
function remove_prom_coupon_detail_date() {
    $('#promotion_id_date').val('');
    $('#coupon_id_date').val('');
    $('#get_promotion_id_date').val('');
    $('#get_coupon_id_date').val('');
}
function remove_prom_coupon_detail_activity() {
    $('#promotion_id_activi').val('');
    $('#coupon_id_activi').val('');
    $('#get_promotion_id_activi').val('');
    $('#get_coupon_id_activi').val('');
}
//Remove_event function clear value of event place textbox at the time of edit
function remove_event(id) {
    $('#event_place'+id).val('');
}
//Product Portfolio ID Trigger subtype Add more button functionality
function addProductPortfolio() {
    var wrapper_product_trig = $(".input_fields_link_product_trig"); //Fields wrapper
    var max_fields = 100;
    var pr;
    if ($("#product_count").val()) {
        pr = $("#product_count").val();
    } else {
        pr = 1; //initlal text box count
    }
    if (pr < max_fields) { //max input box allowed
        pr++; //text box increment
        $("#product_count").val(pr);
        var appendhtml = '<div class="row">';
        appendhtml += '<div class="item w15">';
        appendhtml += '<label for="product_id_trig">Link Product Portfolio<span class="required">*</span></label>';
        appendhtml += '</div>';
        appendhtml += '<div class="item w30">';
        appendhtml += '<input type="text" name="trig_link_product_name[]" id="trig_link_product_name' + pr + '" class="trig_link_product" value="" required="required" readonly />';
        appendhtml += '<input type="hidden" name="trig_link_product_id[]" id="trig_link_product_id' + pr + '" value="" />';
        appendhtml += '<input type="button" name="btn_link_product" id="btn_link_product" tabindex="0" title="Select Product" class="button firstChild" value="Search" onclick="getProductsList(' + pr + ',\'trig_link_product_\');" />';
        appendhtml += '</div>';
        appendhtml += '<a href="#" class="remove_product_field">Remove</a></div>';
        $(wrapper_product_trig).append(appendhtml); //add input box
    }

    $(wrapper_product_trig).on("click", ".remove_product_field", function (e) { //user click on remove text
        e.preventDefault();
        $(this).parent('div').remove();
        pr--;
    });
}
//Promotion ID Subtype Trigger Add more button functionality
function addPromotionCouponTrigger() {
    var wrapper_promotion_subtype_trig = $(".input_fields_promotion_id_trig"); //Fields wrapper
    var max_fields = 10;
    var p;
    if ($("#promotion_trig_count").val()) {
        p = $("#promotion_trig_count").val();
    } else {
        p = 1; //initlal text box count
    }
    if(p < max_fields){ //max input box allowed
        p++; //text box increment
        $("#promotion_trig_count").val(p);
        var appendhtml ='<div class="row">';
         appendhtml +='<div class="item w15">';
            appendhtml +='<label for="promotion_id_trig">Promotion ID</label>';
        appendhtml +='</div>';
        appendhtml +='<div class="item w30">';
           appendhtml +='<input type="text" name="promotion_id_trig[]" id="promotion_id_trig'+p+'" class="promotion_id_trig" value="" required="required" readonly />';
            appendhtml +='<input type="hidden" name="get_promotion_id_trig[]" id="get_promotion_id_trig'+p+'" value="" />';
            appendhtml +='<input type="button" name="btn_trig_promotion_name" id="btn_trig_promotion_name" tabindex="0" title="Select Promotions" class="button firstChild" value="Search" onclick="getTrigPromotionsList('+p+');" />';
        appendhtml +='</div>';
        appendhtml +='<div class="item w15">';
            appendhtml +='<label for="coupon_id_trig">Link Coupon</label>';              
        appendhtml +='</div>';
        appendhtml +='<div class="item w30">';
            appendhtml +='<input type="text" name="coupon_id_trig[]" id="coupon_id_trig'+p+'" class="coupon_id_trig" value="" readonly />';
            appendhtml +='<input type="hidden" name="get_coupon_id_trig[]" id="get_coupon_id_trig'+p+'" value="" />';
            appendhtml +='<input type="button" name="btn_trig_coupon_name" id="btn_trig_coupon_name" tabindex="0" title="Select Coupons" class="button firstChild" value="Search" onclick="getTrigCouponsList('+p+');" />';
        appendhtml +='</div>';
        appendhtml +='<a href="#" class="remove_promotion_subtype_field">Remove</a></div>';
        $(wrapper_promotion_subtype_trig).append(appendhtml); //add input box
    }

    $(wrapper_promotion_subtype_trig).on("click",".remove_promotion_subtype_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); p--;
    });
}
//Promotion ID Subtype Date Add more button functionality
function addPromotionCouponDate(){
    var wrapper_promotion_subtype_date = $(".input_fields_promotion_id_date"); //Fields wrapper
    var max_fields = 10;
    var q;
    if ($("#promotion_date_count").val()) {
        q = $("#promotion_date_count").val();
    } else {
        q = 1; //initlal text box count
    }
    if(q < max_fields){ //max input box allowed
        q++; //text box increment
        $("#promotion_date_count").val(q);
        var appendhtml ='<div class="row">';
         appendhtml +='<div class="item w15">';
            appendhtml +='<label for="promotion_id_date">Promotion ID</label>';
        appendhtml +='</div>';
        appendhtml +='<div class="item w30">';
           appendhtml +='<input type="text" name="promotion_id_date[]" id="promotion_id_date'+q+'" class="promotion_id_date" value="" required="required" readonly />';
            appendhtml +='<input type="hidden" name="get_promotion_id_date[]" id="get_promotion_id_date'+q+'" value="" />';
            appendhtml +='<input type="button" name="btn_date_promotion_name" id="btn_date_promotion_name" tabindex="0" title="Select Promotions" class="button firstChild" value="Search" onclick="getDatePromotionsList('+q+');" />';
        appendhtml +='</div>';
        appendhtml +='<div class="item w15">';
            appendhtml +='<label for="coupon_id_date">Link Coupon</label>';
        appendhtml +='</div>';
        appendhtml +='<div class="item w30">';
            appendhtml +='<input type="text" name="coupon_id_date[]" id="coupon_id_date'+q+'" class="coupon_id_date" value="" readonly />';
            appendhtml +='<input type="hidden" name="get_coupon_id_date[]" id="get_coupon_id_date'+q+'" value="" />';
            appendhtml +='<input type="button" name="btn_date_coupon_name" id="btn_date_coupon_name" tabindex="0" title="Select Coupons" class="button firstChild" value="Search" onclick="getDateCouponsList('+q+');" />';
        appendhtml +='</div>';
        appendhtml +='<a href="#" class="remove_promotion_subtype_date_field">Remove</a></div>';
        $(wrapper_promotion_subtype_date).append(appendhtml); //add input box
    }
    
    $(wrapper_promotion_subtype_date).on("click",".remove_promotion_subtype_date_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); q--;
    });
}
//Promotion ID Subtype Activity Add more button functionality
function addPromotionCouponActivity(){
    var wrapper_promotion_subtype_activi = $(".input_fields_promotion_id_activi"); //Fields wrapper
    var max_fields = 10;
    var r;
    if ($("#promotion_activity_count").val()) {
        r = $("#promotion_activity_count").val();
    } else {
        r = 1; //initlal text box count
    }
    if(r < max_fields){ //max input box allowed
            r++; //text box increment
            $("#promotion_activity_count").val(r);
            var appendhtml ='<div class="row">';
             appendhtml +='<div class="item w15">';
                appendhtml +='<label for="promotion_id_activi">Promotion ID</label>';
            appendhtml +='</div>';
            appendhtml +='<div class="item w30">';
                appendhtml +='<input type="text" name="promotion_id_activi[]" id="promotion_id_activi'+r+'" class="promotion_id_activi" value="" required="required" readonly />';
                appendhtml +='<input type="hidden" name="get_promotion_id_activi[]" id="get_promotion_id_activi'+r+'" value="" />';
                appendhtml +='<input type="button" name="btn_activi_promotion_name" id="btn_activi_promotion_name" tabindex="0" title="Select Promotions" class="button firstChild" value="Search" onclick="getActivityPromotionsList('+r+');" />';
            appendhtml +='</div>';
            appendhtml +='<div class="item w15">';
                appendhtml +='<label for="coupon_id_activi">Link Coupon</label>';
            appendhtml +='</div>';
            appendhtml +='<div class="item w30">';
                appendhtml +='<input type="text" name="coupon_id_activi[]" id="coupon_id_activi'+r+'" class="coupon_id_activi" value="" readonly />';
                appendhtml +='<input type="hidden" name="get_coupon_id_activi[]" id="get_coupon_id_activi'+r+'" value="" />';
                appendhtml +='<input type="button" name="btn_activi_coupon_name" id="btn_activi_coupon_name" tabindex="0" title="Select Coupons" class="button firstChild" value="Search" onclick="getActivityCouponsList('+r+');" />';
            appendhtml +='</div>';
            appendhtml +='<a href="#" class="remove_promotion_subtype_activi_field">Remove</a></div>';
            $(wrapper_promotion_subtype_activi).append(appendhtml); //add input box
        }

    $(wrapper_promotion_subtype_activi).on("click",".remove_promotion_subtype_activi_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); r--;
    });
    
}
//Promotion ID Subtype Normal Activity Add more button functionality
function addPromotionCouponNormalActivity(){
    var wrapper_promotion_subtype_normal_acti = $(".input_fields_promotion_id_normal_acti"); //Fields wrapper
    var max_fields = 10;
    var na;
    if ($("#promotion_normal_count").val()) {
        na = $("#promotion_normal_count").val();
    } else {
        na = 1; //initlal text box count
    }
    if (na < max_fields){ //max input box allowed
        na++; //text box increment
        $("#promotion_normal_count").val(na);
        var appendhtml = '<div class="row">';
        appendhtml += '<div class="item w15">';
        appendhtml += '<label for="promotion_id_normal_acti">Promotion ID</label>';
        appendhtml += '</div>';
        appendhtml += '<div class="item w30">';
        appendhtml += '<input type="text" name="promotion_id_normal_acti[]" id="promotion_id_normal_acti' + na + '" class="promotion_id_normal_acti" value="" readonly />';
        appendhtml += '<input type="hidden" name="get_promotion_id_normal_acti[]" id="get_promotion_id_normal_acti' + na + '" value="" />';
        appendhtml += '<input type="button" name="btn_normal_acti_promotion_name" id="btn_normal_acti_promotion_name" tabindex="0" title="Select Promotions" class="button firstChild" value="Search" onclick="getNormalActivityPromotionsList(' + na + ');" />';
        appendhtml += '</div>';
        appendhtml += '<div class="item w15">';
        appendhtml += '<label for="coupon_id_normal_acti">Link Coupon</label>';
        appendhtml += '</div>';
        appendhtml += '<div class="item w30">';
        appendhtml += '<input type="text" name="coupon_id_normal_acti[]" id="coupon_id_normal_acti' + na + '" class="coupon_id_normal_acti" value="" readonly />';
        appendhtml += '<input type="hidden" name="get_coupon_id_normal_acti[]" id="get_coupon_id_normal_acti' + na + '" value="" />';
        appendhtml += '<input type="button" name="btn_normal_acti_coupon_name" id="btn_normal_acti_coupon_name" tabindex="0" title="Select Promotions" class="button firstChild" value="Search" onclick="getNormalActivityCouponsList(' + na + ');" />';
        appendhtml += '</div>';
        appendhtml += '<a href="#" class="remove_promotion_normal_acti_subtype_field">Remove</a></div>';
        $(wrapper_promotion_subtype_normal_acti).append(appendhtml); //add input box
    }

    $(wrapper_promotion_subtype_normal_acti).on("click", ".remove_promotion_normal_acti_subtype_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); na--;
    });
}