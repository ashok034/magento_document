$(document).ready(function () {
    $('#campaign_list').DataTable({
        "paging": true,
        "columns": [{"orderable": false}, null, null, null, {"orderable": false}, null, null, null, null, {"orderable": false}, {"orderable": false}],
        "bFilter": false,
        "lengthChange": false,
        "iDisplayLength": 50//remove customer id value of Null
    });
    $("#search_form_clear_advanced").on('click', function () {
        $("#search_form_submit_advanced").trigger("click");
    });
});
//Campaign Start Date
Calendar.setup({
    inputField: "range_start_date_advanced",
    daFormat: "%d-%m-%Y %I:%M%P",
    button: "start_date_advanced_trigger",
    singleClick: true,
    dateStr: "",
    startWeekday: 0,
    step: 1,
    weekNumbers: false
});
//Campaign End Date
Calendar.setup({
    inputField: "range_end_date_advanced",
    daFormat: "%d-%m-%Y %I:%M%P",
    button: "end_date_advanced_trigger",
    singleClick: true,
    dateStr: "",
    startWeekday: 0,
    step: 1,
    weekNumbers: false
});
//Submit form on Enter Button
function submitOnEnter(e) {
    var characterCode = (e && e.which) ? e.which : event.keyCode;
    if (characterCode == 13) {
        document.getElementById('search_form').submit();
        return false;
    } else {
        return true;
    }
}
//Get Campaign Subtypes based on Campaign Type
function getSubtype() {
    var url_data = $('#siteurl').val();
    $.ajax({
        url: url_data + '/index.php?module=Campaigns&action=getsubtype',
        data: {cid: $('select#campaign_type_advanced').val()},
        type: 'post',
        success: function (output) {
            $('#campaign_subtype_advanced').html(output);
        }
    });
}
//Campaign Active and call cron for send Email/SMS to all related customer
function updateActiveStatusCampaign() {
    if (confirm('Are you sure you want to activate campaign(s)?')) {
        var url_data = $('#siteurl').val();
        var checkValues = $('input[name=mass[]]:checked').map(function () {
            return $(this).val();
        }).get();
        $('#loading_image').show();
        $.ajax({
            url: url_data + '/index.php?module=Campaigns&action=updateActiveCampaign',
            data: {cid: checkValues},
            type: 'post',
            success: function (output) {
                if (output != '') {
                    $('#loading_image').hide();
                    //alert(output);
                    alert('Campaign status has been changed successfully');
                    window.location.reload();
                }else{
                    $('#loading_image').hide();
                    alert('Please select at least 1 record to proceed.');
                }
            }
        });
    }
}
//Campagin Inactive
function updateInActiveStatusCampaign() {
    if (confirm('Are you sure you want to Deactivate campaign(s)?')) {
        var url_data = $('#siteurl').val();
        var checkValues = $('input[name=mass[]]:checked').map(function () {
            return $(this).val();
        }).get();
        $('#loading_image').show();
        $.ajax({
            url: url_data + '/index.php?module=Campaigns&action=updateInActiveCampaign',
            data: {cid: checkValues},
            type: 'post',
            success: function (output) {
                if (output == 1) {
                    $('#loading_image').hide();
                    alert('Campaign status has been changed successfully');
                    window.location.reload();
                }else{
                    $('#loading_image').hide();
                    alert('Please select at least 1 record to proceed.');
                }
            }
        });
    }
}
//Delete Campaigns
function deleteCampaign() {
    var url_data = $('#siteurl').val();
    var checkValues = $('input[name=mass[]]:checked').map(function () {
        return $(this).val();
    }).get();
    $('#loading_image').show();
    $.ajax({
        url: url_data + '/index.php?module=Campaigns&action=deleteCampaign',
        data: {cid: checkValues},
        type: 'post',
        success: function (output) {
            if (output == 1) {
                $('#loading_image').hide();
                alert('Campaign has been removed.');
                window.location.reload();
            }else{
                $('#loading_image').hide();
                alert('Please select at least 1 record to proceed.');
            }
        }
    });
}
//Campagin Clone
function cloneCampaign(campaignID) {
    if (confirm('Are you sure you want to clone the campaign(s)?')) {
        var url_data = $('#siteurl').val();
        $('#loading_image').show();
        $.ajax({
            url: url_data + '/index.php?module=Campaigns&action=clone',
            data: {record: campaignID},
            type: 'post',
            success: function (output) {
                if (output == 1) {
                    $('#loading_image').hide();
                    alert('Campaign has been cloned successfully.');
                    window.location.reload();
                }else{
                    $('#loading_image').hide();
                    alert('Campaign not cloned.');
                }
            }
        });
    }
}