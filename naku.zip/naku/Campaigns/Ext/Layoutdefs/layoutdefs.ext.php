<?php 
 //WARNING: The contents of this file are auto-generated


 unset($layout_defs['Campaigns']['subpanel_setup']['prospectlists']); 
 unset($layout_defs['Campaigns']['subpanel_setup']['tracked_urls']); 
 unset($layout_defs['Campaigns']['subpanel_setup']['emailmarketing']); 
 unset($layout_defs['Campaigns']['subpanel_setup']['track_queue']); 
 unset($layout_defs['Campaigns']['subpanel_setup']['targeted']); 
 unset($layout_defs['Campaigns']['subpanel_setup']['viewed']); 
 unset($layout_defs['Campaigns']['subpanel_setup']['link']); 
 unset($layout_defs['Campaigns']['subpanel_setup']['lead']); 
 unset($layout_defs['Campaigns']['subpanel_setup']['contact']); 
 unset($layout_defs['Campaigns']['subpanel_setup']['invalid_email']); 
 unset($layout_defs['Campaigns']['subpanel_setup']['send_error']); 
 unset($layout_defs['Campaigns']['subpanel_setup']['removed']); 
 unset($layout_defs['Campaigns']['subpanel_setup']['blocked']); 
 unset($layout_defs['Campaigns']['subpanel_setup']['accounts']); 
 unset($layout_defs['Campaigns']['subpanel_setup']['leads']); 
 unset($layout_defs['Campaigns']['subpanel_setup']['opportunities']);

?>