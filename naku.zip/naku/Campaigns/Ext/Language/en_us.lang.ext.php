<?php 
 //WARNING: The contents of this file are auto-generated


$mod_strings['LBL_ASSET_USER_ID_C'] = 'Asset ID';



if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
$mod_strings['LBL_CREATE_CAMPAIGN'] = 'New Product Launch';
$mod_strings['LBL_CAMPAIGN_START_DATE'] = 'Start Date';
$mod_strings['LBL_CAMPAIGN_END_DATE'] = 'End Date';
$mod_strings['LBL_CAMPAIGN_NAME'] = 'Campaign Name';
$mod_strings['LBL_CAMPAIGN_TYPE'] = 'Campaign Type';
$mod_strings['LBL_CAMPAIGN_SUBTYPE'] = 'Campaign Subtype';
$mod_strings['LBL_CAMPAIGN_CONTENT'] = 'Campaign Description';
$mod_strings['LBL_CAMPAIGN_STATUS'] = 'Status';
$mod_strings['LBL_CAMPAIGN_COUNTRY'] = 'Select Country';
$mod_strings['LBL_CAMPAIGN_ID'] = 'Campaign ID';
$mod_strings['LBL_CAMPAIGN_ESTIMATED_REVENUE'] = 'Estimated Revenue';
$mod_strings['LBL_CAMPAIGN_ALLOCATE_BUDGET'] = 'Allocated Budget';
$mod_strings['LBL_CAMPAIGN_COST'] = 'Campaign Cost';
$mod_strings['LBL_CAMPAIGN_OWNER'] = 'Campaign Owner';
$mod_strings['LBL_CAMPAIGN_SUPPLIER_ID'] = 'Supplier ID';
$mod_strings['LBL_CAMPAIGN_COST_CONTRIBUTION'] = 'Cost Contribution';
$mod_strings['LBL_CAMPAIGN_PROMOTION_ID'] = 'Link Promotion ID';
$mod_strings['LBL_CAMPAIGN_TYPE_SELECTED'] = 'Campaign Type Selected';
$mod_strings['LBL_CAMPAIGN_SUBTYPES'] = 'Campaign Subtypes';
$mod_strings['LBL_CAMPAIGN_SUB_TYPE'] = 'Sub-type';
$mod_strings['LBL_CAMPAIGN_DURATION_FROM'] = 'Duration From Date';
$mod_strings['LBL_CAMPAIGN_DURATION_TO'] = 'Duration To Date';
$mod_strings['LBL_CAMPAIGN_ACTIVITY_COST'] = 'Activity Cost';
$mod_strings['LBL_CAMPAIGN_MARKETING_LIST'] = 'Marketing List';
$mod_strings['LBL_CAMPAIGN_ACTIVITY_TYPE'] = 'Activity type';
$mod_strings['LBL_CAMPAIGN_TRIGGER_BASED'] = 'Trigger based';
$mod_strings['LBL_CAMPAIGN_DATE_BASED'] = 'Date based';
$mod_strings['LBL_CAMPAIGN_ACTIVITY_BASED'] = 'Activity based';
$mod_strings['LBL_NORMAL_CAMPAIGN_ACTIVITY'] = 'Normal Activity';
$mod_strings['LBL_CAMPAIGN_ACTIVITY_EMAIL'] = 'Campaign Activity - Email';
$mod_strings['LBL_CAMPAIGN_ACTIVITY_SMS'] = 'Campaign Activity - SMS';
$mod_strings['LBL_CAMPAIGN_ACTIVITY_SOCIAL_MEDIA'] = 'Campaign Activity - Social media';
$mod_strings['LBL_CAMPAIGN_ACTIVITY_INSTORE_DANGLERS'] = 'Campaign Activity - Instore Danglers';
$mod_strings['LBL_CAMPAIGN_ACTIVITY_STANDERS'] = 'Campaign Activity - Standers';
$mod_strings['LBL_CAMPAIGN_ACTIVITY_FLYERS'] = 'Campaign Activity - Flyers';
$mod_strings['LBL_CAMPAIGN_ACTIVITY_DIGITAL_SCREEN'] = 'Campaign Activity - Digital Screen';
$mod_strings['LBL_CAMPAIGN_ACTIVITY_PASYSTEM'] = 'Campaign Activity - PA System';
$mod_strings['LBL_CAMPAIGN_ACTIVITY_TILLADS'] = 'Campaign Activity - Till Ads';
$mod_strings['LBL_CAMPAIGN_SET_SUBTYPE_ATTRIBUTES'] = 'Set Subtype Attributes';
$mod_strings['LBL_CAMPAIGN_SELECT_ACTIVITY'] = 'Select Activity';
$mod_strings['LBL_CAMPAIGN_LINK_COUPON'] = 'Link Coupon';
$mod_strings['LBL_CAMPAIGN_LINK_PRODUCT_PORTFOLIO'] = 'Link Product Portfolio';
$mod_strings['LBL_CAMPAIGN_LINK_TEMPLATE'] = 'Link template';
$mod_strings['LBL_CAMPAIGN_COMMENTS'] = 'Comments';
$mod_strings['LBL_CAMPAIGN_SUBTYPE_ID'] = 'Sub-type Campaign ID';
$mod_strings['LBL_CAMPAIGN_SUBTYPE_POPUP'] = 'Campaign Subtype';
$mod_strings['LBL_CAMPAIGN_LINK'] = 'Link';
$mod_strings['LBL_CAMPAIGN_SAVE'] = 'SAVE';
$mod_strings['LBL_CAMPAIGN_CANCEL'] = 'CANCEL';
$mod_strings['LBL_CAMPAIGN_ATTACH'] = 'Attach';
$mod_strings['LBL_CAMPAIGN_SEARCH'] = 'Search';
$mod_strings['LBL_CAMPAIGN_ID_C'] = 'Campaign ID';
$mod_strings['LBL_LATITUDE'] = 'Latitude';
$mod_strings['LBL_LONGITUDE'] = 'Longitude';
$mod_strings['LBL_EVENT_NAME'] = 'Event Name';
$mod_strings['LBL_EVENT_DESCRIPTION'] = 'Event Description';
$mod_strings['LBL_EVENT_PLACE'] = 'Event Place';
$mod_strings['LBL_EDIT'] = 'Edit';
$mod_strings['LBL_DELETE'] = 'Delete';
$mod_strings['LBL_ASSET_ID_LIST'] = 'Link Banner For List';
$mod_strings['LBL_ASSET_ID_DETAIL'] = 'Link Banner For Detail';
$mod_strings['LBL_NAKU_COST_CONTRIBUTION_C'] = 'Nakumatt\'s Cost Contribution';
$mod_strings['LBL_NAKU_COST_TYPE_C'] = 'Nakumatt\'s Cost Type';
$mod_strings['LBL_SUB_TYPE'] = 'Sub Type';
$mod_strings['LBL_STORE_TYPE'] = 'Store Type';
$mod_strings['LBL_STORE_IN'] = 'Inside';
$mod_strings['LBL_STORE_OUT'] = 'Outside';
$mod_strings['LBL_STORE'] = 'Select Store(Branch)';

?>