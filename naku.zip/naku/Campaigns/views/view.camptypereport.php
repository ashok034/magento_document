<?php
if (!defined('sugarEntry'))
    define('sugarEntry', true);
	
	
class CampaignsViewCamptypereport extends SugarView {

   public function display() {
		global $mod_strings, $sugar_config;
		$smarty = new Sugar_Smarty();
		$smarty->assign('SITE_URL', $sugar_config['site_url']);
		$cmp='';
		
      //Fetch the options for Cmapaign type dropdown
      if (!empty($this->view_object_map['Camp_Type'])) {
         foreach ($this->view_object_map['Camp_Type'] as $cmpkey => $cmpval) {
            if($_POST['campaign_type'] == $cmpkey) {
				$cmp.='<option selected="selected" value="' . $cmpkey . '">' . $cmpval . '</option>';
				$selected_type_name = $cmpval;
			} else
               $cmp.='<option value="' . $cmpkey . '">' . $cmpval . '</option>';
         }
      }
		
		//Fetch the options for Cmapaign SubType dropdown
        $sql = "SELECT * FROM `camp_subtype` where deleted=0";
        $result_subtype = $GLOBALS['db']->query($sql);
        if ($result_subtype->num_rows > 0) {
            $camp_subtype = array();
            $camp_subtype[] = ['id' => 'all', 'name'=>'All'];
            while ($row = $GLOBALS['db']->fetchByAssoc($result_subtype)) {
                $camp_subtype[] = $row;
            }
            $this->view_object_map['camp_subtype'] = $camp_subtype;
		}
		$selected_sub_type_name = '';
		if ($_POST['campaign_subtype'] == 'all') {
			$selected_sub_type_name = 'All';
		}
		
		if($_POST['campaign_type'] && $_POST['campaign_subtype'])
		{
			if ($this->view_object_map['camp_subtype']) {
					foreach ($this->view_object_map['camp_subtype'] as $sub_type) {
						if ($sub_type['type_id'] == $_POST['campaign_type'] || $_POST['campaign_type'] =='all' || $sub_type['id'] == 'all') {
							if ($sub_type['id'] == $_POST['campaign_subtype']) {
                       			$selected_sub_type_name = $sub_type['name'];
								$cmp_subtype_selected_name[$sub_type['id']] = $sub_type['name'];
								$cmp_subtype.='<option  selected="selected" value="' . $sub_type['id'] . '">' . $sub_type['name'] . '</option>';
							} else {
								$cmp_subtype.='<option value="' . $sub_type['id'] . '">' . $sub_type['name'] . '</option>';
							}
						}
					}
				} 
		}
		      
      	$smarty->assign('ctype_name', $this->view_object_map['ctype_name']);
      	$smarty->assign('csubtype_name', $selected_sub_type_name);
      	$smarty->assign('report_data',$this->view_object_map['report_data']);
      
      	//dropdown options for CampaignType and SubType
		$smarty->assign('Camp_Type', $cmp);	
		$smarty->assign('cmp_subtype', $cmp_subtype);	
		$smarty->assign('Camp_data', $_POST);

		$quarterOptions = '<select required>';
		foreach ($this->view_object_map['quarterOptions'] as $key => $quarterOption) {
			$quarterOptions .= "<option value= ".$key.">". $quarterOption['name']." (".$quarterOption['year'] .")</option>";
		}
		$quarterOptions .= '</select>';
		$smarty->assign('QuarterOption', $quarterOptions);

		//Get the report_peiods	in a string 
		//$periodsSelected = implode(',', $_POST['report_period']);
		//$smarty->assign('Report_Period', $periodsSelected);

        $smarty->display("custom/modules/Campaigns/tpls/camptypereport.tpl");
    }
}
?>
