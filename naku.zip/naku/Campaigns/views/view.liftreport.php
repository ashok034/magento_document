<?php
class CampaignsViewliftreport extends SugarView {

    public function display() {
        global $mod_strings, $sugar_config, $app_list_strings;
        $smarty = new Sugar_Smarty();
        $cmp = '';
        if (!empty($this->view_object_map['Camp_Type'])) {
            foreach ($this->view_object_map['Camp_Type'] as $cmpkey => $cmpval) {
                if ($_POST['campaign_type'] == $cmpkey)
                    $cmp.='<option selected="selected" value="' . $cmpkey . '">' . $cmpval . '</option>';
                else
                    $cmp.='<option value="' . $cmpkey . '">' . $cmpval . '</option>';
            }
        }
        // get all subtype record
        $sql = "SELECT * FROM `camp_subtype` where deleted=0";
        $result_subtype = $GLOBALS['db']->query($sql);
        if ($result_subtype->num_rows > 0) {
            $camp_subtype = array();
            while ($row = $GLOBALS['db']->fetchByAssoc($result_subtype)) {
                $camp_subtype[] = $row;
            }
            $this->view_object_map['camp_subtype'] = $camp_subtype;
        }
        if ($_POST['campaign_type'] && $_POST['campaign_subtype']) {
            if ($this->view_object_map['camp_subtype']) {
                foreach ($this->view_object_map['camp_subtype'] as $sub_type) {

                    if ($sub_type['type_id'] == $_POST['campaign_type']) {
                        if ($sub_type['id'] == $_POST['campaign_subtype']) {
                            $cmp_subtype_selected_name[$sub_type['id']] = $sub_type['name'];
                            $cmp_subtype.='<option  selected="selected" value="' . $sub_type['id'] . '">' . $sub_type['name'] . '</option>';
                        } else {
                            $cmp_subtype.='<option value="' . $sub_type['id'] . '">' . $sub_type['name'] . '</option>';
                        }
                    }
                }
            }
        }
        $smarty->assign('Camp_Type', $cmp);
        $smarty->assign('cmp_subtype', $cmp_subtype);
        $smarty->assign('Camp_data', $_POST);
        $smarty->assign('getTimePeriod', $this->view_object_map['getTimePeriod']);
        $smarty->display("custom/modules/Campaigns/tpls/campaignliftreport.tpl");
    }

}
?>