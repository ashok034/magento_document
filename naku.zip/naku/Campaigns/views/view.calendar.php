<?php
if (!defined('sugarEntry'))
    define('sugarEntry', true);

class CampaignsViewCalendar extends SugarView {

    public function display() {
        global $mod_strings, $sugar_config;
        $smarty = new Sugar_Smarty();
        $smarty->assign('LBL_CAMPAIGN_TYPE', $mod_strings['LBL_CAMPAIGN_TYPE']);
        $smarty->assign('LBL_CAMPAIGN_SUBTYPE', $mod_strings['LBL_CAMPAIGN_SUBTYPE']);
        $smarty->assign('campaign', $this->view_object_map['campaign']);
		$smarty->assign('campaignType', $this->view_object_map['campaignType']);
		$smarty->assign('campaignSubtype', $this->view_object_map['campaignSubtype']);
        $smarty->assign('SITE_URL', $sugar_config['site_url']);
        $cmp = '<option value="">Select</option>';
        if (!empty($this->view_object_map['Camp_Type'])) {
            foreach ($this->view_object_map['Camp_Type'] as $cmpkey => $cmpval) {
                $cmp.='<option value="' . $cmpkey . '">' . $cmpval . '</option>';
            }
        }
        $smarty->assign('Camp_Type', $cmp);
        
        $smarty->assign('createCalIcon', $this->view_object_map['createCalIcon']);
        $smarty->assign('editCalIcon', $this->view_object_map['editCalIcon']);
        $smarty->assign('viewCalIcon', $this->view_object_map['viewCalIcon']);
        $smarty->assign('searchCalIcon', $this->view_object_map['searchCalIcon']);
        $smarty->assign('exportCalIcon', $this->view_object_map['exportCalIcon']);
        $smarty->assign('adminRole', $this->view_object_map['adminRole']);
        
        $smarty->display("custom/modules/Campaigns/tpls/calendar.tpl");
    }

}
?>