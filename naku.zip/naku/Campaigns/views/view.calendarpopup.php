<?php
class CampaignsViewCalendarPopup extends SugarView{
    public $options = array('show_header' => false, 'show_title' => true, 'show_subpanels' => false, 'show_search' => true, 'show_footer' => false, 'show_javascript' => true, 'view_print' => false,);
    function CampaignsViewCalendarPopup(){
        
		parent::SugarView($this->options);
	} 
    public function display()
    {
        global $mod_strings, $sugar_config;
        $smarty = new Sugar_Smarty();
		$smarty->assign('SITE_URL',$sugar_config['site_url']);
        $smarty->assign('campaign', $this->view_object_map['campaign']);
        $smarty->display("custom/modules/Campaigns/tpls/calendarpopup.tpl");
    }
}
?>