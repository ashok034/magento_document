<?php
if (!defined('sugarEntry'))
    define('sugarEntry', true);
	
class CampaignsViewResponserate extends SugarView { 

    public function display() {
		global $mod_strings, $sugar_config;
		$smarty = new Sugar_Smarty();
		$smarty->assign('SITE_URL', $sugar_config['site_url']);
		$cmp='';
		if (!empty($this->view_object_map['Camp_Type'])) {
                foreach ($this->view_object_map['Camp_Type'] as $cmpkey => $cmpval) {
					if($_POST['campaign_type']==$cmpkey)
						   $cmp.='<option selected="selected" value="' . $cmpkey . '">' . $cmpval . '</option>';
					else
					   $cmp.='<option value="' . $cmpkey . '">' . $cmpval . '</option>';
                }
        }
		
		// get all subtype record
        $sql = "SELECT * FROM `camp_subtype` where deleted=0";
        $result_subtype = $GLOBALS['db']->query($sql);
        if ($result_subtype->num_rows > 0) {
            $camp_subtype = array();
            while ($row = $GLOBALS['db']->fetchByAssoc($result_subtype)) {
                $camp_subtype[] = $row;
            }
            $this->view_object_map['camp_subtype'] = $camp_subtype;
		}	
		if($_POST['campaign_type'] && $_POST['campaign_subtype'])
		{	
			
			if ($this->view_object_map['camp_subtype']) {
				foreach ($this->view_object_map['camp_subtype'] as $sub_type) {
					if ($sub_type['type_id'] == $_POST['campaign_type']
						&& in_array($sub_type['name'], $this->view_object_map['allowedSubTypes'])
					) {
						if ($sub_type['id']==$_POST['campaign_subtype']) {
							$cmp_subtype_selected_name[$sub_type['id']] = $sub_type['name'];
							$cmp_subtype.='<option  selected="selected" value="' . $sub_type['id'] . '">' . $sub_type['name'] . '</option>';
						} else {
							$cmp_subtype.='<option value="' . $sub_type['id'] . '">' . $sub_type['name'] . '</option>';
						}
					}
				}
			} 
		}
		
		$campStatuses = array(''=>'Please Select','all'=>'All' , 'active' => 'Active', 'ended' => 'Ended');
		$cmp_status = '';
		foreach ($campStatuses as $key => $status) {
			$cmp_status.='<option value="'. $key .'"' .($_POST['campaign_status'] == $key ? ' selected' : '') .'>' . $status .' </option>';
		}
		if ($_POST['campaign_id'] == 'all') {
			$smarty->assign('campaign_id_all', 'All');
		}	
        $smarty->assign('ctype_name',$this->view_object_map['ctype_name']);	
        $smarty->assign('csubtype_name',$this->view_object_map['csubtype_name']);	
        $smarty->assign('report_data',$this->view_object_map['report_data']);	
		$smarty->assign('Camp_Type', $cmp);	
		$smarty->assign('cmp_subtype', $cmp_subtype);	
		$smarty->assign('cmp_status', $cmp_status);	
		$smarty->assign('Camp_data', $_POST);
		$smarty->assign('campaigns', $this->view_object_map['campaigns']);
		
		$MonthlyOption = '<select required onchange=validateToDate(this)>';
		$count = 1;
		foreach ($this->view_object_map['createMonthdd'] as $monthOption) {
			$MonthlyOption .= "<option value= $monthOption count=$count> $monthOption </option>";
			$count++;
		}
		$MonthlyOption .= '</select>';

		$quarterOptions = '<select required  onchange=validateToDate(this)>';
		$count = 1;
		foreach ($this->view_object_map['quarterOptions'] as $key => $quarterOption) {
			$quarterOptions .= "<option count=$count value= ".$key.">". $quarterOption['name']." (".$quarterOption['year'] .")</option>";
			$count++;
		}
		$quarterOptions .= '</select>';
				
		$smarty->assign('MonthlyOption', $MonthlyOption);
		$smarty->assign('QuarterOption', $quarterOptions);
        $smarty->display("custom/modules/Campaigns/tpls/responserate.tpl");
    }
}
?>
