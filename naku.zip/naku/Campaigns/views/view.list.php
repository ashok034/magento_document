<?php
class CampaignsViewList extends SugarView {
    public function display() {
        global $mod_strings,$sugar_config;
        $smarty = new Sugar_Smarty();
        $smarty->assign('site_url', $sugar_config['site_url']);
        $smarty->assign('list_type', $this->view_object_map['list_type']);
        $smarty->assign('list_subtype', $this->view_object_map['list_subtype']);
        $smarty->assign('list_campaigns', $this->view_object_map['list_campaigns']);
        
        $smarty->assign('range_start_date_advanced', $this->view_object_map['range_start_date_advanced']);
        $smarty->assign('campaign_id_c_advanced', $this->view_object_map['campaign_id_c_advanced']);
        $smarty->assign('campaign_type_advanced', $this->view_object_map['campaign_type_advanced']);
        $smarty->assign('range_end_date_advanced', $this->view_object_map['range_end_date_advanced']);
        $smarty->assign('name_advanced', $this->view_object_map['name_advanced']);
        $smarty->assign('campaign_subtype_advanced', $this->view_object_map['campaign_subtype_advanced']);
        $smarty->assign('status_advanced', $this->view_object_map['status_advanced']);
        //Start Roles and Permission Hacks by Akhilesh
        $smarty->assign('viewIcon',     $this->view_object_map['viewIcon']);
        $smarty->assign('searchIcon',   $this->view_object_map['searchIcon']);
        $smarty->assign('createIcon',   $this->view_object_map['createIcon']);
        $smarty->assign('editIcon',     $this->view_object_map['editIcon']);
        $smarty->assign('exportIcon',   $this->view_object_map['exportIcon']);
        $smarty->assign('deleteIcon',   $this->view_object_map['deleteIcon']);
        $smarty->assign('approveIcon',  $this->view_object_map['approveIcon']);
        $smarty->assign('rejectIcon',   $this->view_object_map['rejectIcon']);
        $smarty->assign('cloneIcon',    $this->view_object_map['cloneIcon']);
        $smarty->assign('adminRole',    $this->view_object_map['adminRole']);
        //End Roles and Permission Hacks by Akhilesh
        $smarty->display("custom/modules/Campaigns/tpls/listview.tpl");
    }
}
?>