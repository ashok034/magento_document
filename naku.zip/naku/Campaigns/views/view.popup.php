<?php
class CampaignsViewPopup extends SugarView{
    public $options = array('show_header' => false, 'show_title' => true, 'show_subpanels' => false, 'show_search' => true, 'show_footer' => false, 'show_javascript' => true, 'view_print' => false,);
    function CampaignsViewPopup(){
        
		parent::SugarView($this->options);
	} 
    public function display()
    {
        global $mod_strings, $sugar_config;
        $smarty = new Sugar_Smarty();
		$smarty->assign('SITE_URL',$sugar_config['site_url']);
        $smarty->assign('currentpage', $this->view_object_map['currentpage']);
        $smarty->assign('dataRows', $this->view_object_map['dataRows']);
        $smarty->assign('totalpages', $this->view_object_map['totalpages']);
        $smarty->assign('rowsperpage', $this->view_object_map['rowsperpage']);
        $smarty->assign('numRows', $this->view_object_map['numRows']);
        $smarty->assign('nextDisabled', $this->view_object_map['nextDisabled']);
        $smarty->assign('prevDisabled', $this->view_object_map['prevDisabled']);
        $smarty->assign('paginationText', $this->view_object_map['paginationText']);
        $smarty->assign('prevpage', $this->view_object_map['prevpage']);
        $smarty->assign('nextpage', $this->view_object_map['nextpage']);
        if(!empty($_GET['mkid'])) {
            $smarty->assign('mkid',$_GET['mkid']);			
        }
        if(!empty($_GET['trig'])) {
            $smarty->assign('trig',$_GET['trig']);
        }	
        if(!empty($_GET['flag'])) {
            $smarty->assign('flag',$_GET['flag']);			
        }
        $smarty->display("custom/modules/Campaigns/tpls/popup.tpl");
    }
}
?>