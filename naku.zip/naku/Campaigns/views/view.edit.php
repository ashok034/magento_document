<?php

/* * *******************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 * ****************************************************************************** */

/**
 * Campaigns SugarCRM ViewEdit
 * @api
 */
class CampaignsViewEdit extends SugarView {

    public function display() {
        global $mod_strings, $sugar_config;
        $smarty = new Sugar_Smarty();
        //Define languange variabes
        $smarty->assign('SITE_URL', $sugar_config['site_url']);
        $smarty->assign('LBL_EDIT_EXISTING', $mod_strings['LBL_EDIT_EXISTING']);
        $smarty->assign('LBL_CREATE_NEW_CAMPAIGN', $mod_strings['LBL_CREATE_NEW_CAMPAIGN']);
        $smarty->assign('LBL_CAMPAIGN_START_DATE', $mod_strings['LBL_CAMPAIGN_START_DATE']);
        $smarty->assign('LBL_CAMPAIGN_END_DATE', $mod_strings['LBL_CAMPAIGN_END_DATE']);
        $smarty->assign('LBL_CAMPAIGN_NAME', $mod_strings['LBL_CAMPAIGN_NAME']);
        $smarty->assign('LBL_CAMPAIGN_TYPE', $mod_strings['LBL_CAMPAIGN_TYPE']);
        $smarty->assign('LBL_CAMPAIGN_SUBTYPE', $mod_strings['LBL_CAMPAIGN_SUBTYPE']);
        $smarty->assign('LBL_CAMPAIGN_CONTENT', $mod_strings['LBL_CAMPAIGN_CONTENT']);
        $smarty->assign('LBL_CAMPAIGN_STATUS', $mod_strings['LBL_CAMPAIGN_STATUS']);
        $smarty->assign('LBL_CAMPAIGN_COUNTRY', $mod_strings['LBL_CAMPAIGN_COUNTRY']);
        $smarty->assign('LBL_CAMPAIGN_ID', $mod_strings['LBL_CAMPAIGN_ID']);
        $smarty->assign('LBL_CAMPAIGN_ESTIMATED_REVENUE', $mod_strings['LBL_CAMPAIGN_ESTIMATED_REVENUE']);
        $smarty->assign('LBL_CAMPAIGN_ALLOCATE_BUDGET', $mod_strings['LBL_CAMPAIGN_ALLOCATE_BUDGET']);
        $smarty->assign('LBL_CAMPAIGN_COST', $mod_strings['LBL_CAMPAIGN_COST']);
        $smarty->assign('LBL_CAMPAIGN_OWNER', $mod_strings['LBL_CAMPAIGN_OWNER']);
        $smarty->assign('LBL_CAMPAIGN_SUPPLIER_ID', $mod_strings['LBL_CAMPAIGN_SUPPLIER_ID']);
        $smarty->assign('LBL_CAMPAIGN_COST_CONTRIBUTION', $mod_strings['LBL_CAMPAIGN_COST_CONTRIBUTION']);
        $smarty->assign('LBL_CAMPAIGN_PROMOTION_ID', $mod_strings['LBL_CAMPAIGN_PROMOTION_ID']);
        $smarty->assign('LBL_CAMPAIGN_TYPE_SELECTED', $mod_strings['LBL_CAMPAIGN_TYPE_SELECTED']);
        $smarty->assign('LBL_CAMPAIGN_SUBTYPES', $mod_strings['LBL_CAMPAIGN_SUBTYPES']);
        $smarty->assign('LBL_CAMPAIGN_SUB_TYPE', $mod_strings['LBL_CAMPAIGN_SUB_TYPE']);
        $smarty->assign('LBL_CAMPAIGN_DURATION_FROM', $mod_strings['LBL_CAMPAIGN_DURATION_FROM']);
        $smarty->assign('LBL_CAMPAIGN_DURATION_TO', $mod_strings['LBL_CAMPAIGN_DURATION_TO']);
        $smarty->assign('LBL_CAMPAIGN_ACTIVITY_COST', $mod_strings['LBL_CAMPAIGN_ACTIVITY_COST']);
        $smarty->assign('LBL_CAMPAIGN_MARKETING_LIST', $mod_strings['LBL_CAMPAIGN_MARKETING_LIST']);
        $smarty->assign('LBL_CAMPAIGN_ACTIVITY_TYPE', $mod_strings['LBL_CAMPAIGN_ACTIVITY_TYPE']);
        $smarty->assign('LBL_CAMPAIGN_TRIGGER_BASED', $mod_strings['LBL_CAMPAIGN_TRIGGER_BASED']);
        $smarty->assign('LBL_CAMPAIGN_DATE_BASED', $mod_strings['LBL_CAMPAIGN_DATE_BASED']);
        $smarty->assign('LBL_CAMPAIGN_ACTIVITY_BASED', $mod_strings['LBL_CAMPAIGN_ACTIVITY_BASED']);
        $smarty->assign('LBL_CAMPAIGN_ACTIVITY_EMAIL', $mod_strings['LBL_CAMPAIGN_ACTIVITY_EMAIL']);
        $smarty->assign('LBL_CAMPAIGN_ACTIVITY_SMS', $mod_strings['LBL_CAMPAIGN_ACTIVITY_SMS']);
        $smarty->assign('LBL_CAMPAIGN_ACTIVITY_SOCIAL_MEDIA', $mod_strings['LBL_CAMPAIGN_ACTIVITY_SOCIAL_MEDIA']);
        $smarty->assign('LBL_CAMPAIGN_ACTIVITY_INSTORE_DANGLERS', $mod_strings['LBL_CAMPAIGN_ACTIVITY_INSTORE_DANGLERS']);
        $smarty->assign('LBL_CAMPAIGN_ACTIVITY_STANDERS', $mod_strings['LBL_CAMPAIGN_ACTIVITY_STANDERS']);
        $smarty->assign('LBL_CAMPAIGN_ACTIVITY_FLYERS', $mod_strings['LBL_CAMPAIGN_ACTIVITY_FLYERS']);
        $smarty->assign('LBL_CAMPAIGN_ACTIVITY_DIGITAL_SCREEN', $mod_strings['LBL_CAMPAIGN_ACTIVITY_DIGITAL_SCREEN']);
        $smarty->assign('LBL_CAMPAIGN_ACTIVITY_PASYSTEM', $mod_strings['LBL_CAMPAIGN_ACTIVITY_PASYSTEM']);
        $smarty->assign('LBL_CAMPAIGN_ACTIVITY_TILLADS', $mod_strings['LBL_CAMPAIGN_ACTIVITY_TILLADS']);
        $smarty->assign('LBL_CAMPAIGN_SET_SUBTYPE_ATTRIBUTES', $mod_strings['LBL_CAMPAIGN_SET_SUBTYPE_ATTRIBUTES']);
        $smarty->assign('LBL_CAMPAIGN_SELECT_ACTIVITY', $mod_strings['LBL_CAMPAIGN_SELECT_ACTIVITY']);
        $smarty->assign('LBL_CAMPAIGN_LINK_COUPON', $mod_strings['LBL_CAMPAIGN_LINK_COUPON']);
        $smarty->assign('LBL_CAMPAIGN_LINK_PRODUCT_PORTFOLIO', $mod_strings['LBL_CAMPAIGN_LINK_PRODUCT_PORTFOLIO']);
        $smarty->assign('LBL_CAMPAIGN_LINK_TEMPLATE', $mod_strings['LBL_CAMPAIGN_LINK_TEMPLATE']);
        $smarty->assign('LBL_CAMPAIGN_COMMENTS', $mod_strings['LBL_CAMPAIGN_COMMENTS']);
        $smarty->assign('LBL_CAMPAIGN_SUBTYPE_ID', $mod_strings['LBL_CAMPAIGN_SUBTYPE_ID']);
        $smarty->assign('LBL_CAMPAIGN_SUBTYPE_POPUP', $mod_strings['LBL_CAMPAIGN_SUBTYPE_POPUP']);
        $smarty->assign('LBL_CAMPAIGN_LINK', $mod_strings['LBL_CAMPAIGN_LINK']);
        $smarty->assign('LBL_CAMPAIGN_SAVE', $mod_strings['LBL_CAMPAIGN_SAVE']);
        $smarty->assign('LBL_CAMPAIGN_CANCEL', $mod_strings['LBL_CAMPAIGN_CANCEL']);
        $smarty->assign('LBL_CAMPAIGN_ATTACH', $mod_strings['LBL_CAMPAIGN_ATTACH']);
        $smarty->assign('LBL_CAMPAIGN_SEARCH', $mod_strings['LBL_CAMPAIGN_SEARCH']);
        $smarty->assign('LBL_EVENT_PLACE', $mod_strings['LBL_EVENT_PLACE']);
        $smarty->assign('LBL_EVENT_DESCRIPTION', $mod_strings['LBL_EVENT_DESCRIPTION']);
        $smarty->assign('LBL_EVENT_NAME', $mod_strings['LBL_EVENT_NAME']);
        $smarty->assign('LBL_LONGITUDE', $mod_strings['LBL_LONGITUDE']);
        $smarty->assign('LBL_LATITUDE', $mod_strings['LBL_LATITUDE']);
        $smarty->assign('LBL_EDIT', $mod_strings['LBL_EDIT']);
        $smarty->assign('LBL_DELETE', $mod_strings['LBL_DELETE']);
        $smarty->assign('LBL_ASSET_ID_LIST', $mod_strings['LBL_ASSET_ID_LIST']);
        $smarty->assign('LBL_ASSET_ID_DETAIL', $mod_strings['LBL_ASSET_ID_DETAIL']);
        $smarty->assign('LBL_NAKU_COST_CONTRIBUTION_C', $mod_strings['LBL_NAKU_COST_CONTRIBUTION_C']);
        $smarty->assign('LBL_ASSET_FOR_WEBSITE', $mod_strings['LBL_ASSET_FOR_WEBSITE']);
        $smarty->assign('LBL_NAKU_COST_TYPE_C', $mod_strings['LBL_NAKU_COST_TYPE_C']);
        $smarty->assign('LBL_STORE_TYPE', $mod_strings['LBL_STORE_TYPE']);
        $smarty->assign('LBL_STORE_IN', $mod_strings['LBL_STORE_IN']);
        $smarty->assign('LBL_STORE_OUT', $mod_strings['LBL_STORE_OUT']);
        $smarty->assign('LBL_STORE', $mod_strings['LBL_STORE']);
        $smarty->assign('LBL_NORMAL_CAMPAIGN_ACTIVITY', $mod_strings['LBL_NORMAL_CAMPAIGN_ACTIVITY']);
        $smarty->assign('LBL_POLLS', $mod_strings['LBL_POLLS']);
        $smarty->assign('LBL_ABTESTING', $mod_strings['LBL_ABTESTING']);
        
        if (!empty($_GET['start_date'])) {
            $smarty->assign('campaign_start_date', $_GET['start_date']);
        }

        if (!empty($_GET['id'])) {
            $smarty->assign('campaign_id', $_GET['id']);
            $smarty->assign('campaign', $this->view_object_map['campaign']);
            $smarty->assign('campaign_sup', $this->view_object_map['campaign_sup']);
            $smarty->assign('campaign_sup_count', $this->view_object_map['campaign_sup_count']);
            $smarty->assign('camp_id', $this->view_object_map['campaign']['campaign_id_c']);
            // get selected campaign type    
            $camp_type_selected = explode(',', $this->view_object_map['campaign']['campaign_type']);
            $cmp = '<option value="">Select</option>';
            if (!empty($this->view_object_map['Camp_Type'])) {
                foreach ($this->view_object_map['Camp_Type'] as $cmpkey => $cmpval) {
                    if (in_array($cmpkey, $camp_type_selected)) {
                        $cmp_type_selected_name[$cmpkey] = $cmpval;
                        $cmp.='<option  selected="selected" value="' . $cmpkey . '">' . $cmpval . '</option>';
                    } else {
                        $cmp.='<option value="' . $cmpkey . '">' . $cmpval . '</option>';
                    }
                }
            }
            $smarty->assign('Camp_Type', $cmp);
            $smarty->assign('cmp_type_selected_name', $cmp_type_selected_name);

            // get selected campaign sub type	
            $camp_subtype_selected = explode(',', $this->view_object_map['campaign']['campaign_subtype']);
            $cmp_subtype = '<option value="">Select</option>';
            if ($this->view_object_map['camp_subtype']) {
                foreach ($this->view_object_map['camp_subtype'] as $sub_type) {
                    if (in_array($sub_type['type_id'], $camp_type_selected)) {
                        if (in_array($sub_type['id'], $camp_subtype_selected)) {
                            $cmp_subtype_selected_name[$sub_type['id']] = $sub_type['name'];
                            $cmp_subtype.='<option  selected="selected" value="' . $sub_type['id'] . '">' . $sub_type['name'] . '</option>';
                        } else {
                            $cmp_subtype.='<option value="' . $sub_type['id'] . '">' . $sub_type['name'] . '</option>';
                        }
                    }
                }
            }
            $smarty->assign('cmp_subtype', $cmp_subtype);
            $cmp_subtype_selected_name = isset($cmp_subtype_selected_name) ? $cmp_subtype_selected_name : '';
            $smarty->assign('cmp_subtype_selected_name', $cmp_subtype_selected_name);
            $smarty->assign('campaign_activity', $this->view_object_map['campaign_activity']);
            $smarty->assign('camp_type_activity', $this->view_object_map['camp_type_activity']);
            $smarty->assign('getAllBranches', $this->view_object_map['getAllBranchName']);//get branch name
            $smarty->assign('getAllPolls', $this->view_object_map['getAllPolls']);//get polls name
            //echo'<pre>';print_r($this->view_object_map['getAllPolls']);
        } else {
            $cmp = '<option value="">Select</option>';
            if (!empty($this->view_object_map['Camp_Type'])) {
                foreach ($this->view_object_map['Camp_Type'] as $cmpkey => $cmpval) {
                    $cmp.='<option value="' . $cmpkey . '">' . $cmpval . '</option>';
                }
            }
            $smarty->assign('Camp_Type', $cmp);
            $smarty->assign('camp_id', $this->view_object_map['camp_id']);
        }
        
        //Start Roles and Permission Hacks by Akhilesh
        $smarty->assign('approveIcon',  $this->view_object_map['approveIcon']);
        $smarty->assign('rejectIcon',   $this->view_object_map['rejectIcon']);
        $smarty->assign('adminRole',    $this->view_object_map['adminRole']);
        //End Roles and Permission Hacks by Akhilesh
        
        $smarty->display("custom/modules/Campaigns/tpls/editview.tpl");
    }
}