<?php
class campaign_type {
	function camp_type($bean, $event,$arguments)
	{
		if(!empty($bean->campaign_type))
		{
			$type_id=explode(',',$bean->campaign_type); 
			if(!empty($type_id))
			{
				$type_name=array();
				foreach($type_id as $t_id)
				{
					$sql = "SELECT id,name FROM `camp_type` where deleted=0 AND id='".$t_id."'";
					$result = $GLOBALS['db']->query($sql);
					
					while($row = $GLOBALS['db']->fetchByAssoc($result)) 
					{
						$type_name[]=$row['name'];
					}
				}
				$bean->campaign_type=implode(',',$type_name);
			}
		}		
	}
}
?> 