<?php
class clone_campaign {
	function clone_camp($bean, $event,$arguments)
	{
		$bean->clone_c =  "<a title='Edit' id='edit-$bean->id' href='index.php?module=Campaigns&action=clone&record=$bean->id'>Clone</a>";
	}
}
?> 