<?php
class campaign_subtype {
	function camp_subtype($bean, $event,$arguments)
	{
		if(!empty($bean->campaign_subtype))
		{
			$type_id=explode(',',$bean->campaign_subtype); 
			if(!empty($type_id))
			{
				$type_name=array();
				foreach($type_id as $t_id)
				{
					$sql = "SELECT id,name FROM `camp_subtype` where deleted=0 AND id='".$t_id."'";
					$result = $GLOBALS['db']->query($sql);
					
					while($row = $GLOBALS['db']->fetchByAssoc($result)) 
					{
						$type_name[]=$row['name'];
					}
				}
				$bean->campaign_subtype=implode(',',$type_name);
			}
		}		
	}
}
?> 