<?php
class campaign_update {
	function camp_update($bean, $event, $arguments){
	
		 $bean->update_c =  "<a title='Edit' id='edit-$bean->id' href='index.php?module=Campaigns&action=EditView&id=$bean->id'>Edit</a>";
	
	}

}
?> 