<?php
require_once 'include/dompdf/dompdf_config.inc.php';
$dompdf = new Dompdf();
$content = '';
$header = '<html>
			<head>
			<link rel="stylesheet" href="custom/modules/Campaigns/js/calendar/fullcalendar.css"/>
			<link href="custom/modules/Campaigns/js/calendar/fullcalendar.print.css" rel="stylesheet" media="print" />
			
			
	<style>

		
	
	body {
		margin: 0;
		padding: 0;
		font-family: "Lucida Grande",Helvetica,Arial,Verdana,sans-serif;
		font-size: 14px;
	}

	#script-warning {
		display: none;
		background: #eee;
		border-bottom: 1px solid #ddd;
		padding: 0 10px;
		line-height: 40px;
		text-align: center;
		font-weight: bold;
		font-size: 12px;
		color: red;
	}

	#loading {
		display: none;
		position: absolute;
		top: 10px;
		right: 10px;
	}

	#calendar {
		max-width: 900px;
		margin: 40px auto;
		padding: 0 10px;
	}

</style>
			</head>
            <body>
                <div style="width:100%;color:#fff;background:#17479d;padding:5px 0px;margin:0px;text-align:center;">
                    <img src="custom/include/images/logo.png" style="padding: 7px;position: absolute;left: 10px;"><h2>Customer Service List</h2>
                </div>';
				
$content .= html_entity_decode($_POST['cal_block_data']);
	


				
$footer = ' <div style="width:100%;color:#ccc;background:#17479d;padding:5px 0px;margin:0px;text-align:center;">
                <h5>www.nakumatt.net</h5>
            </div>
            <h4 style="color:red;">The content is confidential and not meant to be shared in any form with any external persons / entities.</h4>
        </body>
        </html>';		
?>
<?php	
	
$html = $header . $content . $footer; 
$dompdf->load_html($html);
// (Optional) Setup the paper size and orientation
$dompdf->set_paper('A4', 'landscape');
// Render the HTML as PDF
$dompdf->render();
// Output the generated PDF to Browser
$filename = "CS" . date('Y-m-d:H:i:s') . ".pdf";
$dompdf->stream($filename);  
?>