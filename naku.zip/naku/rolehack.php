<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE);
if (!defined('sugarEntry') || !sugarEntry)
    die('Not A Valid Entry Point');

class RoleHack {

    function getCustomRole($uid, $category, $rootAction, $subAction, $type) {

        $showIcon = false;
        $getRootAction = ACLAction::getUserActions($uid, false, $category, $type, $rootAction);
        if (@is_array($getRootAction[$category])) {
            if ((count($getRootAction[$category]) > 0) && ($getRootAction[$category][$type][$rootAction]['aclaccess'] == 90) && (!$getRootAction[$category][$type][$rootAction]['isDefault'])) {
                $showIcon = true;
            } else {
                $getSubAction = @ACLAction::getUserActions($uid, false, $category, $type, $subAction);
                // echo "<pre>";
                //print_r($getSubAction);
                if ((count($getSubAction[$category]) > 0) && ($getSubAction[$category][$type][$subAction]['aclaccess'] == 90) && (!$getSubAction[$category][$type][$subAction]['isDefault'])) {
                    $showIcon = true;
                } else {
                    if ((count($getSubAction) > 0) && ($getSubAction['aclaccess'] == 90) && (!$getSubAction['isDefault'])) {
                        $showIcon = true;
                    } else {
                        $showIcon = false;
                    }
                }
            }
        } else {
            if ((count($getRootAction) > 0) && ($getRootAction['aclaccess'] == 90) && (!$getRootAction['isDefault'])) {
                $showIcon = true;
            } else {
                $getSubAction = ACLAction::getUserActions($uid, false, $category, $type, $subAction);
                //echo "<pre>";
                //print_r($getSubAction);
                if ((count($getSubAction) > 0) && ($getSubAction['aclaccess'] == 90) && (!$getSubAction['isDefault'])) {
                    $showIcon = true;
                } else {
                    if ((count(@$getSubAction[$category]) > 0) && ($getSubAction[$category][$type][$subAction]['aclaccess'] == 90) && (!$getSubAction[$category][$type][$subAction]['isDefault'])) {
                        $showIcon = true;
                    } else {
                        $showIcon = false;
                    }
                }
            }
        }
        return $showIcon;
    }
}
?>