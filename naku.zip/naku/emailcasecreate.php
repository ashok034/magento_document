<?php
error_reporting(0);
if (!defined('sugarEntry'))
    define('sugarEntry', true);
require_once("include/entryPoint.php");
global $sugar_config, $db, $current_user;

/* connect to gmail */
$hostname = $sugar_config['IMAP_hostname']; //"{imap.gmail.com:993/imap/ssl}INBOX";
$username = $sugar_config['IMAP_username']; //'nakumattcrmapp@gmail.com';
$password = $sugar_config['IMAP_password']; //'CrM@Nakuma!16app';

/* try to connect */
$inbox = imap_open($hostname, $username, $password) or die('Cannot connect to Gmail: ' . imap_last_error());

/* grab emails */
$emails = imap_search($inbox, 'UNSEEN'); //ALL-for fetch all mails(read&unread)

/* if emails are returned, cycle through each... */
if ($emails) {

    /* put the newest emails on top */
    rsort($emails);

    /* for every email... */
    foreach ($emails as $email_number) {

        /* get information specific to this email */
        $overview = imap_fetch_overview($inbox, $email_number, 0);
        
        //$message = imap_fetchbody($inbox, $email_number, 2);

        /* output the email header information */
        $email_title     = explode('Re:',$overview[0]->subject);
        if($email_title[1]){
            $case_title_break = trim($email_title[1]);
        }else{
            $case_title_break = trim($overview[0]->subject); //first time email
        }
        $case_title_ex = explode(':',$case_title_break);

        //Set Category and Subcategory
        if(!empty($case_title_ex[0]) && !empty($case_title_ex[1])) { //contactus page
            $case_title = trim($case_title_ex[1]);
            if($case_title == $sugar_config['NakumattGlobal']){//Nakumatt Global
                $category_name = $sugar_config['NakumattGlobal'];
            }elseif($case_title == $sugar_config['Product']){//Product
                $category_name = $sugar_config['Product'];
            }else{//service
                $category_name = $sugar_config['Service'];
            }
        }else{ //email to email
            $case_title = trim($case_title_ex[0]);
            $category_name = $sugar_config['category'];
        }
        
        //Set origin
        if($case_title_ex[0] == 'Web'){
            $origin_value   = $sugar_config['origin_web'];
        }else{
            $origin_value   = $sugar_config['origin'];
        }
        
        //Get Category ID by Name
        $cat_id = getCategoryByName(trim($category_name));
        //Get SubCategory ID & Priority by CategoryID
        $subcategoryDetails = getSubCategoryByCatID($cat_id,trim($sugar_config['subcategory']));
        
        //$case_desc      = strip_tags($message);
        $category       = $cat_id;
        $sub_category   = $subcategoryDetails['id'];
        //$origin         = $sugar_config['origin'];
        $origin         = $origin_value;
        $status         = $sugar_config['status'];
        $case_type      = $sugar_config['case_type'];
        $assigned_user_id = $sugar_config['assigned_user_id'];
        $created_by_id  = $sugar_config['created_by_id'];
        $date_entered   = date('Y-m-d H:i:s');
        $date_modified  = date('Y-m-d H:i:s');
        $case_number    = '';

        $header         = imap_headerinfo($inbox, $overview[0]->msgno);
        
        if(!empty(trim($case_title_ex[2]))){
            $customer_email_check = trim($case_title_ex[2]);
            $message    = str_replace('=', '', imap_body($inbox, $email_number));
            $cus        = explode('@',$customer_email_check);
            $customer   = $cus[0];
        }else{
            $customer_email_check = $header->from[0]->mailbox . "@" . $header->from[0]->host;
            $message    = imap_fetchbody($inbox, $email_number, 2);
            $customer   = $overview[0]->from;
        }
        $case_desc      = strip_tags($message);
    
       // echo $customer_email_check;die;
        $existCustomerID = checkCustomer($case_title,$customer_email_check);
        if($existCustomerID){
            //echo $existCustomerID;
            //Retrieve bean
            $bean = BeanFactory::getBean('Cases', $existCustomerID);
            $bean->description  = $case_desc;
            $bean->save();
            //die('updated');
            if(empty($bean->id)){ 
                $date = date('d.m.Y h:i:s'); 
                $logmsg = "Date:  ".$date." | Message: Case description of case title '". $case_title ."' not append. \n"; 
                error_log($logmsg, 3, "logs/email_case_create.log"); 
            }
        }
        else{
            $customerData   = getCustomerInfo($customer_email_check);
            if (!empty($customerData)) {
                if ($customerData['member_type'] == 0) { //Member or Individual
                    $member_type = 'member';
                } elseif ($customerData['member_type'] == 1) { //Corporate 
                    $member_type = 'corporate';
                } else { //Guest
                    $member_type = 'guest';
                }
                if($customerData['title'] == 1){
                    $gender = 'male';
                }else{
                    $gender = 'female';
                }
                $customer_name  = $customerData['first_name'] . '&nbsp;' . $customerData['last_name'];
                $mobile_number  = ($customerData['phone_mobile']) ? $customerData['phone_mobile'] : '';
                $email          = ($customerData['email']) ? $customerData['email'] : '';
                $loyalty_id     = ($customerData['loyalty_id']) ? $customerData['loyalty_id'] : '';
                $member_tier    = ($customerData['member_tier']) ? $customerData['member_tier'] : '';
                $birthdate      = ($customerData['birthdate']) ? $customerData['birthdate'] : '';
            } else {
                $member_type    = 'guest';
                $customer_name  = $customer;
                $mobile_number  = '';
                $email          = $customer_email_check;  //$header->from[0]->mailbox . "@" . $header->from[0]->host;
                $loyalty_id     = '';
                $member_tier    = '';
                $birthdate      = '';
                $gender         = '';
            }

            if ($customerData['member_tier'] == 'Gold' || $customerData['member_tier'] == 'gold') {
                $priority = 'P1';
            } else {
                $priority = $subcategoryDetails['priority'];
            }
            //Create bean
            $bean = BeanFactory::newBean('Cases');
            $bean->name             = $case_title;
            $bean->description      = $case_desc;
            $bean->member_type_c    = $member_type;
            $bean->customer_name_c  = $customer_name;
            $bean->mobile_number_c  = $mobile_number;
            $bean->email_c          = $email;
            $bean->loyalty_id_c     = $loyalty_id;
            $bean->member_tier_c    = $member_tier;
            $bean->dob_c            = $birthdate;
            $bean->gender_c         = $gender;
            $bean->category_c       = $category;
            $bean->subcategory_c    = $sub_category;
            $bean->priority         = $priority;
            $bean->origin_c         = $origin;
            $bean->status           = $status;
            $bean->caserelation_c   = $case_type;
            $bean->date_entered     = $date_entered;
            $bean->date_modified    = $date_modified;
            $bean->assigned_user_id = $assigned_user_id;
            $bean->created_by       = $created_by_id;
            //echo'<pre>'; print_r($bean); die;
            $bean->save();
            if(empty($bean->id)) {
                $date = date('d.m.Y h:i:s'); 
                $logmsg = "Date:  ".$date." | Message: Case title '". $bean->name ."' not inserted. \n"; 
                error_log($logmsg, 3, "logs/email_case_create.log"); 
            }
        }
    }
}
/* close the connection */
imap_close($inbox);

//function to get customer information by email
function getCustomerInfo($email) {
    global $db;
    if (!empty($email)) {
        $data = array();
        $sql = "SELECT first_name,last_name,phone_mobile,email,loyalty_id,member_tier,birthdate,member_type,title FROM `contacts` WHERE deleted=0 AND email='$email'";
        $result = $db->query($sql);
        while ($row = $db->fetchByAssoc($result)) {
            $row['birthdate'] = date('d/m/Y', strtotime($row['birthdate']));
            $data[] = $row;
        }
        if (count($data) > 0) {
            return $data[0];
        } else {
            return false;
        }
    }
}
//function to check existing customer or not by email
function checkCustomer($case_title, $email) {
    global $db;
    if (!empty($email)) {
        $data = array();
       $sql = "SELECT cases.id FROM `cases` LEFT JOIN `cases_cstm` ON cases.id = cases_cstm.id_c WHERE deleted=0 AND cases_cstm.email_c='$email' AND cases.name ='$case_title'";
        $result = $db->getOne($sql);
        if (!empty($result)) {
            return $result;
        } else {
            return false;
        }
    }
}
//function to get category id By category name
function getCategoryByName($name) {
        global $db;
        if (!empty($name)) {
            $sql = "SELECT id FROM `naku_casecategory` WHERE deleted=0 AND name = '$name'";
            $result = $db->getOne($sql);
            return $result;
        }
    }
//function to get subcategory_id and priority by category id
function getSubCategoryByCatID($catid,$subcategory) {
        global $db;
        if (!empty($catid)) {
            $data = array();
            $sql = "SELECT id,priority FROM `naku_casesubcategory` WHERE deleted=0 AND category_id='$catid' AND name = '$subcategory'";
            $result = $db->query($sql);
            while ($row = $db->fetchByAssoc($result)) {
                $data[] = $row;
            }
            if (count($data) > 0) {
                return $data[0];
            } else {
                return false;
            }
        }
    }
?>