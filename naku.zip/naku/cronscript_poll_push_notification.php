<?php
/**
* This CRON Script for PUSH NOTIFICATION to CUSTOMER Mobile
* Data:
    * notif_desc => content[campaign description]
    * notif_title => title [poll title]
    * notif_type => TYPE_POLLS hardcore value
    * notif_id => poll_id
    * extra_polls_id =>
* to: device_token
*/
//ini_set("max_execution_time", 3000);
if (!defined('sugarEntry'))
    define('sugarEntry', true);
require_once("include/entryPoint.php");
include('cronscripts/config.php');

global $sugar_config,$db;
//Get magentoCRM database details
$mag_host   = $sugar_config['crm_host'];
$mag_user   = $sugar_config['crm_user'];
$mag_pass   = $sugar_config['crm_password'];
$mag_db     = $sugar_config['crm_db'];
$key        = $sugar_config['EventPushAuthorizationKey'];
$URL        = $sugar_config['EventPushURL'];

//Magento CRM Database connection for get "device_token" in Table "mobile_notification_token"
$con    =   new createConnection($mag_host,$mag_user,$mag_pass,$mag_db);
$con->selectDatabase();
//Fetch all "device_token" in Table "mobile_notification_token" Magento CRM Database
$data_device_token = array();
$mag_sql    =   "SELECT device_token FROM mobile_notification_token";
$mag_result =   $con->query($mag_sql);
while($mag_row = $con->fetchByAssoc($mag_result)) {
    $data_device_token[] = $mag_row['device_token'];
}
//echo count($data_device_token); //For DEBUG
//Fetch all campaign/poll details when status Active
$sql    = "SELECT act.polls_id, camp.content as campaign_desc"
        . " FROM campaigns as camp LEFT JOIN camp_activity as act "
        . "ON act.cmp_id = camp.id WHERE act.name = 'Email' AND camp.deleted=0 AND camp.status='Active'";
$result =   $db->query($sql);
while($row = $db->fetchByAssoc($result)) {
 //echo'<pre>';   print_r($row);
    $poll_id    =  $row["polls_id"];
    $sql_poll   = "SELECT title FROM ". $sugar_config['crm_polls'] ." WHERE polls_id = ".$poll_id." AND status = 1";
    $list_polls = $con->query($sql_poll);
    $arr_polls  = array();
    while ($row_poll = $con->fetchByAssoc($list_polls)) {
        $arr_polls[] = $row_poll['title'];
    }
   
    //$row['title']       =   $arr_polls ;
    //echo'<pre>';  print_r($arr_polls);echo'<br/>'; //For DEBUG
    
    $data_event['notif_desc']     = $row['campaign_desc'];
    $data_event['notif_title']    = $arr_polls[0];
    $data_event['notif_type']     = 'TYPE_POLLS';
    $data_event['notif_id']       = $poll_id;
    $data_event['extra_polls_id'] = '';
 
   if(!empty($data_event['notif_id'])) {
       
        if(count($data_device_token) > 1) {
                
            $data = array(
                        "data" => $data_event,
                        "registration_ids" => $data_device_token
                    );
       }else{
            
           $data = array(
                        "data" => $data_event,
                        "to" => $data_device_token[0]
                    );
        }
        
        $data_string = json_encode($data);                                                                                   

        $ch = curl_init($URL);                                                                      
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                      
            'Content-Type: application/json',
            'Authorization:'.$key
            )                                                               
        );
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string); 
        $responce= curl_exec($ch);
        curl_close($ch);
        echo '<pre>Responce=';
        $responce_array = json_decode($responce);
        print_r($responce_array);
    }else {
        $date = date('d.m.Y h:i:s'); 
        $logmsg = "Date:  ".$date." | Message: Data not found. \n"; 
        error_log($logmsg, 3, "logs/poll_push_notification.log"); 
        //http://php.net/manual/en/function.error-log.php
    }
}//End While