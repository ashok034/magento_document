<?php
/**
* This CRON Script for PUSH NOTIFICATION to CUSTOMER Mobile
* Data:
    * notif_desc => event_desc
    * notif_title => event_title
    * notif_type => TYPE_EVENT hardcore value
    * notif_id => event_id
    * extra_event_img_url => event_list_img_url 
    * extra_event_start_date => event_start_date
    * extra_event_end_date => event_end_date
* to: device_token
*/
//ini_set("max_execution_time", 3000);
if (!defined('sugarEntry'))
    define('sugarEntry', true);
require_once("include/entryPoint.php");
include('cronscripts/config.php');

global $sugar_config,$db;
//Get magentoCRM database details
$mag_host   = $sugar_config['crm_host'];
$mag_user   = $sugar_config['crm_user'];
$mag_pass   = $sugar_config['crm_password'];
$mag_db     = $sugar_config['crm_db'];
$key        = $sugar_config['EventPushAuthorizationKey'];
$URL        = $sugar_config['EventPushURL'];

//Magento CRM Database connection for get "device_token" in Table "mobile_notification_token"
$con    =   new createConnection($mag_host,$mag_user,$mag_pass,$mag_db);
$con->selectDatabase();
//Fetch all "device_token" in Table "mobile_notification_token" Magento CRM Database
$data_device_token = array();
$mag_sql    =   "SELECT device_token FROM mobile_notification_token";
$mag_result =   $con->query($mag_sql);
while($mag_row = $con->fetchByAssoc($mag_result)) {
    $data_device_token[] = '"'.$mag_row['device_token'].'"';
}
//echo count($data_device_token); //For DEBUG
//Fetch all campaign/event details when status Active
$sql    =   "SELECT camp.id as campaign_id, camp.name as campaign_name, camp.content as campaign_desc, camp.status, "
        . "act.id as event_id, act.event_name as event_title, act.event_desc as event_desc, act.event_place, "
        . "act.asset_id_c, act.event_start_datetime as event_start_date, act.event_end_datetime as event_end_date "
        . " FROM campaigns as camp LEFT JOIN camp_activity as act "
        . "ON act.cmp_id = camp.id WHERE act.name = 'Website Event' AND camp.deleted=0 AND camp.status='Active'";
$result =   $db->query($sql);
while($row = $db->fetchByAssoc($result)) {
    $asset_id   =  $row["asset_id_c"];
    $sql_assets = "SELECT file_name FROM asset_assets WHERE id IN ('" . str_replace(",", "','", $asset_id) . "')";
    $listImages = $db->query($sql_assets);
    $arr_assets = array();
    while ($row_assets = $db->fetchByAssoc($listImages)) {
        $arr_assets[] = $row_assets['file_name'];
    }
    $row['event_list_img_url']    = isset($arr_assets[0]) ? $arr_assets[0] : '';
    $row['event_detail_img_url']  = isset($arr_assets[1]) ? $arr_assets[1] : '';
   
    // echo'<pre>';  print_r($arr_assets);echo'<br/>'; //For DEBUG
    
    $data_event['notif_desc']     = $row['event_desc'];
    $data_event['notif_title']    = $row['event_title'];
    $data_event['notif_type']     = 'TYPE_EVENT';
    $data_event['notif_id']       = $row['event_id'];
    $data_event['extra_event_img_url'] = $row['event_list_img_url'];
    $data_event['extra_event_start_date'] = date('d/m/Y',strtotime($row['event_start_date']));
    $data_event['extra_event_end_date']   =  date('d/m/Y',strtotime($row['event_end_date']));
 
   if(!empty($data_event['notif_id'])) {
       
        if(count($data_device_token) > 1) {
                
            $data = array(
                        "data" => $data_event,
                        "registration_ids" => $data_device_token
                    );
       }else{
           $SingleData_device_token =  str_replace('"',"",$data_device_token[0]); // for single token
           $data = array(
                        "data" => $data_event,
                        "to" => $SingleData_device_token
                    );
        }
        
        $data_string = json_encode($data);                                                                                   

        $ch = curl_init($URL);                                                                      
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                      
            'Content-Type: application/json',
            'Authorization:'.$key
            )                                                               
        );
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string); 
        $responce= curl_exec($ch);
        curl_close($ch);
        echo '<pre>Responce=';
        $responce_array = json_decode($responce);
        print_r($responce_array);
    }else {
        $date = date('d.m.Y h:i:s'); 
        $logmsg = "Date:  ".$date." | Message: Data not found. \n"; 
        error_log($logmsg, 3, "logs/event_push_notification.log"); 
        //http://php.net/manual/en/function.error-log.php
    }
}//End While