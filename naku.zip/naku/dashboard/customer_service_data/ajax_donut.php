<?php

include('../config.php');
$myconn = new createConnection();
$db = $myconn->selectDatabase();
$limit = '';//limit 10';
$custom_donut = array();
$condition ='';
$condition_org ='';

if ($_REQUEST['from_date'] && $_REQUEST['to_date'] && $_REQUEST['to_date'] !='MM/DD/YYYY' && $_REQUEST['from_date'] !='MM/DD/YYYY') {
    $condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($_REQUEST['from_date'])) . "' AND '" . date("Y-m-d", strtotime($_REQUEST['to_date'])) . "' AND ";
}
         
if(isset($_REQUEST['member_tier_c']) && $_REQUEST['member_tier_c'] !=''){
    $condition .= 'cases_cstm.member_tier_c = "'.$_REQUEST['member_tier_c'].'" AND ';
}
if ($_REQUEST['category_id']) {
    $condition .= "  cases_cstm.category_c = '" . $_REQUEST['category_id'] . "' AND ";
}
if ($_REQUEST['origin']) {
    $condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
}
if ($_REQUEST['branch_store_name']) {
    $condition .= "  cases.branch_store_name = '" . $_REQUEST['branch_store_name'] . "'  AND ";
}
if ($_REQUEST['status']) {
    $condition .= "  cases.status = '" . $_REQUEST['status'] . "' AND ";
}
if ($_REQUEST['priority']) {
    $condition .= "  cases.priority = '" . $_REQUEST['priority'] . "' AND ";
}
$query = "SELECT count(cases.id) as total,cases_cstm.member_tier_c "
                . " FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN users ON cases.assigned_user_id=users.id AND cases.deleted=0 AND users.deleted=0 "
                . " LEFT JOIN naku_casecategory ON cases_cstm.category_c = naku_casecategory.id AND naku_casecategory.deleted=0  "
                . " where " . $condition . " " . $condition_org . " cases_cstm.member_tier_c IN ('Silver','Gold','Base') AND cases.deleted=0 AND cases_cstm.member_tier_c <> '' AND cases_cstm.loyalty_id_c NOT IN ('Guest','guest' ) GROUP BY cases_cstm.member_tier_c ORDER BY cases.date_entered DESC " . $limit;

$result = $myconn->query($query);

$data= array();
$xdata= array();
$data_final['dataPoints']= array();
$i=1;
while ($row = $myconn->fetchByAssoc($result)) {
    $custom_donut[] = $row;
    
    $membertier_check = $row['member_tier_c'];
    if($membertier_check ==''){
        $membertier ='Anonymous'.$i;
        $i++;
    }else{
        $membertier =$membertier_check ;
    }
    $data['y']=$row['total'];
    $data['indexLabel']=$membertier;
   $xdata[]=$data;
} 
/*$member_value = array('Silver','Gold','Base');
foreach($member_value as $tier) {
  
   $key = array_search($tier, array_column($xdata, 'indexLabel'));
   if($key === FALSE){
       $data = array();
        $data['y'] = 0;
        $data['indexLabel'] = $tier;
        $xdata[] = $data;
    }

}*/

 $data_final['dataPoints']=$xdata;
 echo json_encode($data_final['dataPoints']);
//print_r($data_final);


?>
