<?php
include('../config.php');
$myconn = new createConnection();
$db = $myconn->selectDatabase();
$limit = ''; //limit 10';
$custom_bar = array();
$condition ='';
$condition_org ='';

if ($_REQUEST['from_date'] && $_REQUEST['to_date'] && $_REQUEST['to_date'] !='MM/DD/YYYY' && $_REQUEST['from_date'] !='MM/DD/YYYY') {
    $condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($_REQUEST['from_date'])) . "' AND '" . date("Y-m-d", strtotime($_REQUEST['to_date'])) . "' AND ";
}
         
if(isset($_REQUEST['member_tier_c']) && $_REQUEST['member_tier_c'] !=''){
    $condition .= 'cases_cstm.member_tier_c = "'.$_REQUEST['member_tier_c'].'" AND ';
}
if ($_REQUEST['category_id']) {
    $condition .= "  cases_cstm.category_c = '" . $_REQUEST['category_id'] . "' AND ";
}
if ($_REQUEST['origin']) {
    $condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
}
if ($_REQUEST['branch_store_name']) {
    $condition .= "  cases.branch_store_name = '" . $_REQUEST['branch_store_name'] . "'  AND ";
}

if ($_REQUEST['status']) {
    $condition .= "  cases.status = '" . $_REQUEST['status'] . "' AND ";
}
if ($_REQUEST['priority']) {
    $condition .= "  cases.priority = '" . $_REQUEST['priority'] . "' AND ";
}

$query = "SELECT count(cases.id) as total,cases.status "
                . " FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN users ON cases.assigned_user_id=users.id AND cases.deleted=0 AND users.deleted=0 "
                . " LEFT JOIN naku_casecategory ON cases_cstm.category_c = naku_casecategory.id AND naku_casecategory.deleted=0  "
                . " where " . $condition . " " . $condition_org . " cases.status IN ('Created', 'InProgress', 'UnderResearch', 'Resolved','Closed','Reopen') AND cases.deleted=0 GROUP BY cases.status ORDER BY cases.date_entered DESC " . $limit;

$result = $myconn->query($query);

$data= array();
$xdata= array();
$data_final['dataPoints']= array();

$status_value = array("Created", "InProgress", "UnderResearch", "Resolved", "Closed", "Reopen" );

while ($row = $myconn->fetchByAssoc($result)) {
    $data['y']=$row['total'];
    $data['label']=$row['status'];
   $xdata[]=$data;
} 

foreach($status_value as $status) {
  
   $key = array_search($status, array_column($xdata, 'label'));
   if($key === FALSE){
       $data = array();
        $data['y'] = 0;
        $data['label'] = $status;
        $xdata[] = $data;
    }

}
 $data_final['dataPoints']=$xdata;
 echo  json_encode($data_final['dataPoints'],JSON_NUMERIC_CHECK);


?>
