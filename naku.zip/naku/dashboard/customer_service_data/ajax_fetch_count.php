<?php
include('../config.php');
$myconn = new createConnection();
$db = $myconn->selectDatabase();
$limit = '';//limit 10';
$condition ='';
$condition_org ='';

if ($_REQUEST['from_date'] && $_REQUEST['to_date'] && $_REQUEST['to_date'] !='MM/DD/YYYY' && $_REQUEST['from_date'] !='MM/DD/YYYY') {
    $condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($_REQUEST['from_date'])) . "' AND '" . date("Y-m-d", strtotime($_REQUEST['to_date'])) . "' AND ";
}
         
if(isset($_REQUEST['member_tier_c']) && $_REQUEST['member_tier_c'] !=''){
    $condition .= 'cases_cstm.member_tier_c = "'.$_REQUEST['member_tier_c'].'" AND ';
}
 if ($_REQUEST['category_id']) {
    $condition .= "  cases_cstm.category_c = '" . $_REQUEST['category_id'] . "' AND ";
}
if ($_REQUEST['origin']) {
    $condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
}
if ($_REQUEST['branch_store_name']) {
    $condition .= "  cases.branch_store_name = '" . $_REQUEST['branch_store_name'] . "'  AND ";
}

if ($_REQUEST['status']) {
    $condition .= "  cases.status = '" . $_REQUEST['status'] . "' AND ";
}
if ($_REQUEST['priority']) {
    $condition .= "  cases.priority = '" . $_REQUEST['priority'] . "' AND ";
}
$todaydate = date("Y-m-d");
$query = "SELECT count(cases.id) as total , (SELECT count(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
        . " LEFT JOIN users ON cases.assigned_user_id=users.id AND cases.deleted=0 AND users.deleted=0 "
        . " LEFT JOIN naku_casecategory ON cases_cstm.category_c = naku_casecategory.id AND naku_casecategory.deleted=0 "
        . " where " . $condition . " " . $condition_org . " cases.deleted=0 AND cases.status='Resolved')"
        . "as cases_resolved , (SELECT count(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
        . " LEFT JOIN users ON cases.assigned_user_id=users.id AND cases.deleted=0 AND users.deleted=0 "
        . " LEFT JOIN naku_casecategory ON cases_cstm.category_c = naku_casecategory.id AND naku_casecategory.deleted=0 "
        . " where " . $condition . " " . $condition_org . " cases.deleted=0 AND cases.status NOT IN ('Resolved', 'Closed'))"
        . "as cases_pending , (SELECT count(*) FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
        . " LEFT JOIN users ON cases.assigned_user_id=users.id AND cases.deleted=0 AND users.deleted=0 "
        . " LEFT JOIN naku_casecategory ON cases_cstm.category_c = naku_casecategory.id AND naku_casecategory.deleted=0 "
        . " where " . $condition . " " . $condition_org . " cases.deleted=0 AND cases.date_entered >='".$todaydate."') "
        . "as cases_addedon , DATE_ADD(CURDATE(), INTERVAL -0 day) as previous_date"
                . " FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN users ON cases.assigned_user_id=users.id AND cases.deleted=0 AND users.deleted=0 "
                . " LEFT JOIN naku_casecategory ON cases_cstm.category_c = naku_casecategory.id AND naku_casecategory.deleted=0  "
                . " where " . $condition . " " . $condition_org . " cases.deleted=0 ";

$result = $myconn->query($query);
$custom_fetch = array();
while ($row = $myconn->fetchByAssoc($result)) {
    $custom_fetch[] = $row;
} 
        
        
$data_final['dataPoints']=$custom_fetch;

echo json_encode($data_final['dataPoints'],JSON_NUMERIC_CHECK);
?>
