<?php
include('../config.php');
$myconn = new createConnection();
$db = $myconn->selectDatabase();
$limit = '';//limit 10';
$custom_bar = array();
$condition ='';
$condition_org ='';

if ($_REQUEST['from_date'] && $_REQUEST['to_date'] && $_REQUEST['to_date'] !='MM/DD/YYYY' && $_REQUEST['from_date'] !='MM/DD/YYYY') {
    $condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($_REQUEST['from_date'])) . "' AND '" . date("Y-m-d", strtotime($_REQUEST['to_date'])) . "' AND ";
}
         
if(isset($_REQUEST['member_tier_c']) && $_REQUEST['member_tier_c'] !=''){
    $condition .= 'cases_cstm.member_tier_c = "'.$_REQUEST['member_tier_c'].'" AND ';
}
if ($_REQUEST['category_id']) {
    $condition .= "  cases_cstm.category_c = '" . $_REQUEST['category_id'] . "' AND ";
}
if ($_REQUEST['origin']) {
    $condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
}

if ($_REQUEST['branch_store_name']) {
    $condition .= "  cases.branch_store_name = '" . $_REQUEST['branch_store_name'] . "'  AND ";
}

if ($_REQUEST['status']) {
    $condition .= "  cases.status = '" . $_REQUEST['status'] . "' AND ";
}
if ($_REQUEST['priority']) {
    $condition .= "  cases.priority = '" . $_REQUEST['priority'] . "' AND ";
}

$query = "SELECT count(cases.id) as total,cases_cstm.origin_c "
                . " FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c  "
                . " LEFT JOIN users ON cases.assigned_user_id=users.id AND cases.deleted=0 AND users.deleted=0 "
                . " LEFT JOIN naku_casecategory ON cases_cstm.category_c = naku_casecategory.id AND naku_casecategory.deleted=0  "
                . " where " . $condition . " " . $condition_org . " cases.deleted=0 AND cases_cstm.origin_c <>''  GROUP BY cases_cstm.origin_c ORDER BY cases_cstm.origin_c DESC " . $limit;

$result = $myconn->query($query);

$data= array();
$xdata= array();
$data_final['dataPoints']= array();
$i=1;
$origin_value = array(1=>"Branch", 2=>"Call Center", 3=>"Web", 4=>"HQ Email",5=>"Newspaper",6=>"Post",7=>"Inperson",8=>"Social Media");

while ($row = $myconn->fetchByAssoc($result)) {
    $custom_bar[] = $row;
    
    $origin_check = $row['origin_c'];
    if($origin_check == 1){
        $origin_check = 'Branch';
    }
    if($origin_check == 2){
        $origin_check = 'Call Center';
    }
    if($origin_check == 3){
        $origin_check = 'Web';
    }
    if($origin_check == 4){
        $origin_check = 'HQ Email';
    }
    if($origin_check == 5){
        $origin_check = 'Newspaper';
    }
    if($origin_check ==6){
        $origin_check = 'Post';
    }
    if($origin_check == 7){
        $origin_check = 'Inperson';
    }
	if($origin_check == 8){
        $origin_check = 'Social Media';
    }
    
    
    if($origin_check ==''){
        $origin_c ='Anonymous'.$i;
                $i++;
    }else{
        $origin_c =$origin_check ;
    }
    $data['y']=$row['total'];
    $data['label']=$origin_c;
   $xdata[]=$data;
} 

foreach($origin_value as $origin) {
  
   $key = array_search($origin, array_column($xdata, 'label'));
   if($key === FALSE){
       $data = array();
        $data['y'] = 0;
        $data['label'] = $origin;
        $xdata[] = $data;
    }

}


 $data_final['dataPoints']=$xdata;
 echo  json_encode($data_final['dataPoints'],JSON_NUMERIC_CHECK);


?>
