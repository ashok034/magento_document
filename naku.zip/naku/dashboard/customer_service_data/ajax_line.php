<?php
include('../config.php');
$myconn = new createConnection();
$db = $myconn->selectDatabase();
$limit = '';//limit 10';
$custom_line = array();
$condition ='';
$condition_org ='';

 if ($_REQUEST['from_date'] && $_REQUEST['to_date'] && $_REQUEST['to_date'] !='MM/DD/YYYY' && $_REQUEST['from_date'] !='MM/DD/YYYY') {
    $condition .= "  DATE(cases.date_entered) BETWEEN '" . date("Y-m-d", strtotime($_REQUEST['from_date'])) . "' AND '" . date("Y-m-d", strtotime($_REQUEST['to_date'])) . "' AND ";
}
         
if(isset($_REQUEST['member_tier_c']) && $_REQUEST['member_tier_c'] !=''){
    $condition .= 'cases_cstm.member_tier_c = "'.$_REQUEST['member_tier_c'].'" AND ';
}
if ($_REQUEST['category_id']) {
    $condition .= "  cases_cstm.category_c = '" . $_REQUEST['category_id'] . "' AND ";
}
if ($_REQUEST['origin']) {
    $condition .= "  cases_cstm.origin_c = '" . $_REQUEST['origin'] . "'  AND ";
}
if ($_REQUEST['branch_store_name']) {
    $condition .= "  cases.branch_store_name = '" . $_REQUEST['branch_store_name'] . "'  AND ";
}
if ($_REQUEST['status']) {
    $condition .= "  cases.status = '" . $_REQUEST['status'] . "' AND ";
}
if ($_REQUEST['priority']) {
    $condition .= "  cases.priority = '" . $_REQUEST['priority'] . "' AND ";
}
$query = "SELECT count(cases.id) as total, MONTHNAME(cases.date_entered) as month, year(cases.date_entered) as year "
                . " FROM cases LEFT JOIN cases_cstm ON cases.id = cases_cstm.id_c "
                . " LEFT JOIN users ON cases.assigned_user_id=users.id AND cases.deleted=0 AND users.deleted=0 "
                . " LEFT JOIN naku_casecategory ON cases_cstm.category_c = naku_casecategory.id AND naku_casecategory.deleted=0  "
                . " where " . $condition . " " . $condition_org . " cases.deleted=0 GROUP BY MONTH(cases.date_entered) ORDER BY cases.date_entered " . $limit;

$result = $myconn->query($query);

$data= array();
$xdata= array();
$data_final['dataPoints']= array();
while ($row = $myconn->fetchByAssoc($result)) {
    $custom_line[] = $row;
    
    $month_check = $row['month'];
    if($month_check ==''){
        $month ='Anonymous';
    }else{
        $month =$month_check ;
    }
    $data['y']=$row['total'];
    $data['label']=$month.' '.$row['year'];
   $xdata[]=$data;
} 
 $data_final['dataPoints']=$xdata;
 
 echo json_encode($data_final['dataPoints'],JSON_NUMERIC_CHECK);

?>
