<?php
  include('config.php');
  $myconn = new createConnection('localhost', 'root', '', 'nakumatt_sugarcrm_23122016');
  $myconn->selectDatabase();
    function getAllCategory(){
       global $db;
            $cat = array();$xdata='';
            $sql = "SELECT id,name FROM `naku_casecategory` where deleted=0 ";
            $result = mysql_query($sql);
            $num=mysql_num_rows($result);
            if(0==$num) {
                echo "No record";
                exit;
            }

                while($row = mysql_fetch_assoc($result)){
                    $cat['id'] =$row['id'];
                    $cat['name'] =$row['name'];
                    $xdata[]=$cat;
                }
            
            return $xdata;
   }
    $category = getAllCategory();
    
    function getAllBranchName(){
       global $db;
            $branchName = array();$xdata='';
            $sql = "SELECT distinct(branch_store_name) FROM `cases` where deleted=0 AND branch_store_name !=''";
            $result = mysql_query($sql);
            $num=mysql_num_rows($result);
            if(0==$num) {
                echo "No record";
                exit;
            }

                while($row = mysql_fetch_assoc($result)){
                    $branchName['branch_store_name'] =$row['branch_store_name'];
                    $xdata[]=$branchName;
                }
            
            return $xdata;
   }
    $branchName = getAllBranchName();
    
?>
<!DOCTYPE HTML>
<html>
   <head>
       <meta charset="utf-8">
	<meta name="viewport" content="initial-scale = 1.0,maximum-scale = 1.0" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Dashboard</title>
	<link href="css/dashboard.css" rel="stylesheet">
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <script type="text/javascript" src ="js/cases_js.js"></script>
        <script src="js/canvasjs.min.js"></script>

        <script>
          $(document).ready(function() {
            $("#from_date").datepicker();
            $("#to_date").datepicker();
            
            $("#branch_store_name").prop("disabled",true);
            $('#branch_store_name').css('background-color', '#DEDEDE');
            $('#origin').change(function () { 
                if($('#origin').val() == 1){
                    $("#branch_store_name").prop("disabled",false);
                    $('#branch_store_name').css('background-color', '#ffffff');
                }else{
                    $('#branch_store_name').val('');
                    $("#branch_store_name").prop("disabled",true);
                    $('#branch_store_name').css('background-color', '#DEDEDE');
                }
            });
    
    
          }); 
        </script>
   </head>
   
   <body>
        <div class="dashboard-container"> <h2>Customer Service Dashboard</h2>
            <form id="dashboard_search_form" name="dashboard_search_form" class="search_form" action="" method="post">
                <input type="hidden" name="query" value="true">
                         <div class="filter-sect">
                                <div class="col-timeRange">
                                    <label>Time Range</label>
                                    <div class="fld-Wrap">
                                        <input class="date_input" type="text" name="from_date" id="from_date" value="MM/DD/YYYY" readonly="readonly">
                                        <input class="date_input" type="text" name="to_date" id="to_date" value="MM/DD/YYYY" readonly="readonly">
                                    </div>
                                </div>
                                 <div class="col-singleFld">
                                    <label>Member Tier</label>
                                    <div class="fld-Wrap">
                                        <select name="member_tier_c" id="member_tier_c">
                                            <option value="">Select</option>
                                            <option value="Base">Base</option>
                                            <option value="Silver">Silver</option>
                                            <option value="Gold">Gold</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-singleFld">
                                    <label>Case Origin</label>
                                    <div class="fld-Wrap">
                                        <select name="origin" id="origin">
                                               <option value="">Select</option>
                                               <option value="1">Branch Help Desk</option>
                                               <option value="2">Call Center</option>
                                               <option value="3">Web</option>
                                               <option value="4">HQ Email</option>
                                               <option value="5">Newspaper</option>
                                               <option value="6">Post</option>
                                               <option value="7">Inperson</option>
											   <option value="8">Social Media</option>
											   
                                        </select>
                                    </div>
                                </div>
                                <div class="col-singleFld">
                                    <label>Select Branch</label>
                                    <div class="fld-Wrap">
                                        <select name="branch_store_name" id="branch_store_name">
                                            <option value="">Select</option>
                                           <?php  
                                                foreach( $branchName as  $data){
                                                       echo '<option value="'.$data['branch_store_name'].'" >'.$data['branch_store_name'].'</option>';
                                                }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-singleFld">
                                    <label>Case Category</label>
                                    <div class="fld-Wrap">
                                        <select name="category_id" id="category_id">
                                            <option value="">Select</option>
                                            <?php  
                                             foreach( $category as  $data){
                                                    echo '<option value="'.$data['id'].'" >'.$data['name'].'</option>';
                                             }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-singleFld">
                                    <label>Case Status</label>
                                    <div class="fld-Wrap">
                                        <select name="status" id="status">
                                            <option value="">Select</option>
                                            <option value="Created">Created</option>
                                            <option value="InProgress">In Progress</option>
                                            <option value="UnderResearch">Under Research</option>
                                            <option value="Resolved">Resolved</option>
                                            <option value="Closed">Closed</option>
											<option value="Reopen">Reopen</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-singleFld">
                                    <label>Case Priority</label>
                                    <div class="fld-Wrap">
                                        <select name="priority" id="priority">
                                            <option value="">Select</option>
                                                          <option value="P1">High</option>
                                                          <option value="P2">Medium</option>
                                                          <option value="P3">Low</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="flterBtn-wrap">
                                    <!--button id="show_all_field" >Apply Filters</button>
                                    <button id="clear_filter" >Reset</button-->
                                     <input type="button" id="show_all_field" value="Apply Filters">
                                     <input type="button" id="clear_filter" value="Reset">
                                </div>
                         </div>    

            </form>
            <div class="dashboard-content">
                <div class="sidebar">
                    <ul>
                        <li><strong>Cases Registered</strong><div id="cases_raised"></div></li>
                        <li><strong>Cases  Resolved</strong><div id="cases_resolved"></div></li>
                        <li><strong>Cases  Pending </strong><div id="cases_pending"></div></li>
                        <li><strong>Cases  Added On <span>(<span id="prev_date"></span>)</span></strong><div id="cases_addedon" style="width: 100%; height: 90px;font-weight: bold;"></div></li>
                    </ul>
                </div>
            
                <div class="chart-sect">
                     <div class="content-row">
                        <div class="two-chart-block">
                              <h3>Case Status Report</h3>
                              <div id="chartContainer3" class="two-chart"></div>
                              <div id="chartContainer6" class="two-chart"></div>
                            </div>
                    </div>
                    <div class="content-row">
                    <div class="one-chart-block">
                            <h3>Case By Member Tier</h3>
                            <div id="chartContainer5" class="one-chart"></div>
                            </div>
                    <div class="one-chart-block">
                            <h3>Volume Of Cases By Category</h3>
                            <div id="chartContainer2" class="one-chart"></div>
                            </div>
                    </div>
                    <div class="content-row">
                        <div class="two-chart-block">
                            <h3>Cases Created By Period</h3>
                            <div id="chartContainer4" class="one-chart"></div>
                        </div>
                    </div>

                </div>
            </div>
            
   </div>
   </body>
</html>
  