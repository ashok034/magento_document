<?php

 class createConnection //create a class for make connection
{
   // var $host="nakumatt-qa-vm.cloudapp.net";
   // var $username="root";    // specify the sever details for mysql
   // Var $password="M@gent0";
   // var $database="sugarcrm";
   // var $db_server =  'localhost';

	var $host="localhost";
    var $username="root";    // specify the sever details for mysql
   var $password="";
    var $database="sugarcrm_05062017";//"nakumatt_sugarcrm_23122016";
   
	
    function connectToDatabase() // create a function for connect database
    {

        $db= mysql_connect($this->host,$this->username,$this->password,$this->database);
        
        if (mysqli_connect_errno()) {
            printf("connect failed : %s\n", mysqli_connect_errno());
        }
        else
        {
            $this->myconn = $db;
           // echo "Connection established";
        }
        return $this->myconn;
    }

    function selectDatabase() // selecting the database.
    {
       $this->connectToDatabase();
       $selectdb=  mysql_select_db($this->database);  //use php inbuild functions for select database

        if(mysql_error()) // if error occured display the error message
        {

            echo "Cannot find the database ".$this->database;

        }
        return $this->db=$selectdb;
        
    }

    function closeConnection() // close the connection
    {
        mysql_close($this->myconn);

        echo "Connection closed";
    }
    
   function query($sql){
       return mysql_query($sql);
   }
    function fetchByAssoc($result){
       return mysql_fetch_assoc($result);
   }
   
   //fetch the category from database and display here
   function getAllCategory(){
            $cat = array();$xdata='';
            $sql = "SELECT id,name FROM `naku_casecategory` where deleted=0 ";
            $result = mysql_query($sql);
            while($row = mysql_fetch_array($result)){
                $cat['id'] =$row['id'];
                $cat['name'] =$row['name'];
                $xdata[]=$cat;
            }
            return $xdata;
   }
   
}

?>

