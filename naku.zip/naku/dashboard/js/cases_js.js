$(document).ready(function() {
    
     $("#branch_store_name").prop("disabled",true);
            $('#branch_store_name').css('background-color', '#DEDEDE');
            $('#origin').change(function () { 
                if($('#origin').val() == 1){
                    $("#branch_store_name").prop("disabled",false);
                    $('#branch_store_name').css('background-color', '#ffffff');
                }else{
                    $('#branch_store_name').val('');
                    $("#branch_store_name").prop("disabled",true);
                    $('#branch_store_name').css('background-color', '#DEDEDE');
                }
            });
            
    $('#chartContainer').hide();
        $('#chartContainer1').hide();
        $('#chartContainer2').show();
        $('#chartContainer3').show();
        $('#chartContainer4').show();
        $('#chartContainer5').show();
        $('#chartContainer6').show();
         
        var from_date = $('#from_date').val();
        var to_date = $('#to_date').val(); 
        var member_tier_c = $('#member_tier_c').val(); 
        var origin = $('#origin').val();
        var category_id = $('#category_id').val();
        var status = $('#status').val();
        var priority = $('#priority').val();
        var branch_store_name = $('#branch_store_name').val();
        $.ajax({
            url: 'customer_service_data/ajax_pie.php',
            data: { from_date : from_date,to_date : to_date,member_tier_c : member_tier_c,origin : origin,
                     category_id : category_id,status : status,priority : priority,branch_store_name : branch_store_name,  },
            type: 'post',
            dataType: 'json',

            success: function(output) { 
                var chart = new CanvasJS.Chart("chartContainer2", {
                                //theme: "theme2",
                                title: {
                                        text: "Cases By Category",
										fontSize: 20,
                                },
                                legend: {
                                      //  fontSize: 15,
                                      //  verticalAlign: "center",
                                      //  horizontalAlign: "left",
                                      //  fontFamily: "Helvetica"  
                                },
                                animationEnabled: true,
                                      data:  [{
                                            type: "pie",
                                            showInLegend: true,
                                            indexLabelFontSize:10,
                                            indexLabelFontWeight: "bold",
                                            //toolTipContent: "{y} - #percent %",
                                            legendText: "{indexLabel}",
                                            dataPoints:output,
                                    }]
                        });
                chart.render();
            }
        });

         $.ajax({
            url: 'customer_service_data/ajax_bar.php',
             data: { from_date : from_date,to_date : to_date,member_tier_c : member_tier_c,origin : origin,
                             category_id : category_id,status : status,priority : priority,branch_store_name : branch_store_name,  },
            type: 'post',
            dataType: 'json',
            success: function(output) { 
            var chart = new CanvasJS.Chart("chartContainer3", {
                            //theme: "theme2",
                            title: {
                                    text: "Case Status",
										fontSize: 20,
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
                                        indexLabelFontSize:15,
                                        indexLabelFontWeight: "bold",
					dataPoints:output,
                            
				}]
                    });

                chart.render();
            }
        });
        //for origin and branch name
         $.ajax({
            url: 'customer_service_data/ajax_bar_origin.php',
             data: { from_date : from_date,to_date : to_date,member_tier_c : member_tier_c,origin : origin,
                             category_id : category_id,status : status,priority : priority,branch_store_name : branch_store_name,  },
            type: 'post',
            dataType: 'json',
            success: function(output) { 
            var chart = new CanvasJS.Chart("chartContainer6", {
                            //theme: "theme2",
                            title: {
                                    text: "Case Origin",
										fontSize: 20,
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
					dataPoints:output,
                            
				}]
                    });

                chart.render();
            }
        });
        
        $.ajax({
            url: 'customer_service_data/ajax_line.php',
             data: { from_date : from_date,to_date : to_date,member_tier_c : member_tier_c,origin : origin,
                             category_id : category_id,status : status,priority : priority,branch_store_name : branch_store_name,  },
            type: 'post',
            dataType: 'json',

            success: function(output) {
                var chart = new CanvasJS.Chart("chartContainer4", {
                                // theme: "theme2",
                                title: {
                                        text: "Cases By Period",
										fontSize: 20,
                                },
                                axisX:{
                                    labelFontSize: 10
                                },
                                      data:  [{
                                            type: "line",
                                            dataPoints:output,

                                    }]
                        });

                chart.render();
            }
        });
        $.ajax({
            url: 'customer_service_data/ajax_donut.php',
            data: { from_date : from_date,to_date : to_date,member_tier_c : member_tier_c,origin : origin,
                             category_id : category_id,status : status,priority : priority,branch_store_name : branch_store_name, },
            type: 'post',
            dataType: 'json',
            cache: false,
            success: function(output) {
                var chart = new CanvasJS.Chart("chartContainer5", {
                                title: {
                                        text: "Cases By Member Tier",
										fontSize: 20,
                                },
                                 legend: {
                                        fontSize: 12,
                                       // verticalAlign: "center",
                                        //horizontalAlign: "left",
                                        fontFamily: "Helvetica"  
                                },
                                animationEnabled: true,
                                //theme: "theme2",
                                    data: [
                                        {
                                            type: "doughnut",
                                            indexLabelFontFamily: "Garamond",
                                            showInLegend: true,
                                            legendText: "{indexLabel}",
                                            indexLabelFontSize: 12,
                                            indexLabelFontWeight: "bold",
                                            startAngle: 0,
                                            indexLabelFontColor: "dimgrey",
                                            indexLabelLineColor: "darkgrey",

                                            dataPoints: output,
                                        }
                                        ]
                        });
                chart.render();
            }
        });
        //Plain value : case raised, case resolved, cases pending and cases addedon
         $.ajax({
            url: 'customer_service_data/ajax_fetch_count.php',
            data: { from_date : from_date,to_date : to_date,member_tier_c : member_tier_c,origin : origin,
                             category_id : category_id,status : status,priority : priority,branch_store_name : branch_store_name, },
            type: 'post',
            dataType: 'json',
            cache: false,
            success: function(output) {
                    
                    var jsonstring = JSON.stringify(output);
                    var data = $.parseJSON(jsonstring);
                     if(data.flag !=0){
                        $(data).each(function(i,val){
                                total   =   val.total;
                                cases_resolved = val.cases_resolved;
                                cases_pending = val.cases_pending;
                                cases_addedon = val.cases_addedon;
                                previous_date = val.previous_date;
                                var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                                                    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
                                                  ];
                                var d = new Date(previous_date);
                                var day = d.getDate();
                                var month = monthNames[d.getMonth()];
                                var year = d.getFullYear();
                                var displayPreviousdate = day +' '+ month +',' + year;
                                $("#cases_raised").html(total);
                                $("#cases_resolved").html(cases_resolved);
                                $("#cases_pending").html(cases_pending);
                                $("#prev_date").html(displayPreviousdate);
                                $("#cases_addedon").html(cases_addedon);
                        });
                     }
                    
             }
           });
     $('#clear_filter').click(function () {
        $('#from_date').val('MM/DD/YYYY');
        $('#to_date').val('MM/DD/YYYY');
        $('#member_tier_c').val('');
        $('#origin').val('');
        $('#category_id').val('');
        $('#status').val('');
        $('#priority').val('');
        $('#branch_store_name').val('');
            
        $('#chartContainer').hide();
        $('#chartContainer1').hide();
        $('#chartContainer2').show();
        $('#chartContainer3').show();
        $('#chartContainer4').show();
        $('#chartContainer5').show();
        $('#chartContainer6').show(); 
      
        $('#branch_store_name').val('');
        $("#branch_store_name").prop("disabled",true);
        $('#branch_store_name').css('background-color', '#DEDEDE');
                    
          $.ajax({
            url: 'customer_service_data/ajax_pie.php',
            data: { from_date : from_date,to_date : to_date,member_tier_c : member_tier_c,origin : origin,
                     category_id : category_id,status : status,priority : priority,branch_store_name : branch_store_name,  },
            type: 'post',
            dataType: 'json',

            success: function(output) { 
                var chart = new CanvasJS.Chart("chartContainer2", {
                                //theme: "theme2",
                                title: {
                                        text: "Cases By Category",
										fontSize: 20,
                                },
                                legend: {
                                        //fontSize: 10,
                                       // verticalAlign: "center",
                                      //  horizontalAlign: "left",
                                        fontFamily: "Helvetica"  
                                },
                                animationEnabled: true,
                                      data:  [{
                                            type: "pie",
                                            showInLegend: true,
                                            indexLabelFontSize:10,
                                            indexLabelFontWeight: "bold",
                                            //toolTipContent: "{y} - #percent %",
                                            legendText: "{indexLabel}",
                                            dataPoints:output,
                                    }]
                        });
                chart.render();
            }
        });

         $.ajax({
            url: 'customer_service_data/ajax_bar.php',
             data: { from_date : from_date,to_date : to_date,member_tier_c : member_tier_c,origin : origin,
                             category_id : category_id,status : status,priority : priority,branch_store_name : branch_store_name,  },
            type: 'post',
            dataType: 'json',
            success: function(output) { 
            var chart = new CanvasJS.Chart("chartContainer3", {
                            //theme: "theme2",
                            title: {
                                    text: "Case Status",
									fontSize: 20,
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
                                        indexLabelFontSize:15,
                                        indexLabelFontWeight: "bold",
					dataPoints:output,
                            
				}]
                    });

                chart.render();
            }
        });
        //for origin and branch name
         $.ajax({
            url: 'customer_service_data/ajax_bar_origin.php',
             data: { from_date : from_date,to_date : to_date,member_tier_c : member_tier_c,origin : origin,
                             category_id : category_id,status : status,priority : priority,branch_store_name : branch_store_name,  },
            type: 'post',
            dataType: 'json',
            success: function(output) { 
            var chart = new CanvasJS.Chart("chartContainer6", {
                            //theme: "theme2",
                            title: {
                                    text: "Case Origin",
										fontSize: 20,
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
					dataPoints:output,
                            
				}]
                    });

                chart.render();
            }
        });
        
        $.ajax({
            url: 'customer_service_data/ajax_line.php',
             data: { from_date : from_date,to_date : to_date,member_tier_c : member_tier_c,origin : origin,
                             category_id : category_id,status : status,priority : priority,branch_store_name : branch_store_name,  },
            type: 'post',
            dataType: 'json',

            success: function(output) {
                var chart = new CanvasJS.Chart("chartContainer4", {
                                // theme: "theme2",
                                title: {
                                        text: "Cases By Period",
										fontSize: 20,
                                },
                                axisX:{
                                    labelFontSize: 10
                                },
                                      data:  [{
                                            type: "line",
                                            dataPoints:output,

                                    }]
                        });

                chart.render();
            }
        });
        $.ajax({
            url: 'customer_service_data/ajax_donut.php',
            data: { from_date : from_date,to_date : to_date,member_tier_c : member_tier_c,origin : origin,
                             category_id : category_id,status : status,priority : priority,branch_store_name : branch_store_name, },
            type: 'post',
            dataType: 'json',
            cache: false,
            success: function(output) {
                var chart = new CanvasJS.Chart("chartContainer5", {
                                title: {
                                        text: "Cases By Member Tier",
										fontSize: 20,
                                },
                                 legend: {
                                        fontSize: 12,
                                       // verticalAlign: "center",
                                       // horizontalAlign: "left",
                                        fontFamily: "Helvetica"  
                                },
                                animationEnabled: true,
                                //theme: "theme2",
                                    data: [
                                        {
                                            type: "doughnut",
                                            indexLabelFontFamily: "Garamond",
                                            showInLegend: true,
                                            legendText: "{indexLabel}",
                                            indexLabelFontSize: 12,
                                            indexLabelFontWeight: "bold",
                                            startAngle: 0,
                                            indexLabelFontColor: "dimgrey",
                                            indexLabelLineColor: "darkgrey",

                                            dataPoints: output,
                                        }
                                        ]
                        });
                chart.render();
            }
        });
        //Plain value : case raised, case resolved, cases pending and cases addedon
         $.ajax({
            url: 'customer_service_data/ajax_fetch_count.php',
            data: { from_date : from_date,to_date : to_date,member_tier_c : member_tier_c,origin : origin,
                             category_id : category_id,status : status,priority : priority,branch_store_name : branch_store_name, },
            type: 'post',
            dataType: 'json',
            cache: false,
            success: function(output) {
                    
                    var jsonstring = JSON.stringify(output);
                    var data = $.parseJSON(jsonstring);
                     if(data.flag !=0){
                        $(data).each(function(i,val){
                                total   =   val.total;
                                cases_resolved = val.cases_resolved;
                                cases_pending = val.cases_pending;
                                cases_addedon = val.cases_addedon;
                                previous_date = val.previous_date;
                                
                                var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                                                    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
                                                  ];
                                var d = new Date(previous_date);
                                var day = d.getDate();
                                var month = monthNames[d.getMonth()];
                                var year = d.getFullYear();
                                var displayPreviousdate = day +' '+ month +',' + year;
                                $("#cases_raised").html(total);
                                $("#cases_resolved").html(cases_resolved);
                                $("#cases_pending").html(cases_pending);
                                $("#prev_date").html(displayPreviousdate);
                                $("#cases_addedon").html(cases_addedon);
                        });
                     }
                    
             }
           });
           
     });
    $('#show_all_field').click(function () {
      
        $('#chartContainer').hide();
        $('#chartContainer1').hide();
        $('#chartContainer2').show();
        $('#chartContainer3').show();
        $('#chartContainer4').show();
        $('#chartContainer5').show();
        $('#chartContainer6').show();
 
        var from_date = $('#from_date').val();
        var to_date = $('#to_date').val(); 
        var member_tier_c = $('#member_tier_c').val(); 
        var origin = $('#origin').val();
        var category_id = $('#category_id').val();
        var status = $('#status').val();
        var priority = $('#priority').val();
         var branch_store_name = $('#branch_store_name').val();
           
          $.ajax({
            url: 'customer_service_data/ajax_pie.php',
            data: { from_date : from_date,to_date : to_date,member_tier_c : member_tier_c,origin : origin,
                     category_id : category_id,status : status,priority : priority,branch_store_name : branch_store_name,  },
            type: 'post',
            dataType: 'json',

            success: function(output) { 
                var chart = new CanvasJS.Chart("chartContainer2", {
                                //theme: "theme2",
                                title: {
                                         text: "Cases By Category",
										fontSize: 20,
                                },
                                legend: {
                                        //fontSize: 10,
                                        //verticalAlign: "center",
                                       // horizontalAlign: "left",
                                        fontFamily: "Helvetica"  
                                },
                                animationEnabled: true,
                                      data:  [{
                                            type: "pie",
                                            showInLegend: true,
                                            indexLabelFontSize:10,
                                            indexLabelFontWeight: "bold",
                                            //toolTipContent: "{y} - #percent %",
                                            legendText: "{indexLabel}",
                                            dataPoints:output,
                                    }]
                        });
                chart.render();
            }
        });

         $.ajax({
            url: 'customer_service_data/ajax_bar.php',
             data: { from_date : from_date,to_date : to_date,member_tier_c : member_tier_c,origin : origin,
                             category_id : category_id,status : status,priority : priority,branch_store_name : branch_store_name,  },
            type: 'post',
            dataType: 'json',
            success: function(output) { 
            var chart = new CanvasJS.Chart("chartContainer3", {
                            //theme: "theme2",
                            title: {
                                    text: "Case Status",
										fontSize: 20,
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
                                        indexLabelFontSize:15,
                                        indexLabelFontWeight: "bold",
					dataPoints:output,
                            
				}]
                    });

                chart.render();
            }
        });
        //for origin and branch name
         $.ajax({
            url: 'customer_service_data/ajax_bar_origin.php',
             data: { from_date : from_date,to_date : to_date,member_tier_c : member_tier_c,origin : origin,
                             category_id : category_id,status : status,priority : priority,branch_store_name : branch_store_name,  },
            type: 'post',
            dataType: 'json',
            success: function(output) { 
            var chart = new CanvasJS.Chart("chartContainer6", {
                            //theme: "theme2",
                            title: {
                                    text: "Case Origin",
										fontSize: 20,
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
					dataPoints:output,
                            
				}]
                    });

                chart.render();
            }
        });
        
        $.ajax({
            url: 'customer_service_data/ajax_line.php',
             data: { from_date : from_date,to_date : to_date,member_tier_c : member_tier_c,origin : origin,
                             category_id : category_id,status : status,priority : priority,branch_store_name : branch_store_name,  },
            type: 'post',
            dataType: 'json',

            success: function(output) {
                var chart = new CanvasJS.Chart("chartContainer4", {
                                // theme: "theme2",
                                title: {
                                        text: "Cases By Period",
										fontSize: 20,
                                },
                                axisX:{
                                    labelFontSize: 10
                                },
                                      data:  [{
                                            type: "line",
                                            dataPoints:output,

                                    }]
                        });

                chart.render();
            }
        });
        $.ajax({
            url: 'customer_service_data/ajax_donut.php',
            data: { from_date : from_date,to_date : to_date,member_tier_c : member_tier_c,origin : origin,
                             category_id : category_id,status : status,priority : priority,branch_store_name : branch_store_name, },
            type: 'post',
            dataType: 'json',
            cache: false,
            success: function(output) {
                var chart = new CanvasJS.Chart("chartContainer5", {
                                title: {
                                        text: "Cases By Member Tier",
										fontSize: 20,
                                },
                                 legend: {
                                        fontSize: 12,
                                       // verticalAlign: "center",
                                        //horizontalAlign: "left",
                                        fontFamily: "Helvetica"  
                                },
                                animationEnabled: true,
                                //theme: "theme2",
                                    data: [
                                        {
                                            type: "doughnut",
                                            indexLabelFontFamily: "Garamond",
                                            showInLegend: true,
                                            legendText: "{indexLabel}",
                                            indexLabelFontSize: 12,
                                            indexLabelFontWeight: "bold",
                                            startAngle: 0,
                                            indexLabelFontColor: "dimgrey",
                                            indexLabelLineColor: "darkgrey",

                                            dataPoints: output,
                                        }
                                        ]
                        });
                chart.render();
            }
        });
        //Plain value : case raised, case resolved, cases pending and cases addedon
         $.ajax({
            url: 'customer_service_data/ajax_fetch_count.php',
            data: { from_date : from_date,to_date : to_date,member_tier_c : member_tier_c,origin : origin,
                             category_id : category_id,status : status,priority : priority,branch_store_name : branch_store_name, },
            type: 'post',
            dataType: 'json',
            cache: false,
            success: function(output) {
                    
                    var jsonstring = JSON.stringify(output);
                    var data = $.parseJSON(jsonstring);
                     if(data.flag !=0){
                        $(data).each(function(i,val){
                                total   =   val.total;
                                cases_resolved = val.cases_resolved;
                                cases_pending = val.cases_pending;
                                cases_addedon = val.cases_addedon;
                                previous_date = val.previous_date;
                                
                                var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                                                    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
                                                  ];
                                var d = new Date(previous_date);
                                var day = d.getDate();
                                var month = monthNames[d.getMonth()];
                                var year = d.getFullYear();
                                var displayPreviousdate = day +' '+ month +',' + year;
                                $("#cases_raised").html(total);
                                $("#cases_resolved").html(cases_resolved);
                                $("#cases_pending").html(cases_pending);
                                $("#prev_date").html(displayPreviousdate);
                                $("#cases_addedon").html(cases_addedon);
                        });
                     }
                    
             }
           });
    });
});
        