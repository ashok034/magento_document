function create_chart(fdate='',todate='',camp_type='',camp_subtype='')
{
  
	 $.ajax({
			url: 'campaign_service_data/ajax_bar_social_media.php',
            data: { 
				from_date:fdate,
				to_date:todate
			},
            type: 'post',
            dataType: 'json',
            success: function(output) { 
            var chart = new CanvasJS.Chart("chartContainer_socialmedia", {
                            //theme: "theme2",
                            title: {
                                  //  text: "Social Media"
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
                                        indexLabelFontSize:15,
                                        indexLabelFontWeight: "bold",
					dataPoints: output,
                            
				}]
                    });

                chart.render();
            }
        });
		
		
		 $.ajax({
			url: 'campaign_service_data/ajax_bar_email.php',
            data: { 
				from_date:fdate,
				to_date:todate
			},
            type: 'post',
            dataType: 'json',
            success: function(output) { 
            var chart = new CanvasJS.Chart("chartContainer_email", {
                            //theme: "theme2",
                            title: {
                                  //  text: "Email"
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
                                        indexLabelFontSize:15,
                                        indexLabelFontWeight: "bold",
					dataPoints: output,
                            
				}]
                    });

                chart.render();
            }
        });
		
		 $.ajax({
			url: 'campaign_service_data/ajax_bar_sms.php',
            data: {
				from_date:fdate,
				to_date:todate
			},
            type: 'post',
            dataType: 'json',
            success: function(output) {
            var chart = new CanvasJS.Chart("chartContainer_sms", {
                            //theme: "theme2",
                            title: {
                                    //text: "SMS"
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
                                        indexLabelFontSize:15,
                                        indexLabelFontWeight: "bold",
					dataPoints: output,
                            
				}]
                    });

                chart.render();
            }
        });
		
		 $.ajax({
			url: 'campaign_service_data/ajax_bar_newspaper.php',
            data: { 
				from_date:fdate,
				to_date:todate
			},
            type: 'post',
            dataType: 'json',
            success: function(output) { 
            var chart = new CanvasJS.Chart("chartContainer_newspaper", {
                            //theme: "theme2",
                            title: {
                                   // text: "News Paper"
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
                                        indexLabelFontSize:15,
                                        indexLabelFontWeight: "bold",
					dataPoints: output,
                            
				}]
                    });

                chart.render();
            }
        });
		
		
		
		/*****************/
		
		
		$.ajax({
			url: 'campaign_service_data/ajax_bar_web.php',
            data: { 
				from_date:fdate,
				to_date:todate
			},
            type: 'post',
            dataType: 'json',
            success: function(output) { 
            var chart = new CanvasJS.Chart("chartContainer_web", {
                            //theme: "theme2",
                            title: {
                                    //text: "Website"
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
                                        indexLabelFontSize:15,
                                        indexLabelFontWeight: "bold",
					dataPoints: output,
                            
				}]
                    });

                chart.render();
            }
        });
		
		
		$.ajax({
			url: 'campaign_service_data/ajax_bar_store.php',
            data: { 
				from_date:fdate,
				to_date:todate
			},
            type: 'post',
            dataType: 'json',
            success: function(output) { 
            var chart = new CanvasJS.Chart("chartContainer_store", {
                            //theme: "theme2",
                            title: {
                                  //  text: "Store"
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
                                        indexLabelFontSize:15,
                                        indexLabelFontWeight: "bold",
					dataPoints: output,
                            
				}]
                    });

                chart.render();
            }
        });
		
		
		
		$.ajax({
			url: 'campaign_service_data/ajax_bar_tv.php',
            data: { 
				from_date:fdate,
				to_date:todate
			},
            type: 'post',
            dataType: 'json',
            success: function(output) { 
            var chart = new CanvasJS.Chart("chartContainer_tv", {
                            //theme: "theme2",
                            title: {
                                   // text: "TV"
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
                                        indexLabelFontSize:15,
                                        indexLabelFontWeight: "bold",
					dataPoints: output,
                            
				}]
                    });

                chart.render();
            }
        });
		
		$.ajax({
			url: 'campaign_service_data/ajax_bar_rad.php',
            data: { 
				from_date:fdate,
				to_date:todate
			},
            type: 'post',
            dataType: 'json',
            success: function(output) { 
            var chart = new CanvasJS.Chart("chartContainer_rad", {
                            //theme: "theme2",
                            title: {
                                   // text: "Radio"
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
                                        indexLabelFontSize:15,
                                        indexLabelFontWeight: "bold",
					dataPoints: output,
                            
				}]
                    });

                chart.render();
            }
        });
		
		$.ajax({
			url: 'campaign_service_data/ajax_bar_webevent.php',
            data: { 
				from_date:fdate,
				to_date:todate
			},
            type: 'post',
            dataType: 'json',
            success: function(output) { 
            var chart = new CanvasJS.Chart("chartContainer_webevent", {
                            //theme: "theme2",
                            title: {
                                   // text: "Website Event"
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
                                        indexLabelFontSize:15,
                                        indexLabelFontWeight: "bold",
					dataPoints: output,
                            
				}]
                    });

                chart.render();
            }
        });
		
		$.ajax({
			url: 'campaign_service_data/ajax_bar_till.php',
            data: { 
				from_date:fdate,
				to_date:todate
			},
            type: 'post',
            dataType: 'json',
            success: function(output) { 
            var chart = new CanvasJS.Chart("chartContainer_till", {
                            //theme: "theme2",
                            title: {
                                   // text: "Till Ads"
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
                                        indexLabelFontSize:15,
                                        indexLabelFontWeight: "bold",
					dataPoints: output,
                            
				}]
                    });

                chart.render();
            }
        });
		
		
		$.ajax({
			url: 'campaign_service_data/ajax_bar_pasys.php',
            data: { 
				from_date:fdate,
				to_date:todate
			},
            type: 'post',
            dataType: 'json',
            success: function(output) { 
            var chart = new CanvasJS.Chart("chartContainer_pasys", {
                            //theme: "theme2",
                            title: {
                                   // text: "PA Systems"
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
                                        indexLabelFontSize:15,
                                        indexLabelFontWeight: "bold",
					dataPoints: output,
                            
				}]
                    });

                chart.render();
            }
        });
		
		
		$.ajax({
			url: 'campaign_service_data/ajax_bar_digscr.php',
            data: { 
				from_date:fdate,
				to_date:todate
			},
            type: 'post',
            dataType: 'json',
            success: function(output) { 
            var chart = new CanvasJS.Chart("chartContainer_digscr", {
                            //theme: "theme2",
                            title: {
                                  // text: "Digital Screens"
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
                                        indexLabelFontSize:15,
                                        indexLabelFontWeight: "bold",
					dataPoints: output,
                            
				}]
                    });

                chart.render();
            }
        });
		
		$.ajax({
			url: 'campaign_service_data/ajax_bar_flyers.php',
            data: { 
				from_date:fdate,
				to_date:todate
			},
            type: 'post',
            dataType: 'json',
            success: function(output) { 
            var chart = new CanvasJS.Chart("chartContainer_flyers", {
                            //theme: "theme2",
                            title: {
                                   // text: "Flyers"
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
                                        indexLabelFontSize:15,
                                        indexLabelFontWeight: "bold",
					dataPoints: output,
                            
				}]
                    });

                chart.render();
            }
        });
		
		$.ajax({
			url: 'campaign_service_data/ajax_bar_instore.php',
            data: { 
				from_date:fdate,
				to_date:todate
			},
            type: 'post',
            dataType: 'json',
            success: function(output) { 
            var chart = new CanvasJS.Chart("chartContainer_instore", {
                            //theme: "theme2",
                            title: {
                                  //  text: "Instore Danglers"
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
                                        indexLabelFontSize:15,
                                        indexLabelFontWeight: "bold",
					dataPoints: output,
                            
				}]
                    });

                chart.render();
            }
        });
		
		$.ajax({
			url: 'campaign_service_data/ajax_bar_standers.php',
            data: { 
				from_date:fdate,
				to_date:todate
			},
            type: 'post',
            dataType: 'json',
            success: function(output) { 
            var chart = new CanvasJS.Chart("chartContainer_standers", {
                            //theme: "theme2",
                            title: {
                                  //  text: "Standers"
                            },
                            axisX:{
                                labelFontSize: 10
                            },
                                  data:  [{
					type: "column",
                                        indexLabelFontSize:15,
                                        indexLabelFontWeight: "bold",
					dataPoints: output,
                            
				}]
                    });

                chart.render();
            }
        });
		
		/*******************Marketing**/
		
		
		
		
		
		
		
		 $.ajax({
            url: 'campaign_service_data/ajax_bar_cost.php',
            data: { 
			
				from_date:fdate,
				to_date:todate,
				camp_type:camp_type,
				campaign_subtype:camp_subtype

			},
            type: 'post',
            dataType: 'json',

            success: function(output) { 
                var chart = new CanvasJS.Chart("chartContainer_cost", {
                                //theme: "theme2",
                                title: {
                                        text: ""
                                },
                                legend: {
                                        //fontSize: 15,
                                       // verticalAlign: "center",
                                       // horizontalAlign: "left",
                                       // fontFamily: "Helvetica"  
                                },
                                animationEnabled: true,
                                      data:  [{
                                            type: "pie",
                                            showInLegend: true,
                                            indexLabelFontSize:10,
                                            indexLabelFontWeight: "bold",
                                            //toolTipContent: "{y} - #percent %",
                                            legendText: "{indexLabel}",
                                            dataPoints:output,
                                    }]
                        });
                chart.render();
            }
        });
		
		$.ajax({
            url: 'campaign_service_data/ajax_bar_top_camp.php',
            data: { 
					
				from_date:fdate,
				to_date:todate,
				camp_type:camp_type,
				campaign_subtype:camp_subtype
		
			},
            type: 'post',
            dataType: 'json',

            success: function(output) { 
                var chart = new CanvasJS.Chart("chartContainer_top_camp", {
                                //theme: "theme2",
                                title: {
                                        text: ""
                                },
                                legend: {
                                        fontSize: 15,
                                        verticalAlign: "center",
                                        horizontalAlign: "left",
                                        fontFamily: "Helvetica"  
                                },
                                animationEnabled: true,
                                      data: [
										{
											type: "bar",

											dataPoints: output
										}
										]
                        });
                chart.render();
            }
        });
  
}
$(document).ready(function() {            
 
		create_chart();
		
		$('#show_all_field').click(function () {				
				var from_date = $('#from_date').val();
				var to_date = $('#to_date').val(); 
				var camp_type = $('#camp_type').val(); 
				var campaign_subtype = $('#campaign_subtype').val();
				
				create_chart(from_date,to_date,camp_type,campaign_subtype);
		});
		
		$('#clear_filter').click(function () {
			$('#from_date').val('MM/DD/YYYY');
			$('#to_date').val('MM/DD/YYYY'); 
			$('#camp_type').val(''); 
			//$('#campaign_subtype').val('');
			$('#campaign_subtype').html('<option value="">All</option>');
			create_chart();
		});
		
              
});
        