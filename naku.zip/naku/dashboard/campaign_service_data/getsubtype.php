<?php
include('../config.php');
$myconn = new createConnection();
$myconn->selectDatabase();

$query = "Select id,name from camp_subtype where deleted=0 AND type_id='".$_POST['cid']."' ";//and name not in('','')
$result = $myconn->query($query); 

$str="<option value=''>All</options>";
while ($row = $myconn->fetchByAssoc($result)) 
{
	$str.="<option value='".$row['id']."'>".$row['name']."</options>";
} 
echo $str;
exit;


?>
