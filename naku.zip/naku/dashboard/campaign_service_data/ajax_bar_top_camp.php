<?php
error_reporting(0);
include('../config.php');
$myconn = new createConnection();
$myconn->selectDatabase();
$limit = '';//limit 10';
$custom_bar = array();
$condition ='';
$condition_org ='';


/*if (!empty($_REQUEST['from_date']) && $_REQUEST['from_date'] !='MM/DD/YYYY' && !empty($_REQUEST['to_date']) && $_REQUEST['to_date'] !='MM/DD/YYYY')
{ 
	$condition .= "  AND DATE(camp_activity.start_date) BETWEEN '" . date("Y-m-d", strtotime($_REQUEST['from_date'])) . "' AND '" .date("Y-m-d", strtotime($_REQUEST['to_date']))."'";
}*/

if (!empty($_REQUEST['from_date']) && $_REQUEST['from_date'] !='MM/DD/YYYY')
{ 
	$condition .= "  AND DATE(camp_activity.start_date) >= '" . date("Y-m-d", strtotime($_REQUEST['from_date']))."'";
}

if (!empty($_REQUEST['to_date']) && $_REQUEST['to_date'] !='MM/DD/YYYY')
{ 
	$condition .= "  AND DATE(camp_activity.end_date) <= '" . date("Y-m-d", strtotime($_REQUEST['to_date']))."'";
}

if(!empty($_REQUEST['campaign_subtype']))
{
	$condition .= "  AND cmp_subtype_id = '" .$_REQUEST['campaign_subtype']."'";
}


$query = "Select name,cmp_id,cmp_subtype_id, SUM(response_rate_c) as response_rate, count(cmp_id) as camp from camp_activity where camp_activity.deleted=0 ".$condition." group by name order by response_rate DESC limit 0,5";


$result = $myconn->query($query); 

$data= array();
$xdata= array();
$xdata1= array();
$data_final['dataPoints']= array();

$count_estimated=0;
while ($row = $myconn->fetchByAssoc($result)) 
{	
	$xdata1[$row['name']]=$row['response_rate']/$row['camp'];
	
}
if(!empty($xdata1))
{
	 arsort($xdata1);
	 foreach(array_reverse($xdata1) as $xkey=>$xval)
	 {
		$data['y']=$xval;
		$data['label']=$xkey;
		$xdata[]=$data;
	 }
}
 

 $data_final['dataPoints']=$xdata;
 echo  json_encode($data_final['dataPoints']);


?>
