<?php
include('../config.php');
$myconn = new createConnection();
$myconn->selectDatabase();
$limit = '';//limit 10';
$custom_bar = array();
$condition ='';
$condition_org ='';

/*if (!empty($_REQUEST['from_date']) && $_REQUEST['from_date'] !='MM/DD/YYYY' && !empty($_REQUEST['to_date']) && $_REQUEST['to_date'] !='MM/DD/YYYY')
{ 
	$condition .= "  AND DATE(campaigns.start_date) BETWEEN '" . date("Y-m-d", strtotime($_REQUEST['from_date'])) . "' AND '" .date("Y-m-d", strtotime($_REQUEST['to_date']))."'";
}*/	

if (!empty($_REQUEST['from_date']) && $_REQUEST['from_date'] !='MM/DD/YYYY')
{ 
	$condition .= "  AND DATE(campaigns.start_date) >= '" . date("Y-m-d", strtotime($_REQUEST['from_date']))."'";
}

if (!empty($_REQUEST['to_date']) && $_REQUEST['to_date'] !='MM/DD/YYYY')
{ 
	$condition .= "  AND DATE(campaigns.end_date) <= '" . date("Y-m-d", strtotime($_REQUEST['to_date']))."'";
}




$query = "Select 
count(campaigns.id) as total,campaigns.status
from campaigns 
left join camp_activity on camp_activity.cmp_id=campaigns.id
where campaigns.status IN ('Pending Approval','Approved','Active','Inactive','Completed') AND campaigns.deleted=0 AND camp_activity.name='Social Media' " .$condition." GROUP BY campaigns.status";


$result = $myconn->query($query); 

$data= array();
$xdata= array();
$data_final['dataPoints']= array();

$status_value = array("Pending Approval","Approved","Active","Inactive","Completed");


while ($row = $myconn->fetchByAssoc($result)) {
    $data['y']=$row['total'];
    $data['label']=$row['status'];
   $xdata[]=$data;
} 
foreach($status_value as $status) {
  
   $key = array_search($status, array_column($xdata, 'label'));
   if($key === FALSE){
       $data = array();
        $data['y'] = 0;
        $data['label'] = $status;
        $xdata[] = $data;
    }

}
 $data_final['dataPoints']=$xdata;
 echo  json_encode($data_final['dataPoints'],JSON_NUMERIC_CHECK);


?>
