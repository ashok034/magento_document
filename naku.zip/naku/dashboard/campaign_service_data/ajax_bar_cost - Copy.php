<?php
error_reporting(0);
include('../config.php');
$myconn = new createConnection();
$myconn->selectDatabase();
$limit = '';//limit 10';
$custom_bar = array();
$condition ='';
$condition_org ='';
$condition_date ='';
/*if (!empty($_REQUEST['from_date']) && $_REQUEST['from_date'] !='mm/dd/yyyy' && !empty($_REQUEST['to_date']) && $_REQUEST['to_date'] !='mm/dd/yyyy')
{ 
	$condition .= "  AND DATE(campaigns.start_date) BETWEEN '" . date("Y-m-d", strtotime($_REQUEST['from_date'])) . "' AND '" .date("Y-m-d", strtotime($_REQUEST['to_date']))."'";
}*/

//echo "**********";echo "<pre>";print_r($_REQUEST);
if (!empty($_REQUEST['from_date']) && $_REQUEST['from_date'] !='MM/DD/YYYY')
{ 
	$condition .= "  AND DATE(camp.start_date) >= '" . date("Y-m-d", strtotime($_REQUEST['from_date']))."'";
	$condition_date .= "  AND DATE(camp.start_date) >= '" . date("Y-m-d", strtotime($_REQUEST['from_date']))."'";
}

if (!empty($_REQUEST['to_date']) && $_REQUEST['to_date'] !='MM/DD/YYYY')
{ 
	$condition .= "  AND DATE(camp.end_date) <= '" . date("Y-m-d", strtotime($_REQUEST['to_date']))."'";
	$condition_date .= "  AND DATE(camp.end_date) <= '" . date("Y-m-d", strtotime($_REQUEST['to_date']))."'";
}
$isSpecificCampSubType = 0;
if(!empty($_REQUEST['campaign_subtype']))
{
	 $isSpecificCampSubType = 1;
	$condition .= "  AND campaign_subtype LIKE '%" .$_REQUEST['campaign_subtype']."%'";
	$postedCampSubtypeID = $_REQUEST['campaign_subtype'];
}

$isSpecificCampType = 0;
if(!empty($_REQUEST['camp_type']))
{
	 $isSpecificCampType = 1;
	$condition .= "  AND campaign_type LIKE '%" .$_REQUEST['camp_type']."%'";
	$postedCampTypeID = $_REQUEST['camp_type'];
	
	
}
 
 //$sdate = $_REQUEST['from_date'];
//$edate = $_REQUEST['to_date'];

 //Check is specific campaign subtype selected or "All" subtypes data required
    /*    $isSpecificCampSubType = 0;
        if (!empty($postedCampSubtypeID) && $postedCampSubtypeID != 'all' ) {
            $isSpecificCampSubType = 1;
        }

        //Check is specific CAMPAIGN TYPE selected or "All" CAMPAIGN TYPE data required
        $isSpecificCampType = 0;
        if (!empty($postedCampTypeID) && $postedCampTypeID != 'all' ) {
            $isSpecificCampType = 1;
        }
		
		$query = "Select GROUP_CONCAT(camp.id), 
                GROUP_CONCAT(DISTINCT activity.cmp_id) as activity_ids,
                GROUP_CONCAT(DISTINCT csubtype.name) as csubtype_name, 
                SUM(DISTINCTROW camp.budget) as campaign_total_budget, 
                SUM(
                    IF(activity.activity_cost_type = 'percentage', 
                        (camp.budget*activity.activity_cost)/100, 
                        activity.activity_cost
                    ) 
                ) as camp_type_budget,
                GROUP_CONCAT(DISTINCT ctype.name) as ctype,
                SUM( " .
                    (($isSpecificCampSubType == 1) ? " IF(activity.cmp_subtype_id like '%" . $postedCampSubtypeID ."%' ," : "" ).
                        (($isSpecificCampType == 1) ? " IF (ctype.id = '" . $postedCampTypeID . "', " : "" ).
                            " IF(activity.activity_cost_type = 'percentage', (camp.budget * activity.activity_cost)/100, activity.activity_cost)" .
                        (($isSpecificCampType == 1) ? " , 0) " : "" ).
                    (($isSpecificCampSubType == 1) ? ", 0)" : "" ).
                ") as activity_spend 
                , camp.start_date 
                from campaigns camp 
                LEFT JOIN camp_activity activity on camp.id = activity.cmp_id 
                LEFT JOIN camp_subtype csubtype on activity.cmp_subtype_id = csubtype.id 
                LEFT JOIN camp_type ctype on csubtype.type_id = ctype.id 
                WHERE camp.campaign_subtype LIKE CONCAT('%',activity.cmp_subtype_id, '%')  AND
                 camp.deleted = 0 
                AND camp.budget IS NOT NULL" .
                (($isSpecificCampType == 1) ? " AND ctype.id = '".trim($postedCampTypeID)."'" : "" ).
                 $condition; 
				 
				 
				 //GROUP_CONCAT(camp.id), 
                GROUP_CONCAT(DISTINCT activity.cmp_id) as activity_ids,
                GROUP_CONCAT(DISTINCT csubtype.name) as csubtype_name, 
		*/
	//$query = "Select * from campaigns where campaigns.deleted=0 " .$condition."";
	
 
 echo $query = "Select 
                SUM(DISTINCTROW camp.budget) as campaign_total_budget, camp.id as campID,activity.cmp_id as activityCampID,camp.budget as campBudget,activity.name as activityName,
                SUM(
                    IF(activity.activity_cost_type = 'percentage', 
                        (camp.budget*activity.activity_cost)/100, 
                        activity.activity_cost
                    ) 
                ) as camp_type_budget,
                GROUP_CONCAT(DISTINCT ctype.name) as ctype,
                SUM( " .
                    (($isSpecificCampSubType == 1) ? " IF(activity.cmp_subtype_id like '%" . $postedCampSubtypeID ."%' ," : "" ).
                        (($isSpecificCampType == 1) ? " IF (ctype.id = '" . $postedCampTypeID . "', " : "" ).
                            " IF(activity.activity_cost_type = 'percentage', (camp.budget * activity.activity_cost)/100, activity.activity_cost)" .
                        (($isSpecificCampType == 1) ? " , 0) " : "" ).
                    (($isSpecificCampSubType == 1) ? ", 0)" : "" ).
                ") as activity_spend 
                from campaigns camp 
                JOIN camp_activity activity on camp.id = activity.cmp_id 
                JOIN camp_subtype csubtype on activity.cmp_subtype_id = csubtype.id 
                JOIN camp_type ctype on csubtype.type_id = ctype.id 
                WHERE 
                 camp.deleted = 0 
                AND camp.budget IS NOT NULL" . $condition; 
				
	die;		

$result = $myconn->query($query); 

$data= array();
$xdata= array();
$data_final['dataPoints']= array();

while ($row = $myconn->fetchByAssoc($result)) 
{

//echo "<pre>";print_r($row);
	$data['y']=$row['campBudget'];
    $data['label']=$row['activityName'];
    $xdata[]=$data;
}


$cat_value_BTL = array(1=>"SMS", 2=>"Instore Danglers", 3=>"Flyers", 4=>"Tablet",5=>"Standers",6=>"PA Systems",7=>"Till Ads",8=>"Email",9=>"Social Media",6=>"Digital Screens",10=>"Mobile");
$cat_value_ATL = array(1=>"TV", 2=>"Newspaper Ad", 3=>"Website", 4=>"Radio",5=>"Store",6=>"Website Event");

if($_REQUEST['camp_type'] ==''){
	$cat_value = array_merge($cat_value_BTL,$cat_value_ATL);
}elseif(!empty($_REQUEST['camp_type'])){
	if($_REQUEST['camp_type'] == 'b553a77b-bfcb-e6ba-e236-58e372044c27'){
		$cat_value = array(1=>"SMS", 2=>"Instore Danglers", 3=>"Flyers", 4=>"Tablet",5=>"Standers",6=>"PA Systems",7=>"Till Ads",8=>"Email",9=>"Social Media",6=>"Digital Screens",10=>"Mobile");
	}if($_REQUEST['camp_type'] == 'c5ff1feb-a4cf-3189-7ff0-58e370a70086'){
		$cat_value = array(1=>"TV", 2=>"Newspaper Ad", 3=>"Website", 4=>"Radio",5=>"Store",6=>"Website Event");
	}else{
		$cat_value = array_merge($cat_value_BTL,$cat_value_ATL);

	}
		
}
echo "<pre>";print_r($cat_value);
foreach($cat_value as $k->$cat) {
	$key = array_search($cat, array_column($xdata, 'indexLabel'));
	if($key === FALSE){
		$data = array();
		 $data['y'] = $data['y'];
		 $data['indexLabel'] = $cat;
		 $xdata[] = $data;
	 }
}

		
/*
$count_estimated=0;
while ($row = $myconn->fetchByAssoc($result)) 
{	
	$count_estimated+=$row['budget'];
	$query_camp_act="Select id,name,cmp_id,activity_cost,activity_cost_type,cmp_subtype_id from camp_activity where camp_activity.cmp_id='".$row['id']."'";
	$result_camp_act = $myconn->query($query_camp_act); 	
	while($row_camp_act = $myconn->fetchByAssoc($result_camp_act))
	{
		$row_camp_act['total_budget']=$row['budget'];
		if($row_camp_act['activity_cost_type'] == 'percentage')
		{
			$row_camp_act['activity_cost']=($row_camp_act['total_budget']*$row_camp_act['activity_cost'])/100;
		}
		$arr_camp[$row['id']][]=$row_camp_act;		
	}
	
	//$data['y']=$row['total'];
   // $data['label']=$row['status'];
   //$xdata[]=$data;
}*/

/*
if(!empty($arr_camp))
{
	$sumArray = array();
	foreach($arr_camp as $a_c=>$a_val)
	{
		foreach($a_val as $a_cost)
		{
			$sumArray[$a_cost['name']]+=$a_cost['activity_cost'];
		}
		
	}
}
echo "<pre>";print_r($sumArray);
echo "<br />************";
$final_sum_array=array();
if(!empty($sumArray))
{
	foreach($sumArray as $name=>$value)
	{
		$final_sum_array[$name]=($value*100)/$count_estimated;
	}
}
*/
/*
echo "<pre>";print_r($final_sum_array);

if(!empty($final_sum_array))
{
	foreach($final_sum_array as $final_key=>$final_val)
	{
			$data['y'] = $final_val;
			$data['indexLabel'] = $final_key;
			$xdata[] = $data;
	}
}*/
 $data_final['dataPoints']=$xdata;
 echo  json_encode($data_final['dataPoints'],JSON_NUMERIC_CHECK);


?>
