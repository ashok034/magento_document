<?php
	error_reporting(0);
	include('../config.php');
	$myconn = new createConnection();
	$myconn->selectDatabase();
	$limit = '';//limit 10';
	$custom_bar = array();
	$condition ='';
	$condition_org ='';
	$condition_ind ='';
	$condition_date ='';
	if (!empty($_REQUEST['from_date']) && $_REQUEST['from_date'] !='MM/DD/YYYY')
	{ 
		$condition .= "  AND DATE(campaigns.start_date) >= '" . date("Y-m-d", strtotime($_REQUEST['from_date']))."'";
	}

	if (!empty($_REQUEST['to_date']) && $_REQUEST['to_date'] !='MM/DD/YYYY')
	{ 
		$condition .= "  AND DATE(campaigns.end_date) <= '" . date("Y-m-d", strtotime($_REQUEST['to_date']))."'";
	}
	
	
	$isSpecificCampSubType = 0;
	if(!empty($_REQUEST['campaign_subtype']))
	{
		$isSpecificCampSubType = 1;
		$condition .= "  AND campaigns.campaign_subtype LIKE '%" .$_REQUEST['campaign_subtype']."%'";
		$postedCampSubtypeID = $_REQUEST['campaign_subtype'];
		$condition_ind .= "  AND activity.cmp_subtype_id LIKE '%" .$_REQUEST['campaign_subtype']."%'";
	}else{
	
		$condition .= " ";
	}

	$isSpecificCampType = 0;
	if(!empty($_REQUEST['camp_type']))
	{
		$isSpecificCampType = 1;
		$condition .= "  AND campaigns.campaign_type LIKE '%" .$_REQUEST['camp_type']."%'";
		$postedCampTypeID = $_REQUEST['camp_type'];
		$condition_ind .= "  AND ctype.id LIKE '%" .$_REQUEST['camp_type']."%'";
	}

	//Check is specific campaign subtype selected or "All" subtypes data required
	$isSpecificCampSubType = 0;
	if (!empty($postedCampSubtypeID) && $postedCampSubtypeID != 'all' ) {
		$isSpecificCampSubType = 1;
	}

	//Check is specific CAMPAIGN TYPE selected or "All" CAMPAIGN TYPE data required
	$isSpecificCampType = 0;
	if (!empty($postedCampTypeID) && $postedCampTypeID != 'all' ) {
		$isSpecificCampType = 1;
	}

	$query = " Select 
				GROUP_CONCAT(campaigns.id), 
                GROUP_CONCAT(DISTINCT activity.cmp_id) as activity_ids,
                GROUP_CONCAT(DISTINCT csubtype.name) as csubtype_name, 
                SUM(DISTINCTROW campaigns.budget) as campaign_total_budget, 
						activity.name as name,
						activity.id as camp_act_id, 
						campaigns.id, 
						
						IF(activity.activity_cost_type = 'percentage', 
								(campaigns.budget*activity.activity_cost)/100, 
								activity.activity_cost
							) 
						 as activity_cost ,
						 sum(IF(activity.activity_cost_type = 'percentage', 
								(campaigns.budget*activity.activity_cost)/100, 
								activity.activity_cost
							) )
						 as my_total_activity_cost ,
						 
						
						ROUND( (sum(IF(activity.activity_cost_type = 'percentage', 
								(campaigns.budget*activity.activity_cost)/100, 
								activity.activity_cost
							) )/(SELECT 
						SUM( IF(activity.activity_cost_type = 'percentage', 
								(campaigns.budget*activity.activity_cost)/100, 
								activity.activity_cost
							) 
						) as budget  FROM campaigns campaigns JOIN camp_activity activity on campaigns.id = activity.cmp_id JOIN camp_subtype csubtype on activity.cmp_subtype_id = csubtype.id JOIN camp_type ctype on csubtype.type_id = ctype.id  where campaigns.deleted=0  " .$condition." ". $condition_ind."))*100,1) as percentage
						
						
						from campaigns campaigns JOIN camp_activity activity on campaigns.id = activity.cmp_id JOIN camp_subtype csubtype on activity.cmp_subtype_id = csubtype.id JOIN camp_type ctype on csubtype.type_id = ctype.id  where campaigns.deleted=0  " .$condition." ". $condition_ind." GROUP BY activity.name ";

			
	$result = $myconn->query($query); 

	$data= array();
	$xdata= array();
	$data_final['dataPoints']= array();

	$count_estimated=0;
	while ($row = $myconn->fetchByAssoc($result)) 
	{	
		$data['y'] = $row['percentage'];
		$data['indexLabel'] = $row['name'];
		$xdata[] = $data;
	
	}
	
	$data_final['dataPoints']=$xdata;
	echo  json_encode($data_final['dataPoints'],JSON_NUMERIC_CHECK);


	?>
