<?php
include('config.php');
$myconn = new createConnection();
$myconn->selectDatabase();
    

 function getAllCategory(){
       global $db;
            $cat = array();$xdata='';
            $sql = "SELECT id,name FROM `camp_type` where deleted=0 ";
            $result = mysql_query($sql);
            $num=mysql_num_rows($result);
            if(0==$num) {
                echo "No record";
                exit;
            }

                while($row = mysql_fetch_assoc($result)){
                    $cat['id'] =$row['id'];
                    $cat['name'] =$row['name'];
                    $xdata[]=$cat;
                }
            
            return $xdata;
   }
    $category = getAllCategory();
	
?>
<!DOCTYPE HTML>
<html>
   <head>
       <meta charset="utf-8">
	<meta name="viewport" content="initial-scale = 1.0,maximum-scale = 1.0" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Campaign Dashboard</title>
	<link href="css/dashboard1.css" rel="stylesheet">
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <script type="text/javascript" src ="js/campaign_js.js"></script>
        <script src="js/canvasjs.min.js"></script>

        <script>
          $(document).ready(function() {
            $("#from_date").datepicker();
            $("#to_date").datepicker();
   
			
          }); 
		  function getsubcategory(cid)
		  {
			 $.ajax({ 
				url: 'campaign_service_data/getsubtype.php',
				data: { cid : cid },
				type: 'post',
				success: function(output) {
					$('#campaign_subtype').html(output);
				}
			});
		  }
		  
		  
        </script>
   </head>
   
   <body>
        <div class="dashboard-container"> <h2>Campaign Dashboard</h2>
            <form id="dashboard_search_form" name="dashboard_search_form" class="search_form" action="" method="post">
                <input type="hidden" name="query" value="true">
                         <div class="filter-sect">
                                <div class="col-timeRange">
                                    <label>Time Range</label>
                                    <div class="fld-Wrap">
                                        <input class="date_input" type="text" name="from_date" id="from_date" value="MM/DD/YYYY"  readonly="readonly">
                                        <input class="date_input" type="text" name="to_date" id="to_date" value="MM/DD/YYYY"  readonly="readonly">
                                    </div>
                                </div>
                                 <div class="col-singleFld-md">
                                    <label>Campaign Type</label>
                                    <div class="fld-Wrap">
                                        <select name="camp_type" id="camp_type" onchange="getsubcategory(this.value)">
                                            <option value="">All</option>
                                            <?php if(!empty($category)) { 
												foreach($category as $cat)
												{
											?>
												<option value="<?php echo $cat['id']; ?>"><?php echo $cat['name']; ?></option>
                                            <?php 
												}
											} ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-singleFld-md">
                                    <label>Campaign Sub-type</label>
                                    <div class="fld-Wrap">
                                        <select name="campaign_subtype" id="campaign_subtype">
                                              <option value="">All</option>
                                        </select>
                                    </div>
                                </div>                         
                                <div class="flterBtn-Campaign-wrap">
                                    <!--button id="show_all_field" >Apply Filters</button>
                                    <button id="clear_filter" >Reset</button-->
                                     <input type="button" id="show_all_field" value="Apply Filters">
                                     <input type="button" id="clear_filter" value="Reset">
                                </div>
                         </div>    

            </form>
            <div class="dashboard-content">
                         
						
						 
                <div class="chart-sect-fullWidth">
					<div class="non-marketing">
						<div class="content-row">
							<div class="two-clm-chart-block">
								<h3>Top Campaign By Response (Top 5)</h3>
								<div id="chartContainer_top_camp" class="one-chart"></div>
							 </div>
							<div class="two-clm-chart-block">
								<h3>Campaign Cost Analysis</h3>
								<div id="chartContainer_cost" class="one-chart"></div>
							</div>
						</div>
					</div>
					<div class="marketng">
						<div class="marketng_default">
							<div class="content-row">
								<div class="two-clm-chart-block">
									<h3>Marketing Calendar - Social Media</h3>
									<div id="chartContainer_socialmedia" class="one-chart"></div>
								 </div>
								<div class="two-clm-chart-block">
									<h3>Marketing Calendar - Newspaper</h3>
									<div id="chartContainer_newspaper" class="one-chart"></div>
								</div>
							</div>
							
							<div class="content-row">
								<div class="two-clm-chart-block">
									<h3>Marketing Calendar - Email</h3>
									<div id="chartContainer_email" class="one-chart"></div>
								 </div>
								<div class="two-clm-chart-block">
									<h3>Marketing Calendar - SMS</h3>
									<div id="chartContainer_sms" class="one-chart"></div>
								</div>
							</div>
							<div class="content-row">
								<div class="two-clm-chart-block">
									<h3>Marketing Calendar - Website</h3>
									<div id="chartContainer_web" class="one-chart"></div>
								 </div>
								<div class="two-clm-chart-block">
									<h3>Marketing Calendar - Store</h3>
									<div id="chartContainer_store" class="one-chart"></div>
								</div>
							</div>
							<div class="content-row">
								<div class="two-clm-chart-block">
									<h3>Marketing Calendar - Radio</h3>
									<div id="chartContainer_rad" class="one-chart"></div>
								 </div>
								<div class="two-clm-chart-block">
									<h3>Marketing Calendar - Tv</h3>
									<div id="chartContainer_tv" class="one-chart"></div>
								</div>
							</div>
							<div class="content-row">
								<div class="two-clm-chart-block">
									<h3>Marketing Calendar - Website Event</h3>
									<div id="chartContainer_webevent" class="one-chart"></div>
								 </div>
								<div class="two-clm-chart-block">
									<h3>Marketing Calendar - Till Ads</h3>
									<div id="chartContainer_till" class="one-chart"></div>
								</div>
							</div>
							<div class="content-row">
								<div class="two-clm-chart-block">
									<h3>Marketing Calendar - PA Systems</h3>
									<div id="chartContainer_pasys" class="one-chart"></div>
								 </div>
								<div class="two-clm-chart-block">
									<h3>Marketing Calendar - Digital Screens</h3>
									<div id="chartContainer_digscr" class="one-chart"></div>
								</div>
							</div>
							<div class="content-row">
								<div class="two-clm-chart-block">
									<h3>Marketing Calendar - Flyers</h3>
									<div id="chartContainer_flyers" class="one-chart"></div>
								 </div>
								<div class="two-clm-chart-block">
									<h3>Marketing Calendar - Instore Danglers</h3>
									<div id="chartContainer_instore" class="one-chart"></div>
								</div>
							</div>
							
							<div class="content-row">
								 <div class="two-clm-chart-block">
									 <h3>Marketing Calendar - Standers</h3>
										<div id="chartContainer_standers" class="one-chart"></div>
								 </div>
								
							</div>
						
						</div>
						<!--div class="marketng_search">
						
							<div class="content-row">
								 <div class="two-clm-chart-block">
									 <h3>Marketing Calendar - Standers</h3>
										<div id="chartContainer_standers" class="one-chart">hhhhhhhhh</div>
								 </div>
								
							</div>
							
						</div>100951082247 -->
					</div>
					
					

                </div>
            </div>
            
   </div>
   </body>
</html>
  