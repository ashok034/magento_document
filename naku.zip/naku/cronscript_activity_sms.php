<?php
 
if (!defined('sugarEntry'))
    define('sugarEntry', true);
require_once("include/entryPoint.php");
include('cronscripts/config.php');
global $sugar_config;
$fp = fopen('php://input', 'r');
$rawData = stream_get_contents($fp);
$obj = json_decode($rawData);
$campId = $obj->campId;
//Database connection MagentoCRM
$con_mk = new createConnection($sugar_config['mk_server_name'], $sugar_config['mk_username'], $sugar_config['mk_password'], $sugar_config['mk_db_name']);
$con_mk->selectDatabase();

// fetch all marketing list detal
$sql_marketing_name = "SELECT segment_id,name FROM `magento_customersegment_segment`";
$result_mk = $con_mk->query($sql_marketing_name);
$arr_mk = array();
while ($row_mk = $con_mk->fetchByAssoc($result_mk)) {
    $arr_mk[$row_mk['segment_id']] = $row_mk['name'];
}
//print_r($arr_mk);
// fetch all marketing list users
$sql_cus_seg = "SELECT * FROM `magento_customersegment_customer`";
$result_cus_seg = $con_mk->query($sql_cus_seg);
$arr_cug_seg = array();
while ($row_cus_seg = $con_mk->fetchByAssoc($result_cus_seg)) {
    $arr_cug_seg[] = $row_cus_seg;
}
//print_r($arr_cug_seg);
//code added by akhilesh 10-07-2017
$camp_prom_coup_name = array();
$sql_prom_coup_name = "SELECT row_id, name, auto_coupon_code FROM " . $sugar_config['crm_salesrule'] . " WHERE is_active = 1";
$result_prom_coup = $con_mk->query($sql_prom_coup_name);
while ($row_prom_coup_name = $con_mk->fetchByAssoc($result_prom_coup)) {
    $camp_prom_coup_name[$row_prom_coup_name['row_id']] = $row_prom_coup_name;
}
//End code added by akhilesh 10-07-2017

$con_mk->closeConnection();

$con = new createConnection($sugar_config['dbconfig']['db_host_name'], $sugar_config['dbconfig']['db_user_name'], $sugar_config['dbconfig']['db_password'], $sugar_config['dbconfig']['db_name']); //nakumattvm.cloudapp.net
$con->selectDatabase();

// fetch all promotions comment by akhilesh 10-07-2017
/* $sql_prom_name = "SELECT id,name,promotion_id FROM `naku_promotions` where deleted=0";
  $result_prom = $con->query($sql_prom_name);
  $arr_prom_name = array();
  while ($row_prom = $con->fetchByAssoc($result_prom)) {
  $arr_prom_name[$row_prom['id']] = $row_prom;
  }

  // fetch all coupons
  $sql_coupon_name = "SELECT id,name,start_date,end_date,coupon_id,coupon_validity FROM `naku_coupons` where deleted=0";
  $result_coupon = $con->query($sql_coupon_name);
  $arr_coupon = array();
  while ($row_coupon = $con->fetchByAssoc($result_coupon)) {
  $arr_coupon[$row_coupon['id']] = $row_coupon;
  } */

// fetch all email templates
$sql_email_temp = "SELECT id,description,name FROM `email_templates` WHERE deleted=0";
$result_email_temp = $con->query($sql_email_temp);
$arr_email_temp = array();
while ($row_email_temp = $con->fetchByAssoc($result_email_temp)) {
    $arr_email_temp[$row_email_temp['id']] = $row_email_temp;
}

//echo '<pre><br/>';print_r($arr_email_temp);
//Repalce $campIDs = SELECT id FROM campaigns WHERE DATE(date_modified) = CURDATE() AND status = 'Active' AND deleted=0 added by akhilesh 10-07-2017
$sql = "SELECT camp_activity.id as ca_id, camp_activity.name as ca_name, camp_activity.cmp_id as ca_cmp_id, 
camp_activity.cmp_subtype_id as ca_cmp_subtype_id, camp_activity.marketing_list_id as ca_marketing_list_id, 
camp_activity.coupon_id_c as ca_coupon_id_c, camp_activity.promotion_id_c as ca_promotion_id_c, camp_activity.template_id_c as ca_template_id_c

FROM campaigns 
LEFT JOIN camp_activity on camp_activity.cmp_id=campaigns.id

WHERE campaigns.deleted=0 AND campaigns.status='Approved' AND camp_activity.name='SMS' AND campaigns.id IN('".$campId."')";

$result = $con->query($sql);
$campaign_data = array();
$customer = array();
while ($row = $con->fetchByAssoc($result)) {
    $cmp_activity = array();

    // fetch campaign  activity
    $cmp_activity['id'] = $row['ca_id'];
    $cmp_activity['name'] = $row['ca_name'];
    $cmp_activity['marketing_list_id'] = $row['ca_marketing_list_id'];
    if (!empty($cmp_activity['marketing_list_id'])) {
        if (array_key_exists($cmp_activity['marketing_list_id'], $arr_mk)) {
            $cmp_activity['marketing_list_name'] = $arr_mk[$cmp_activity['marketing_list_id']];
        }

        if (!empty($arr_cug_seg)) {
            foreach ($arr_cug_seg as $a_c_s) {
                if ($a_c_s['segment_id'] == $cmp_activity['marketing_list_id']) {
                    $camp_customer_data[] = $a_c_s;
                }
            }
            $cus_ids['customer_id'] = $camp_customer_data;
        }
    }
    //start fetch templates
    $cmp_activity['template_id'] = $row['ca_template_id_c'];
    if (!empty($cmp_activity['template_id'])) {
        if (array_key_exists($cmp_activity['template_id'], $arr_email_temp)) {
            $cmp_activity['template'] = $arr_email_temp[$cmp_activity['template_id']];
        }
    }
    //echo'<pre>templates array='; print_r($cmp_activity['template']);
    //end fetch templates
    //start fetch promotion and coupons
    $cmp_activity['promotion_id_c'] = $row['ca_promotion_id_c'];
    if (!empty($cmp_activity['promotion_id_c'])) {

        $promotion = explode(',', $cmp_activity['promotion_id_c']);
        $p_data = array();
        foreach ($promotion as $p) {
            if (array_key_exists($p, $camp_prom_coup_name)) { //replace $arr_prom_name TO $camp_prom_coup_name by akhilesh 10-07-2017
                $p_data[] = $camp_prom_coup_name[$p]; //replace $arr_prom_name TO $camp_prom_coup_name by akhilesh 10-07-2017
            }
        }
        $promotions['promotion_name'] = $p_data;
    }

    //Comment by akhilesh 10-07-2017
    /* $cmp_activity['coupon_id_c'] = $row['ca_coupon_id_c'];
      if (!empty($cmp_activity['coupon_id_c'])) {

      $coupon = explode(',', $cmp_activity['coupon_id_c']);
      $c_data = array();
      foreach ($coupon as $c) {
      if (array_key_exists($c, $arr_coupon)) {
      $c_data[] = $arr_coupon[$c];
      }
      }
      $coupons['coupon_name'] = $c_data;
      } */

    if (!empty($promotions['promotion_name'])) {
        $coupon_cnt = 0;
        $prom_coupon_detail = '';
        foreach ($promotions['promotion_name'] as $p_name) {
            //Comment and add new line by akhilesh 10-07-2017
            //$prom_coupon_detail.='<br>Promotion - ' . $p_name['name'] . ' Coupon - ' . $coupons['coupon_name'][$coupon_cnt]['name'];
            if(!empty($p_name['auto_coupon_code'])){
			$prom_coupon_detail.='Promotion - ' . $p_name['name'] . ' & Coupon - ' . $p_name['auto_coupon_code']. ', ';
			} else{
			$prom_coupon_detail.='Promotion - ' . $p_name['name'] . ', ';
			}
            $coupon_cnt++;
        }
    }
    $cmp_activity['prom_coupon_details'] = $prom_coupon_detail;
    //end fetch promotion and coupons

    if (!empty($cus_ids['customer_id'])) {

        $camp_customer_detail = array();
        $arr_contacts = array();
        foreach ($cus_ids['customer_id'] as $a_c) {
            $sql_contacts = "SELECT customer_id,first_name,last_name,phone_mobile,birthdate,campaign_id,email,member_tier,loyalty_id,member_type FROM `contacts` where customer_id=" . $a_c['customer_id'];

            $result_contacts = $con->query($sql_contacts);

            while ($row_contacts = $con->fetchByAssoc($result_contacts)) {
                if (!empty($row_contacts['customer_id'])) {
                    //$cmp_activity['template']['body']=str_replace("{{prom_coupon}}",$cmp_activity['prom_coupon_details'],$cmp_activity['template']['body']);
                    //$cmp_activity['template']['body']=str_replace("{{first_name}}",$row_contacts['first_name'],$cmp_activity['template']['body']);
                    $template_body_prom_coupon = str_replace("{{prom_coupon}}", $cmp_activity['prom_coupon_details'], $cmp_activity['template']['description']);  //Chnaged by akhilesh 10-07-2017
                    $template_fname = str_replace("{{first_name}}", $row_contacts['first_name'], $template_body_prom_coupon);   //Changed by akhilesh 10-07-2017
                    $row_contacts['template_name'] = $cmp_activity['template']['name'];
                    $row_contacts['template'] = $template_fname;
                    $arr_contacts[$row_contacts['customer_id']] = $row_contacts;
                }
            }
        }
        $cmp_activity['customer_detail'] = $arr_contacts;
    }

    if (!empty($cmp_activity['customer_detail'])) {
        $customers = array();
        foreach ($cmp_activity['customer_detail'] as $k => $customer_details) {

            if (array_key_exists($k, $customer)) {
                $customer[$k]['promotions_ids'][] = $cmp_activity['promotion_id_c'];
                $customer[$k]['marketing_list_id_c'][] = $cmp_activity['marketing_list_id'];
                //$customer[$k]['link_coupon_code'][] = $cmp_activity['coupon_id_c'];   //Comment by akhilesh 10-07-2017
                $customer[$k]['template'].=$customer_details['template'];
            } else {
                $customer_details['marketing_list_id_c'][] = $cmp_activity['marketing_list_id'];
                $customer_details['promotions_ids'][] = $cmp_activity['promotion_id_c'];
                //$customer_details['link_coupon_code'][] = $cmp_activity['coupon_id_c'];  //Comment by akhilesh 10-07-2017
                $customer[$customer_details['customer_id']] = $customer_details;
            }
        }
    }

    ///echo '<pre>'; print_r($cmp_activity);
}

//echo '<pre>final array=';
//print_r($customer);
//exit;
//start send sms functionality
if (!empty($customer)) {
    $messages = array();
    foreach ($customer as $cust_details) {

        if (!empty($cust_details['template'])) {
			$num = 254;
			$cust_details['phone_mobile'] = $num.(int)$cust_details['phone_mobile'];
            $messages[] = array("sender" => 'Nakumatt', "phone" => array($cust_details['phone_mobile']), "text" => $cust_details['template']);
        }
    }

    $smsArray = array("messages" => $messages);
    $smsJson = json_encode($smsArray);
    $url = "http://192.168.0.128:8100/sms/sendBulk";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $smsJson);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3000);

    $data = curl_exec($ch);
    //fwrite($fp, $data);
    if (curl_errno($ch))
        print curl_error($ch);
    else
        curl_close($ch);
    //curl_close($ch);
    //$array_data = simplexml_load_string($data);
    echo '<pre>Responce=' . $data;
    print_r(json_decode($data));
}
//end send sms functionality
?>